(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/lib/tags/data:c55f88 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchAllTags",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40daec315fd65d825c8a346303dd020af4fcd41b35":"fetchAllTags"},"app/lib/tags/tags-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40daec315fd65d825c8a346303dd020af4fcd41b35", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "fetchAllTags");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vdGFncy1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRhZ3MgYWN0aW9uc1xyXG5cclxuXCJ1c2Ugc2VydmVyXCI7XHJcblxyXG5pbXBvcnQgcG9vbCBmcm9tIFwiQC9kYlwiO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQWxsVGFncyh0ZW5hbnRfaWQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nW10+IHtcclxuICB0cnkge1xyXG4gICAgLy8g0JLQsNGA0LjQsNC90YIg0LHQtdC3INGD0YfQtdGC0LAgdGVuYW50X2lmICjQtNC70Y8g0L7RgtC70LDQtNC60LgpXHJcbiAgICAvLyAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PHsgbmFtZTogc3RyaW5nIH0+KFxyXG4gICAgLy8gICAgIGBcclxuICAgIC8vICAgICBTRUxFQ1QgbmFtZVxyXG4gICAgLy8gICAgIEZST00gdGFnc1xyXG4gICAgLy8gICAgIE9SREVSIEJZIG5hbWUgQVNDXHJcbiAgICAvLyAgIGBcclxuICAgIC8vICAgKTtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PHsgbmFtZTogc3RyaW5nIH0+KFxyXG4gICAgICBgXHJcbiAgICAgIFNFTEVDVCBuYW1lXHJcbiAgICAgIEZST00gdGFnc1xyXG4gICAgICBXSEVSRSB0ZW5hbnRfaWQgPSAkMVxyXG4gICAgICBPUkRFUiBCWSBuYW1lIEFTQ1xyXG4gICAgYCxcclxuICAgICAgW3RlbmFudF9pZF1cclxuICAgICk7XHJcbiAgICBjb25zdCB0YWdzID0gZGF0YS5yb3dzLm1hcCgocm93KSA9PiByb3cubmFtZSk7IC8vIOKGkCDQuNC30LLQu9C10LrQsNC10Lwg0YLQvtC70YzQutC+INGB0YLRgNC+0LrQuFxyXG4gICAgcmV0dXJuIHRhZ3M7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgRXJyb3I6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggYWxsIHRhZ3M6IFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cHNlcnRUYWdzKFxyXG4gIHRhZ05hbWVzOiBzdHJpbmdbXSxcclxuICB0ZW5hbnRfaWQ6IHN0cmluZ1xyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuaWYgKCF0YWdOYW1lcyB8fCB0YWdOYW1lcy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYFxyXG4gICAgICBJTlNFUlQgSU5UTyB0YWdzIChuYW1lLCB0ZW5hbnRfaWQpXHJcbiAgICAgIFNFTEVDVCB1bm5lc3QoJDE6OnRleHRbXSksICQyXHJcbiAgICAgIE9OIENPTkZMSUNUIChuYW1lLCB0ZW5hbnRfaWQpIERPIE5PVEhJTkdcclxuICAgICAgYCxcclxuICAgICAgW3RhZ05hbWVzLCB0ZW5hbnRfaWRdXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHVwc2VydCB0YWdzOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gdXBzZXJ0IHRhZ3MuXCIpO1xyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjZSQU1zQix5TEFBQSJ9
}),
"[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "setIsCancelButtonPressed",
    ()=>setIsCancelButtonPressed,
    "setIsDocumentChanged",
    ()=>setIsDocumentChanged,
    "setIsMessageBoxOpen",
    ()=>setIsMessageBoxOpen,
    "setIsOKButtonPressed",
    ()=>setIsOKButtonPressed,
    "setIsShowMessageBoxCancel",
    ()=>setIsShowMessageBoxCancel,
    "setMessageBoxText",
    ()=>setMessageBoxText,
    "useDocumentStore",
    ()=>useDocumentStore,
    "useIsDocumentChanged",
    ()=>useIsDocumentChanged,
    "useMessageBox",
    ()=>useMessageBox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const initialState = {
    messageBox: {
        isMessageBoxOpen: false,
        messageBoxText: "",
        isOKButtonPressed: false,
        isCancelButtonPressed: false,
        isShowMessageBoxCancel: false
    },
    isDocumentChanged: false,
    allTags: [],
    documentTenantId: "",
    sessionUser: {},
    userSections: []
};
const messageBoxStore = (set)=>({
        ...initialState,
        setIsMessageBoxOpen: (isMessageBoxOpen)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        isMessageBoxOpen
                    }
                }), false, "setIsMessageBoxOpen"),
        setMessageBoxText: (messageBoxText)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        messageBoxText
                    }
                }), false, "setMessageBoxText"),
        setIsOKButtonPressed: (isOKButtonPressed)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        isOKButtonPressed
                    }
                }), false, "setIsOKButtonPressed"),
        setIsCancelButtonPressed: (isCancelButtonPressed)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        isCancelButtonPressed
                    }
                }), false, "setIsCancelButtonPressed"),
        setIsShowMessageBoxCancel: (isShowMessageBoxCancel)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        isShowMessageBoxCancel
                    }
                }), false, "setIsShowMessageBoxCancel"),
        setIsDocumentChanged: (isDocumentChanged)=>{
            set({
                isDocumentChanged: isDocumentChanged
            }, false, "setIsDocumentChanged");
        },
        setAllTags: (tags)=>{
            if (tags) set({
                allTags: tags
            }), "setAllTags";
        },
        // addAllTags: (newTags) => set((state) => ({ allTags: [...state.allTags, ...newTags] }), false, "addAllTags"),
        addAllTags: (newTags)=>{
            if (newTags) {
                set((state)=>({
                        allTags: Array.from(new Set([
                            ...state.allTags,
                            ...newTags
                        ])).sort((a, b)=>a.localeCompare(b, undefined, {
                                sensitivity: "base"
                            }))
                    }), false, "addAllTags");
            }
        },
        setDocumentTenantId: (docTenantId)=>{
            set({
                documentTenantId: docTenantId
            }, false, "setDocumentTenantId");
        },
        setSessionUser: (user)=>{
            set({
                sessionUser: user
            }, false, "setSessionUser");
        },
        setUserSections: (sections)=>{
            set({
                userSections: sections
            }, false, "setUserSections");
        }
    });
const useDocumentStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["immer"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devtools"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])(messageBoxStore, {
    name: "messagebox-storage",
    storage: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createJSONStorage"])(()=>localStorage),
    partialize: (state)=>({
            messageBox: state.messageBox,
            isDocumentChanged: state.isDocumentChanged,
            allTags: state.allTags,
            documentTenantId: state.documentTenantId,
            sessionUser: state.sessionUser,
            userSections: state.userSections
        })
}), {
    name: "Document"
})));
const useMessageBox = ()=>{
    _s();
    return useDocumentStore({
        "useMessageBox.useDocumentStore": (state)=>state.messageBox
    }["useMessageBox.useDocumentStore"]);
};
_s(useMessageBox, "YBOcV9vipWfdFGkpNROIlwHjiag=", false, function() {
    return [
        useDocumentStore
    ];
});
const useIsDocumentChanged = ()=>{
    _s1();
    return useDocumentStore({
        "useIsDocumentChanged.useDocumentStore": (state)=>state.isDocumentChanged
    }["useIsDocumentChanged.useDocumentStore"]);
};
_s1(useIsDocumentChanged, "YBOcV9vipWfdFGkpNROIlwHjiag=", false, function() {
    return [
        useDocumentStore
    ];
});
const setIsMessageBoxOpen = (isMessageBoxOpen)=>useDocumentStore.getState().setIsMessageBoxOpen(isMessageBoxOpen);
const setMessageBoxText = (messageBoxText)=>useDocumentStore.getState().setMessageBoxText(messageBoxText);
const setIsOKButtonPressed = (isOKButtonPressed)=>useDocumentStore.getState().setIsOKButtonPressed(isOKButtonPressed);
const setIsCancelButtonPressed = (isCancelButtonPressed)=>useDocumentStore.getState().setIsCancelButtonPressed(isCancelButtonPressed);
const setIsShowMessageBoxCancel = (isShowMessageBoxCancel)=>useDocumentStore.getState().setIsShowMessageBoxCancel(isShowMessageBoxCancel);
const setIsDocumentChanged = (isDocumentChanged)=>useDocumentStore.getState().setIsDocumentChanged(isDocumentChanged);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/doc-wrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DocWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$c55f88__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/lib/tags/data:c55f88 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function DocWrapper(props) {
    _s();
    const docTenantId = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().documentTenantId;
    // const isDocumentChanged = useIsDocumentChanged();
    const msgBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"])();
    //#region sessionUser & userSections
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            const initializeStoreUser = {
                "DocWrapper.useEffect.initializeStoreUser": ()=>{
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().sessionUser.id !== props.pageUser.id) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setSessionUser(props.pageUser);
                    }
                }
            }["DocWrapper.useEffect.initializeStoreUser"];
            initializeStoreUser();
        }
    }["DocWrapper.useEffect"], [
        props.pageUser
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            const initializeStoreUserSections = {
                "DocWrapper.useEffect.initializeStoreUserSections": ()=>{
                    if (props.userSections) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setUserSections(props.userSections);
                    }
                }
            }["DocWrapper.useEffect.initializeStoreUserSections"];
            initializeStoreUserSections();
        }
    }["DocWrapper.useEffect"], [
        props.userSections
    ]);
    //#endregion
    //#region tenant_id and tags  
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            const fetchAndSetTags = {
                "DocWrapper.useEffect.fetchAndSetTags": async ()=>{
                    try {
                        const tags = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$c55f88__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["fetchAllTags"])(props.docTenantId);
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setAllTags(tags);
                    } catch (error) {
                        console.error('Failed to fetch all tags: ', error);
                    }
                }
            }["DocWrapper.useEffect.fetchAndSetTags"];
            if (props.docTenantId) {
                __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setDocumentTenantId(props.docTenantId);
                fetchAndSetTags();
            }
        }
    }["DocWrapper.useEffect"], [
        props.docTenantId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            const fetchAndSetTags = {
                "DocWrapper.useEffect.fetchAndSetTags": async ()=>{
                    try {
                        const tags = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$c55f88__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["fetchAllTags"])(docTenantId);
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setAllTags(tags);
                    } catch (error) {
                        console.error('Failed to fetch all tags: ', error);
                    }
                }
            }["DocWrapper.useEffect.fetchAndSetTags"];
            if (docTenantId) fetchAndSetTags();
        }
    }["DocWrapper.useEffect"], [
        docTenantId
    ]);
    //#endregion
    //#region msgBox
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            return ({
                "DocWrapper.useEffect": ()=>{
                    // Сброс при уходе со страницы
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(false);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(false);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(false);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(true);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('');
                }
            })["DocWrapper.useEffect"];
        }
    }["DocWrapper.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            if (msgBox.isOKButtonPressed && msgBox.messageBoxText === 'Документ изменен. Закрыть без сохранения?') {
                // router.push('/erp/premises/');
                window.history.back();
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(true);
        }
    }["DocWrapper.useEffect"], [
        msgBox.isOKButtonPressed
    ]);
    //#endregion
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: props.children
    }, void 0, false);
}
_s(DocWrapper, "Y4761O/iB5XZYunqLW+hOJxOZSM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"]
    ];
});
_c = DocWrapper;
var _c;
__turbopack_context__.k.register(_c, "DocWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/ui/ref-search.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RefSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/use-debounce/dist/index.module.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function RefSearch({ callback, term, elementIdPrefix }) {
    _s();
    const handleSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedCallback"])({
        "RefSearch.useDebouncedCallback[handleSearch]": (term)=>{
            callback(term);
        }
    }["RefSearch.useDebouncedCallback[handleSearch]"], 100);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative flex flex-1 flex-shrink-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: elementIdPrefix + 'search',
                className: "sr-only",
                children: "Search"
            }, void 0, false, {
                fileName: "[project]/app/ui/ref-search.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                id: elementIdPrefix + 'search',
                className: "peer block w-full h-10 rounded-md border border-gray-300 group-focus-within:border-blue-500   py-[9px] pl-10 text-sm placeholder:text-gray-500",
                placeholder: "найти ...",
                onChange: (e)=>{
                    handleSearch(e.target.value);
                },
                onFocus: (e)=>e.target.style.borderColor = '#3b82f6',
                onBlur: (e)=>e.target.style.borderColor = '#d2d6dc',
                value: term
            }, void 0, false, {
                fileName: "[project]/app/ui/ref-search.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__["MagnifyingGlassIcon"], {
                className: "absolute left-3 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-gray-500 peer-focus:text-gray-900"
            }, void 0, false, {
                fileName: "[project]/app/ui/ref-search.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/ui/ref-search.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_s(RefSearch, "HFdfYUdpR2RsesUyL2Qu9GdfQic=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedCallback"]
    ];
});
_c = RefSearch;
var _c;
__turbopack_context__.k.register(_c, "RefSearch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/sections/lib/sections-ref-table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SectionsRefTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/ui/ref-search.tsx [app-client] (ecmascript)");
;
;
function SectionsRefTable(props) {
    const handleSearch = (input)=>{
        props.setTerm(input);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Выберите раздел:"
            }, void 0, false, {
                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                lineNumber: 23,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                callback: handleSearch,
                term: props.term,
                elementIdPrefix: ""
            }, void 0, false, {
                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                lineNumber: 24,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0 flow-root",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto md:block hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "inline-block min-w-full align-middle",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-hidden rounded-md bg-gray-50 p-1 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            className: "rounded-md bg-gray-50 text-left text-sm font-normal",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 overflow-hidden px-0 py-5 font-medium sm:pl-6",
                                                        children: "Название"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                        lineNumber: 33,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 px-3 py-5 font-medium",
                                                        children: "Организация"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                        lineNumber: 36,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                lineNumber: 32,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                            lineNumber: 31,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                        lineNumber: 30,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                    lineNumber: 29,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            className: "divide-y divide-gray-200 text-gray-900",
                                            children: props.sections.filter((section)=>section.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap text-ellipsis bg-white py-1 pl-0 text-left     pr-3 text-sm text-black group-first-of-type:rounded-md group-last-of-type:rounded-md sm:pl-6",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-left gap-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    onClick: (e)=>{
                                                                        props.handleSelectSection(section.id, section.name, section.tenant_id, section.tenant_name);
                                                                        props.setTerm("");
                                                                        props.closeModal();
                                                                    },
                                                                    // href={"#"}
                                                                    className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                                    children: section.name.substring(0, 36)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                                    lineNumber: 57,
                                                                    columnNumber: 53
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                                lineNumber: 56,
                                                                columnNumber: 49
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                            lineNumber: 54,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                            children: section.tenant_name
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                            lineNumber: 68,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, section.id, true, {
                                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                    lineNumber: 53,
                                                    columnNumber: 41
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                            lineNumber: 46,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                        lineNumber: 45,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                    lineNumber: 44,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                            lineNumber: 28,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                        lineNumber: 27,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "block md:hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2",
                            children: props.sections.filter((section)=>section.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-gray-200 bg-white p-4 text-sm text-gray-900 last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium text-black",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                onClick: (e)=>{
                                                    props.handleSelectSection(section.id, section.name, section.tenant_id, section.tenant_name);
                                                    props.setTerm("");
                                                    props.closeModal();
                                                },
                                                className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                children: section.name.substring(0, 36)
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                lineNumber: 92,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                            lineNumber: 91,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500",
                                            children: section.tenant_name
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                            lineNumber: 103,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, section.id, true, {
                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                    lineNumber: 87,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                            lineNumber: 80,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                        lineNumber: 79,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                lineNumber: 25,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
        lineNumber: 22,
        columnNumber: 9
    }, this);
}
_c = SectionsRefTable;
var _c;
__turbopack_context__.k.register(_c, "SectionsRefTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/sections/lib/btn-sections-ref.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BtnSectionsRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import Modal from "@/app/lib/modal";
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BookOpenIcon.js [app-client] (ecmascript) <export default as BookOpenIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$sections$2f$lib$2f$sections$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/sections/lib/sections-ref-table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = Modal;
function BtnSectionsRef(props) {
    _s();
    const sections = props.sections ? props.sections : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().userSections;
    const [modal, setModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openModal = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setModal(true);
    };
    const closeModal = ()=>{
        setModal(false);
    };
    const [term, setTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: openModal,
                className: "rounded-md border border-gray-200 p-2 h-10 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__["BookOpenIcon"], {
                    className: "w-5 h-5 text-gray-800"
                }, void 0, false, {
                    fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Modal, {
                open: modal,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$sections$2f$lib$2f$sections$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sections: sections,
                        handleSelectSection: props.handleSelectSection,
                        closeModal: closeModal,
                        setTerm: setTerm,
                        term: term
                    }, void 0, false, {
                        fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between space-x-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    alert("действие!");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                                lineNumber: 55,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: closeModal,
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Exit"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
} // export default BtnRefLegalEntity;
_s(BtnSectionsRef, "MW/KQDlZppFu/nDnRAs8d7ejpwM=");
_c1 = BtnSectionsRef;
var _c, _c1;
__turbopack_context__.k.register(_c, "Modal");
__turbopack_context__.k.register(_c1, "BtnSectionsRef");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/message-box-ok-cancel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import { setIsCancelButtonPressed, setIsMessageBoxOpen, setIsOKButtonPressed, useIsMessageBoxOpen, useIsShowMessageBoxCancel, useMessageBoxText } from "@/app/store/useMessageBoxStore";
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
const MessageBoxOKCancel = ()=>{
    _s();
    // const isMessageBoxOpen = useIsMessageBoxOpen();
    // const messageBoxText = useMessageBoxText();
    // const isShowMessageBoxCancel = useIsShowMessageBoxCancel();
    const msgBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"])();
    if (!msgBox.isMessageBoxOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "message-box",
        className: "fixed inset-0 flex items-center justify-center z-50",
        style: {
            backgroundColor: 'rgba(0, 0, 0, 0.3)'
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white p-6 rounded-lg shadow-lg max-w-md w-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-lg mb-4 whitespace-pre-line",
                    children: String(msgBox.messageBoxText)
                }, void 0, false, {
                    fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end space-x-3",
                    children: [
                        msgBox.isShowMessageBoxCancel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>{
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(false);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(true);
                            },
                            className: "px-4 py-2 bg-gray-300 rounded-md hover:bg-gray-400 focus:outline-none",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
                            lineNumber: 18,
                            columnNumber: 45
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>{
                                if (msgBox.messageBoxText === 'Документ сохранен.') {
                                    // Просто закрываем, НЕ устанавливая isOKButtonPressed
                                    // setIsMessageBoxOpen(false);
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('');
                                } else {
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(true);
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(false);
                                }
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
                            },
                            className: "px-4 py-2 bg-red-300 text-white rounded-md hover:bg-red-700 focus:outline-none",
                            children: "OK"
                        }, void 0, false, {
                            fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
            lineNumber: 15,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(MessageBoxOKCancel, "ioouC6guqMTbpgyYuZWcuoqNjg4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"]
    ];
});
_c = MessageBoxOKCancel;
const __TURBOPACK__default__export__ = MessageBoxOKCancel;
var _c;
__turbopack_context__.k.register(_c, "MessageBoxOKCancel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/input-field.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const InputField = ({ label, name, value, w, type, onChange, refBook, readonly, errors, textArea, placeholder })=>{
    const labelClassName = `${w[0]} text-sm text-blue-900 font-medium flex items-center p-2`;
    // const inputClassName = `${w[1]} ${moreInputClassName} control rounded-md border border-gray-200 p-2`;
    // `${inputClassName} break-words`
    const inputClassName = `${w[1]} disabled:text-gray-400 disabled:bg-gray-100 break-words control rounded-md border border-gray-200 p-2`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between mt-1",
                children: [
                    label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: name,
                        className: labelClassName,
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/app/lib/input-field.tsx",
                        lineNumber: 40,
                        columnNumber: 27
                    }, ("TURBOPACK compile-time value", void 0)),
                    !textArea && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        id: name,
                        type: type,
                        name: name,
                        className: inputClassName,
                        disabled: readonly,
                        value: value,
                        placeholder: placeholder,
                        onChange: type !== "date" ? (e)=>onChange(e.target.value) : (e)=>onChange(new Date(e.target.value))
                    }, void 0, false, {
                        fileName: "[project]/app/lib/input-field.tsx",
                        lineNumber: 46,
                        columnNumber: 31
                    }, ("TURBOPACK compile-time value", void 0)),
                    textArea && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        id: name,
                        // type={type}
                        name: name,
                        // className={inputClassName}
                        disabled: readonly,
                        value: value,
                        onChange: type !== "date" ? (e)=>onChange(e.target.value) : (e)=>onChange(new Date(e.target.value)),
                        className: "w-full break-words rounded-md border border-gray-200 p-2"
                    }, void 0, false, {
                        fileName: "[project]/app/lib/input-field.tsx",
                        lineNumber: 58,
                        columnNumber: 30
                    }, ("TURBOPACK compile-time value", void 0)),
                    !readonly && refBook
                ]
            }, void 0, true, {
                fileName: "[project]/app/lib/input-field.tsx",
                lineNumber: 39,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: `${name}-error`,
                "aria-live": "polite",
                "aria-atomic": "true",
                children: errors && errors.map((error, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-xs text-red-500",
                        children: error
                    }, index, false, {
                        fileName: "[project]/app/lib/input-field.tsx",
                        lineNumber: 76,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/app/lib/input-field.tsx",
                lineNumber: 73,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/lib/input-field.tsx",
        lineNumber: 37,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = InputField;
const __TURBOPACK__default__export__ = InputField;
var _c;
__turbopack_context__.k.register(_c, "InputField");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/cars/lib/data:09f8e3 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createCar",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40ded52aeb48c0955e23ff841b8fa61ea19e87dc5f":"createCar"},"app/erp/cars/lib/cars-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40ded52aeb48c0955e23ff841b8fa61ea19e87dc5f", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createCar");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vY2Fycy1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIENhcnMgYWN0aW9uc1xyXG5cclxuXCJ1c2Ugc2VydmVyXCI7XHJcblxyXG4vLyBpbXBvcnQgeyB6IH0gZnJvbSBcInpvZFwiO1xyXG5pbXBvcnQgcG9vbCBmcm9tIFwiQC9kYlwiO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gXCJuZXh0L2NhY2hlXCI7XHJcbi8vIGltcG9ydCB7IHJlZGlyZWN0IH0gZnJvbSBcIm5leHQvbmF2aWdhdGlvblwiO1xyXG5pbXBvcnQgeyBhdXRoIH0gZnJvbSBcIkAvYXV0aFwiO1xyXG5pbXBvcnQgeyBDYXJGb3JtLCBDYXIgfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcblxyXG5jb25zdCBJVEVNU19QRVJfUEFHRSA9IDg7XHJcblxyXG4vLyNyZWdpb24gQ3JlYXRlIFRhc2tcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVDYXIoY2FyOiBDYXIpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYXV0aCgpO1xyXG4gIGNvbnN0IHVzZXJuYW1lID0gc2Vzc2lvbj8udXNlcj8ubmFtZTtcclxuICBjb25zdCBkYXRlX2NyZWF0ZWQgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcbiAgY29uc3Qge1xyXG4gICAgbmFtZSxcclxuICAgIG1vZGVsLFxyXG4gICAgZ29zX251bWJlcixcclxuICAgIG1ha2UsXHJcbiAgICB2aW4sXHJcbiAgICB5ZWFyLFxyXG4gICAgY3VzdG9tZXJfaWQsXHJcbiAgICBjYXJfc3RhdHVzLFxyXG4gICAgdW5pdF9pZCxcclxuICAgIGxvY2F0aW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHRlbmFudF9pZCxcclxuICAgIGF1dGhvcl9pZCxcclxuICB9ID0gY2FyO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIElOU0VSVCBJTlRPIGNhcnMgKFxyXG4gICAgICAgIG5hbWUsIG1vZGVsLCBnb3NfbnVtYmVyLCBtYWtlLCB2aW4sIHllYXIsIGN1c3RvbWVyX2lkLFxyXG4gICAgICAgIGNhcl9zdGF0dXMsIHVuaXRfaWQsIGxvY2F0aW9uX2lkLFxyXG4gICAgICAgIHVzZXJuYW1lLCBzZWN0aW9uX2lkLCB0aW1lc3RhbXB0eixcclxuICAgICAgICB0ZW5hbnRfaWQsIGF1dGhvcl9pZFxyXG4gICAgICApIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1LCAkNiwgJDcsICQ4LCAkOSwgJDEwLCAkMTEsICQxMiwgJDEzLCAkMTQsICQxNSlcclxuICAgIGAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIG1vZGVsLFxyXG4gICAgICAgIGdvc19udW1iZXIsXHJcbiAgICAgICAgbWFrZSxcclxuICAgICAgICB2aW4sXHJcbiAgICAgICAgeWVhcixcclxuICAgICAgICBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLFxyXG4gICAgICAgIHVuaXRfaWQsXHJcbiAgICAgICAgbG9jYXRpb25faWQsXHJcbiAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICBkYXRlX2NyZWF0ZWQsXHJcbiAgICAgICAgdGVuYW50X2lkLFxyXG4gICAgICAgIGF1dGhvcl9pZCxcclxuICAgICAgXSxcclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIGNhcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0LfQtNCw0YLRjCBjYXI6XCIgKyBTdHJpbmcoZXJyb3IpKTtcclxuICB9XHJcblxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL3JlcGFpci9jYXJzXCIpO1xyXG59XHJcblxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBVcGRhdGUvRGVsZXRlIGNhclxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUNhcihjYXI6IENhcikge1xyXG4gIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBhdXRoKCk7XHJcbiAgY29uc3QgdXNlcm5hbWUgPSBzZXNzaW9uPy51c2VyPy5uYW1lO1xyXG5cclxuICBjb25zdCB7XHJcbiAgICBpZCxcclxuICAgIG5hbWUsXHJcbiAgICBtb2RlbCxcclxuICAgIGdvc19udW1iZXIsXHJcbiAgICBtYWtlLFxyXG4gICAgdmluLFxyXG4gICAgeWVhcixcclxuICAgIGN1c3RvbWVyX2lkLFxyXG4gICAgY2FyX3N0YXR1cyxcclxuICAgIHVuaXRfaWQsXHJcbiAgICBsb2NhdGlvbl9pZCxcclxuICAgIHNlY3Rpb25faWQsXHJcbiAgICB0ZW5hbnRfaWQsXHJcbiAgICBhdXRob3JfaWQsXHJcbiAgICBkb2Nfc3RhdHVzLFxyXG4gIH0gPSBjYXI7XHJcblxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIFVQREFURSBjYXJzIFNFVFxyXG4gICAgICAgIG5hbWUgPSAkMSwgbW9kZWwgPSAkMiwgZ29zX251bWJlciA9ICQzLCBtYWtlID0gJDQsIHZpbiA9ICQ1LCB5ZWFyID0gJDYsXHJcbiAgICAgICAgY3VzdG9tZXJfaWQgPSAkNywgXHJcbiAgICAgICAgY2FyX3N0YXR1cyA9ICQ4LCBcclxuICAgICAgICB1bml0X2lkID0gJDksIFxyXG4gICAgICAgIGxvY2F0aW9uX2lkID0gJDEwLFxyXG4gICAgICAgIHVzZXJuYW1lID0gJDExLFxyXG4gICAgICAgIHNlY3Rpb25faWQgPSAkMTIsXHJcbiAgICAgICAgdGVuYW50X2lkID0gJDEzLFxyXG4gICAgICAgIGF1dGhvcl9pZCA9ICQxNCxcclxuICAgICAgICBkb2Nfc3RhdHVzID0gJDE1LFxyXG4gICAgICAgIHRpbWVzdGFtcHR6ID0gbm93KClcclxuICAgICAgV0hFUkUgaWQgPSAkMTZcclxuICAgIGAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIG1vZGVsLFxyXG4gICAgICAgIGdvc19udW1iZXIsXHJcbiAgICAgICAgbWFrZSxcclxuICAgICAgICB2aW4sXHJcbiAgICAgICAgeWVhcixcclxuICAgICAgICBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLFxyXG4gICAgICAgIHVuaXRfaWQsXHJcbiAgICAgICAgbG9jYXRpb25faWQsXHJcbiAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGRvY19zdGF0dXMsXHJcbiAgICAgICAgaWQsXHJcbiAgICAgIF0sXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtCx0L3QvtCy0LjRgtGMIGNhcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICBcItCe0YjQuNCx0LrQsCDQsdCw0LfRiyDQtNCw0L3QvdGL0YU6INCd0LUg0YPQtNCw0LvQvtGB0Ywg0L7QsdC90L7QstC40YLRjCBjYXI6IFwiICsgU3RyaW5nKGVycm9yKSxcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXZhbGlkYXRlUGF0aChcIi9yZXBhaXIvY2Fyc1wiKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUNhcihpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIGNhcnMgV0hFUkUgaWQgPSAkMWAsIFtpZF0pO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINGD0LTQsNC70LXQvdC40Y8gY2FyOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgIFwi0J7RiNC40LHQutCwINCx0LDQt9GLINC00LDQvdC90YvRhTog0J3QtSDRg9C00LDQu9C+0YHRjCDRg9C00LDQu9C40YLRjCBjYXI6IFwiICsgU3RyaW5nKGVycm9yKSxcclxuICAgICk7XHJcbiAgfVxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL3JlcGFpci9jYXJzXCIpO1xyXG59XHJcblxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBGZXRjaCBjYXJzXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hDYXIoaWQ6IHN0cmluZywgY3VycmVudF9zZWN0aW9uczogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PENhcj4oXHJcbiAgICAgIGBcclxuICAgICAgV0lUSCB5b3VyX2NhcnMgQVMgKCBTRUxFQ1QgKiBGUk9NIGNhcnMgd2hlcmUgc2VjdGlvbl9pZCA9IFxyXG4gICAgICAgIEFOWSAoJDE6OnV1aWRbXSkpXHJcblxyXG4gICAgICBTRUxFQ1RcclxuICAgICAgICBpZCxcclxuICAgICAgICBuYW1lLCBtb2RlbCwgZ29zX251bWJlciwgbWFrZSwgdmluLCB5ZWFyLCBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLCB1bml0X2lkLCBsb2NhdGlvbl9pZCxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICBlZGl0aW5nX2J5X3VzZXJfaWQsXHJcbiAgICAgICAgZWRpdGluZ19zaW5jZSxcclxuICAgICAgICB0aW1lc3RhbXB0eixcclxuICAgICAgICBkYXRlX2NyZWF0ZWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGVkaXRvcl9pZCxcclxuICAgICAgICBkb2Nfc3RhdHVzXHJcbiAgICAgIEZST00geW91cl9jYXJzXHJcbiAgICAgIFdIRVJFIGlkID0gJDJcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zLCBpZF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyBjYXIg0L/QviBJRDpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCBjYXI6XCIgKyBTdHJpbmcoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hDYXJGb3JtKGlkOiBzdHJpbmcsIGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxDYXJGb3JtPihcclxuICAgICAgYFxyXG4gICAgICBXSVRIIHlvdXJfY2FycyBBUyAoIFNFTEVDVCAqIEZST00gY2FycyB3aGVyZSBzZWN0aW9uX2lkID0gXHJcbiAgICAgICAgQU5ZICgkMTo6dXVpZFtdKSlcclxuXHJcbiAgICAgIFNFTEVDVFxyXG4gICAgICAgIGNhcnMuaWQsXHJcbiAgICAgICAgY2Fycy5uYW1lLCBjYXJzLm5hbWUsIGNhcnMubW9kZWwsIGNhcnMuZ29zX251bWJlciwgY2Fycy5tYWtlLCBjYXJzLnZpbiwgY2Fycy55ZWFyLFxyXG4gICAgICAgIGNhcnMuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgY2Fycy5jYXJfc3RhdHVzLCBcclxuICAgICAgICBjYXJzLnVuaXRfaWQsIFxyXG4gICAgICAgIGNhcnMubG9jYXRpb25faWQsXHJcbiAgICAgICAgY2Fycy51c2VybmFtZSxcclxuICAgICAgICBjYXJzLnNlY3Rpb25faWQsXHJcbiAgICAgICAgY2Fycy50ZW5hbnRfaWQsXHJcbiAgICAgICAgY2Fycy5hdXRob3JfaWQsXHJcbiAgICAgICAgY2Fycy5lZGl0b3JfaWQsXHJcbiAgICAgICAgY2Fycy5kb2Nfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMuZWRpdGluZ19ieV91c2VyX2lkLFxyXG4gICAgICAgIGNhcnMuZWRpdGluZ19zaW5jZSxcclxuICAgICAgICBjYXJzLnRpbWVzdGFtcHR6LFxyXG4gICAgICAgIHNlY3Rpb25zLm5hbWUgQVMgc2VjdGlvbl9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKHVuaXRzLm5hbWUsICcnKSBhcyB1bml0X25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UobG9jYXRpb25zLm5hbWUsICcnKSBhcyBsb2NhdGlvbl9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKGN1c3RvbWVycy5uYW1lLCAnJykgYXMgY3VzdG9tZXJfbmFtZVxyXG4gICAgICBGUk9NIHlvdXJfY2FycyBjYXJzXHJcbiAgICAgIExFRlQgSk9JTiBzZWN0aW9ucyBPTiBjYXJzLnNlY3Rpb25faWQgPSBzZWN0aW9ucy5pZFxyXG4gICAgICBMRUZUIEpPSU4gdW5pdHMgT04gY2Fycy51bml0X2lkID0gdW5pdHMuaWRcclxuICAgICAgTEVGVCBKT0lOIGxvY2F0aW9ucyBPTiBjYXJzLmxvY2F0aW9uX2lkID0gbG9jYXRpb25zLmlkXHJcbiAgICAgIExFRlQgSk9JTiBsZWdhbF9lbnRpdGllcyBBUyBjdXN0b21lcnMgT04gY2Fycy5jdXN0b21lcl9pZCA9IGN1c3RvbWVycy5pZFxyXG4gICAgICBXSEVSRSBjYXJzLmlkID0gJDJcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zLCBpZF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyDRhNC+0YDQvNGLIGNhcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCDQtNCw0L3QvdGL0LUg0YTQvtGA0LzRiyBjYXI6IFwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQ2FycyhjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Q2FyPihcclxuICAgICAgYFxyXG4gICAgICBXSVRIIHlvdXJfY2FycyBBUyAoIFNFTEVDVCAqIEZST00gY2FycyB3aGVyZSBzZWN0aW9uX2lkID0gXHJcbiAgICAgICAgQU5ZICgkMTo6dXVpZFtdKSlcclxuXHJcbiAgICAgIFNFTEVDVFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIG5hbWUsIG1vZGVsLCBnb3NfbnVtYmVyLCBtYWtlLCB2aW4sIHllYXIsIGN1c3RvbWVyX2lkLFxyXG4gICAgICAgIGNhcl9zdGF0dXMsIHVuaXRfaWQsIGxvY2F0aW9uX2lkLFxyXG4gICAgICAgIHNlY3Rpb25faWQsXHJcbiAgICAgICAgdGVuYW50X2lkLFxyXG4gICAgICAgIGF1dGhvcl9pZCxcclxuICAgICAgICBlZGl0b3JfaWQsXHJcbiAgICAgICAgZG9jX3N0YXR1cyxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICB0aW1lc3RhbXB0eixcclxuICAgICAgICBkYXRlX2NyZWF0ZWRcclxuICAgICAgRlJPTSB5b3VyX2NhcnNcclxuICAgICAgT1JERVIgQlkgbmFtZSBBU0NcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zXSxcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0L/QvtC70YPRh9C10L3QuNGPINGB0L/QuNGB0LrQsCDQt9Cw0LTQsNGHOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQt9Cw0LPRgNGD0LfQuNGC0Ywg0YHQv9C40YHQvtC6INC30LDQtNCw0Yc6IFwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQ2Fyc0Zvcm0oXHJcbiAgY3VycmVudF9zZWN0aW9uczogc3RyaW5nLFxyXG4gIGxlZ2FsRW50aXR5SWQ/OiBzdHJpbmcsXHJcbikge1xyXG4gIGNvbnN0IGN1c3RvbWVySWQgPSBsZWdhbEVudGl0eUlkID8/IG51bGw7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PENhckZvcm0+KFxyXG4gICAgICBgXHJcbiAgICAgIFdJVEggeW91cl9jYXJzIEFTICggU0VMRUNUICogRlJPTSBjYXJzIHdoZXJlIHNlY3Rpb25faWQgPSBcclxuICAgICAgICBBTlkgKCQxOjp1dWlkW10pKVxyXG5cclxuICAgICAgU0VMRUNUXHJcbiAgICAgICAgY2Fycy5pZCxcclxuICAgICAgICBjYXJzLm5hbWUsXHJcbiAgICAgICAgY2Fycy51bml0X2lkLFxyXG4gICAgICAgIGNhcnMubG9jYXRpb25faWQsXHJcbiAgICAgICAgY2Fycy5jYXJfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMubW9kZWwsXHJcbiAgICAgICAgY2Fycy5nb3NfbnVtYmVyLCBjYXJzLm1ha2UsIGNhcnMudmluLCBjYXJzLnllYXIsIGNhcnMuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgY2Fycy5zZWN0aW9uX2lkLFxyXG4gICAgICAgIGNhcnMudGVuYW50X2lkLFxyXG4gICAgICAgIGNhcnMuYXV0aG9yX2lkLFxyXG4gICAgICAgIGNhcnMuZWRpdG9yX2lkLFxyXG4gICAgICAgIGNhcnMuZG9jX3N0YXR1cyxcclxuICAgICAgICBjYXJzLmRhdGVfY3JlYXRlZCxcclxuICAgICAgICBjYXJzLnVzZXJuYW1lLFxyXG4gICAgICAgIGNhcnMudGltZXN0YW1wdHosXHJcbiAgICAgICAgc2VjdGlvbnMubmFtZSBBUyBzZWN0aW9uX25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UodW5pdHMubmFtZSwgJycpIGFzIHVuaXRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShsb2NhdGlvbnMubmFtZSwgJycpIGFzIGxvY2F0aW9uX25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UoY3VzdG9tZXJzLm5hbWUsICcnKSBhcyBjdXN0b21lcl9uYW1lXHJcbiAgICAgIEZST00geW91cl9jYXJzIGNhcnNcclxuICAgICAgTEVGVCBKT0lOIHNlY3Rpb25zIE9OIGNhcnMuc2VjdGlvbl9pZCA9IHNlY3Rpb25zLmlkXHJcbiAgICAgIExFRlQgSk9JTiB1bml0cyBPTiBjYXJzLnVuaXRfaWQgPSB1bml0cy5pZFxyXG4gICAgICBMRUZUIEpPSU4gbG9jYXRpb25zIE9OIGNhcnMubG9jYXRpb25faWQgPSBsb2NhdGlvbnMuaWRcclxuICAgICAgTEVGVCBKT0lOIGxlZ2FsX2VudGl0aWVzIEFTIGN1c3RvbWVycyBPTiBjYXJzLmN1c3RvbWVyX2lkID0gY3VzdG9tZXJzLmlkXHJcbiAgICAgIFdIRVJFICQyOjp1dWlkIElTIE5VTEwgT1IgY2Fycy5jdXN0b21lcl9pZCA9ICQyOjp1dWlkXHJcbiAgICAgIE9SREVSIEJZIGNhcnMubmFtZSBBU0NcclxuICAgICAgYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGN1c3RvbWVySWRdLFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YTQvtGA0LwgY2FyczpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINGE0L7RgNC80YsgY2FyczpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbi8vI2VuZHJlZ2lvblxyXG5cclxuLy8jcmVnaW9uIEZpbHRlcmVkIGNhcnNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaEZpbHRlcmVkQ2FycyhcclxuICBxdWVyeTogc3RyaW5nLFxyXG4gIGN1cnJlbnRQYWdlOiBudW1iZXIsXHJcbiAgY3VycmVudF9zZWN0aW9uczogc3RyaW5nLFxyXG4pIHtcclxuICBjb25zdCBvZmZzZXQgPSAoY3VycmVudFBhZ2UgLSAxKSAqIElURU1TX1BFUl9QQUdFO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgY2FycyA9IGF3YWl0IHBvb2wucXVlcnk8Q2FyRm9ybT4oXHJcbiAgICAgIGBcclxuICAgICAgV0lUSCB5b3VyX2NhcnMgQVMgKCBTRUxFQ1QgKiBGUk9NIGNhcnMgd2hlcmUgc2VjdGlvbl9pZCA9IFxyXG4gICAgICAgIEFOWSAoJDE6OnV1aWRbXSkpXHJcblxyXG4gICAgICBTRUxFQ1RcclxuICAgICAgICBjYXJzLmlkLFxyXG4gICAgICAgIGNhcnMubmFtZSxcclxuICAgICAgICBjYXJzLnVuaXRfaWQsXHJcbiAgICAgICAgY2Fycy5sb2NhdGlvbl9pZCxcclxuICAgICAgICBjYXJzLmNhcl9zdGF0dXMsXHJcbiAgICAgICAgY2Fycy5tb2RlbCxcclxuICAgICAgICBjYXJzLmdvc19udW1iZXIsIGNhcnMubWFrZSwgY2Fycy52aW4sIGNhcnMueWVhciwgY2Fycy5jdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJzLnNlY3Rpb25faWQsXHJcbiAgICAgICAgY2Fycy50ZW5hbnRfaWQsXHJcbiAgICAgICAgY2Fycy5hdXRob3JfaWQsXHJcbiAgICAgICAgY2Fycy5lZGl0b3JfaWQsXHJcbiAgICAgICAgY2Fycy5kb2Nfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMudXNlcm5hbWUsXHJcbiAgICAgICAgY2Fycy50aW1lc3RhbXB0eixcclxuICAgICAgICBzZWN0aW9ucy5uYW1lIEFTIHNlY3Rpb25fbmFtZSxcclxuICAgICAgICBDT0FMRVNDRSh1bml0cy5uYW1lLCAnJykgYXMgdW5pdF9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKGxvY2F0aW9ucy5uYW1lLCAnJykgYXMgbG9jYXRpb25fbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShjdXN0b21lcnMubmFtZSwgJycpIGFzIGN1c3RvbWVyX25hbWVcclxuICAgICAgRlJPTSB5b3VyX2NhcnMgY2Fyc1xyXG4gICAgICBMRUZUIEpPSU4gc2VjdGlvbnMgT04gY2Fycy5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuICAgICAgTEVGVCBKT0lOIHVuaXRzIE9OIGNhcnMudW5pdF9pZCA9IHVuaXRzLmlkXHJcbiAgICAgIExFRlQgSk9JTiBsb2NhdGlvbnMgT04gY2Fycy5sb2NhdGlvbl9pZCA9IGxvY2F0aW9ucy5pZFxyXG4gICAgICBMRUZUIEpPSU4gbGVnYWxfZW50aXRpZXMgQVMgY3VzdG9tZXJzIE9OIGNhcnMuY3VzdG9tZXJfaWQgPSBjdXN0b21lcnMuaWRcclxuICAgICAgV0hFUkVcclxuICAgICAgICBjYXJzLm5hbWUgSUxJS0UgJDIgXHJcbiAgICAgIC0tIEFORCAoJDUgPSAn0L/QsNGA0LonIE9SICQ1ID0gJ9C/0LXRgNGB0L7QvdCw0LsnIE9SIGNhcnMuY2FyX3N0YXR1cyA9ICQ1KVxyXG4gICAgICBPUkRFUiBCWSBjYXJzLm5hbWUgQVNDXHJcbiAgICAgIExJTUlUICQzIE9GRlNFVCAkNFxyXG4gICAgYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGAlJHtxdWVyeX0lYCwgSVRFTVNfUEVSX1BBR0UsIG9mZnNldF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBjYXJzLnJvd3M7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0YTQuNC70YzRgtGA0LDRhtC40Lgg0JDQstGC0L7QvNC+0LHQuNC70LXQuSjRgtCw0LHQu9C40YbQsCBjYXJzKTpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINC+0YLRhNC40LvRjNGC0YDQvtCy0LDQvdC90YvQtSDQkNCy0YLQvtC80L7QsdC40LvQuDogXCIgKyBTdHJpbmcoZXJyb3IpLFxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaENhcnNQYWdlcyhxdWVyeTogc3RyaW5nLCBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY291bnQgPSBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIFdJVEggeW91cl9jYXJzIEFTICggU0VMRUNUICogRlJPTSBjYXJzIHdoZXJlIHNlY3Rpb25faWQgPSBcclxuICAgICAgICBBTlkgKCQxOjp1dWlkW10pKVxyXG5cclxuICAgICAgU0VMRUNUIENPVU5UKCopIEZST00geW91cl9jYXJzXHJcbiAgICAgIFdIRVJFIHlvdXJfY2Fycy5uYW1lIElMSUtFICQyXHJcbiAgICBgLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgYCUke3F1ZXJ5fSVgXSxcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgdG90YWxQYWdlcyA9IE1hdGguY2VpbChOdW1iZXIoY291bnQucm93c1swXS5jb3VudCkgLyBJVEVNU19QRVJfUEFHRSk7XHJcbiAgICByZXR1cm4gdG90YWxQYWdlcztcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LTRgdGH0ZHRgtCwINGB0YLRgNCw0L3QuNGGIGNhcnM6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgXCLQndC1INGD0LTQsNC70L7RgdGMINC+0L/RgNC10LTQtdC70LjRgtGMINC60L7Qu9C40YfQtdGB0YLQstC+INGB0YLRgNCw0L3QuNGGOiBcIiArIFN0cmluZyhlcnJvciksXHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuLy8jZW5kcmVnaW9uXHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOFJBZXNCLHNMQUFBIn0=
}),
"[project]/app/erp/cars/lib/data:0cdc7e [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateCar",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40214baa60beea4f68365a033df51fb458f6133f96":"updateCar"},"app/erp/cars/lib/cars-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40214baa60beea4f68365a033df51fb458f6133f96", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateCar");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vY2Fycy1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIENhcnMgYWN0aW9uc1xyXG5cclxuXCJ1c2Ugc2VydmVyXCI7XHJcblxyXG4vLyBpbXBvcnQgeyB6IH0gZnJvbSBcInpvZFwiO1xyXG5pbXBvcnQgcG9vbCBmcm9tIFwiQC9kYlwiO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gXCJuZXh0L2NhY2hlXCI7XHJcbi8vIGltcG9ydCB7IHJlZGlyZWN0IH0gZnJvbSBcIm5leHQvbmF2aWdhdGlvblwiO1xyXG5pbXBvcnQgeyBhdXRoIH0gZnJvbSBcIkAvYXV0aFwiO1xyXG5pbXBvcnQgeyBDYXJGb3JtLCBDYXIgfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcblxyXG5jb25zdCBJVEVNU19QRVJfUEFHRSA9IDg7XHJcblxyXG4vLyNyZWdpb24gQ3JlYXRlIFRhc2tcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVDYXIoY2FyOiBDYXIpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYXV0aCgpO1xyXG4gIGNvbnN0IHVzZXJuYW1lID0gc2Vzc2lvbj8udXNlcj8ubmFtZTtcclxuICBjb25zdCBkYXRlX2NyZWF0ZWQgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcbiAgY29uc3Qge1xyXG4gICAgbmFtZSxcclxuICAgIG1vZGVsLFxyXG4gICAgZ29zX251bWJlcixcclxuICAgIG1ha2UsXHJcbiAgICB2aW4sXHJcbiAgICB5ZWFyLFxyXG4gICAgY3VzdG9tZXJfaWQsXHJcbiAgICBjYXJfc3RhdHVzLFxyXG4gICAgdW5pdF9pZCxcclxuICAgIGxvY2F0aW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHRlbmFudF9pZCxcclxuICAgIGF1dGhvcl9pZCxcclxuICB9ID0gY2FyO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIElOU0VSVCBJTlRPIGNhcnMgKFxyXG4gICAgICAgIG5hbWUsIG1vZGVsLCBnb3NfbnVtYmVyLCBtYWtlLCB2aW4sIHllYXIsIGN1c3RvbWVyX2lkLFxyXG4gICAgICAgIGNhcl9zdGF0dXMsIHVuaXRfaWQsIGxvY2F0aW9uX2lkLFxyXG4gICAgICAgIHVzZXJuYW1lLCBzZWN0aW9uX2lkLCB0aW1lc3RhbXB0eixcclxuICAgICAgICB0ZW5hbnRfaWQsIGF1dGhvcl9pZFxyXG4gICAgICApIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1LCAkNiwgJDcsICQ4LCAkOSwgJDEwLCAkMTEsICQxMiwgJDEzLCAkMTQsICQxNSlcclxuICAgIGAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIG1vZGVsLFxyXG4gICAgICAgIGdvc19udW1iZXIsXHJcbiAgICAgICAgbWFrZSxcclxuICAgICAgICB2aW4sXHJcbiAgICAgICAgeWVhcixcclxuICAgICAgICBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLFxyXG4gICAgICAgIHVuaXRfaWQsXHJcbiAgICAgICAgbG9jYXRpb25faWQsXHJcbiAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICBkYXRlX2NyZWF0ZWQsXHJcbiAgICAgICAgdGVuYW50X2lkLFxyXG4gICAgICAgIGF1dGhvcl9pZCxcclxuICAgICAgXSxcclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIGNhcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0LfQtNCw0YLRjCBjYXI6XCIgKyBTdHJpbmcoZXJyb3IpKTtcclxuICB9XHJcblxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL3JlcGFpci9jYXJzXCIpO1xyXG59XHJcblxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBVcGRhdGUvRGVsZXRlIGNhclxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUNhcihjYXI6IENhcikge1xyXG4gIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBhdXRoKCk7XHJcbiAgY29uc3QgdXNlcm5hbWUgPSBzZXNzaW9uPy51c2VyPy5uYW1lO1xyXG5cclxuICBjb25zdCB7XHJcbiAgICBpZCxcclxuICAgIG5hbWUsXHJcbiAgICBtb2RlbCxcclxuICAgIGdvc19udW1iZXIsXHJcbiAgICBtYWtlLFxyXG4gICAgdmluLFxyXG4gICAgeWVhcixcclxuICAgIGN1c3RvbWVyX2lkLFxyXG4gICAgY2FyX3N0YXR1cyxcclxuICAgIHVuaXRfaWQsXHJcbiAgICBsb2NhdGlvbl9pZCxcclxuICAgIHNlY3Rpb25faWQsXHJcbiAgICB0ZW5hbnRfaWQsXHJcbiAgICBhdXRob3JfaWQsXHJcbiAgICBkb2Nfc3RhdHVzLFxyXG4gIH0gPSBjYXI7XHJcblxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIFVQREFURSBjYXJzIFNFVFxyXG4gICAgICAgIG5hbWUgPSAkMSwgbW9kZWwgPSAkMiwgZ29zX251bWJlciA9ICQzLCBtYWtlID0gJDQsIHZpbiA9ICQ1LCB5ZWFyID0gJDYsXHJcbiAgICAgICAgY3VzdG9tZXJfaWQgPSAkNywgXHJcbiAgICAgICAgY2FyX3N0YXR1cyA9ICQ4LCBcclxuICAgICAgICB1bml0X2lkID0gJDksIFxyXG4gICAgICAgIGxvY2F0aW9uX2lkID0gJDEwLFxyXG4gICAgICAgIHVzZXJuYW1lID0gJDExLFxyXG4gICAgICAgIHNlY3Rpb25faWQgPSAkMTIsXHJcbiAgICAgICAgdGVuYW50X2lkID0gJDEzLFxyXG4gICAgICAgIGF1dGhvcl9pZCA9ICQxNCxcclxuICAgICAgICBkb2Nfc3RhdHVzID0gJDE1LFxyXG4gICAgICAgIHRpbWVzdGFtcHR6ID0gbm93KClcclxuICAgICAgV0hFUkUgaWQgPSAkMTZcclxuICAgIGAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIG1vZGVsLFxyXG4gICAgICAgIGdvc19udW1iZXIsXHJcbiAgICAgICAgbWFrZSxcclxuICAgICAgICB2aW4sXHJcbiAgICAgICAgeWVhcixcclxuICAgICAgICBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLFxyXG4gICAgICAgIHVuaXRfaWQsXHJcbiAgICAgICAgbG9jYXRpb25faWQsXHJcbiAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGRvY19zdGF0dXMsXHJcbiAgICAgICAgaWQsXHJcbiAgICAgIF0sXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtCx0L3QvtCy0LjRgtGMIGNhcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICBcItCe0YjQuNCx0LrQsCDQsdCw0LfRiyDQtNCw0L3QvdGL0YU6INCd0LUg0YPQtNCw0LvQvtGB0Ywg0L7QsdC90L7QstC40YLRjCBjYXI6IFwiICsgU3RyaW5nKGVycm9yKSxcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXZhbGlkYXRlUGF0aChcIi9yZXBhaXIvY2Fyc1wiKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUNhcihpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIGNhcnMgV0hFUkUgaWQgPSAkMWAsIFtpZF0pO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINGD0LTQsNC70LXQvdC40Y8gY2FyOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgIFwi0J7RiNC40LHQutCwINCx0LDQt9GLINC00LDQvdC90YvRhTog0J3QtSDRg9C00LDQu9C+0YHRjCDRg9C00LDQu9C40YLRjCBjYXI6IFwiICsgU3RyaW5nKGVycm9yKSxcclxuICAgICk7XHJcbiAgfVxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL3JlcGFpci9jYXJzXCIpO1xyXG59XHJcblxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBGZXRjaCBjYXJzXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hDYXIoaWQ6IHN0cmluZywgY3VycmVudF9zZWN0aW9uczogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PENhcj4oXHJcbiAgICAgIGBcclxuICAgICAgV0lUSCB5b3VyX2NhcnMgQVMgKCBTRUxFQ1QgKiBGUk9NIGNhcnMgd2hlcmUgc2VjdGlvbl9pZCA9IFxyXG4gICAgICAgIEFOWSAoJDE6OnV1aWRbXSkpXHJcblxyXG4gICAgICBTRUxFQ1RcclxuICAgICAgICBpZCxcclxuICAgICAgICBuYW1lLCBtb2RlbCwgZ29zX251bWJlciwgbWFrZSwgdmluLCB5ZWFyLCBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLCB1bml0X2lkLCBsb2NhdGlvbl9pZCxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICBlZGl0aW5nX2J5X3VzZXJfaWQsXHJcbiAgICAgICAgZWRpdGluZ19zaW5jZSxcclxuICAgICAgICB0aW1lc3RhbXB0eixcclxuICAgICAgICBkYXRlX2NyZWF0ZWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGVkaXRvcl9pZCxcclxuICAgICAgICBkb2Nfc3RhdHVzXHJcbiAgICAgIEZST00geW91cl9jYXJzXHJcbiAgICAgIFdIRVJFIGlkID0gJDJcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zLCBpZF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyBjYXIg0L/QviBJRDpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCBjYXI6XCIgKyBTdHJpbmcoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hDYXJGb3JtKGlkOiBzdHJpbmcsIGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxDYXJGb3JtPihcclxuICAgICAgYFxyXG4gICAgICBXSVRIIHlvdXJfY2FycyBBUyAoIFNFTEVDVCAqIEZST00gY2FycyB3aGVyZSBzZWN0aW9uX2lkID0gXHJcbiAgICAgICAgQU5ZICgkMTo6dXVpZFtdKSlcclxuXHJcbiAgICAgIFNFTEVDVFxyXG4gICAgICAgIGNhcnMuaWQsXHJcbiAgICAgICAgY2Fycy5uYW1lLCBjYXJzLm5hbWUsIGNhcnMubW9kZWwsIGNhcnMuZ29zX251bWJlciwgY2Fycy5tYWtlLCBjYXJzLnZpbiwgY2Fycy55ZWFyLFxyXG4gICAgICAgIGNhcnMuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgY2Fycy5jYXJfc3RhdHVzLCBcclxuICAgICAgICBjYXJzLnVuaXRfaWQsIFxyXG4gICAgICAgIGNhcnMubG9jYXRpb25faWQsXHJcbiAgICAgICAgY2Fycy51c2VybmFtZSxcclxuICAgICAgICBjYXJzLnNlY3Rpb25faWQsXHJcbiAgICAgICAgY2Fycy50ZW5hbnRfaWQsXHJcbiAgICAgICAgY2Fycy5hdXRob3JfaWQsXHJcbiAgICAgICAgY2Fycy5lZGl0b3JfaWQsXHJcbiAgICAgICAgY2Fycy5kb2Nfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMuZWRpdGluZ19ieV91c2VyX2lkLFxyXG4gICAgICAgIGNhcnMuZWRpdGluZ19zaW5jZSxcclxuICAgICAgICBjYXJzLnRpbWVzdGFtcHR6LFxyXG4gICAgICAgIHNlY3Rpb25zLm5hbWUgQVMgc2VjdGlvbl9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKHVuaXRzLm5hbWUsICcnKSBhcyB1bml0X25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UobG9jYXRpb25zLm5hbWUsICcnKSBhcyBsb2NhdGlvbl9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKGN1c3RvbWVycy5uYW1lLCAnJykgYXMgY3VzdG9tZXJfbmFtZVxyXG4gICAgICBGUk9NIHlvdXJfY2FycyBjYXJzXHJcbiAgICAgIExFRlQgSk9JTiBzZWN0aW9ucyBPTiBjYXJzLnNlY3Rpb25faWQgPSBzZWN0aW9ucy5pZFxyXG4gICAgICBMRUZUIEpPSU4gdW5pdHMgT04gY2Fycy51bml0X2lkID0gdW5pdHMuaWRcclxuICAgICAgTEVGVCBKT0lOIGxvY2F0aW9ucyBPTiBjYXJzLmxvY2F0aW9uX2lkID0gbG9jYXRpb25zLmlkXHJcbiAgICAgIExFRlQgSk9JTiBsZWdhbF9lbnRpdGllcyBBUyBjdXN0b21lcnMgT04gY2Fycy5jdXN0b21lcl9pZCA9IGN1c3RvbWVycy5pZFxyXG4gICAgICBXSEVSRSBjYXJzLmlkID0gJDJcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zLCBpZF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyDRhNC+0YDQvNGLIGNhcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCDQtNCw0L3QvdGL0LUg0YTQvtGA0LzRiyBjYXI6IFwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQ2FycyhjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Q2FyPihcclxuICAgICAgYFxyXG4gICAgICBXSVRIIHlvdXJfY2FycyBBUyAoIFNFTEVDVCAqIEZST00gY2FycyB3aGVyZSBzZWN0aW9uX2lkID0gXHJcbiAgICAgICAgQU5ZICgkMTo6dXVpZFtdKSlcclxuXHJcbiAgICAgIFNFTEVDVFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIG5hbWUsIG1vZGVsLCBnb3NfbnVtYmVyLCBtYWtlLCB2aW4sIHllYXIsIGN1c3RvbWVyX2lkLFxyXG4gICAgICAgIGNhcl9zdGF0dXMsIHVuaXRfaWQsIGxvY2F0aW9uX2lkLFxyXG4gICAgICAgIHNlY3Rpb25faWQsXHJcbiAgICAgICAgdGVuYW50X2lkLFxyXG4gICAgICAgIGF1dGhvcl9pZCxcclxuICAgICAgICBlZGl0b3JfaWQsXHJcbiAgICAgICAgZG9jX3N0YXR1cyxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICB0aW1lc3RhbXB0eixcclxuICAgICAgICBkYXRlX2NyZWF0ZWRcclxuICAgICAgRlJPTSB5b3VyX2NhcnNcclxuICAgICAgT1JERVIgQlkgbmFtZSBBU0NcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zXSxcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0L/QvtC70YPRh9C10L3QuNGPINGB0L/QuNGB0LrQsCDQt9Cw0LTQsNGHOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQt9Cw0LPRgNGD0LfQuNGC0Ywg0YHQv9C40YHQvtC6INC30LDQtNCw0Yc6IFwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQ2Fyc0Zvcm0oXHJcbiAgY3VycmVudF9zZWN0aW9uczogc3RyaW5nLFxyXG4gIGxlZ2FsRW50aXR5SWQ/OiBzdHJpbmcsXHJcbikge1xyXG4gIGNvbnN0IGN1c3RvbWVySWQgPSBsZWdhbEVudGl0eUlkID8/IG51bGw7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PENhckZvcm0+KFxyXG4gICAgICBgXHJcbiAgICAgIFdJVEggeW91cl9jYXJzIEFTICggU0VMRUNUICogRlJPTSBjYXJzIHdoZXJlIHNlY3Rpb25faWQgPSBcclxuICAgICAgICBBTlkgKCQxOjp1dWlkW10pKVxyXG5cclxuICAgICAgU0VMRUNUXHJcbiAgICAgICAgY2Fycy5pZCxcclxuICAgICAgICBjYXJzLm5hbWUsXHJcbiAgICAgICAgY2Fycy51bml0X2lkLFxyXG4gICAgICAgIGNhcnMubG9jYXRpb25faWQsXHJcbiAgICAgICAgY2Fycy5jYXJfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMubW9kZWwsXHJcbiAgICAgICAgY2Fycy5nb3NfbnVtYmVyLCBjYXJzLm1ha2UsIGNhcnMudmluLCBjYXJzLnllYXIsIGNhcnMuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgY2Fycy5zZWN0aW9uX2lkLFxyXG4gICAgICAgIGNhcnMudGVuYW50X2lkLFxyXG4gICAgICAgIGNhcnMuYXV0aG9yX2lkLFxyXG4gICAgICAgIGNhcnMuZWRpdG9yX2lkLFxyXG4gICAgICAgIGNhcnMuZG9jX3N0YXR1cyxcclxuICAgICAgICBjYXJzLmRhdGVfY3JlYXRlZCxcclxuICAgICAgICBjYXJzLnVzZXJuYW1lLFxyXG4gICAgICAgIGNhcnMudGltZXN0YW1wdHosXHJcbiAgICAgICAgc2VjdGlvbnMubmFtZSBBUyBzZWN0aW9uX25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UodW5pdHMubmFtZSwgJycpIGFzIHVuaXRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShsb2NhdGlvbnMubmFtZSwgJycpIGFzIGxvY2F0aW9uX25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UoY3VzdG9tZXJzLm5hbWUsICcnKSBhcyBjdXN0b21lcl9uYW1lXHJcbiAgICAgIEZST00geW91cl9jYXJzIGNhcnNcclxuICAgICAgTEVGVCBKT0lOIHNlY3Rpb25zIE9OIGNhcnMuc2VjdGlvbl9pZCA9IHNlY3Rpb25zLmlkXHJcbiAgICAgIExFRlQgSk9JTiB1bml0cyBPTiBjYXJzLnVuaXRfaWQgPSB1bml0cy5pZFxyXG4gICAgICBMRUZUIEpPSU4gbG9jYXRpb25zIE9OIGNhcnMubG9jYXRpb25faWQgPSBsb2NhdGlvbnMuaWRcclxuICAgICAgTEVGVCBKT0lOIGxlZ2FsX2VudGl0aWVzIEFTIGN1c3RvbWVycyBPTiBjYXJzLmN1c3RvbWVyX2lkID0gY3VzdG9tZXJzLmlkXHJcbiAgICAgIFdIRVJFICQyOjp1dWlkIElTIE5VTEwgT1IgY2Fycy5jdXN0b21lcl9pZCA9ICQyOjp1dWlkXHJcbiAgICAgIE9SREVSIEJZIGNhcnMubmFtZSBBU0NcclxuICAgICAgYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGN1c3RvbWVySWRdLFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YTQvtGA0LwgY2FyczpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINGE0L7RgNC80YsgY2FyczpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbi8vI2VuZHJlZ2lvblxyXG5cclxuLy8jcmVnaW9uIEZpbHRlcmVkIGNhcnNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaEZpbHRlcmVkQ2FycyhcclxuICBxdWVyeTogc3RyaW5nLFxyXG4gIGN1cnJlbnRQYWdlOiBudW1iZXIsXHJcbiAgY3VycmVudF9zZWN0aW9uczogc3RyaW5nLFxyXG4pIHtcclxuICBjb25zdCBvZmZzZXQgPSAoY3VycmVudFBhZ2UgLSAxKSAqIElURU1TX1BFUl9QQUdFO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgY2FycyA9IGF3YWl0IHBvb2wucXVlcnk8Q2FyRm9ybT4oXHJcbiAgICAgIGBcclxuICAgICAgV0lUSCB5b3VyX2NhcnMgQVMgKCBTRUxFQ1QgKiBGUk9NIGNhcnMgd2hlcmUgc2VjdGlvbl9pZCA9IFxyXG4gICAgICAgIEFOWSAoJDE6OnV1aWRbXSkpXHJcblxyXG4gICAgICBTRUxFQ1RcclxuICAgICAgICBjYXJzLmlkLFxyXG4gICAgICAgIGNhcnMubmFtZSxcclxuICAgICAgICBjYXJzLnVuaXRfaWQsXHJcbiAgICAgICAgY2Fycy5sb2NhdGlvbl9pZCxcclxuICAgICAgICBjYXJzLmNhcl9zdGF0dXMsXHJcbiAgICAgICAgY2Fycy5tb2RlbCxcclxuICAgICAgICBjYXJzLmdvc19udW1iZXIsIGNhcnMubWFrZSwgY2Fycy52aW4sIGNhcnMueWVhciwgY2Fycy5jdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJzLnNlY3Rpb25faWQsXHJcbiAgICAgICAgY2Fycy50ZW5hbnRfaWQsXHJcbiAgICAgICAgY2Fycy5hdXRob3JfaWQsXHJcbiAgICAgICAgY2Fycy5lZGl0b3JfaWQsXHJcbiAgICAgICAgY2Fycy5kb2Nfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMudXNlcm5hbWUsXHJcbiAgICAgICAgY2Fycy50aW1lc3RhbXB0eixcclxuICAgICAgICBzZWN0aW9ucy5uYW1lIEFTIHNlY3Rpb25fbmFtZSxcclxuICAgICAgICBDT0FMRVNDRSh1bml0cy5uYW1lLCAnJykgYXMgdW5pdF9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKGxvY2F0aW9ucy5uYW1lLCAnJykgYXMgbG9jYXRpb25fbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShjdXN0b21lcnMubmFtZSwgJycpIGFzIGN1c3RvbWVyX25hbWVcclxuICAgICAgRlJPTSB5b3VyX2NhcnMgY2Fyc1xyXG4gICAgICBMRUZUIEpPSU4gc2VjdGlvbnMgT04gY2Fycy5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuICAgICAgTEVGVCBKT0lOIHVuaXRzIE9OIGNhcnMudW5pdF9pZCA9IHVuaXRzLmlkXHJcbiAgICAgIExFRlQgSk9JTiBsb2NhdGlvbnMgT04gY2Fycy5sb2NhdGlvbl9pZCA9IGxvY2F0aW9ucy5pZFxyXG4gICAgICBMRUZUIEpPSU4gbGVnYWxfZW50aXRpZXMgQVMgY3VzdG9tZXJzIE9OIGNhcnMuY3VzdG9tZXJfaWQgPSBjdXN0b21lcnMuaWRcclxuICAgICAgV0hFUkVcclxuICAgICAgICBjYXJzLm5hbWUgSUxJS0UgJDIgXHJcbiAgICAgIC0tIEFORCAoJDUgPSAn0L/QsNGA0LonIE9SICQ1ID0gJ9C/0LXRgNGB0L7QvdCw0LsnIE9SIGNhcnMuY2FyX3N0YXR1cyA9ICQ1KVxyXG4gICAgICBPUkRFUiBCWSBjYXJzLm5hbWUgQVNDXHJcbiAgICAgIExJTUlUICQzIE9GRlNFVCAkNFxyXG4gICAgYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGAlJHtxdWVyeX0lYCwgSVRFTVNfUEVSX1BBR0UsIG9mZnNldF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBjYXJzLnJvd3M7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0YTQuNC70YzRgtGA0LDRhtC40Lgg0JDQstGC0L7QvNC+0LHQuNC70LXQuSjRgtCw0LHQu9C40YbQsCBjYXJzKTpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINC+0YLRhNC40LvRjNGC0YDQvtCy0LDQvdC90YvQtSDQkNCy0YLQvtC80L7QsdC40LvQuDogXCIgKyBTdHJpbmcoZXJyb3IpLFxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaENhcnNQYWdlcyhxdWVyeTogc3RyaW5nLCBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY291bnQgPSBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIFdJVEggeW91cl9jYXJzIEFTICggU0VMRUNUICogRlJPTSBjYXJzIHdoZXJlIHNlY3Rpb25faWQgPSBcclxuICAgICAgICBBTlkgKCQxOjp1dWlkW10pKVxyXG5cclxuICAgICAgU0VMRUNUIENPVU5UKCopIEZST00geW91cl9jYXJzXHJcbiAgICAgIFdIRVJFIHlvdXJfY2Fycy5uYW1lIElMSUtFICQyXHJcbiAgICBgLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgYCUke3F1ZXJ5fSVgXSxcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgdG90YWxQYWdlcyA9IE1hdGguY2VpbChOdW1iZXIoY291bnQucm93c1swXS5jb3VudCkgLyBJVEVNU19QRVJfUEFHRSk7XHJcbiAgICByZXR1cm4gdG90YWxQYWdlcztcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LTRgdGH0ZHRgtCwINGB0YLRgNCw0L3QuNGGIGNhcnM6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgXCLQndC1INGD0LTQsNC70L7RgdGMINC+0L/RgNC10LTQtdC70LjRgtGMINC60L7Qu9C40YfQtdGB0YLQstC+INGB0YLRgNCw0L3QuNGGOiBcIiArIFN0cmluZyhlcnJvciksXHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuLy8jZW5kcmVnaW9uXHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOFJBMEVzQixzTEFBQSJ9
}),
"[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PdfDocument
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$renderer$2f$lib$2f$react$2d$pdf$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/renderer/lib/react-pdf.browser.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/primitives/lib/index.js [app-client] (ecmascript)");
;
;
;
__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$renderer$2f$lib$2f$react$2d$pdf$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Font"].register({
    family: 'Arial',
    src: 'https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-light-webfont.ttf  '
});
// Создаем стили для PDF
const styles = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$renderer$2f$lib$2f$react$2d$pdf$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["StyleSheet"].create({
    page: {
        flexDirection: 'column',
        padding: 30,
        fontSize: 12
    },
    section: {
        margin: 10,
        padding: 10,
        flexGrow: 1
    },
    text: {
        fontFamily: 'Arial',
        fontSize: 12
    }
});
const formData = {
    id: "",
    name: "",
    username: ""
};
function PdfDocument({ formData }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Document"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Page"], {
            size: "A4",
            style: styles.page,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["View"], {
                style: styles.section,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        style: styles.text,
                        children: [
                            "Название: ",
                            formData.name
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx",
                        lineNumber: 42,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        style: styles.text,
                        children: [
                            "Номер: ",
                            formData.gos_number
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx",
                        lineNumber: 43,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        style: styles.text,
                        children: [
                            "Модель: ",
                            formData.model
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        style: styles.text,
                        children: [
                            "Участок: ",
                            formData.unit_name
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        style: styles.text,
                        children: [
                            "Местоположение: ",
                            formData.location_name
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx",
                        lineNumber: 46,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"], {
                        style: styles.text,
                        children: [
                            "Состояние: ",
                            formData.car_status
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx",
                        lineNumber: 47,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx",
                lineNumber: 41,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx",
            lineNumber: 40,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx",
        lineNumber: 39,
        columnNumber: 5
    }, this);
}
_c = PdfDocument;
var _c;
__turbopack_context__.k.register(_c, "PdfDocument");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/units/lib/units-ref-table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>UnitsRefTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/ui/ref-search.tsx [app-client] (ecmascript)");
;
;
function UnitsRefTable(props) {
    // const [term, setTerm] = useState<string>("");
    const handleSearch = (input)=>{
        props.setTerm(input);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Выберите участок:"
            }, void 0, false, {
                fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                lineNumber: 20,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                callback: handleSearch,
                term: props.term,
                elementIdPrefix: "unit"
            }, void 0, false, {
                fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                lineNumber: 21,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0 flow-root",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto md:block hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "inline-block min-w-full align-middle",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-hidden rounded-md bg-gray-50 p-1 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            className: "rounded-md bg-gray-50 text-left text-sm font-normal",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 overflow-hidden px-0 py-5 font-medium sm:pl-6",
                                                        children: "Участок"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                                        lineNumber: 30,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-6/16 px-3 py-5 font-medium",
                                                        children: "Объект"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                                        lineNumber: 33,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                                lineNumber: 29,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                            lineNumber: 28,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                        lineNumber: 27,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                    lineNumber: 26,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            className: "divide-y divide-gray-200 text-gray-900",
                                            children: props.units.map((unit)=>(unit.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap text-ellipsis bg-white py-1 pl-0 text-left     pr-3 text-sm text-black group-first-of-type:rounded-md group-last-of-type:rounded-md sm:pl-6",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-left gap-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    onClick: (e)=>{
                                                                        e.preventDefault();
                                                                        e.stopPropagation();
                                                                        props.handleSelectUnit(unit.id, unit.name);
                                                                        props.setTerm("");
                                                                        props.closeModal();
                                                                    },
                                                                    // href={"#"}
                                                                    className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                                    children: unit.name.substring(0, 36)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                                                    lineNumber: 51,
                                                                    columnNumber: 53
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                                                lineNumber: 50,
                                                                columnNumber: 49
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                                            lineNumber: 48,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-6/16 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                            children: unit.object_name
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                                            lineNumber: 64,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, unit.id, true, {
                                                    fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                                    lineNumber: 47,
                                                    columnNumber: 41
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                            lineNumber: 43,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                        lineNumber: 42,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                    lineNumber: 41,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                            lineNumber: 25,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                        lineNumber: 24,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "block md:hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2",
                            children: props.units.filter((unit)=>unit.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((unit)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-gray-200 bg-white p-4 text-sm text-gray-900 last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium text-black",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                onClick: (e)=>{
                                                    props.handleSelectUnit(unit.id, unit.name);
                                                    props.setTerm("");
                                                    props.closeModal();
                                                },
                                                className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                children: unit.name.substring(0, 36)
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                                lineNumber: 88,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                            lineNumber: 87,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500",
                                            children: unit.object_name
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                            lineNumber: 99,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, unit.id, true, {
                                    fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                                    lineNumber: 83,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                            lineNumber: 76,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                        lineNumber: 75,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
                lineNumber: 22,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/units/lib/units-ref-table.tsx",
        lineNumber: 19,
        columnNumber: 9
    }, this);
}
_c = UnitsRefTable;
var _c;
__turbopack_context__.k.register(_c, "UnitsRefTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/units/lib/btn-units-ref.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BtnUnitsRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import Modal from "@/app/lib/modal";
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BookOpenIcon.js [app-client] (ecmascript) <export default as BookOpenIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$units$2f$lib$2f$units$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/units/lib/units-ref-table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = Modal;
function BtnUnitsRef(props) {
    _s();
    // const units = await fetchUnits();
    const [modal, setModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openModal = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setModal(true);
    // redirect("/dashboard/admin/tenants/1");
    };
    const closeModal = ()=>{
        // setUnit((prev) => ({
        //   ...props.unit,
        // }));
        setModal(false);
    };
    const [term, setTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: openModal,
                className: "rounded-md border border-gray-200 p-2 h-10 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__["BookOpenIcon"], {
                    className: "w-5 h-5 text-gray-800"
                }, void 0, false, {
                    fileName: "[project]/app/erp/units/lib/btn-units-ref.tsx",
                    lineNumber: 38,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/erp/units/lib/btn-units-ref.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Modal, {
                open: modal,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$units$2f$lib$2f$units$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        units: props.units,
                        handleSelectUnit: props.handleSelectUnit,
                        closeModal: closeModal,
                        setTerm: setTerm,
                        term: term
                    }, void 0, false, {
                        fileName: "[project]/app/erp/units/lib/btn-units-ref.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between space-x-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    alert("действие!");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/app/erp/units/lib/btn-units-ref.tsx",
                                lineNumber: 52,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    closeModal();
                                    setTerm("");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Exit"
                            }, void 0, false, {
                                fileName: "[project]/app/erp/units/lib/btn-units-ref.tsx",
                                lineNumber: 60,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/units/lib/btn-units-ref.tsx",
                        lineNumber: 51,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/units/lib/btn-units-ref.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/units/lib/btn-units-ref.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(BtnUnitsRef, "MW/KQDlZppFu/nDnRAs8d7ejpwM=");
_c1 = BtnUnitsRef;
var _c, _c1;
__turbopack_context__.k.register(_c, "Modal");
__turbopack_context__.k.register(_c1, "BtnUnitsRef");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/locations/lib/locations-ref-table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LocationsRefTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/ui/ref-search.tsx [app-client] (ecmascript)");
;
;
function LocationsRefTable(props) {
    // const [term, setTerm] = useState<string>("");
    const handleSearch = (input)=>{
        props.setTerm(input);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Выберите место:"
            }, void 0, false, {
                fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                lineNumber: 20,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                callback: handleSearch,
                term: props.term,
                elementIdPrefix: "location"
            }, void 0, false, {
                fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                lineNumber: 21,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0 flow-root",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto md:block hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "inline-block min-w-full align-middle",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-hidden rounded-md bg-gray-50 p-1 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            className: "rounded-md bg-gray-50 text-left text-sm font-normal",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 overflow-hidden px-0 py-5 font-medium sm:pl-6",
                                                        children: "Место"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                                        lineNumber: 30,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-6/16 px-3 py-5 font-medium",
                                                        children: "Название"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                                        lineNumber: 33,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                                lineNumber: 29,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                            lineNumber: 28,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                        lineNumber: 27,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                    lineNumber: 26,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            className: "divide-y divide-gray-200 text-gray-900",
                                            children: props.locations.map((location)=>(location.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap text-ellipsis bg-white py-1 pl-0 text-left     pr-3 text-sm text-black group-first-of-type:rounded-md group-last-of-type:rounded-md sm:pl-6",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-left gap-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    onClick: (e)=>{
                                                                        e.preventDefault();
                                                                        e.stopPropagation();
                                                                        props.handleSelectLocation(location.id, location.name);
                                                                        props.setTerm("");
                                                                        props.closeModal();
                                                                    },
                                                                    // href={"#"}
                                                                    className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                                    children: location.name.substring(0, 36)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                                                    lineNumber: 51,
                                                                    columnNumber: 53
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                                                lineNumber: 50,
                                                                columnNumber: 49
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                                            lineNumber: 48,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-6/16 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                            children: location.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                                            lineNumber: 64,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, location.id, true, {
                                                    fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                                    lineNumber: 47,
                                                    columnNumber: 41
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                            lineNumber: 43,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                        lineNumber: 42,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                    lineNumber: 41,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                            lineNumber: 25,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                        lineNumber: 24,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "block md:hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2",
                            children: props.locations.filter((location)=>location.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((location)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-gray-200 bg-white p-4 text-sm text-gray-900 last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium text-black",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                onClick: (e)=>{
                                                    props.handleSelectLocation(location.id, location.name);
                                                    props.setTerm("");
                                                    props.closeModal();
                                                },
                                                className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                children: location.name.substring(0, 36)
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                                lineNumber: 88,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                            lineNumber: 87,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500",
                                            children: location.name
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                            lineNumber: 99,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, location.id, true, {
                                    fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                                    lineNumber: 83,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                            lineNumber: 76,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                        lineNumber: 75,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
                lineNumber: 22,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/locations/lib/locations-ref-table.tsx",
        lineNumber: 19,
        columnNumber: 9
    }, this);
}
_c = LocationsRefTable;
var _c;
__turbopack_context__.k.register(_c, "LocationsRefTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/locations/lib/btn-locations-ref.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BtnLocationsRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import Modal from "@/app/lib/modal";
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BookOpenIcon.js [app-client] (ecmascript) <export default as BookOpenIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$locations$2f$lib$2f$locations$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/locations/lib/locations-ref-table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = Modal;
function BtnLocationsRef(props) {
    _s();
    // const locations = await fetchLocations();
    const [modal, setModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openModal = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setModal(true);
    // redirect("/dashboard/admin/tenants/1");
    };
    const closeModal = ()=>{
        // setLocation((prev) => ({
        //   ...props.location,
        // }));
        setModal(false);
    };
    const [term, setTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: openModal,
                className: "rounded-md border border-gray-200 p-2 h-10 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__["BookOpenIcon"], {
                    className: "w-5 h-5 text-gray-800"
                }, void 0, false, {
                    fileName: "[project]/app/erp/locations/lib/btn-locations-ref.tsx",
                    lineNumber: 38,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/erp/locations/lib/btn-locations-ref.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Modal, {
                open: modal,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$locations$2f$lib$2f$locations$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        locations: props.locations,
                        handleSelectLocation: props.handleSelectLocation,
                        closeModal: closeModal,
                        setTerm: setTerm,
                        term: term
                    }, void 0, false, {
                        fileName: "[project]/app/erp/locations/lib/btn-locations-ref.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between space-x-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    alert("действие!");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/app/erp/locations/lib/btn-locations-ref.tsx",
                                lineNumber: 52,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    closeModal();
                                    setTerm("");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Exit"
                            }, void 0, false, {
                                fileName: "[project]/app/erp/locations/lib/btn-locations-ref.tsx",
                                lineNumber: 60,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/locations/lib/btn-locations-ref.tsx",
                        lineNumber: 51,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/locations/lib/btn-locations-ref.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/locations/lib/btn-locations-ref.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(BtnLocationsRef, "MW/KQDlZppFu/nDnRAs8d7ejpwM=");
_c1 = BtnLocationsRef;
var _c, _c1;
__turbopack_context__.k.register(_c, "Modal");
__turbopack_context__.k.register(_c1, "BtnLocationsRef");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/common-utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "checkReadonly",
    ()=>checkReadonly,
    "formatCurrencyRUB",
    ()=>formatCurrencyRUB,
    "formatCurrencyUSD",
    ()=>formatCurrencyUSD,
    "formatDate",
    ()=>formatDate,
    "formatDateForInput",
    ()=>formatDateForInput,
    "formatDateToLocal",
    ()=>formatDateToLocal,
    "formatNumber",
    ()=>formatNumber,
    "generatePagination",
    ()=>generatePagination,
    "generateYAxis",
    ()=>generateYAxis,
    "utcISOToLocalDateTimeInput",
    ()=>utcISOToLocalDateTimeInput
]);
const checkReadonly = (userPermissions, document, pageUserId)=>{
    return userPermissions.full_access ? false : userPermissions.editor ? false : userPermissions.author && document.author_id === pageUserId ? false : userPermissions.reader ? true : true;
};
const formatCurrencyUSD = (amount)=>{
    return (amount / 100).toLocaleString("en-US", {
        style: "currency",
        currency: "USD"
    });
};
const formatDateToLocal = (dateStr, locale = "en-US")=>{
    const date = new Date(dateStr);
    const options = {
        day: "numeric",
        month: "short",
        year: "numeric"
    };
    const formatter = new Intl.DateTimeFormat(locale, options);
    return formatter.format(date);
};
const generateYAxis = (revenue)=>{
    // Calculate what labels we need to display on the y-axis
    // based on highest record and in 1000s
    const yAxisLabels = [];
    const highestRecord = Math.max(...revenue.map((month)=>month.revenue));
    const topLabel = Math.ceil(highestRecord / 1000) * 1000;
    for(let i = topLabel; i >= 0; i -= 1000){
        yAxisLabels.push(`$${i / 1000}K`);
    }
    return {
        yAxisLabels,
        topLabel
    };
};
const generatePagination = (currentPage, totalPages)=>{
    // If the total number of pages is 7 or less,
    // display all pages without any ellipsis.
    if (totalPages <= 7) {
        return Array.from({
            length: totalPages
        }, (_, i)=>i + 1);
    }
    // If the current page is among the first 3 pages,
    // show the first 3, an ellipsis, and the last 2 pages.
    if (currentPage <= 3) {
        return [
            1,
            2,
            3,
            "...",
            totalPages - 1,
            totalPages
        ];
    }
    // If the current page is among the last 3 pages,
    // show the first 2, an ellipsis, and the last 3 pages.
    if (currentPage >= totalPages - 2) {
        return [
            1,
            2,
            "...",
            totalPages - 2,
            totalPages - 1,
            totalPages
        ];
    }
    // If the current page is somewhere in the middle,
    // show the first page, an ellipsis, the current page and its neighbors,
    // another ellipsis, and the last page.
    return [
        1,
        "...",
        currentPage - 1,
        currentPage,
        currentPage + 1,
        "...",
        totalPages
    ];
};
const formatDateForInput = (date)=>{
    if (!date) return ""; // Если дата пустая, возвращаем пустую строку
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0"); // Месяцы начинаются с 0
    const day = String(d.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
};
const utcISOToLocalDateTimeInput = (isoString)=>{
    if (!isoString) return "";
    const date = new Date(isoString); // корректно парсит UTC
    // Форматируем как местное время, но в виде YYYY-MM-DDTHH:mm
    return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};
const formatNumber = (value)=>{
    const num = typeof value === "string" ? parseFloat(value) : value;
    return num.toLocaleString("ru-RU", {
        minimumFractionDigits: 3,
        maximumFractionDigits: 3
    });
};
const formatCurrencyRUB = (value)=>{
    const num = typeof value === "string" ? parseFloat(value) : value;
    return num.toLocaleString("ru-RU", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
        style: "currency",
        currency: "RUB"
    });
};
function formatDate(date) {
    const d = typeof date === "string" ? new Date(date) : date;
    return d.toLocaleDateString("ru-RU", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    });
} // export const formatDate = (date: Date | string): string => {
 //   try {
 //     const d = typeof date === "string" ? new Date(date) : date;
 //     return format(d, "dd.MM.yyyy", { locale: ru });
 //   } catch {
 //     return String(date);
 //   }
 // };
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/ui/pagination.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Pagination
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeftIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ArrowLeftIcon.js [app-client] (ecmascript) <export default as ArrowLeftIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowRightIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRightIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ArrowRightIcon.js [app-client] (ecmascript) <export default as ArrowRightIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$common$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/common-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
function Pagination({ totalPages }) {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const currentPage = Number(searchParams.get('page')) || 1;
    const createPageURL = (pageNumber)=>{
        const params = new URLSearchParams(searchParams);
        params.set('page', pageNumber.toString());
        return `${pathname}?${params.toString()}`;
    };
    const allPages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$common$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["generatePagination"])(currentPage, totalPages);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "inline-flex",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PaginationArrow, {
                    direction: "left",
                    href: createPageURL(currentPage - 1),
                    isDisabled: currentPage <= 1
                }, void 0, false, {
                    fileName: "[project]/app/ui/pagination.tsx",
                    lineNumber: 27,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex -space-x-px",
                    children: allPages.map((page, index)=>{
                        let position;
                        if (index === 0) position = 'first';
                        if (index === allPages.length - 1) position = 'last';
                        if (allPages.length === 1) position = 'single';
                        if (page === '...') position = 'middle';
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PaginationNumber, {
                            href: createPageURL(page),
                            page: page,
                            position: position,
                            isActive: currentPage === page
                        }, page, false, {
                            fileName: "[project]/app/ui/pagination.tsx",
                            lineNumber: 43,
                            columnNumber: 15
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/app/ui/pagination.tsx",
                    lineNumber: 33,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PaginationArrow, {
                    direction: "right",
                    href: createPageURL(currentPage + 1),
                    isDisabled: currentPage >= totalPages
                }, void 0, false, {
                    fileName: "[project]/app/ui/pagination.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/ui/pagination.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_s(Pagination, "AxA9T5G2Po78UC4hL8ljCdvMciE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = Pagination;
function PaginationNumber({ page, href, isActive, position }) {
    const className = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('flex h-10 w-10 items-center justify-center text-sm border border-gray-200', {
        'rounded-l-md': position === 'first' || position === 'single',
        'rounded-r-md': position === 'last' || position === 'single',
        'z-10 bg-blue-600 border-blue-600 text-white': isActive,
        'hover:bg-gray-100': !isActive && position !== 'middle',
        'text-gray-300': position === 'middle'
    });
    return isActive || position === 'middle' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        children: page
    }, void 0, false, {
        fileName: "[project]/app/ui/pagination.tsx",
        lineNumber: 87,
        columnNumber: 5
    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        className: className,
        children: page
    }, void 0, false, {
        fileName: "[project]/app/ui/pagination.tsx",
        lineNumber: 89,
        columnNumber: 5
    }, this);
}
_c1 = PaginationNumber;
function PaginationArrow({ href, direction, isDisabled }) {
    const className = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])('flex h-10 w-10 items-center justify-center rounded-md border border-gray-200', {
        'pointer-events-none text-gray-300': isDisabled,
        'hover:bg-gray-100': !isDisabled,
        'mr-2 md:mr-4': direction === 'left',
        'ml-2 md:ml-4': direction === 'right'
    });
    const icon = direction === 'left' ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeftIcon$3e$__["ArrowLeftIcon"], {
        className: "w-4"
    }, void 0, false, {
        fileName: "[project]/app/ui/pagination.tsx",
        lineNumber: 116,
        columnNumber: 7
    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowRightIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowRightIcon$3e$__["ArrowRightIcon"], {
        className: "w-4"
    }, void 0, false, {
        fileName: "[project]/app/ui/pagination.tsx",
        lineNumber: 118,
        columnNumber: 7
    }, this);
    return isDisabled ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: className,
        children: icon
    }, void 0, false, {
        fileName: "[project]/app/ui/pagination.tsx",
        lineNumber: 122,
        columnNumber: 5
    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        className: className,
        href: href,
        children: icon
    }, void 0, false, {
        fileName: "[project]/app/ui/pagination.tsx",
        lineNumber: 124,
        columnNumber: 5
    }, this);
}
_c2 = PaginationArrow;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Pagination");
__turbopack_context__.k.register(_c1, "PaginationNumber");
__turbopack_context__.k.register(_c2, "PaginationArrow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LegalEntitiesRefTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/ui/ref-search.tsx [app-client] (ecmascript)");
;
;
function LegalEntitiesRefTable(props) {
    const handleSearch = (input)=>{
        props.setTerm(input);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Выберите юрлицо:"
            }, void 0, false, {
                fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                callback: handleSearch,
                term: props.term,
                elementIdPrefix: "legalEntity"
            }, void 0, false, {
                fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0 flow-root",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto md:block hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "inline-block min-w-full align-middle",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-hidden rounded-md bg-gray-50 p-1 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            className: "rounded-md bg-gray-50 text-left text-sm font-normal",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 overflow-hidden px-0 py-5 font-medium sm:pl-6",
                                                        children: "Юрлицо"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                                        lineNumber: 29,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-6/16 px-3 py-5 font-medium",
                                                        children: "ИНН"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                                        lineNumber: 32,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                                lineNumber: 28,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                            lineNumber: 27,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                        lineNumber: 26,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                    lineNumber: 25,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            className: "divide-y divide-gray-200 text-gray-900",
                                            children: props.legalEntities.map((le)=>(le.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap text-ellipsis bg-white py-1 pl-0 text-left pr-3 text-sm text-black group-first-of-type:rounded-md group-last-of-type:rounded-md sm:pl-6",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-left gap-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    onClick: (e)=>{
                                                                        e.preventDefault();
                                                                        e.stopPropagation();
                                                                        props.handleSelectLegalEntity(le.id, le.name);
                                                                        props.setTerm("");
                                                                        props.closeModal();
                                                                    },
                                                                    className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                                    children: le.name.substring(0, 36)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                                                    lineNumber: 48,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                                                lineNumber: 47,
                                                                columnNumber: 25
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                                            lineNumber: 46,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-6/16 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                            children: le.inn
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                                            lineNumber: 60,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, le.id, true, {
                                                    fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                                    lineNumber: 45,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                            lineNumber: 41,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                        lineNumber: 40,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                    lineNumber: 39,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "block md:hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2",
                            children: props.legalEntities.filter((le)=>le.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((le)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-gray-200 bg-white p-4 text-sm text-gray-900 last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium text-black",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                onClick: (e)=>{
                                                    props.handleSelectLegalEntity(le.id, le.name);
                                                    props.setTerm("");
                                                    props.closeModal();
                                                },
                                                className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                children: le.name.substring(0, 36)
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                                lineNumber: 83,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                            lineNumber: 82,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500",
                                            children: le.inn
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                            lineNumber: 94,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, le.id, true, {
                                    fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                                    lineNumber: 78,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                            lineNumber: 71,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                        lineNumber: 70,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = LegalEntitiesRefTable;
var _c;
__turbopack_context__.k.register(_c, "LegalEntitiesRefTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BtnLegalEntitiesRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BookOpenIcon.js [app-client] (ecmascript) <export default as BookOpenIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$legal$2d$entities$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/legal-entities/lib/legal-entities-ref-table.tsx [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = Modal;
function BtnLegalEntitiesRef(props) {
    _s();
    const [modal, setModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openModal = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setModal(true);
    };
    const closeModal = ()=>{
        setModal(false);
    };
    const [term, setTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: openModal,
                className: "rounded-md border border-gray-200 p-2 h-10 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__["BookOpenIcon"], {
                    className: "w-5 h-5 text-gray-800"
                }, void 0, false, {
                    fileName: "[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx",
                    lineNumber: 32,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx",
                lineNumber: 29,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Modal, {
                open: modal,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$legal$2d$entities$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        legalEntities: props.legalEntities,
                        handleSelectLegalEntity: props.handleSelectLegalEntity,
                        closeModal: closeModal,
                        setTerm: setTerm,
                        term: term,
                        elementIdPrefix: props.elementIdPrefix
                    }, void 0, false, {
                        fileName: "[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx",
                        lineNumber: 35,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between space-x-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    alert("действие!");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx",
                                lineNumber: 44,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    closeModal();
                                    setTerm("");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Exit"
                            }, void 0, false, {
                                fileName: "[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx",
                                lineNumber: 50,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_s(BtnLegalEntitiesRef, "MW/KQDlZppFu/nDnRAs8d7ejpwM=");
_c1 = BtnLegalEntitiesRef;
var _c, _c1;
__turbopack_context__.k.register(_c, "Modal");
__turbopack_context__.k.register(_c1, "BtnLegalEntitiesRef");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/legal-entities/lib/data:c16e67 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchLegalEntityForm",
    ()=>$$RSC_SERVER_ACTION_4
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"609b7097f1500fe0e82900096a92bca025a93df013":"fetchLegalEntityForm"},"app/erp/legal-entities/lib/legal-entities-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("609b7097f1500fe0e82900096a92bca025a93df013", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "fetchLegalEntityForm");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vbGVnYWwtZW50aXRpZXMtYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWdhbEVudGl0aWVzIGFjdGlvbnNcclxuXCJ1c2Ugc2VydmVyXCI7XHJcbmltcG9ydCB7IHogfSBmcm9tIFwiem9kXCI7XHJcbmltcG9ydCBwb29sIGZyb20gXCJAL2RiXCI7XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSBcIm5leHQvY2FjaGVcIjtcclxuaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tIFwibmV4dC9uYXZpZ2F0aW9uXCI7XHJcbmltcG9ydCB7IGF1dGggfSBmcm9tIFwiQC9hdXRoXCI7XHJcbmltcG9ydCB7IExlZ2FsRW50aXR5Rm9ybSwgTGVnYWxFbnRpdHkgfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcblxyXG5jb25zdCBJVEVNU19QRVJfUEFHRSA9IDg7XHJcblxyXG4vLyNyZWdpb24gQ3JlYXRlIExlZ2FsRW50aXR5XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVMZWdhbEVudGl0eShsZWdhbEVudGl0eTogTGVnYWxFbnRpdHkpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYXV0aCgpO1xyXG4gIGNvbnN0IHVzZXJuYW1lID0gc2Vzc2lvbj8udXNlcj8ubmFtZTtcclxuICBjb25zdCB0aW1lc3RhbXB0eiA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxuICBjb25zdCB7XHJcbiAgICBuYW1lLFxyXG4gICAgZnVsbG5hbWUsXHJcbiAgICBpbm4sXHJcbiAgICBhZGRyZXNzX2xlZ2FsLFxyXG4gICAgcGhvbmUsXHJcbiAgICBlbWFpbCxcclxuICAgIGNvbnRhY3QsXHJcbiAgICBpc19jdXN0b21lcixcclxuICAgIGlzX3N1cHBsaWVyLFxyXG4gICAga3BwLFxyXG4gICAgcmVnaW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHVzZXJfdGFncyxcclxuICAgIGFjY2Vzc190YWdzLFxyXG4gICAgdGVuYW50X2lkLFxyXG4gICAgYXV0aG9yX2lkLFxyXG4gIH0gPSBsZWdhbEVudGl0eTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoXHJcbiAgICAgIGBcclxuSU5TRVJUIElOVE8gbGVnYWxfZW50aXRpZXMgKFxyXG5uYW1lLFxyXG5mdWxsbmFtZSxcclxuaW5uLFxyXG5hZGRyZXNzX2xlZ2FsLFxyXG5waG9uZSxcclxuZW1haWwsXHJcbmNvbnRhY3QsXHJcbmlzX2N1c3RvbWVyLFxyXG5pc19zdXBwbGllcixcclxua3BwLFxyXG5yZWdpb25faWQsXHJcbnNlY3Rpb25faWQsXHJcbnVzZXJfdGFncyxcclxuYWNjZXNzX3RhZ3MsXHJcbnVzZXJuYW1lLFxyXG50ZW5hbnRfaWQsXHJcbmF1dGhvcl9pZFxyXG4pIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1LCAkNiwgJDcsICQ4LCAkOSwgJDEwLCAkMTEsICQxMiwgJDEzLCAkMTQsICQxNSwgJDE2LCAkMTcpXHJcbmAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIGZ1bGxuYW1lLFxyXG4gICAgICAgIGlubixcclxuICAgICAgICBhZGRyZXNzX2xlZ2FsLFxyXG4gICAgICAgIHBob25lLFxyXG4gICAgICAgIGVtYWlsLFxyXG4gICAgICAgIGNvbnRhY3QsXHJcbiAgICAgICAgaXNfY3VzdG9tZXIsXHJcbiAgICAgICAgaXNfc3VwcGxpZXIsXHJcbiAgICAgICAga3BwLFxyXG4gICAgICAgIHJlZ2lvbl9pZCxcclxuICAgICAgICBzZWN0aW9uX2lkLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHVzZXJfdGFncyksXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoYWNjZXNzX3RhZ3MpLFxyXG4gICAgICAgIHVzZXJuYW1lLFxyXG4gICAgICAgIHRlbmFudF9pZCxcclxuICAgICAgICBhdXRob3JfaWQsXHJcbiAgICAgIF1cclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIExlZ2FsRW50aXR5OlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIExlZ2FsRW50aXR5OlwiICsgU3RyaW5nKGVycm9yKSk7XHJcbiAgfVxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL2VycC9sZWdhbC1lbnRpdGllc1wiKTtcclxufVxyXG5cclxuLy8jZW5kcmVnaW9uXHJcblxyXG4vLyNyZWdpb24gVXBkYXRlL0RlbGV0ZSBMZWdhbEVudGl0eVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlTGVnYWxFbnRpdHkobGVnYWxFbnRpdHk6IExlZ2FsRW50aXR5KSB7XHJcbiAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGF1dGgoKTtcclxuICBjb25zdCB1c2VybmFtZSA9IHNlc3Npb24/LnVzZXI/Lm5hbWU7XHJcbiAgY29uc3Qge1xyXG4gICAgaWQsXHJcbiAgICBuYW1lLFxyXG4gICAgZnVsbG5hbWUsXHJcbiAgICBpbm4sXHJcbiAgICBhZGRyZXNzX2xlZ2FsLFxyXG4gICAgcGhvbmUsXHJcbiAgICBlbWFpbCxcclxuICAgIGNvbnRhY3QsXHJcbiAgICBpc19jdXN0b21lcixcclxuICAgIGlzX3N1cHBsaWVyLFxyXG4gICAga3BwLFxyXG4gICAgcmVnaW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHVzZXJfdGFncyxcclxuICAgIGFjY2Vzc190YWdzLFxyXG4gICAgdGVuYW50X2lkLFxyXG4gICAgYXV0aG9yX2lkLFxyXG4gIH0gPSBsZWdhbEVudGl0eTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoXHJcbiAgICAgIGBcclxuVVBEQVRFIGxlZ2FsX2VudGl0aWVzIFNFVFxyXG5uYW1lID0gJDEsXHJcbmZ1bGxuYW1lID0gJDIsXHJcbmlubiA9ICQzLFxyXG5hZGRyZXNzX2xlZ2FsID0gJDQsXHJcbnBob25lID0gJDUsXHJcbmVtYWlsID0gJDYsXHJcbmNvbnRhY3QgPSAkNyxcclxuaXNfY3VzdG9tZXIgPSAkOCxcclxuaXNfc3VwcGxpZXIgPSAkOSxcclxua3BwID0gJDEwLFxyXG5yZWdpb25faWQgPSAkMTEsXHJcbnNlY3Rpb25faWQgPSAkMTIsXHJcbnVzZXJfdGFncyA9ICQxMyxcclxuYWNjZXNzX3RhZ3MgPSAkMTQsXHJcbnVzZXJuYW1lID0gJDE1LFxyXG50aW1lc3RhbXB0eiA9IG5vdygpLFxyXG50ZW5hbnRfaWQgPSAkMTYsXHJcbmF1dGhvcl9pZCA9ICQxN1xyXG5XSEVSRSBpZCA9ICQxOFxyXG5gLFxyXG4gICAgICBbXHJcbiAgICAgICAgbmFtZSxcclxuICAgICAgICBmdWxsbmFtZSxcclxuICAgICAgICBpbm4sXHJcbiAgICAgICAgYWRkcmVzc19sZWdhbCxcclxuICAgICAgICBwaG9uZSxcclxuICAgICAgICBlbWFpbCxcclxuICAgICAgICBjb250YWN0LFxyXG4gICAgICAgIGlzX2N1c3RvbWVyLFxyXG4gICAgICAgIGlzX3N1cHBsaWVyLFxyXG4gICAgICAgIGtwcCxcclxuICAgICAgICByZWdpb25faWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICBKU09OLnN0cmluZ2lmeSh1c2VyX3RhZ3MpLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KGFjY2Vzc190YWdzKSxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGlkLFxyXG4gICAgICBdXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtCx0L3QvtCy0LjRgtGMIExlZ2FsRW50aXR5OlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQntGI0LjQsdC60LAg0LHQsNC30Ysg0LTQsNC90L3Ri9GFOiDQndC1INGD0LTQsNC70L7RgdGMINC+0LHQvdC+0LLQuNGC0YwgTGVnYWxFbnRpdHk6IFwiICsgZXJyb3IpO1xyXG4gIH1cclxuICByZXZhbGlkYXRlUGF0aChcIi9lcnAvbGVnYWwtZW50aXRpZXNcIik7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVMZWdhbEVudGl0eShpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIGxlZ2FsX2VudGl0aWVzIFdIRVJFIGlkID0gJDFgLCBbaWRdKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDRg9C00LDQu9C10L3QuNGPIExlZ2FsRW50aXR5OlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgIFwi0J7RiNC40LHQutCwINCx0LDQt9GLINC00LDQvdC90YvRhTog0J3QtSDRg9C00LDQu9C+0YHRjCDRg9C00LDQu9C40YLRjCBMZWdhbEVudGl0eTogXCIgKyBTdHJpbmcoZXJyb3IpXHJcbiAgICApO1xyXG4gIH1cclxuICByZXZhbGlkYXRlUGF0aChcIi9lcnAvbGVnYWwtZW50aXRpZXNcIik7XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcblxyXG4vLyNyZWdpb24gRmV0Y2ggTGVnYWxFbnRpdGllc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMZWdhbEVudGl0eShpZDogc3RyaW5nLCBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8TGVnYWxFbnRpdHk+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5pZCxcclxubmFtZSxcclxuZnVsbG5hbWUsXHJcbmlubixcclxuYWRkcmVzc19sZWdhbCxcclxucGhvbmUsXHJcbmVtYWlsLFxyXG5jb250YWN0LFxyXG5pc19jdXN0b21lcixcclxuaXNfc3VwcGxpZXIsXHJcbmtwcCxcclxucmVnaW9uX2lkLFxyXG5zZWN0aW9uX2lkLFxyXG51c2VyX3RhZ3MsXHJcbmFjY2Vzc190YWdzLFxyXG51c2VybmFtZSxcclxuZWRpdGluZ19ieV91c2VyX2lkLFxyXG5lZGl0aW5nX3NpbmNlLFxyXG50aW1lc3RhbXB0elxyXG5GUk9NIHlvdXJfbGVnYWxfZW50aXRpZXNcclxuV0hFUkUgaWQgPSAkMjo6dXVpZFxyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgaWRdXHJcbiAgICApO1xyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0L/QvtC70YPRh9C10L3QuNGPIExlZ2FsRW50aXR5INC/0L4gSUQ6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINC/0L7Qu9GD0YfQuNGC0YwgTGVnYWxFbnRpdHk6XCIgKyBTdHJpbmcoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMZWdhbEVudGl0eUZvcm0oaWQ6IHN0cmluZywgY3VycmVudF9zZWN0aW9uczogc3RyaW5nKSB7XHJcbiAgY29uc29sZS5sb2coXCJmZXRjaExlZ2FsRW50aXR5Rm9ybSBieSBpZDpcIiwgaWQpO1xyXG4gIGNvbnNvbGUubG9nKFwiY3VycmVudF9zZWN0aW9uczpcIiwgY3VycmVudF9zZWN0aW9ucyk7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PExlZ2FsRW50aXR5Rm9ybT4oXHJcbiAgICAgIGBcclxuV0lUSCB5b3VyX2xlZ2FsX2VudGl0aWVzIEFTICggU0VMRUNUICogRlJPTSBsZWdhbF9lbnRpdGllcyB3aGVyZSBzZWN0aW9uX2lkID1cclxuQU5ZICgkMTo6dXVpZFtdKSlcclxuU0VMRUNUXHJcbmxlLmlkLFxyXG5sZS5uYW1lLFxyXG5sZS5mdWxsbmFtZSxcclxubGUuaW5uLFxyXG5sZS5hZGRyZXNzX2xlZ2FsLFxyXG5sZS5waG9uZSxcclxubGUuZW1haWwsXHJcbmxlLmNvbnRhY3QsXHJcbmxlLmlzX2N1c3RvbWVyLFxyXG5sZS5pc19zdXBwbGllcixcclxubGUua3BwLFxyXG5sZS5yZWdpb25faWQsXHJcbmxlLnNlY3Rpb25faWQsXHJcbmxlLnVzZXJfdGFncyxcclxubGUuYWNjZXNzX3RhZ3MsXHJcbmxlLnVzZXJuYW1lLFxyXG5sZS5lZGl0aW5nX2J5X3VzZXJfaWQsXHJcbmxlLmVkaXRpbmdfc2luY2UsXHJcbmxlLnRpbWVzdGFtcHR6LFxyXG5sZS50ZW5hbnRfaWQsXHJcbmxlLmF1dGhvcl9pZCxcclxubGUuZWRpdG9yX2lkLFxyXG5DT0FMRVNDRShyZWdpb25zLm5hbWUsICcnKSBhcyByZWdpb25fbmFtZSxcclxuQ09BTEVTQ0Uoc2VjdGlvbnMubmFtZSwgJycpIGFzIHNlY3Rpb25fbmFtZVxyXG5GUk9NIHlvdXJfbGVnYWxfZW50aXRpZXMgbGVcclxuTEVGVCBKT0lOIHNlY3Rpb25zIE9OIGxlLnNlY3Rpb25faWQgPSBzZWN0aW9ucy5pZFxyXG5MRUZUIEpPSU4gcmVnaW9ucyBPTiBsZS5yZWdpb25faWQgPSByZWdpb25zLmlkXHJcbldIRVJFIGxlLmlkID0gJDI6OnV1aWRcclxuYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGlkXVxyXG4gICAgKTtcclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyDRhNC+0YDQvNGLIExlZ2FsRW50aXR5OlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQv9C+0LvRg9GH0LjRgtGMINC00LDQvdC90YvQtSDRhNC+0YDQvNGLIExlZ2FsRW50aXR5OlwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoTGVnYWxFbnRpdGllcyhjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8TGVnYWxFbnRpdHk+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5pZCxcclxubmFtZSxcclxuZnVsbG5hbWUsXHJcbmlubixcclxuYWRkcmVzc19sZWdhbCxcclxucGhvbmUsXHJcbmVtYWlsLFxyXG5jb250YWN0LFxyXG5pc19jdXN0b21lcixcclxuaXNfc3VwcGxpZXIsXHJcbmtwcCxcclxucmVnaW9uX2lkLFxyXG5zZWN0aW9uX2lkLFxyXG51c2VyX3RhZ3MsXHJcbmFjY2Vzc190YWdzLFxyXG50ZW5hbnRfaWQsXHJcbmF1dGhvcl9pZCxcclxudXNlcm5hbWUsXHJcbnRpbWVzdGFtcHR6XHJcbkZST00geW91cl9sZWdhbF9lbnRpdGllc1xyXG5PUkRFUiBCWSBuYW1lIEFTQ1xyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9uc11cclxuICAgICk7XHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YHQv9C40YHQutCwINGO0YDQu9C40YY6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINC30LDQs9GA0YPQt9C40YLRjCDRgdC/0LjRgdC+0Log0Y7RgNC70LjRhjpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaExlZ2FsRW50aXRpZXNGb3JtKGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxMZWdhbEVudGl0eUZvcm0+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5sZS5pZCxcclxubGUubmFtZSxcclxubGUuZnVsbG5hbWUsXHJcbmxlLmlubixcclxubGUuYWRkcmVzc19sZWdhbCxcclxubGUucGhvbmUsXHJcbmxlLmVtYWlsLFxyXG5sZS5jb250YWN0LFxyXG5sZS5pc19jdXN0b21lcixcclxubGUuaXNfc3VwcGxpZXIsXHJcbmxlLmtwcCxcclxubGUucmVnaW9uX2lkLFxyXG5sZS5zZWN0aW9uX2lkLFxyXG5sZS51c2VyX3RhZ3MsXHJcbmxlLmFjY2Vzc190YWdzLFxyXG5sZS51c2VybmFtZSxcclxubGUuZWRpdGluZ19ieV91c2VyX2lkLFxyXG5sZS5lZGl0aW5nX3NpbmNlLFxyXG5sZS50aW1lc3RhbXB0eixcclxubGUudGVuYW50X2lkLFxyXG5sZS5hdXRob3JfaWQsXHJcbmxlLmVkaXRvcl9pZCxcclxuQ09BTEVTQ0UocmVnaW9ucy5uYW1lLCAnJykgYXMgcmVnaW9uX25hbWUsXHJcbkNPQUxFU0NFKHNlY3Rpb25zLm5hbWUsICcnKSBhcyBzZWN0aW9uX25hbWVcclxuRlJPTSB5b3VyX2xlZ2FsX2VudGl0aWVzIGxlXHJcbkxFRlQgSk9JTiBzZWN0aW9ucyBPTiBsZS5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuTEVGVCBKT0lOIHJlZ2lvbnMgT04gbGUucmVnaW9uX2lkID0gcmVnaW9ucy5pZFxyXG5PUkRFUiBCWSBsZS5uYW1lIEFTQ1xyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9uc11cclxuICAgICk7XHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YTQvtGA0LwgTGVnYWxFbnRpdGllczpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINGE0L7RgNC80YsgTGVnYWxFbnRpdGllczpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcblxyXG4vLyNyZWdpb24gRmlsdGVyZWQgTGVnYWxFbnRpdGllc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hGaWx0ZXJlZExlZ2FsRW50aXRpZXMoXHJcbiAgcXVlcnk6IHN0cmluZyxcclxuICBjdXJyZW50UGFnZTogbnVtYmVyLFxyXG4gIGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZyxcclxuICByb3dzX3Blcl9wYWdlPzogbnVtYmVyXHJcbikge1xyXG4gIGNvbnN0IG9mZnNldCA9IChjdXJyZW50UGFnZSAtIDEpICogKHJvd3NfcGVyX3BhZ2UgfHwgSVRFTVNfUEVSX1BBR0UpO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBsZWdhbEVudGl0aWVzID0gYXdhaXQgcG9vbC5xdWVyeTxMZWdhbEVudGl0eUZvcm0+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5sZS5pZCxcclxubGUubmFtZSxcclxubGUuZnVsbG5hbWUsXHJcbmxlLmlubixcclxubGUuYWRkcmVzc19sZWdhbCxcclxubGUucGhvbmUsXHJcbmxlLmVtYWlsLFxyXG5sZS5jb250YWN0LFxyXG5sZS5pc19jdXN0b21lcixcclxubGUuaXNfc3VwcGxpZXIsXHJcbmxlLmtwcCxcclxubGUucmVnaW9uX2lkLFxyXG5sZS5zZWN0aW9uX2lkLFxyXG5sZS51c2VyX3RhZ3MsXHJcbmxlLmFjY2Vzc190YWdzLFxyXG5sZS51c2VybmFtZSxcclxubGUuZWRpdGluZ19ieV91c2VyX2lkLFxyXG5sZS5lZGl0aW5nX3NpbmNlLFxyXG5sZS50aW1lc3RhbXB0eixcclxubGUudGVuYW50X2lkLFxyXG5sZS5hdXRob3JfaWQsXHJcbmxlLmVkaXRvcl9pZCxcclxuQ09BTEVTQ0UocmVnaW9ucy5uYW1lLCAnJykgYXMgcmVnaW9uX25hbWUsXHJcbkNPQUxFU0NFKHNlY3Rpb25zLm5hbWUsICcnKSBhcyBzZWN0aW9uX25hbWVcclxuRlJPTSB5b3VyX2xlZ2FsX2VudGl0aWVzIGxlXHJcbkxFRlQgSk9JTiBzZWN0aW9ucyBPTiBsZS5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuTEVGVCBKT0lOIHJlZ2lvbnMgT04gbGUucmVnaW9uX2lkID0gcmVnaW9ucy5pZFxyXG5XSEVSRVxyXG5sZS5uYW1lIElMSUtFICQyXHJcbk9SREVSIEJZIGxlLm5hbWUgQVNDXHJcbkxJTUlUICQzIE9GRlNFVCAkNFxyXG5gLFxyXG4gICAgICBbXHJcbiAgICAgICAgY3VycmVudF9zZWN0aW9ucyxcclxuICAgICAgICBgJSR7cXVlcnl9JWAsXHJcbiAgICAgICAgcm93c19wZXJfcGFnZSB8fCBJVEVNU19QRVJfUEFHRSxcclxuICAgICAgICBvZmZzZXQsXHJcbiAgICAgIF1cclxuICAgICk7XHJcbiAgICByZXR1cm4gbGVnYWxFbnRpdGllcy5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINGE0LjQu9GM0YLRgNCw0YbQuNC4IExlZ2FsRW50aXRpZXM6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgXCLQndC1INGD0LTQsNC70L7RgdGMINC30LDQs9GA0YPQt9C40YLRjCDQvtGC0YTQuNC70YzRgtGA0L7QstCw0L3QvdGL0LUgTGVnYWxFbnRpdGllczpcIiArIFN0cmluZyhlcnJvcilcclxuICAgICk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMZWdhbEVudGl0aWVzUGFnZXMoXHJcbiAgcXVlcnk6IHN0cmluZyxcclxuICBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcsXHJcbiAgcm93c19wZXJfcGFnZT86IG51bWJlclxyXG4pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY291bnQgPSBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVCBDT1VOVCgqKSBGUk9NIHlvdXJfbGVnYWxfZW50aXRpZXNcclxuV0hFUkUgbmFtZSBJTElLRSAkMlxyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgYCUke3F1ZXJ5fSVgXVxyXG4gICAgKTtcclxuICAgIGNvbnN0IHRvdGFsUGFnZXMgPSBNYXRoLmNlaWwoXHJcbiAgICAgIE51bWJlcihjb3VudC5yb3dzWzBdLmNvdW50KSAvIChyb3dzX3Blcl9wYWdlIHx8IElURU1TX1BFUl9QQUdFKVxyXG4gICAgKTtcclxuICAgIHJldHVybiB0b3RhbFBhZ2VzO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7QtNGB0YfRkdGC0LAg0YHRgtGA0LDQvdC40YYgTGVnYWxFbnRpdGllczpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtC/0YDQtdC00LXQu9C40YLRjCDQutC+0LvQuNGH0LXRgdGC0LLQviDRgdGC0YDQsNC90LjRhi5cIik7XHJcbiAgfVxyXG59XHJcbi8vI2VuZHJlZ2lvbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiNlRBdU5zQixpTUFBQSJ9
}),
"[project]/app/erp/cars/[id]/edit/car-edit-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarEditForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
// import { formatDateForInput } from "@/app/lib/common-utils";
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$sections$2f$lib$2f$btn$2d$sections$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/sections/lib/btn-sections-ref.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zod/lib/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$renderer$2f$lib$2f$react$2d$pdf$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/renderer/lib/react-pdf.browser.js [app-client] (ecmascript) <locals>");
// import BtnTaskScheduleRef from "@/app/erp/task-schedules/lib/btn-task-schedule-ref";
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$message$2d$box$2d$ok$2d$cancel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/message-box-ok-cancel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/input-field.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$data$3a$09f8e3__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/erp/cars/lib/data:09f8e3 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$data$3a$0cdc7e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/erp/cars/lib/data:0cdc7e [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f5b$id$5d2f$edit$2f$car$2d$pdf$2d$document$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/cars/[id]/edit/car-pdf-document.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$units$2f$lib$2f$btn$2d$units$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/units/lib/btn-units-ref.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$locations$2f$lib$2f$btn$2d$locations$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/locations/lib/btn-locations-ref.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$pagination$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/ui/pagination.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$btn$2d$legal$2d$entities$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/legal-entities/lib/btn-legal-entities-ref.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$data$3a$c16e67__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/erp/legal-entities/lib/data:c16e67 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
// Car EditForm
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
//#region zod schema
const CarStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].enum([
    'норма',
    'ремонт',
    'ожидание',
    'неизвестно'
]);
const DocStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].enum([
    'draft',
    'active',
    'deleted'
]);
const CarFormSchemaFull = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().uuid(),
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(2, {
        message: "Название должно содержать не менее 2-х символов."
    }),
    unit_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string(),
    unit_name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string(),
    location_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string(),
    location_name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string(),
    gos_number: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(5, {
        message: "Поле Гос.номер должно быть заполнено."
    }),
    model: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(1, {
        message: "Поле Модель должно быть заполнено."
    }),
    make: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(2, {
        message: "Поле Марка должно быть заполнено."
    }),
    vin: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(5, {
        message: "Поле VIN должно быть заполнено."
    }),
    year: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(4, {
        message: "Поле Год выпуска должно быть заполнено (4 цифры)."
    }),
    customer_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string(),
    customer_name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(1, {
        message: "Поле Клиент должно быть заполнено."
    }),
    car_status: CarStatusSchema,
    section_name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(1, {
        message: "Поле Раздел должно быть заполнено."
    }),
    section_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(1, {
        message: "Поле section_id должно быть заполнено."
    }),
    username: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().optional(),
    timestamptz: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().optional(),
    author_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string(),
    editor_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string(),
    tenant_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string(),
    editing_by_user_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().nullable(),
    editing_since: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().nullable(),
    doc_status: DocStatusSchema
});
const CarFormSchema = CarFormSchemaFull.omit({
    id: true,
    timestamptz: true,
    username: true,
    editing_by_user_id: true,
    editing_since: true
});
function CarEditForm(props) {
    _s();
    //#region unified form hooks and variables 
    const docTenantId = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().documentTenantId;
    const sessionUserId = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().sessionUser.id;
    const [showErrors, setShowErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // const [formData, setFormData] = useState<FormData>(props.premise);
    const isDocumentChanged = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsDocumentChanged"])();
    const msgBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const docChanged = ()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(true);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Документ изменен. Закрыть без сохранения?');
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CarEditForm.useEffect": ()=>{
            setFormData({
                "CarEditForm.useEffect": (prev)=>({
                        ...prev,
                        author_id: sessionUserId,
                        editor_id: sessionUserId
                    })
            }["CarEditForm.useEffect"]);
        }
    }["CarEditForm.useEffect"], [
        sessionUserId
    ]);
    //#endregion
    const currentSections = '{' + __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().userSections.map((section)=>section.id).join(',') + '}';
    const [pdfUrl, setPdfUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(props.car);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [repairReason, setRepairReason] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const customerId = searchParams.get('customer_id');
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CarEditForm.useEffect": ()=>{
            if (customerId) {
                const fetchData = {
                    "CarEditForm.useEffect.fetchData": async ()=>{
                        try {
                            setIsLoading(true);
                            setError(null);
                            const customer = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$data$3a$c16e67__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["fetchLegalEntityForm"])(customerId, currentSections);
                            setFormData({
                                "CarEditForm.useEffect.fetchData": (prev)=>({
                                        ...prev,
                                        author_id: sessionUserId,
                                        tenant_id: docTenantId,
                                        customer_id: customerId,
                                        customer_name: customer.name
                                    })
                            }["CarEditForm.useEffect.fetchData"]);
                        } catch (err) {
                            setError(err instanceof Error ? err.message : 'Произошла ошибка');
                        } finally{
                            setIsLoading(false);
                        }
                    }
                }["CarEditForm.useEffect.fetchData"];
                fetchData();
            } else {
                setFormData({
                    "CarEditForm.useEffect": (prev)=>({
                            ...prev,
                            author_id: sessionUserId,
                            tenant_id: docTenantId
                        })
                }["CarEditForm.useEffect"]);
            }
        }
    }["CarEditForm.useEffect"], [
        customerId,
        currentSections
    ]);
    const validate = ()=>{
        const res = CarFormSchema.safeParse({
            ...formData
        });
        if (res.success) {
            return undefined;
        }
        return res.error.format();
    };
    //#region handles
    const handleSubmit = async (e)=>{
        e.preventDefault();
        const errors = validate();
        if (errors) {
            setShowErrors(true);
            console.log("ошибки есть: " + JSON.stringify(errors));
            return;
        }
        try {
            if (formData.id === "") {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$data$3a$09f8e3__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["createCar"])(formData);
                // setMessageBoxText('Документ сохранен.');
                setTimeout(()=>{
                    if (window.history.length > 1) {
                        router.back();
                    } else {
                        router.push('/erp/cars');
                    }
                }, 2000);
            } else {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$data$3a$0cdc7e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updateCar"])(formData);
                router.refresh();
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Документ сохранен.');
        } catch (error) {
            // if (String(error) === 'NEXT_REDIRECT') {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Документ не сохранен! :' + String(error));
        // }
        // alert('Документ не сохранен! :' + String(error));
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(false);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
    };
    const handleBackClick = async (e)=>{
        e.preventDefault();
        if (props.unlockAction) await props.unlockAction("cars", props.car.id, sessionUserId);
        if (isDocumentChanged && !msgBox.isOKButtonPressed) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(true);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
        } else if (isDocumentChanged && msgBox.isOKButtonPressed) {} else if (!isDocumentChanged) {
            window.history.back();
        }
    };
    const handleSelectSection = (new_section_id, new_section_name, new_section_tenant_id)=>{
        setFormData((prev)=>({
                ...prev,
                section_id: new_section_id,
                section_name: new_section_name,
                tenant_id: new_section_tenant_id
            }));
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setDocumentTenantId(new_section_tenant_id);
        docChanged();
    };
    const handleSelectUnit = (new_unit_id, new_unit_name)=>{
        setFormData((prev)=>({
                ...prev,
                unit_id: new_unit_id,
                unit_name: new_unit_name
            }));
        docChanged();
    };
    function handleSelectCarStatus(event) {
        setFormData((prev)=>({
                ...prev,
                car_status: event.target.value
            }));
        docChanged();
    }
    const handleSelectLocation = (new_location_id, new_location_name)=>{
        setFormData((prev)=>({
                ...prev,
                location_id: new_location_id,
                location_name: new_location_name
            }));
        docChanged();
    };
    const handleSelectCustomer = (new_customer_id, new_customer_name)=>{
        setFormData((prev)=>({
                ...prev,
                customer_id: new_customer_id,
                customer_name: new_customer_name
            }));
        docChanged();
    };
    const handleShowPDF = async ()=>{
        try {
            // Создаем PDF из компонента PdfDocument
            const blob = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$renderer$2f$lib$2f$react$2d$pdf$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["pdf"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f5b$id$5d2f$edit$2f$car$2d$pdf$2d$document$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                formData: formData
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                lineNumber: 259,
                columnNumber: 30
            }, this)).toBlob();
            // Создаем URL для Blob-объекта
            const url = URL.createObjectURL(blob);
            setPdfUrl(url);
        } catch (error) {
            console.error('Ошибка при экспорте PDF:', error);
        }
    };
    const handleClosePDF = ()=>{
        if (pdfUrl) {
            // Освобождаем ресурсы Blob-URL
            URL.revokeObjectURL(pdfUrl);
            // Убираем iframe
            setPdfUrl(null);
        }
    };
    const handleInputChange = (field, value)=>{
        setFormData((prev)=>({
                ...prev,
                [field]: value
            }));
        docChanged();
    };
    //#endregion
    const [claimsTableKey, setClaimsTableKey] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const errors = showErrors ? validate() : undefined;
    // const handleCreateClaim = async (FormData: FormData) => {
    //   setFormData((prev) => ({
    //     ...prev,
    //     car_status: 'ремонт',
    //   }));
    //   const claim = {
    //     name: repairReason,
    //     // claim_date: new Date().toISOString(),
    //     claim_date: (function () {
    //       const d = new Date();
    //       return d.getFullYear() + '-' +
    //         String(d.getMonth() + 1).padStart(2, '0') + '-' +
    //         String(d.getDate()).padStart(2, '0');// + 'T' +
    //       // String(d.getHours()).padStart(2, '0') + ':' +
    //       // String(d.getMinutes()).padStart(2, '0');
    //     })(),
    //     priority: "низкий",
    //     car_id: formData.id,
    //     car_name: formData.name,
    //     car_car_status: formData.car_status,
    //     location_id: formData.location_id,
    //     location_name: formData.location_name,
    //     repair_todo: "",
    //     repair_reason: repairReason,
    //     breakdown_reasons: "",
    //     emergency_act: "",
    //     system_id: null,
    //     section_id: formData.section_id,
    //     section_name: formData.section_name,
    //     tenant_id: formData.tenant_id,
    //     author_id: formData.author_id,
    //     username: "",
    //     date_created: new Date(),
    //     editing_since: null,
    //     editing_by_user_id: null,
    //     // approved_date: (function () {
    //     //   const d = new Date();
    //     //   return d.getFullYear() + '-' +
    //     //     String(d.getMonth() + 1).padStart(2, '0') + '-' +
    //     //     String(d.getDate()).padStart(2, '0') + 'T' +
    //     //     String(d.getHours()).padStart(2, '0') + ':' +
    //     //     String(d.getMinutes()).padStart(2, '0');
    //     // })(),
    //     // accepted_date: (function () {
    //     //   const d = new Date();
    //     //   return d.getFullYear() + '-' +
    //     //     String(d.getMonth() + 1).padStart(2, '0') + '-' +
    //     //     String(d.getDate()).padStart(2, '0') + 'T' +
    //     //     String(d.getHours()).padStart(2, '0') + ':' +
    //     //     String(d.getMinutes()).padStart(2, '0');
    //     // })(),
    //   } as ClaimForm;
    //   try {
    //     await createClaim(claim);
    //     setClaimsTableKey(prev => prev + 1);
    //   } catch (error) {
    //     setMessageBoxText('Документ не сохранен! :' + String(error) + ' ' + JSON.stringify(claim));
    //   }
    // }
    if (isLoading) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: "Загрузка..."
    }, void 0, false, {
        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
        lineNumber: 345,
        columnNumber: 25
    }, this);
    if (error) return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            "Ошибка: ",
            error
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
        lineNumber: 346,
        columnNumber: 21
    }, this);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            !pdfUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                id: "task-form",
                onSubmit: handleSubmit,
                className: "flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col md:flex-row gap-4 w-full",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-4 w-full md:w-1/2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "name",
                                        value: formData.name,
                                        label: "Название:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('name', value),
                                        readonly: props.readonly,
                                        errors: errors?.name?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 357,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "gos_number",
                                        value: formData.gos_number,
                                        label: "Гос.номер:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('gos_number', value),
                                        readonly: props.readonly,
                                        errors: errors?.gos_number?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 365,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "make",
                                        value: formData.make,
                                        label: "Марка:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('make', value),
                                        readonly: props.readonly,
                                        errors: errors?.make?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 373,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "model",
                                        value: formData.model,
                                        label: "Модель:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('model', value),
                                        readonly: props.readonly,
                                        errors: errors?.model?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 381,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "year",
                                        value: formData.year,
                                        label: "Год выпуска:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('year', value),
                                        readonly: props.readonly,
                                        errors: errors?.year?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 389,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "vin",
                                        value: formData.vin,
                                        label: "VIN:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('vin', value),
                                        readonly: props.readonly,
                                        errors: errors?.vin?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 397,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                lineNumber: 354,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-4 w-full md:w-1/2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "customer_name",
                                        value: formData.customer_name,
                                        label: "Клиент:",
                                        type: "text",
                                        w: [
                                            "w-6/16",
                                            "w-11/16"
                                        ],
                                        onChange: ()=>{},
                                        refBook: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$btn$2d$legal$2d$entities$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            handleSelectLegalEntity: handleSelectCustomer,
                                            legalEntities: props.customers,
                                            elementIdPrefix: "customer"
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                            lineNumber: 417,
                                            columnNumber: 26
                                        }, void 0),
                                        readonly: props.readonly,
                                        errors: errors?.customer_name?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 410,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "section_name",
                                        value: formData.section_name,
                                        label: "Раздел:",
                                        type: "text",
                                        w: [
                                            "w-6/16",
                                            "w-11/16"
                                        ],
                                        // onChange={(value) => handleInputChange('section_id', value)}
                                        onChange: (value)=>{},
                                        refBook: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$sections$2f$lib$2f$btn$2d$sections$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            handleSelectSection: handleSelectSection
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                            lineNumber: 427,
                                            columnNumber: 26
                                        }, void 0),
                                        readonly: props.readonly,
                                        errors: errors?.section_name?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 423,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "unit_name",
                                        value: formData.unit_name,
                                        label: "Участок:",
                                        type: "text",
                                        w: [
                                            "w-6/16",
                                            "w-11/16"
                                        ],
                                        // onChange={(value) => handleInputChange('section_id', value)}
                                        onChange: (value)=>{},
                                        refBook: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$units$2f$lib$2f$btn$2d$units$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            handleSelectUnit: handleSelectUnit,
                                            units: props.units
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                            lineNumber: 437,
                                            columnNumber: 26
                                        }, void 0),
                                        readonly: props.readonly,
                                        errors: errors?.unit_name?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 433,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "location_name",
                                        value: formData.location_name,
                                        label: "Местоположение:",
                                        type: "text",
                                        w: [
                                            "w-6/16",
                                            "w-11/16"
                                        ],
                                        // onChange={(value) => handleInputChange('section_id', value)}
                                        onChange: (value)=>{},
                                        refBook: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$locations$2f$lib$2f$btn$2d$locations$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            handleSelectLocation: handleSelectLocation,
                                            locations: props.locations
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                            lineNumber: 447,
                                            columnNumber: 26
                                        }, void 0),
                                        readonly: props.readonly,
                                        errors: errors?.location_name?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 443,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1 flex items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "car_status",
                                                className: "text-sm font-medium flex items-center p-2",
                                                children: "Состояние:"
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                                lineNumber: 454,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                name: "car_status",
                                                id: "car_status",
                                                className: "w-full h-10 cursor-pointer rounded-md border border-gray-300 px-3 py-2 hover:bg-gray-50 focus:outline-none focus:ring focus:ring-blue-300",
                                                value: formData.car_status,
                                                onChange: (e)=>handleSelectCarStatus(e),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "",
                                                        disabled: true,
                                                        children: "Состояние"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                                        lineNumber: 461,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 'норма',
                                                        children: "норма"
                                                    }, 'норма', false, {
                                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                                        lineNumber: 464,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 'ремонт',
                                                        children: "ремонт"
                                                    }, 'ремонт', false, {
                                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                                        lineNumber: 467,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 'ожидание',
                                                        children: "ожидание"
                                                    }, 'ожидание', false, {
                                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                                        lineNumber: 470,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: 'неизвестно',
                                                        children: "неизвестно"
                                                    }, 'неизвестно', false, {
                                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                                        lineNumber: 473,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                                lineNumber: 455,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 453,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-center h-1/4 md:w-full",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                            id: "repairReason",
                                            name: "repairReason",
                                            className: "w-full break-words rounded-md border border-gray-200 p-2",
                                            disabled: props.readonly,
                                            placeholder: "Причина постановки в ремонт",
                                            value: repairReason,
                                            onChange: (e)=>setRepairReason(e.target.value)
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                            lineNumber: 481,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 480,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                lineNumber: 407,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                        lineNumber: 351,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: "form-error",
                        "aria-live": "polite",
                        "aria-atomic": "true",
                        children: errors && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-2 text-sm text-red-500",
                            children: JSON.stringify(errors)
                        }, 'form_errors', false, {
                            fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                            lineNumber: 508,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                        lineNumber: 506,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between mt-4 mr-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex w-full md:w-3/4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full md:w-1/2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        disabled: props.readonly,
                                        className: `w-full rounded-md border p-2 ${props.readonly ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-blue-400 text-white hover:bg-blue-100 hover:text-gray-500 cursor-pointer'}`,
                                        type: "submit",
                                        children: "Сохранить"
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 517,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                    lineNumber: 516,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full md:w-1/2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: handleBackClick,
                                        className: "bg-blue-400 text-white w-full rounded-md border p-2   hover:bg-blue-100 hover:text-gray-500 cursor-pointer",
                                        children: props.readonly ? 'Закрыть' : 'Закрыть и освободить'
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 528,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                    lineNumber: 527,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full md:w-1/2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: handleShowPDF,
                                        className: "bg-green-400 text-white w-full rounded-md border p-2 hover:bg-green-100 hover:text-gray-500 cursor-pointer",
                                        children: "Открыть PDF"
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                        lineNumber: 538,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                                    lineNumber: 537,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                            lineNumber: 515,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                        lineNumber: 514,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                lineNumber: 350,
                columnNumber: 9
            }, this),
            pdfUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: handleClosePDF,
                style: {
                    position: 'absolute',
                    top: '50px',
                    right: '50px',
                    padding: '5px 10px',
                    background: 'red',
                    color: 'white',
                    border: 'none',
                    borderRadius: '5px',
                    cursor: 'pointer'
                },
                children: "Закрыть PDF"
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                lineNumber: 553,
                columnNumber: 9
            }, this),
            pdfUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("iframe", {
                src: pdfUrl,
                style: {
                    width: '100%',
                    height: '1200px',
                    border: '2px solid red',
                    marginTop: '20px'
                },
                title: "PDF Preview"
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                lineNumber: 572,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-5 flex w-full justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$pagination$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    totalPages: 1
                }, void 0, false, {
                    fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                    lineNumber: 590,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                lineNumber: 589,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$message$2d$box$2d$ok$2d$cancel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
                lineNumber: 592,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/cars/[id]/edit/car-edit-form.tsx",
        lineNumber: 348,
        columnNumber: 5
    }, this);
}
_s(CarEditForm, "Uon/aDfvaRCDXt1UY+tMyJbKEhM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsDocumentChanged"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = CarEditForm;
var _c;
__turbopack_context__.k.register(_c, "CarEditForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_6b203c8c._.js.map