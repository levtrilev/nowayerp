(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_lib_common-modal_tsx_7042dcfd._.js",
  "static/chunks/[root-of-the-server]__e30fe2d4._.js",
  "static/chunks/node_modules_176c4872._.js"
],
    source: "dynamic"
});
