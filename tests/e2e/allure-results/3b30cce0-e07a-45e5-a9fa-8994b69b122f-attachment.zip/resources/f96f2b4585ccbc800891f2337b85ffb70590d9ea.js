(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/app_lib_common-modal_tsx_45dabcaf._.js",
  "static/chunks/app_lib_common-modal_tsx_1cfb1418._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);