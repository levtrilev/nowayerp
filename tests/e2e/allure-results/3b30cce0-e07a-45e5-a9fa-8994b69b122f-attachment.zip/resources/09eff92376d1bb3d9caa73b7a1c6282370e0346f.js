(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/lib/tags/data:c55f88 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchAllTags",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40daec315fd65d825c8a346303dd020af4fcd41b35":"fetchAllTags"},"app/lib/tags/tags-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40daec315fd65d825c8a346303dd020af4fcd41b35", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "fetchAllTags");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vdGFncy1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRhZ3MgYWN0aW9uc1xyXG5cclxuXCJ1c2Ugc2VydmVyXCI7XHJcblxyXG5pbXBvcnQgcG9vbCBmcm9tIFwiQC9kYlwiO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQWxsVGFncyh0ZW5hbnRfaWQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nW10+IHtcclxuICB0cnkge1xyXG4gICAgLy8g0JLQsNGA0LjQsNC90YIg0LHQtdC3INGD0YfQtdGC0LAgdGVuYW50X2lmICjQtNC70Y8g0L7RgtC70LDQtNC60LgpXHJcbiAgICAvLyAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PHsgbmFtZTogc3RyaW5nIH0+KFxyXG4gICAgLy8gICAgIGBcclxuICAgIC8vICAgICBTRUxFQ1QgbmFtZVxyXG4gICAgLy8gICAgIEZST00gdGFnc1xyXG4gICAgLy8gICAgIE9SREVSIEJZIG5hbWUgQVNDXHJcbiAgICAvLyAgIGBcclxuICAgIC8vICAgKTtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PHsgbmFtZTogc3RyaW5nIH0+KFxyXG4gICAgICBgXHJcbiAgICAgIFNFTEVDVCBuYW1lXHJcbiAgICAgIEZST00gdGFnc1xyXG4gICAgICBXSEVSRSB0ZW5hbnRfaWQgPSAkMVxyXG4gICAgICBPUkRFUiBCWSBuYW1lIEFTQ1xyXG4gICAgYCxcclxuICAgICAgW3RlbmFudF9pZF1cclxuICAgICk7XHJcbiAgICBjb25zdCB0YWdzID0gZGF0YS5yb3dzLm1hcCgocm93KSA9PiByb3cubmFtZSk7IC8vIOKGkCDQuNC30LLQu9C10LrQsNC10Lwg0YLQvtC70YzQutC+INGB0YLRgNC+0LrQuFxyXG4gICAgcmV0dXJuIHRhZ3M7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgRXJyb3I6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggYWxsIHRhZ3M6IFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cHNlcnRUYWdzKFxyXG4gIHRhZ05hbWVzOiBzdHJpbmdbXSxcclxuICB0ZW5hbnRfaWQ6IHN0cmluZ1xyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuaWYgKCF0YWdOYW1lcyB8fCB0YWdOYW1lcy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYFxyXG4gICAgICBJTlNFUlQgSU5UTyB0YWdzIChuYW1lLCB0ZW5hbnRfaWQpXHJcbiAgICAgIFNFTEVDVCB1bm5lc3QoJDE6OnRleHRbXSksICQyXHJcbiAgICAgIE9OIENPTkZMSUNUIChuYW1lLCB0ZW5hbnRfaWQpIERPIE5PVEhJTkdcclxuICAgICAgYCxcclxuICAgICAgW3RhZ05hbWVzLCB0ZW5hbnRfaWRdXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHVwc2VydCB0YWdzOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gdXBzZXJ0IHRhZ3MuXCIpO1xyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjZSQU1zQix5TEFBQSJ9
}),
"[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "setIsCancelButtonPressed",
    ()=>setIsCancelButtonPressed,
    "setIsDocumentChanged",
    ()=>setIsDocumentChanged,
    "setIsMessageBoxOpen",
    ()=>setIsMessageBoxOpen,
    "setIsOKButtonPressed",
    ()=>setIsOKButtonPressed,
    "setIsShowMessageBoxCancel",
    ()=>setIsShowMessageBoxCancel,
    "setMessageBoxText",
    ()=>setMessageBoxText,
    "useDocumentStore",
    ()=>useDocumentStore,
    "useIsDocumentChanged",
    ()=>useIsDocumentChanged,
    "useMessageBox",
    ()=>useMessageBox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const initialState = {
    messageBox: {
        isMessageBoxOpen: false,
        messageBoxText: "",
        isOKButtonPressed: false,
        isCancelButtonPressed: false,
        isShowMessageBoxCancel: false
    },
    isDocumentChanged: false,
    allTags: [],
    documentTenantId: "",
    sessionUser: {},
    userSections: []
};
const messageBoxStore = (set)=>({
        ...initialState,
        setIsMessageBoxOpen: (isMessageBoxOpen)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        isMessageBoxOpen
                    }
                }), false, "setIsMessageBoxOpen"),
        setMessageBoxText: (messageBoxText)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        messageBoxText
                    }
                }), false, "setMessageBoxText"),
        setIsOKButtonPressed: (isOKButtonPressed)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        isOKButtonPressed
                    }
                }), false, "setIsOKButtonPressed"),
        setIsCancelButtonPressed: (isCancelButtonPressed)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        isCancelButtonPressed
                    }
                }), false, "setIsCancelButtonPressed"),
        setIsShowMessageBoxCancel: (isShowMessageBoxCancel)=>set((state)=>({
                    messageBox: {
                        ...state.messageBox,
                        isShowMessageBoxCancel
                    }
                }), false, "setIsShowMessageBoxCancel"),
        setIsDocumentChanged: (isDocumentChanged)=>{
            set({
                isDocumentChanged: isDocumentChanged
            }, false, "setIsDocumentChanged");
        },
        setAllTags: (tags)=>{
            if (tags) set({
                allTags: tags
            }), "setAllTags";
        },
        // addAllTags: (newTags) => set((state) => ({ allTags: [...state.allTags, ...newTags] }), false, "addAllTags"),
        addAllTags: (newTags)=>{
            if (newTags) {
                set((state)=>({
                        allTags: Array.from(new Set([
                            ...state.allTags,
                            ...newTags
                        ])).sort((a, b)=>a.localeCompare(b, undefined, {
                                sensitivity: "base"
                            }))
                    }), false, "addAllTags");
            }
        },
        setDocumentTenantId: (docTenantId)=>{
            set({
                documentTenantId: docTenantId
            }, false, "setDocumentTenantId");
        },
        setSessionUser: (user)=>{
            set({
                sessionUser: user
            }, false, "setSessionUser");
        },
        setUserSections: (sections)=>{
            set({
                userSections: sections
            }, false, "setUserSections");
        }
    });
const useDocumentStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["immer"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devtools"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])(messageBoxStore, {
    name: "messagebox-storage",
    storage: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createJSONStorage"])(()=>localStorage),
    partialize: (state)=>({
            messageBox: state.messageBox,
            isDocumentChanged: state.isDocumentChanged,
            allTags: state.allTags,
            documentTenantId: state.documentTenantId,
            sessionUser: state.sessionUser,
            userSections: state.userSections
        })
}), {
    name: "Document"
})));
const useMessageBox = ()=>{
    _s();
    return useDocumentStore({
        "useMessageBox.useDocumentStore": (state)=>state.messageBox
    }["useMessageBox.useDocumentStore"]);
};
_s(useMessageBox, "YBOcV9vipWfdFGkpNROIlwHjiag=", false, function() {
    return [
        useDocumentStore
    ];
});
const useIsDocumentChanged = ()=>{
    _s1();
    return useDocumentStore({
        "useIsDocumentChanged.useDocumentStore": (state)=>state.isDocumentChanged
    }["useIsDocumentChanged.useDocumentStore"]);
};
_s1(useIsDocumentChanged, "YBOcV9vipWfdFGkpNROIlwHjiag=", false, function() {
    return [
        useDocumentStore
    ];
});
const setIsMessageBoxOpen = (isMessageBoxOpen)=>useDocumentStore.getState().setIsMessageBoxOpen(isMessageBoxOpen);
const setMessageBoxText = (messageBoxText)=>useDocumentStore.getState().setMessageBoxText(messageBoxText);
const setIsOKButtonPressed = (isOKButtonPressed)=>useDocumentStore.getState().setIsOKButtonPressed(isOKButtonPressed);
const setIsCancelButtonPressed = (isCancelButtonPressed)=>useDocumentStore.getState().setIsCancelButtonPressed(isCancelButtonPressed);
const setIsShowMessageBoxCancel = (isShowMessageBoxCancel)=>useDocumentStore.getState().setIsShowMessageBoxCancel(isShowMessageBoxCancel);
const setIsDocumentChanged = (isDocumentChanged)=>useDocumentStore.getState().setIsDocumentChanged(isDocumentChanged);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/doc-wrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>DocWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$c55f88__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/lib/tags/data:c55f88 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function DocWrapper(props) {
    _s();
    const docTenantId = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().documentTenantId;
    // const isDocumentChanged = useIsDocumentChanged();
    const msgBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"])();
    //#region sessionUser & userSections
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            const initializeStoreUser = {
                "DocWrapper.useEffect.initializeStoreUser": ()=>{
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().sessionUser.id !== props.pageUser.id) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setSessionUser(props.pageUser);
                    }
                }
            }["DocWrapper.useEffect.initializeStoreUser"];
            initializeStoreUser();
        }
    }["DocWrapper.useEffect"], [
        props.pageUser
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            const initializeStoreUserSections = {
                "DocWrapper.useEffect.initializeStoreUserSections": ()=>{
                    if (props.userSections) {
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setUserSections(props.userSections);
                    }
                }
            }["DocWrapper.useEffect.initializeStoreUserSections"];
            initializeStoreUserSections();
        }
    }["DocWrapper.useEffect"], [
        props.userSections
    ]);
    //#endregion
    //#region tenant_id and tags  
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            const fetchAndSetTags = {
                "DocWrapper.useEffect.fetchAndSetTags": async ()=>{
                    try {
                        const tags = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$c55f88__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["fetchAllTags"])(props.docTenantId);
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setAllTags(tags);
                    } catch (error) {
                        console.error('Failed to fetch all tags: ', error);
                    }
                }
            }["DocWrapper.useEffect.fetchAndSetTags"];
            if (props.docTenantId) {
                __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setDocumentTenantId(props.docTenantId);
                fetchAndSetTags();
            }
        }
    }["DocWrapper.useEffect"], [
        props.docTenantId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            const fetchAndSetTags = {
                "DocWrapper.useEffect.fetchAndSetTags": async ()=>{
                    try {
                        const tags = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$c55f88__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["fetchAllTags"])(docTenantId);
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setAllTags(tags);
                    } catch (error) {
                        console.error('Failed to fetch all tags: ', error);
                    }
                }
            }["DocWrapper.useEffect.fetchAndSetTags"];
            if (docTenantId) fetchAndSetTags();
        }
    }["DocWrapper.useEffect"], [
        docTenantId
    ]);
    //#endregion
    //#region msgBox
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            return ({
                "DocWrapper.useEffect": ()=>{
                    // Сброс при уходе со страницы
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(false);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(false);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(false);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(true);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('');
                }
            })["DocWrapper.useEffect"];
        }
    }["DocWrapper.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocWrapper.useEffect": ()=>{
            if (msgBox.isOKButtonPressed && msgBox.messageBoxText === 'Документ изменен. Закрыть без сохранения?') {
                // router.push('/erp/premises/');
                window.history.back();
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(true);
        }
    }["DocWrapper.useEffect"], [
        msgBox.isOKButtonPressed
    ]);
    //#endregion
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: props.children
    }, void 0, false);
}
_s(DocWrapper, "Y4761O/iB5XZYunqLW+hOJxOZSM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"]
    ];
});
_c = DocWrapper;
var _c;
__turbopack_context__.k.register(_c, "DocWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/message-box-ok-cancel.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import { setIsCancelButtonPressed, setIsMessageBoxOpen, setIsOKButtonPressed, useIsMessageBoxOpen, useIsShowMessageBoxCancel, useMessageBoxText } from "@/app/store/useMessageBoxStore";
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
const MessageBoxOKCancel = ()=>{
    _s();
    // const isMessageBoxOpen = useIsMessageBoxOpen();
    // const messageBoxText = useMessageBoxText();
    // const isShowMessageBoxCancel = useIsShowMessageBoxCancel();
    const msgBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"])();
    if (!msgBox.isMessageBoxOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "message-box",
        className: "fixed inset-0 flex items-center justify-center z-50",
        style: {
            backgroundColor: 'rgba(0, 0, 0, 0.3)'
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white p-6 rounded-lg shadow-lg max-w-md w-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-lg mb-4 whitespace-pre-line",
                    children: String(msgBox.messageBoxText)
                }, void 0, false, {
                    fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end space-x-3",
                    children: [
                        msgBox.isShowMessageBoxCancel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>{
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(false);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(true);
                            },
                            className: "px-4 py-2 bg-gray-300 rounded-md hover:bg-gray-400 focus:outline-none",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
                            lineNumber: 18,
                            columnNumber: 45
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>{
                                if (msgBox.messageBoxText === 'Документ сохранен.') {
                                    // Просто закрываем, НЕ устанавливая isOKButtonPressed
                                    // setIsMessageBoxOpen(false);
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('');
                                } else {
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(true);
                                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(false);
                                }
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
                            },
                            className: "px-4 py-2 bg-red-300 text-white rounded-md hover:bg-red-700 focus:outline-none",
                            children: "OK"
                        }, void 0, false, {
                            fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
            lineNumber: 15,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/lib/message-box-ok-cancel.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(MessageBoxOKCancel, "ioouC6guqMTbpgyYuZWcuoqNjg4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"]
    ];
});
_c = MessageBoxOKCancel;
const __TURBOPACK__default__export__ = MessageBoxOKCancel;
var _c;
__turbopack_context__.k.register(_c, "MessageBoxOKCancel");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/tags/tag-store.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createTagStore",
    ()=>createTagStore,
    "useAccessTagStore",
    ()=>useAccessTagStore,
    "useTagStore",
    ()=>useTagStore,
    "useUserTagStore",
    ()=>useUserTagStore
]);
// Хранилище для автозаполнения и выбранных тегов
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
;
const createTagStore = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
            // allTags: [],
            selectedTags: [],
            input: "",
            // setAllTags: (tags) => set({ allTags: tags }),
            setInput: (input)=>set({
                    input
                }),
            addTag: (tag)=>{
                const normalized = tag.trim().toLowerCase();
                if (!normalized || get().selectedTags.includes(normalized)) return;
                set((state)=>({
                        selectedTags: [
                            ...state.selectedTags,
                            normalized
                        ],
                        input: ""
                    }));
            },
            removeTag: (tag)=>set((state)=>({
                        selectedTags: state.selectedTags.filter((t)=>t !== tag)
                    })),
            setSelectedTags: (tags)=>{
                if (!tags) return;
                set({
                    selectedTags: tags.map((t)=>t.trim().toLowerCase())
                });
            },
            getSuggestions: ()=>{
                const allTags = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().allTags; // добавлено
                // const { allTags, selectedTags, input } = get();
                const { selectedTags, input } = get(); // изменено
                if (!input) return [];
                const filtered = allTags.filter((tag)=>!selectedTags.includes(tag)).filter((tag)=>tag.toLowerCase().includes(input.toLowerCase()));
                return filtered.slice(0, 5);
            }
        }));
const useTagStore = createTagStore();
const useAccessTagStore = createTagStore();
const useUserTagStore = createTagStore();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/input-field.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const InputField = ({ label, name, value, w, type, onChange, refBook, readonly, errors, textArea, placeholder })=>{
    const labelClassName = `${w[0]} text-sm text-blue-900 font-medium flex items-center p-2`;
    // const inputClassName = `${w[1]} ${moreInputClassName} control rounded-md border border-gray-200 p-2`;
    // `${inputClassName} break-words`
    const inputClassName = `${w[1]} disabled:text-gray-400 disabled:bg-gray-100 break-words control rounded-md border border-gray-200 p-2`;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex-col",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between mt-1",
                children: [
                    label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: name,
                        className: labelClassName,
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/app/lib/input-field.tsx",
                        lineNumber: 40,
                        columnNumber: 27
                    }, ("TURBOPACK compile-time value", void 0)),
                    !textArea && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        id: name,
                        type: type,
                        name: name,
                        className: inputClassName,
                        disabled: readonly,
                        value: value,
                        placeholder: placeholder,
                        onChange: type !== "date" ? (e)=>onChange(e.target.value) : (e)=>onChange(new Date(e.target.value))
                    }, void 0, false, {
                        fileName: "[project]/app/lib/input-field.tsx",
                        lineNumber: 46,
                        columnNumber: 31
                    }, ("TURBOPACK compile-time value", void 0)),
                    textArea && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        id: name,
                        // type={type}
                        name: name,
                        // className={inputClassName}
                        disabled: readonly,
                        value: value,
                        onChange: type !== "date" ? (e)=>onChange(e.target.value) : (e)=>onChange(new Date(e.target.value)),
                        className: "w-full break-words rounded-md border border-gray-200 p-2"
                    }, void 0, false, {
                        fileName: "[project]/app/lib/input-field.tsx",
                        lineNumber: 58,
                        columnNumber: 30
                    }, ("TURBOPACK compile-time value", void 0)),
                    !readonly && refBook
                ]
            }, void 0, true, {
                fileName: "[project]/app/lib/input-field.tsx",
                lineNumber: 39,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: `${name}-error`,
                "aria-live": "polite",
                "aria-atomic": "true",
                children: errors && errors.map((error, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "mt-2 text-xs text-red-500",
                        children: error
                    }, index, false, {
                        fileName: "[project]/app/lib/input-field.tsx",
                        lineNumber: 76,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/app/lib/input-field.tsx",
                lineNumber: 73,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/lib/input-field.tsx",
        lineNumber: 37,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = InputField;
const __TURBOPACK__default__export__ = InputField;
var _c;
__turbopack_context__.k.register(_c, "InputField");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/legal-entities/lib/data:f8bce7 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createLegalEntity",
    ()=>$$RSC_SERVER_ACTION_0
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"4016eeb0765014a04ccb23e8f1fdc20fbaee3de0ca":"createLegalEntity"},"app/erp/legal-entities/lib/legal-entities-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_0 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4016eeb0765014a04ccb23e8f1fdc20fbaee3de0ca", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createLegalEntity");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vbGVnYWwtZW50aXRpZXMtYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWdhbEVudGl0aWVzIGFjdGlvbnNcclxuXCJ1c2Ugc2VydmVyXCI7XHJcbmltcG9ydCB7IHogfSBmcm9tIFwiem9kXCI7XHJcbmltcG9ydCBwb29sIGZyb20gXCJAL2RiXCI7XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSBcIm5leHQvY2FjaGVcIjtcclxuaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tIFwibmV4dC9uYXZpZ2F0aW9uXCI7XHJcbmltcG9ydCB7IGF1dGggfSBmcm9tIFwiQC9hdXRoXCI7XHJcbmltcG9ydCB7IExlZ2FsRW50aXR5Rm9ybSwgTGVnYWxFbnRpdHkgfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcblxyXG5jb25zdCBJVEVNU19QRVJfUEFHRSA9IDg7XHJcblxyXG4vLyNyZWdpb24gQ3JlYXRlIExlZ2FsRW50aXR5XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVMZWdhbEVudGl0eShsZWdhbEVudGl0eTogTGVnYWxFbnRpdHkpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYXV0aCgpO1xyXG4gIGNvbnN0IHVzZXJuYW1lID0gc2Vzc2lvbj8udXNlcj8ubmFtZTtcclxuICBjb25zdCB0aW1lc3RhbXB0eiA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxuICBjb25zdCB7XHJcbiAgICBuYW1lLFxyXG4gICAgZnVsbG5hbWUsXHJcbiAgICBpbm4sXHJcbiAgICBhZGRyZXNzX2xlZ2FsLFxyXG4gICAgcGhvbmUsXHJcbiAgICBlbWFpbCxcclxuICAgIGNvbnRhY3QsXHJcbiAgICBpc19jdXN0b21lcixcclxuICAgIGlzX3N1cHBsaWVyLFxyXG4gICAga3BwLFxyXG4gICAgcmVnaW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHVzZXJfdGFncyxcclxuICAgIGFjY2Vzc190YWdzLFxyXG4gICAgdGVuYW50X2lkLFxyXG4gICAgYXV0aG9yX2lkLFxyXG4gIH0gPSBsZWdhbEVudGl0eTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoXHJcbiAgICAgIGBcclxuSU5TRVJUIElOVE8gbGVnYWxfZW50aXRpZXMgKFxyXG5uYW1lLFxyXG5mdWxsbmFtZSxcclxuaW5uLFxyXG5hZGRyZXNzX2xlZ2FsLFxyXG5waG9uZSxcclxuZW1haWwsXHJcbmNvbnRhY3QsXHJcbmlzX2N1c3RvbWVyLFxyXG5pc19zdXBwbGllcixcclxua3BwLFxyXG5yZWdpb25faWQsXHJcbnNlY3Rpb25faWQsXHJcbnVzZXJfdGFncyxcclxuYWNjZXNzX3RhZ3MsXHJcbnVzZXJuYW1lLFxyXG50ZW5hbnRfaWQsXHJcbmF1dGhvcl9pZFxyXG4pIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1LCAkNiwgJDcsICQ4LCAkOSwgJDEwLCAkMTEsICQxMiwgJDEzLCAkMTQsICQxNSwgJDE2LCAkMTcpXHJcbmAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIGZ1bGxuYW1lLFxyXG4gICAgICAgIGlubixcclxuICAgICAgICBhZGRyZXNzX2xlZ2FsLFxyXG4gICAgICAgIHBob25lLFxyXG4gICAgICAgIGVtYWlsLFxyXG4gICAgICAgIGNvbnRhY3QsXHJcbiAgICAgICAgaXNfY3VzdG9tZXIsXHJcbiAgICAgICAgaXNfc3VwcGxpZXIsXHJcbiAgICAgICAga3BwLFxyXG4gICAgICAgIHJlZ2lvbl9pZCxcclxuICAgICAgICBzZWN0aW9uX2lkLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHVzZXJfdGFncyksXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoYWNjZXNzX3RhZ3MpLFxyXG4gICAgICAgIHVzZXJuYW1lLFxyXG4gICAgICAgIHRlbmFudF9pZCxcclxuICAgICAgICBhdXRob3JfaWQsXHJcbiAgICAgIF1cclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIExlZ2FsRW50aXR5OlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIExlZ2FsRW50aXR5OlwiICsgU3RyaW5nKGVycm9yKSk7XHJcbiAgfVxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL2VycC9sZWdhbC1lbnRpdGllc1wiKTtcclxufVxyXG5cclxuLy8jZW5kcmVnaW9uXHJcblxyXG4vLyNyZWdpb24gVXBkYXRlL0RlbGV0ZSBMZWdhbEVudGl0eVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlTGVnYWxFbnRpdHkobGVnYWxFbnRpdHk6IExlZ2FsRW50aXR5KSB7XHJcbiAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGF1dGgoKTtcclxuICBjb25zdCB1c2VybmFtZSA9IHNlc3Npb24/LnVzZXI/Lm5hbWU7XHJcbiAgY29uc3Qge1xyXG4gICAgaWQsXHJcbiAgICBuYW1lLFxyXG4gICAgZnVsbG5hbWUsXHJcbiAgICBpbm4sXHJcbiAgICBhZGRyZXNzX2xlZ2FsLFxyXG4gICAgcGhvbmUsXHJcbiAgICBlbWFpbCxcclxuICAgIGNvbnRhY3QsXHJcbiAgICBpc19jdXN0b21lcixcclxuICAgIGlzX3N1cHBsaWVyLFxyXG4gICAga3BwLFxyXG4gICAgcmVnaW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHVzZXJfdGFncyxcclxuICAgIGFjY2Vzc190YWdzLFxyXG4gICAgdGVuYW50X2lkLFxyXG4gICAgYXV0aG9yX2lkLFxyXG4gIH0gPSBsZWdhbEVudGl0eTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoXHJcbiAgICAgIGBcclxuVVBEQVRFIGxlZ2FsX2VudGl0aWVzIFNFVFxyXG5uYW1lID0gJDEsXHJcbmZ1bGxuYW1lID0gJDIsXHJcbmlubiA9ICQzLFxyXG5hZGRyZXNzX2xlZ2FsID0gJDQsXHJcbnBob25lID0gJDUsXHJcbmVtYWlsID0gJDYsXHJcbmNvbnRhY3QgPSAkNyxcclxuaXNfY3VzdG9tZXIgPSAkOCxcclxuaXNfc3VwcGxpZXIgPSAkOSxcclxua3BwID0gJDEwLFxyXG5yZWdpb25faWQgPSAkMTEsXHJcbnNlY3Rpb25faWQgPSAkMTIsXHJcbnVzZXJfdGFncyA9ICQxMyxcclxuYWNjZXNzX3RhZ3MgPSAkMTQsXHJcbnVzZXJuYW1lID0gJDE1LFxyXG50aW1lc3RhbXB0eiA9IG5vdygpLFxyXG50ZW5hbnRfaWQgPSAkMTYsXHJcbmF1dGhvcl9pZCA9ICQxN1xyXG5XSEVSRSBpZCA9ICQxOFxyXG5gLFxyXG4gICAgICBbXHJcbiAgICAgICAgbmFtZSxcclxuICAgICAgICBmdWxsbmFtZSxcclxuICAgICAgICBpbm4sXHJcbiAgICAgICAgYWRkcmVzc19sZWdhbCxcclxuICAgICAgICBwaG9uZSxcclxuICAgICAgICBlbWFpbCxcclxuICAgICAgICBjb250YWN0LFxyXG4gICAgICAgIGlzX2N1c3RvbWVyLFxyXG4gICAgICAgIGlzX3N1cHBsaWVyLFxyXG4gICAgICAgIGtwcCxcclxuICAgICAgICByZWdpb25faWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICBKU09OLnN0cmluZ2lmeSh1c2VyX3RhZ3MpLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KGFjY2Vzc190YWdzKSxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGlkLFxyXG4gICAgICBdXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtCx0L3QvtCy0LjRgtGMIExlZ2FsRW50aXR5OlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQntGI0LjQsdC60LAg0LHQsNC30Ysg0LTQsNC90L3Ri9GFOiDQndC1INGD0LTQsNC70L7RgdGMINC+0LHQvdC+0LLQuNGC0YwgTGVnYWxFbnRpdHk6IFwiICsgZXJyb3IpO1xyXG4gIH1cclxuICByZXZhbGlkYXRlUGF0aChcIi9lcnAvbGVnYWwtZW50aXRpZXNcIik7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVMZWdhbEVudGl0eShpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIGxlZ2FsX2VudGl0aWVzIFdIRVJFIGlkID0gJDFgLCBbaWRdKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDRg9C00LDQu9C10L3QuNGPIExlZ2FsRW50aXR5OlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgIFwi0J7RiNC40LHQutCwINCx0LDQt9GLINC00LDQvdC90YvRhTog0J3QtSDRg9C00LDQu9C+0YHRjCDRg9C00LDQu9C40YLRjCBMZWdhbEVudGl0eTogXCIgKyBTdHJpbmcoZXJyb3IpXHJcbiAgICApO1xyXG4gIH1cclxuICByZXZhbGlkYXRlUGF0aChcIi9lcnAvbGVnYWwtZW50aXRpZXNcIik7XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcblxyXG4vLyNyZWdpb24gRmV0Y2ggTGVnYWxFbnRpdGllc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMZWdhbEVudGl0eShpZDogc3RyaW5nLCBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8TGVnYWxFbnRpdHk+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5pZCxcclxubmFtZSxcclxuZnVsbG5hbWUsXHJcbmlubixcclxuYWRkcmVzc19sZWdhbCxcclxucGhvbmUsXHJcbmVtYWlsLFxyXG5jb250YWN0LFxyXG5pc19jdXN0b21lcixcclxuaXNfc3VwcGxpZXIsXHJcbmtwcCxcclxucmVnaW9uX2lkLFxyXG5zZWN0aW9uX2lkLFxyXG51c2VyX3RhZ3MsXHJcbmFjY2Vzc190YWdzLFxyXG51c2VybmFtZSxcclxuZWRpdGluZ19ieV91c2VyX2lkLFxyXG5lZGl0aW5nX3NpbmNlLFxyXG50aW1lc3RhbXB0elxyXG5GUk9NIHlvdXJfbGVnYWxfZW50aXRpZXNcclxuV0hFUkUgaWQgPSAkMjo6dXVpZFxyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgaWRdXHJcbiAgICApO1xyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0L/QvtC70YPRh9C10L3QuNGPIExlZ2FsRW50aXR5INC/0L4gSUQ6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINC/0L7Qu9GD0YfQuNGC0YwgTGVnYWxFbnRpdHk6XCIgKyBTdHJpbmcoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMZWdhbEVudGl0eUZvcm0oaWQ6IHN0cmluZywgY3VycmVudF9zZWN0aW9uczogc3RyaW5nKSB7XHJcbiAgY29uc29sZS5sb2coXCJmZXRjaExlZ2FsRW50aXR5Rm9ybSBieSBpZDpcIiwgaWQpO1xyXG4gIGNvbnNvbGUubG9nKFwiY3VycmVudF9zZWN0aW9uczpcIiwgY3VycmVudF9zZWN0aW9ucyk7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PExlZ2FsRW50aXR5Rm9ybT4oXHJcbiAgICAgIGBcclxuV0lUSCB5b3VyX2xlZ2FsX2VudGl0aWVzIEFTICggU0VMRUNUICogRlJPTSBsZWdhbF9lbnRpdGllcyB3aGVyZSBzZWN0aW9uX2lkID1cclxuQU5ZICgkMTo6dXVpZFtdKSlcclxuU0VMRUNUXHJcbmxlLmlkLFxyXG5sZS5uYW1lLFxyXG5sZS5mdWxsbmFtZSxcclxubGUuaW5uLFxyXG5sZS5hZGRyZXNzX2xlZ2FsLFxyXG5sZS5waG9uZSxcclxubGUuZW1haWwsXHJcbmxlLmNvbnRhY3QsXHJcbmxlLmlzX2N1c3RvbWVyLFxyXG5sZS5pc19zdXBwbGllcixcclxubGUua3BwLFxyXG5sZS5yZWdpb25faWQsXHJcbmxlLnNlY3Rpb25faWQsXHJcbmxlLnVzZXJfdGFncyxcclxubGUuYWNjZXNzX3RhZ3MsXHJcbmxlLnVzZXJuYW1lLFxyXG5sZS5lZGl0aW5nX2J5X3VzZXJfaWQsXHJcbmxlLmVkaXRpbmdfc2luY2UsXHJcbmxlLnRpbWVzdGFtcHR6LFxyXG5sZS50ZW5hbnRfaWQsXHJcbmxlLmF1dGhvcl9pZCxcclxubGUuZWRpdG9yX2lkLFxyXG5DT0FMRVNDRShyZWdpb25zLm5hbWUsICcnKSBhcyByZWdpb25fbmFtZSxcclxuQ09BTEVTQ0Uoc2VjdGlvbnMubmFtZSwgJycpIGFzIHNlY3Rpb25fbmFtZVxyXG5GUk9NIHlvdXJfbGVnYWxfZW50aXRpZXMgbGVcclxuTEVGVCBKT0lOIHNlY3Rpb25zIE9OIGxlLnNlY3Rpb25faWQgPSBzZWN0aW9ucy5pZFxyXG5MRUZUIEpPSU4gcmVnaW9ucyBPTiBsZS5yZWdpb25faWQgPSByZWdpb25zLmlkXHJcbldIRVJFIGxlLmlkID0gJDI6OnV1aWRcclxuYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGlkXVxyXG4gICAgKTtcclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyDRhNC+0YDQvNGLIExlZ2FsRW50aXR5OlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQv9C+0LvRg9GH0LjRgtGMINC00LDQvdC90YvQtSDRhNC+0YDQvNGLIExlZ2FsRW50aXR5OlwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoTGVnYWxFbnRpdGllcyhjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8TGVnYWxFbnRpdHk+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5pZCxcclxubmFtZSxcclxuZnVsbG5hbWUsXHJcbmlubixcclxuYWRkcmVzc19sZWdhbCxcclxucGhvbmUsXHJcbmVtYWlsLFxyXG5jb250YWN0LFxyXG5pc19jdXN0b21lcixcclxuaXNfc3VwcGxpZXIsXHJcbmtwcCxcclxucmVnaW9uX2lkLFxyXG5zZWN0aW9uX2lkLFxyXG51c2VyX3RhZ3MsXHJcbmFjY2Vzc190YWdzLFxyXG50ZW5hbnRfaWQsXHJcbmF1dGhvcl9pZCxcclxudXNlcm5hbWUsXHJcbnRpbWVzdGFtcHR6XHJcbkZST00geW91cl9sZWdhbF9lbnRpdGllc1xyXG5PUkRFUiBCWSBuYW1lIEFTQ1xyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9uc11cclxuICAgICk7XHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YHQv9C40YHQutCwINGO0YDQu9C40YY6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINC30LDQs9GA0YPQt9C40YLRjCDRgdC/0LjRgdC+0Log0Y7RgNC70LjRhjpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaExlZ2FsRW50aXRpZXNGb3JtKGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxMZWdhbEVudGl0eUZvcm0+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5sZS5pZCxcclxubGUubmFtZSxcclxubGUuZnVsbG5hbWUsXHJcbmxlLmlubixcclxubGUuYWRkcmVzc19sZWdhbCxcclxubGUucGhvbmUsXHJcbmxlLmVtYWlsLFxyXG5sZS5jb250YWN0LFxyXG5sZS5pc19jdXN0b21lcixcclxubGUuaXNfc3VwcGxpZXIsXHJcbmxlLmtwcCxcclxubGUucmVnaW9uX2lkLFxyXG5sZS5zZWN0aW9uX2lkLFxyXG5sZS51c2VyX3RhZ3MsXHJcbmxlLmFjY2Vzc190YWdzLFxyXG5sZS51c2VybmFtZSxcclxubGUuZWRpdGluZ19ieV91c2VyX2lkLFxyXG5sZS5lZGl0aW5nX3NpbmNlLFxyXG5sZS50aW1lc3RhbXB0eixcclxubGUudGVuYW50X2lkLFxyXG5sZS5hdXRob3JfaWQsXHJcbmxlLmVkaXRvcl9pZCxcclxuQ09BTEVTQ0UocmVnaW9ucy5uYW1lLCAnJykgYXMgcmVnaW9uX25hbWUsXHJcbkNPQUxFU0NFKHNlY3Rpb25zLm5hbWUsICcnKSBhcyBzZWN0aW9uX25hbWVcclxuRlJPTSB5b3VyX2xlZ2FsX2VudGl0aWVzIGxlXHJcbkxFRlQgSk9JTiBzZWN0aW9ucyBPTiBsZS5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuTEVGVCBKT0lOIHJlZ2lvbnMgT04gbGUucmVnaW9uX2lkID0gcmVnaW9ucy5pZFxyXG5PUkRFUiBCWSBsZS5uYW1lIEFTQ1xyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9uc11cclxuICAgICk7XHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YTQvtGA0LwgTGVnYWxFbnRpdGllczpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINGE0L7RgNC80YsgTGVnYWxFbnRpdGllczpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcblxyXG4vLyNyZWdpb24gRmlsdGVyZWQgTGVnYWxFbnRpdGllc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hGaWx0ZXJlZExlZ2FsRW50aXRpZXMoXHJcbiAgcXVlcnk6IHN0cmluZyxcclxuICBjdXJyZW50UGFnZTogbnVtYmVyLFxyXG4gIGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZyxcclxuICByb3dzX3Blcl9wYWdlPzogbnVtYmVyXHJcbikge1xyXG4gIGNvbnN0IG9mZnNldCA9IChjdXJyZW50UGFnZSAtIDEpICogKHJvd3NfcGVyX3BhZ2UgfHwgSVRFTVNfUEVSX1BBR0UpO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBsZWdhbEVudGl0aWVzID0gYXdhaXQgcG9vbC5xdWVyeTxMZWdhbEVudGl0eUZvcm0+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5sZS5pZCxcclxubGUubmFtZSxcclxubGUuZnVsbG5hbWUsXHJcbmxlLmlubixcclxubGUuYWRkcmVzc19sZWdhbCxcclxubGUucGhvbmUsXHJcbmxlLmVtYWlsLFxyXG5sZS5jb250YWN0LFxyXG5sZS5pc19jdXN0b21lcixcclxubGUuaXNfc3VwcGxpZXIsXHJcbmxlLmtwcCxcclxubGUucmVnaW9uX2lkLFxyXG5sZS5zZWN0aW9uX2lkLFxyXG5sZS51c2VyX3RhZ3MsXHJcbmxlLmFjY2Vzc190YWdzLFxyXG5sZS51c2VybmFtZSxcclxubGUuZWRpdGluZ19ieV91c2VyX2lkLFxyXG5sZS5lZGl0aW5nX3NpbmNlLFxyXG5sZS50aW1lc3RhbXB0eixcclxubGUudGVuYW50X2lkLFxyXG5sZS5hdXRob3JfaWQsXHJcbmxlLmVkaXRvcl9pZCxcclxuQ09BTEVTQ0UocmVnaW9ucy5uYW1lLCAnJykgYXMgcmVnaW9uX25hbWUsXHJcbkNPQUxFU0NFKHNlY3Rpb25zLm5hbWUsICcnKSBhcyBzZWN0aW9uX25hbWVcclxuRlJPTSB5b3VyX2xlZ2FsX2VudGl0aWVzIGxlXHJcbkxFRlQgSk9JTiBzZWN0aW9ucyBPTiBsZS5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuTEVGVCBKT0lOIHJlZ2lvbnMgT04gbGUucmVnaW9uX2lkID0gcmVnaW9ucy5pZFxyXG5XSEVSRVxyXG5sZS5uYW1lIElMSUtFICQyXHJcbk9SREVSIEJZIGxlLm5hbWUgQVNDXHJcbkxJTUlUICQzIE9GRlNFVCAkNFxyXG5gLFxyXG4gICAgICBbXHJcbiAgICAgICAgY3VycmVudF9zZWN0aW9ucyxcclxuICAgICAgICBgJSR7cXVlcnl9JWAsXHJcbiAgICAgICAgcm93c19wZXJfcGFnZSB8fCBJVEVNU19QRVJfUEFHRSxcclxuICAgICAgICBvZmZzZXQsXHJcbiAgICAgIF1cclxuICAgICk7XHJcbiAgICByZXR1cm4gbGVnYWxFbnRpdGllcy5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINGE0LjQu9GM0YLRgNCw0YbQuNC4IExlZ2FsRW50aXRpZXM6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgXCLQndC1INGD0LTQsNC70L7RgdGMINC30LDQs9GA0YPQt9C40YLRjCDQvtGC0YTQuNC70YzRgtGA0L7QstCw0L3QvdGL0LUgTGVnYWxFbnRpdGllczpcIiArIFN0cmluZyhlcnJvcilcclxuICAgICk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMZWdhbEVudGl0aWVzUGFnZXMoXHJcbiAgcXVlcnk6IHN0cmluZyxcclxuICBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcsXHJcbiAgcm93c19wZXJfcGFnZT86IG51bWJlclxyXG4pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY291bnQgPSBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVCBDT1VOVCgqKSBGUk9NIHlvdXJfbGVnYWxfZW50aXRpZXNcclxuV0hFUkUgbmFtZSBJTElLRSAkMlxyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgYCUke3F1ZXJ5fSVgXVxyXG4gICAgKTtcclxuICAgIGNvbnN0IHRvdGFsUGFnZXMgPSBNYXRoLmNlaWwoXHJcbiAgICAgIE51bWJlcihjb3VudC5yb3dzWzBdLmNvdW50KSAvIChyb3dzX3Blcl9wYWdlIHx8IElURU1TX1BFUl9QQUdFKVxyXG4gICAgKTtcclxuICAgIHJldHVybiB0b3RhbFBhZ2VzO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7QtNGB0YfRkdGC0LAg0YHRgtGA0LDQvdC40YYgTGVnYWxFbnRpdGllczpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtC/0YDQtdC00LXQu9C40YLRjCDQutC+0LvQuNGH0LXRgdGC0LLQviDRgdGC0YDQsNC90LjRhi5cIik7XHJcbiAgfVxyXG59XHJcbi8vI2VuZHJlZ2lvbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiMFRBWXNCLDhMQUFBIn0=
}),
"[project]/app/erp/legal-entities/lib/data:d6f97e [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateLegalEntity",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40ef74d4f8c4e15700f597fc127517b66adadbda42":"updateLegalEntity"},"app/erp/legal-entities/lib/legal-entities-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40ef74d4f8c4e15700f597fc127517b66adadbda42", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateLegalEntity");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vbGVnYWwtZW50aXRpZXMtYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWdhbEVudGl0aWVzIGFjdGlvbnNcclxuXCJ1c2Ugc2VydmVyXCI7XHJcbmltcG9ydCB7IHogfSBmcm9tIFwiem9kXCI7XHJcbmltcG9ydCBwb29sIGZyb20gXCJAL2RiXCI7XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSBcIm5leHQvY2FjaGVcIjtcclxuaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tIFwibmV4dC9uYXZpZ2F0aW9uXCI7XHJcbmltcG9ydCB7IGF1dGggfSBmcm9tIFwiQC9hdXRoXCI7XHJcbmltcG9ydCB7IExlZ2FsRW50aXR5Rm9ybSwgTGVnYWxFbnRpdHkgfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcblxyXG5jb25zdCBJVEVNU19QRVJfUEFHRSA9IDg7XHJcblxyXG4vLyNyZWdpb24gQ3JlYXRlIExlZ2FsRW50aXR5XHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVMZWdhbEVudGl0eShsZWdhbEVudGl0eTogTGVnYWxFbnRpdHkpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYXV0aCgpO1xyXG4gIGNvbnN0IHVzZXJuYW1lID0gc2Vzc2lvbj8udXNlcj8ubmFtZTtcclxuICBjb25zdCB0aW1lc3RhbXB0eiA9IG5ldyBEYXRlKCkudG9JU09TdHJpbmcoKTtcclxuICBjb25zdCB7XHJcbiAgICBuYW1lLFxyXG4gICAgZnVsbG5hbWUsXHJcbiAgICBpbm4sXHJcbiAgICBhZGRyZXNzX2xlZ2FsLFxyXG4gICAgcGhvbmUsXHJcbiAgICBlbWFpbCxcclxuICAgIGNvbnRhY3QsXHJcbiAgICBpc19jdXN0b21lcixcclxuICAgIGlzX3N1cHBsaWVyLFxyXG4gICAga3BwLFxyXG4gICAgcmVnaW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHVzZXJfdGFncyxcclxuICAgIGFjY2Vzc190YWdzLFxyXG4gICAgdGVuYW50X2lkLFxyXG4gICAgYXV0aG9yX2lkLFxyXG4gIH0gPSBsZWdhbEVudGl0eTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoXHJcbiAgICAgIGBcclxuSU5TRVJUIElOVE8gbGVnYWxfZW50aXRpZXMgKFxyXG5uYW1lLFxyXG5mdWxsbmFtZSxcclxuaW5uLFxyXG5hZGRyZXNzX2xlZ2FsLFxyXG5waG9uZSxcclxuZW1haWwsXHJcbmNvbnRhY3QsXHJcbmlzX2N1c3RvbWVyLFxyXG5pc19zdXBwbGllcixcclxua3BwLFxyXG5yZWdpb25faWQsXHJcbnNlY3Rpb25faWQsXHJcbnVzZXJfdGFncyxcclxuYWNjZXNzX3RhZ3MsXHJcbnVzZXJuYW1lLFxyXG50ZW5hbnRfaWQsXHJcbmF1dGhvcl9pZFxyXG4pIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1LCAkNiwgJDcsICQ4LCAkOSwgJDEwLCAkMTEsICQxMiwgJDEzLCAkMTQsICQxNSwgJDE2LCAkMTcpXHJcbmAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIGZ1bGxuYW1lLFxyXG4gICAgICAgIGlubixcclxuICAgICAgICBhZGRyZXNzX2xlZ2FsLFxyXG4gICAgICAgIHBob25lLFxyXG4gICAgICAgIGVtYWlsLFxyXG4gICAgICAgIGNvbnRhY3QsXHJcbiAgICAgICAgaXNfY3VzdG9tZXIsXHJcbiAgICAgICAgaXNfc3VwcGxpZXIsXHJcbiAgICAgICAga3BwLFxyXG4gICAgICAgIHJlZ2lvbl9pZCxcclxuICAgICAgICBzZWN0aW9uX2lkLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHVzZXJfdGFncyksXHJcbiAgICAgICAgSlNPTi5zdHJpbmdpZnkoYWNjZXNzX3RhZ3MpLFxyXG4gICAgICAgIHVzZXJuYW1lLFxyXG4gICAgICAgIHRlbmFudF9pZCxcclxuICAgICAgICBhdXRob3JfaWQsXHJcbiAgICAgIF1cclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIExlZ2FsRW50aXR5OlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIExlZ2FsRW50aXR5OlwiICsgU3RyaW5nKGVycm9yKSk7XHJcbiAgfVxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL2VycC9sZWdhbC1lbnRpdGllc1wiKTtcclxufVxyXG5cclxuLy8jZW5kcmVnaW9uXHJcblxyXG4vLyNyZWdpb24gVXBkYXRlL0RlbGV0ZSBMZWdhbEVudGl0eVxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlTGVnYWxFbnRpdHkobGVnYWxFbnRpdHk6IExlZ2FsRW50aXR5KSB7XHJcbiAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGF1dGgoKTtcclxuICBjb25zdCB1c2VybmFtZSA9IHNlc3Npb24/LnVzZXI/Lm5hbWU7XHJcbiAgY29uc3Qge1xyXG4gICAgaWQsXHJcbiAgICBuYW1lLFxyXG4gICAgZnVsbG5hbWUsXHJcbiAgICBpbm4sXHJcbiAgICBhZGRyZXNzX2xlZ2FsLFxyXG4gICAgcGhvbmUsXHJcbiAgICBlbWFpbCxcclxuICAgIGNvbnRhY3QsXHJcbiAgICBpc19jdXN0b21lcixcclxuICAgIGlzX3N1cHBsaWVyLFxyXG4gICAga3BwLFxyXG4gICAgcmVnaW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHVzZXJfdGFncyxcclxuICAgIGFjY2Vzc190YWdzLFxyXG4gICAgdGVuYW50X2lkLFxyXG4gICAgYXV0aG9yX2lkLFxyXG4gIH0gPSBsZWdhbEVudGl0eTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoXHJcbiAgICAgIGBcclxuVVBEQVRFIGxlZ2FsX2VudGl0aWVzIFNFVFxyXG5uYW1lID0gJDEsXHJcbmZ1bGxuYW1lID0gJDIsXHJcbmlubiA9ICQzLFxyXG5hZGRyZXNzX2xlZ2FsID0gJDQsXHJcbnBob25lID0gJDUsXHJcbmVtYWlsID0gJDYsXHJcbmNvbnRhY3QgPSAkNyxcclxuaXNfY3VzdG9tZXIgPSAkOCxcclxuaXNfc3VwcGxpZXIgPSAkOSxcclxua3BwID0gJDEwLFxyXG5yZWdpb25faWQgPSAkMTEsXHJcbnNlY3Rpb25faWQgPSAkMTIsXHJcbnVzZXJfdGFncyA9ICQxMyxcclxuYWNjZXNzX3RhZ3MgPSAkMTQsXHJcbnVzZXJuYW1lID0gJDE1LFxyXG50aW1lc3RhbXB0eiA9IG5vdygpLFxyXG50ZW5hbnRfaWQgPSAkMTYsXHJcbmF1dGhvcl9pZCA9ICQxN1xyXG5XSEVSRSBpZCA9ICQxOFxyXG5gLFxyXG4gICAgICBbXHJcbiAgICAgICAgbmFtZSxcclxuICAgICAgICBmdWxsbmFtZSxcclxuICAgICAgICBpbm4sXHJcbiAgICAgICAgYWRkcmVzc19sZWdhbCxcclxuICAgICAgICBwaG9uZSxcclxuICAgICAgICBlbWFpbCxcclxuICAgICAgICBjb250YWN0LFxyXG4gICAgICAgIGlzX2N1c3RvbWVyLFxyXG4gICAgICAgIGlzX3N1cHBsaWVyLFxyXG4gICAgICAgIGtwcCxcclxuICAgICAgICByZWdpb25faWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICBKU09OLnN0cmluZ2lmeSh1c2VyX3RhZ3MpLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KGFjY2Vzc190YWdzKSxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGlkLFxyXG4gICAgICBdXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtCx0L3QvtCy0LjRgtGMIExlZ2FsRW50aXR5OlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQntGI0LjQsdC60LAg0LHQsNC30Ysg0LTQsNC90L3Ri9GFOiDQndC1INGD0LTQsNC70L7RgdGMINC+0LHQvdC+0LLQuNGC0YwgTGVnYWxFbnRpdHk6IFwiICsgZXJyb3IpO1xyXG4gIH1cclxuICByZXZhbGlkYXRlUGF0aChcIi9lcnAvbGVnYWwtZW50aXRpZXNcIik7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVMZWdhbEVudGl0eShpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIGxlZ2FsX2VudGl0aWVzIFdIRVJFIGlkID0gJDFgLCBbaWRdKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDRg9C00LDQu9C10L3QuNGPIExlZ2FsRW50aXR5OlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgIFwi0J7RiNC40LHQutCwINCx0LDQt9GLINC00LDQvdC90YvRhTog0J3QtSDRg9C00LDQu9C+0YHRjCDRg9C00LDQu9C40YLRjCBMZWdhbEVudGl0eTogXCIgKyBTdHJpbmcoZXJyb3IpXHJcbiAgICApO1xyXG4gIH1cclxuICByZXZhbGlkYXRlUGF0aChcIi9lcnAvbGVnYWwtZW50aXRpZXNcIik7XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcblxyXG4vLyNyZWdpb24gRmV0Y2ggTGVnYWxFbnRpdGllc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMZWdhbEVudGl0eShpZDogc3RyaW5nLCBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8TGVnYWxFbnRpdHk+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5pZCxcclxubmFtZSxcclxuZnVsbG5hbWUsXHJcbmlubixcclxuYWRkcmVzc19sZWdhbCxcclxucGhvbmUsXHJcbmVtYWlsLFxyXG5jb250YWN0LFxyXG5pc19jdXN0b21lcixcclxuaXNfc3VwcGxpZXIsXHJcbmtwcCxcclxucmVnaW9uX2lkLFxyXG5zZWN0aW9uX2lkLFxyXG51c2VyX3RhZ3MsXHJcbmFjY2Vzc190YWdzLFxyXG51c2VybmFtZSxcclxuZWRpdGluZ19ieV91c2VyX2lkLFxyXG5lZGl0aW5nX3NpbmNlLFxyXG50aW1lc3RhbXB0elxyXG5GUk9NIHlvdXJfbGVnYWxfZW50aXRpZXNcclxuV0hFUkUgaWQgPSAkMjo6dXVpZFxyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgaWRdXHJcbiAgICApO1xyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0L/QvtC70YPRh9C10L3QuNGPIExlZ2FsRW50aXR5INC/0L4gSUQ6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINC/0L7Qu9GD0YfQuNGC0YwgTGVnYWxFbnRpdHk6XCIgKyBTdHJpbmcoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMZWdhbEVudGl0eUZvcm0oaWQ6IHN0cmluZywgY3VycmVudF9zZWN0aW9uczogc3RyaW5nKSB7XHJcbiAgY29uc29sZS5sb2coXCJmZXRjaExlZ2FsRW50aXR5Rm9ybSBieSBpZDpcIiwgaWQpO1xyXG4gIGNvbnNvbGUubG9nKFwiY3VycmVudF9zZWN0aW9uczpcIiwgY3VycmVudF9zZWN0aW9ucyk7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PExlZ2FsRW50aXR5Rm9ybT4oXHJcbiAgICAgIGBcclxuV0lUSCB5b3VyX2xlZ2FsX2VudGl0aWVzIEFTICggU0VMRUNUICogRlJPTSBsZWdhbF9lbnRpdGllcyB3aGVyZSBzZWN0aW9uX2lkID1cclxuQU5ZICgkMTo6dXVpZFtdKSlcclxuU0VMRUNUXHJcbmxlLmlkLFxyXG5sZS5uYW1lLFxyXG5sZS5mdWxsbmFtZSxcclxubGUuaW5uLFxyXG5sZS5hZGRyZXNzX2xlZ2FsLFxyXG5sZS5waG9uZSxcclxubGUuZW1haWwsXHJcbmxlLmNvbnRhY3QsXHJcbmxlLmlzX2N1c3RvbWVyLFxyXG5sZS5pc19zdXBwbGllcixcclxubGUua3BwLFxyXG5sZS5yZWdpb25faWQsXHJcbmxlLnNlY3Rpb25faWQsXHJcbmxlLnVzZXJfdGFncyxcclxubGUuYWNjZXNzX3RhZ3MsXHJcbmxlLnVzZXJuYW1lLFxyXG5sZS5lZGl0aW5nX2J5X3VzZXJfaWQsXHJcbmxlLmVkaXRpbmdfc2luY2UsXHJcbmxlLnRpbWVzdGFtcHR6LFxyXG5sZS50ZW5hbnRfaWQsXHJcbmxlLmF1dGhvcl9pZCxcclxubGUuZWRpdG9yX2lkLFxyXG5DT0FMRVNDRShyZWdpb25zLm5hbWUsICcnKSBhcyByZWdpb25fbmFtZSxcclxuQ09BTEVTQ0Uoc2VjdGlvbnMubmFtZSwgJycpIGFzIHNlY3Rpb25fbmFtZVxyXG5GUk9NIHlvdXJfbGVnYWxfZW50aXRpZXMgbGVcclxuTEVGVCBKT0lOIHNlY3Rpb25zIE9OIGxlLnNlY3Rpb25faWQgPSBzZWN0aW9ucy5pZFxyXG5MRUZUIEpPSU4gcmVnaW9ucyBPTiBsZS5yZWdpb25faWQgPSByZWdpb25zLmlkXHJcbldIRVJFIGxlLmlkID0gJDI6OnV1aWRcclxuYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGlkXVxyXG4gICAgKTtcclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyDRhNC+0YDQvNGLIExlZ2FsRW50aXR5OlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQv9C+0LvRg9GH0LjRgtGMINC00LDQvdC90YvQtSDRhNC+0YDQvNGLIExlZ2FsRW50aXR5OlwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoTGVnYWxFbnRpdGllcyhjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8TGVnYWxFbnRpdHk+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5pZCxcclxubmFtZSxcclxuZnVsbG5hbWUsXHJcbmlubixcclxuYWRkcmVzc19sZWdhbCxcclxucGhvbmUsXHJcbmVtYWlsLFxyXG5jb250YWN0LFxyXG5pc19jdXN0b21lcixcclxuaXNfc3VwcGxpZXIsXHJcbmtwcCxcclxucmVnaW9uX2lkLFxyXG5zZWN0aW9uX2lkLFxyXG51c2VyX3RhZ3MsXHJcbmFjY2Vzc190YWdzLFxyXG50ZW5hbnRfaWQsXHJcbmF1dGhvcl9pZCxcclxudXNlcm5hbWUsXHJcbnRpbWVzdGFtcHR6XHJcbkZST00geW91cl9sZWdhbF9lbnRpdGllc1xyXG5PUkRFUiBCWSBuYW1lIEFTQ1xyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9uc11cclxuICAgICk7XHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YHQv9C40YHQutCwINGO0YDQu9C40YY6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINC30LDQs9GA0YPQt9C40YLRjCDRgdC/0LjRgdC+0Log0Y7RgNC70LjRhjpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaExlZ2FsRW50aXRpZXNGb3JtKGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxMZWdhbEVudGl0eUZvcm0+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5sZS5pZCxcclxubGUubmFtZSxcclxubGUuZnVsbG5hbWUsXHJcbmxlLmlubixcclxubGUuYWRkcmVzc19sZWdhbCxcclxubGUucGhvbmUsXHJcbmxlLmVtYWlsLFxyXG5sZS5jb250YWN0LFxyXG5sZS5pc19jdXN0b21lcixcclxubGUuaXNfc3VwcGxpZXIsXHJcbmxlLmtwcCxcclxubGUucmVnaW9uX2lkLFxyXG5sZS5zZWN0aW9uX2lkLFxyXG5sZS51c2VyX3RhZ3MsXHJcbmxlLmFjY2Vzc190YWdzLFxyXG5sZS51c2VybmFtZSxcclxubGUuZWRpdGluZ19ieV91c2VyX2lkLFxyXG5sZS5lZGl0aW5nX3NpbmNlLFxyXG5sZS50aW1lc3RhbXB0eixcclxubGUudGVuYW50X2lkLFxyXG5sZS5hdXRob3JfaWQsXHJcbmxlLmVkaXRvcl9pZCxcclxuQ09BTEVTQ0UocmVnaW9ucy5uYW1lLCAnJykgYXMgcmVnaW9uX25hbWUsXHJcbkNPQUxFU0NFKHNlY3Rpb25zLm5hbWUsICcnKSBhcyBzZWN0aW9uX25hbWVcclxuRlJPTSB5b3VyX2xlZ2FsX2VudGl0aWVzIGxlXHJcbkxFRlQgSk9JTiBzZWN0aW9ucyBPTiBsZS5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuTEVGVCBKT0lOIHJlZ2lvbnMgT04gbGUucmVnaW9uX2lkID0gcmVnaW9ucy5pZFxyXG5PUkRFUiBCWSBsZS5uYW1lIEFTQ1xyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9uc11cclxuICAgICk7XHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YTQvtGA0LwgTGVnYWxFbnRpdGllczpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINGE0L7RgNC80YsgTGVnYWxFbnRpdGllczpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcblxyXG4vLyNyZWdpb24gRmlsdGVyZWQgTGVnYWxFbnRpdGllc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hGaWx0ZXJlZExlZ2FsRW50aXRpZXMoXHJcbiAgcXVlcnk6IHN0cmluZyxcclxuICBjdXJyZW50UGFnZTogbnVtYmVyLFxyXG4gIGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZyxcclxuICByb3dzX3Blcl9wYWdlPzogbnVtYmVyXHJcbikge1xyXG4gIGNvbnN0IG9mZnNldCA9IChjdXJyZW50UGFnZSAtIDEpICogKHJvd3NfcGVyX3BhZ2UgfHwgSVRFTVNfUEVSX1BBR0UpO1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBsZWdhbEVudGl0aWVzID0gYXdhaXQgcG9vbC5xdWVyeTxMZWdhbEVudGl0eUZvcm0+KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVFxyXG5sZS5pZCxcclxubGUubmFtZSxcclxubGUuZnVsbG5hbWUsXHJcbmxlLmlubixcclxubGUuYWRkcmVzc19sZWdhbCxcclxubGUucGhvbmUsXHJcbmxlLmVtYWlsLFxyXG5sZS5jb250YWN0LFxyXG5sZS5pc19jdXN0b21lcixcclxubGUuaXNfc3VwcGxpZXIsXHJcbmxlLmtwcCxcclxubGUucmVnaW9uX2lkLFxyXG5sZS5zZWN0aW9uX2lkLFxyXG5sZS51c2VyX3RhZ3MsXHJcbmxlLmFjY2Vzc190YWdzLFxyXG5sZS51c2VybmFtZSxcclxubGUuZWRpdGluZ19ieV91c2VyX2lkLFxyXG5sZS5lZGl0aW5nX3NpbmNlLFxyXG5sZS50aW1lc3RhbXB0eixcclxubGUudGVuYW50X2lkLFxyXG5sZS5hdXRob3JfaWQsXHJcbmxlLmVkaXRvcl9pZCxcclxuQ09BTEVTQ0UocmVnaW9ucy5uYW1lLCAnJykgYXMgcmVnaW9uX25hbWUsXHJcbkNPQUxFU0NFKHNlY3Rpb25zLm5hbWUsICcnKSBhcyBzZWN0aW9uX25hbWVcclxuRlJPTSB5b3VyX2xlZ2FsX2VudGl0aWVzIGxlXHJcbkxFRlQgSk9JTiBzZWN0aW9ucyBPTiBsZS5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuTEVGVCBKT0lOIHJlZ2lvbnMgT04gbGUucmVnaW9uX2lkID0gcmVnaW9ucy5pZFxyXG5XSEVSRVxyXG5sZS5uYW1lIElMSUtFICQyXHJcbk9SREVSIEJZIGxlLm5hbWUgQVNDXHJcbkxJTUlUICQzIE9GRlNFVCAkNFxyXG5gLFxyXG4gICAgICBbXHJcbiAgICAgICAgY3VycmVudF9zZWN0aW9ucyxcclxuICAgICAgICBgJSR7cXVlcnl9JWAsXHJcbiAgICAgICAgcm93c19wZXJfcGFnZSB8fCBJVEVNU19QRVJfUEFHRSxcclxuICAgICAgICBvZmZzZXQsXHJcbiAgICAgIF1cclxuICAgICk7XHJcbiAgICByZXR1cm4gbGVnYWxFbnRpdGllcy5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINGE0LjQu9GM0YLRgNCw0YbQuNC4IExlZ2FsRW50aXRpZXM6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgXCLQndC1INGD0LTQsNC70L7RgdGMINC30LDQs9GA0YPQt9C40YLRjCDQvtGC0YTQuNC70YzRgtGA0L7QstCw0L3QvdGL0LUgTGVnYWxFbnRpdGllczpcIiArIFN0cmluZyhlcnJvcilcclxuICAgICk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMZWdhbEVudGl0aWVzUGFnZXMoXHJcbiAgcXVlcnk6IHN0cmluZyxcclxuICBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcsXHJcbiAgcm93c19wZXJfcGFnZT86IG51bWJlclxyXG4pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY291bnQgPSBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbldJVEggeW91cl9sZWdhbF9lbnRpdGllcyBBUyAoIFNFTEVDVCAqIEZST00gbGVnYWxfZW50aXRpZXMgd2hlcmUgc2VjdGlvbl9pZCA9XHJcbkFOWSAoJDE6OnV1aWRbXSkpXHJcblNFTEVDVCBDT1VOVCgqKSBGUk9NIHlvdXJfbGVnYWxfZW50aXRpZXNcclxuV0hFUkUgbmFtZSBJTElLRSAkMlxyXG5gLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgYCUke3F1ZXJ5fSVgXVxyXG4gICAgKTtcclxuICAgIGNvbnN0IHRvdGFsUGFnZXMgPSBNYXRoLmNlaWwoXHJcbiAgICAgIE51bWJlcihjb3VudC5yb3dzWzBdLmNvdW50KSAvIChyb3dzX3Blcl9wYWdlIHx8IElURU1TX1BFUl9QQUdFKVxyXG4gICAgKTtcclxuICAgIHJldHVybiB0b3RhbFBhZ2VzO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7QtNGB0YfRkdGC0LAg0YHRgtGA0LDQvdC40YYgTGVnYWxFbnRpdGllczpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtC/0YDQtdC00LXQu9C40YLRjCDQutC+0LvQuNGH0LXRgdGC0LLQviDRgdGC0YDQsNC90LjRhi5cIik7XHJcbiAgfVxyXG59XHJcbi8vI2VuZHJlZ2lvbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiMFRBd0ZzQiw4TEFBQSJ9
}),
"[next]/internal/font/google/inter_90f380b0.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "className": "inter_90f380b0-module__htd78G__className",
});
}),
"[next]/internal/font/google/inter_90f380b0.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_90f380b0$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[next]/internal/font/google/inter_90f380b0.module.css [app-client] (css module)");
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_90f380b0$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'Inter', 'Inter Fallback'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_90f380b0$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_90f380b0$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;
}),
"[next]/internal/font/google/lusitana_99639ffe.module.css [app-client] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "className": "lusitana_99639ffe-module__7_Xs5q__className",
});
}),
"[next]/internal/font/google/lusitana_99639ffe.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[next]/internal/font/google/lusitana_99639ffe.module.css [app-client] (css module)");
;
const fontData = {
    className: __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].className,
    style: {
        fontFamily: "'Lusitana', 'Lusitana Fallback'",
        fontStyle: "normal"
    }
};
if (__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].variable != null) {
    fontData.variable = __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].variable;
}
const __TURBOPACK__default__export__ = fontData;
}),
"[project]/app/ui/fonts.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$inter_90f380b0$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[next]/internal/font/google/inter_90f380b0.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[next]/internal/font/google/lusitana_99639ffe.js [app-client] (ecmascript)");
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
;
;
}),
"[next]/internal/font/google/lusitana_99639ffe.js [app-client] (ecmascript) <export default as lusitana>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "lusitana",
    ()=>__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[next]/internal/font/google/lusitana_99639ffe.js [app-client] (ecmascript)");
}),
"[project]/app/admin/tenants/lib/tenants-ref-table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TenantsRefTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function TenantsRefTable(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Выберите Организацию:"
            }, void 0, false, {
                fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                lineNumber: 13,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0 flow-root",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "overflow-x-auto",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "inline-block min-w-full align-middle",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "overflow-hidden rounded-md bg-gray-50 p-1 md:pt-0",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                    className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                        className: "rounded-md bg-gray-50 text-left text-sm font-normal",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    scope: "col",
                                                    className: "w-1/2 overflow-hidden px-0 py-5 font-medium sm:pl-6",
                                                    children: "Название"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                                    lineNumber: 21,
                                                    columnNumber: 41
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    scope: "col",
                                                    className: "w-1/2 px-3 py-5 font-medium",
                                                    children: "Описание"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                                    lineNumber: 24,
                                                    columnNumber: 41
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                            lineNumber: 20,
                                            columnNumber: 37
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                        lineNumber: 19,
                                        columnNumber: 33
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                    lineNumber: 18,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                lineNumber: 17,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2 md:pt-0",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                    className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                        className: "divide-y divide-gray-200 text-gray-900",
                                        children: props.tenants.map((tenant)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "group",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "w-1/2 overflow-hidden whitespace-nowrap text-ellipsis bg-white py-1 pl-0 text-left     pr-3 text-sm text-black group-first-of-type:rounded-md group-last-of-type:rounded-md sm:pl-6",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-left gap-3",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                onClick: (e)=>{
                                                                    props.handleSelectTenant(tenant.id, tenant.name);
                                                                    props.closeModal();
                                                                },
                                                                // href={"#"}
                                                                className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                                children: tenant.name.substring(0, 36)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                                                lineNumber: 40,
                                                                columnNumber: 53
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                                            lineNumber: 39,
                                                            columnNumber: 49
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                                        lineNumber: 37,
                                                        columnNumber: 45
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "w-1/2 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                        children: tenant.description
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                                        lineNumber: 47,
                                                        columnNumber: 45
                                                    }, this)
                                                ]
                                            }, tenant.id, true, {
                                                fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                                lineNumber: 36,
                                                columnNumber: 41
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                        lineNumber: 34,
                                        columnNumber: 33
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                    lineNumber: 33,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                                lineNumber: 32,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                        lineNumber: 16,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                    lineNumber: 15,
                    columnNumber: 17
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
                lineNumber: 14,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/tenants/lib/tenants-ref-table.tsx",
        lineNumber: 12,
        columnNumber: 9
    }, this);
}
_c = TenantsRefTable;
var _c;
__turbopack_context__.k.register(_c, "TenantsRefTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/tenants/lib/btn-tenants-ref.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BtnTenantsRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import Modal from "@/app/lib/modal";
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BookOpenIcon.js [app-client] (ecmascript) <export default as BookOpenIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$tenants$2f$lib$2f$tenants$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/tenants/lib/tenants-ref-table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = Modal;
function BtnTenantsRef(props) {
    _s();
    const [modal, setModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openModal = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setModal(true);
    // redirect("/dashboard/admin/tenants/1");
    };
    const closeModal = ()=>{
        // setTenant((prev) => ({
        //   ...props.tenant,
        // }));
        setModal(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: openModal,
                className: "rounded-md border border-gray-200 p-2 h-10 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__["BookOpenIcon"], {
                    className: "w-5 h-5 text-gray-800"
                }, void 0, false, {
                    fileName: "[project]/app/admin/tenants/lib/btn-tenants-ref.tsx",
                    lineNumber: 38,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/admin/tenants/lib/btn-tenants-ref.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Modal, {
                open: modal,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$tenants$2f$lib$2f$tenants$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        tenants: props.tenants,
                        handleSelectTenant: props.handleSelectTenant,
                        closeModal: closeModal
                    }, void 0, false, {
                        fileName: "[project]/app/admin/tenants/lib/btn-tenants-ref.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between space-x-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                // alert("действие!")
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/tenants/lib/btn-tenants-ref.tsx",
                                lineNumber: 50,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: closeModal,
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Exit"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/tenants/lib/btn-tenants-ref.tsx",
                                lineNumber: 58,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/tenants/lib/btn-tenants-ref.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/tenants/lib/btn-tenants-ref.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/tenants/lib/btn-tenants-ref.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(BtnTenantsRef, "FxRBWQPa/dKnwvdbY5qed8chvVc=");
_c1 = BtnTenantsRef;
var _c, _c1;
__turbopack_context__.k.register(_c, "Modal");
__turbopack_context__.k.register(_c1, "BtnTenantsRef");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/permissions/lib/data:ce6d6a [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updatePermission",
    ()=>$$RSC_SERVER_ACTION_9
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"406eccc69fd7f94ee8c5706d0be8a7b78274fbe3cc":"updatePermission"},"app/admin/permissions/lib/permissios-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("406eccc69fd7f94ee8c5706d0be8a7b78274fbe3cc", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updatePermission");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcGVybWlzc2lvcy1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFJvbGVzIGFjdGlvbnMudHNcclxuXHJcblwidXNlIHNlcnZlclwiO1xyXG5pbXBvcnQgeyBnZXRVc2VyUm9sZXMgfSBmcm9tIFwiQC9hcHAvbGliL2NvbW1vbi1hY3Rpb25zXCI7XHJcbmltcG9ydCB7IERvY1VzZXJQZXJtaXNzaW9ucywgUGVybWlzc2lvbiB9IGZyb20gXCJAL2FwcC9saWIvZGVmaW5pdGlvbnNcIjtcclxuaW1wb3J0IHBvb2wgZnJvbSBcIkAvZGJcIjsgLy8g0JjQvNC/0L7RgNGCINC/0YPQu9CwINC/0L7QtNC60LvRjtGH0LXQvdC40LlcclxuaW1wb3J0IHsgcmV2YWxpZGF0ZVBhdGggfSBmcm9tIFwibmV4dC9jYWNoZVwiO1xyXG4vLyBpbXBvcnQgeyByZWRpcmVjdCB9IGZyb20gXCJuZXh0L25hdmlnYXRpb25cIjtcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaERvY1VzZXJQZXJtaXNzaW9ucyhcclxuICB1c2VyX2lkOiBzdHJpbmcsXHJcbiAgZG9jdHlwZTogc3RyaW5nXHJcbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxEb2NVc2VyUGVybWlzc2lvbnM+KFxyXG4gICAgICBgXHJcbiAgICAgIFNFTEVDVCBcclxuICAgICAgICBNQVgocC5mdWxsX2FjY2Vzczo6SU5UKTo6Qk9PTEVBTiBBUyBmdWxsX2FjY2VzcyxcclxuICAgICAgICBNQVgocC5lZGl0b3I6OklOVCk6OkJPT0xFQU4gQVMgZWRpdG9yLFxyXG4gICAgICAgIE1BWChwLmF1dGhvcjo6SU5UKTo6Qk9PTEVBTiBBUyBhdXRob3IsXHJcbiAgICAgICAgTUFYKHAucmVhZGVyOjpJTlQpOjpCT09MRUFOIEFTIHJlYWRlcixcclxuICAgICAgICBNQVgocC5jYW5fZGVsZXRlOjpJTlQpOjpCT09MRUFOIEFTIGNhbl9kZWxldGUsXHJcbiAgICAgICAgTUFYKHAuYWNjZXNzX2J5X3RhZ3M6OklOVCk6OkJPT0xFQU4gQVMgYWNjZXNzX2J5X3RhZ3NcclxuICAgICAgRlJPTSB1c2VycyB1XHJcbiAgICAgICAgTEVGVCBKT0lOIHJvbGVzIHIgT04gci5pZCA9IEFOWSh1LnJvbGVfaWRzKVxyXG4gICAgICAgIExFRlQgSk9JTiBwZXJtaXNzaW9ucyBwIE9OIHAucm9sZV9pZCA9IHIuaWRcclxuICAgICAgV0hFUkUgdS5pZCA9ICQxOjp1dWlkIEFORCBwLmRvY3R5cGUgPSAkMlxyXG4gICAgICAgIEdST1VQIEJZIHUuaWRcclxuICAgICAgYCxcclxuICAgICAgW3VzZXJfaWQsIGRvY3R5cGVdXHJcbiAgICApO1xyXG5cclxuICAgIGlmIChkYXRhLnJvd3MubGVuZ3RoID4gMSkge1xyXG4gICAgICBjb25zb2xlLmxvZyhcclxuICAgICAgICBcIk11bHRpcGxlIHBlcm1pc3Npb25zIGZvdW5kIGZvciB1c2VyIFwiICtcclxuICAgICAgICAgIHVzZXJfaWQgK1xyXG4gICAgICAgICAgXCIgYW5kIGRvY3R5cGUgXCIgK1xyXG4gICAgICAgICAgZG9jdHlwZVxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gICAgaWYgKGRhdGEucm93cy5sZW5ndGggPT09IDApIHtcclxuICAgICAgLy8gY29uc29sZS5sb2coXHJcbiAgICAgIC8vICAgXCJmZXRjaERvY1VzZXJQZXJtaXNzaW9uczogZGF0YS5yb3dzLmxlbmd0aCA9PT0gMCBmb3IgdXNlciBpZCBcIiArXHJcbiAgICAgIC8vICAgICB1c2VyX2lkICtcclxuICAgICAgLy8gICAgIFwiIGFuZCBkb2N0eXBlIFwiICtcclxuICAgICAgLy8gICAgIGRvY3R5cGVcclxuICAgICAgLy8gKTtcclxuICAgICAgcmV0dXJuIHtcclxuICAgICAgICBmdWxsX2FjY2VzczogZmFsc2UsXHJcbiAgICAgICAgZWRpdG9yOiBmYWxzZSxcclxuICAgICAgICBhdXRob3I6IGZhbHNlLFxyXG4gICAgICAgIHJlYWRlcjogZmFsc2UsXHJcbiAgICAgICAgY2FuX2RlbGV0ZTogZmFsc2UsXHJcbiAgICAgICAgYWNjZXNzX2J5X3RhZ3M6IGZhbHNlLFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBwZXJtaXNzaW9uczogXCIgKyBlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuLy8jcmVnaW9uIGZldGNoRG9jdHlwZXNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFBlcm1pc3Npb25zU3VwZXJhZG1pbigpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8UGVybWlzc2lvbj4oXHJcbiAgICAgIGBTRUxFQ1QgaWQsIHJvbGVfaWQsIHJvbGVfbmFtZSwgZG9jdHlwZSwgZG9jdHlwZV9uYW1lLCBmdWxsX2FjY2VzcywgZWRpdG9yLCBhdXRob3IsIFxyXG4gICAgICAgIGNhbl9kZWxldGUsIHJlYWRlciwgYWNjZXNzX2J5X3RhZ3MsIG9yX3RhZ3MsIGFuZF90YWdzLCBub190YWdzLCB0ZW5hbnRfaWQsIHRlbmFudF9uYW1lXHJcbiAgICAgICAgRlJPTSBwZXJtaXNzaW9uc1xyXG4gICAgICAgIE9SREVSIEJZIGRvY3R5cGVfbmFtZSBBU0NgXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBkYXRhLnJvd3M7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgRXJyb3I6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggcGVybWlzc2lvbnM6IFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoUGVybWlzc2lvbnNBZG1pbih0ZW5hbnRfaWQ6IHN0cmluZywgcm9sZV9pZD86IHN0cmluZykge1xyXG4gIGNvbnN0IHJvbGVfaWRfdXVpZCA9IHJvbGVfaWQgPyByb2xlX2lkIDogXCIwMDAwMDAwMC0wMDAwLTAwMDAtMDAwMC0wMDAwMDAwMDAwMDBcIjtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8UGVybWlzc2lvbj4oXHJcbiAgICAgIGBTRUxFQ1QgaWQsIHJvbGVfaWQsIHJvbGVfbmFtZSwgZG9jdHlwZSwgZG9jdHlwZV9uYW1lLCBmdWxsX2FjY2VzcywgZWRpdG9yLCBcclxuICAgICAgICBhdXRob3IsIGNhbl9kZWxldGUsIHJlYWRlciwgYWNjZXNzX2J5X3RhZ3MsIG9yX3RhZ3MsIGFuZF90YWdzLCBub190YWdzLCB0ZW5hbnRfaWQsIHRlbmFudF9uYW1lXHJcbiAgICAgICAgRlJPTSBwZXJtaXNzaW9uc1xyXG4gICAgICAgIFdIRVJFIHRlbmFudF9pZCA9ICQxXHJcbiAgICAgICAgQU5EICgkMiA9ICcwMDAwMDAwMC0wMDAwLTAwMDAtMDAwMC0wMDAwMDAwMDAwMDAnIE9SIHJvbGVfaWQgPSAkMjo6dXVpZClcclxuICAgICAgICBPUkRFUiBCWSBkb2N0eXBlX25hbWUgQVNDYCxcclxuICAgICAgW3RlbmFudF9pZCwgcm9sZV9pZF91dWlkXVxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHBlcm1pc3Npb25zOiBcIiArIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hSb2xlUGVybWlzc2lvbnModGVuYW50X2lkOiBzdHJpbmcsIHJvbGVfaWQ/OiBzdHJpbmcpIHtcclxuICAvLyBjb25zdCByb2xlX2lkX3V1aWQgPSByb2xlX2lkID8gcm9sZV9pZCA6IFwiMDAwMDAwMDAtMDAwMC0wMDAwLTAwMDAtMDAwMDAwMDAwMDAwXCI7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PFBlcm1pc3Npb24+KFxyXG4gICAgICBgU0VMRUNUIGlkLCByb2xlX2lkLCByb2xlX25hbWUsIGRvY3R5cGUsIGRvY3R5cGVfbmFtZSwgZnVsbF9hY2Nlc3MsIGVkaXRvciwgXHJcbiAgICAgICAgYXV0aG9yLCBjYW5fZGVsZXRlLCByZWFkZXIsIGFjY2Vzc19ieV90YWdzLCBvcl90YWdzLCBhbmRfdGFncywgbm9fdGFncywgdGVuYW50X2lkLCB0ZW5hbnRfbmFtZVxyXG4gICAgICAgIEZST00gcGVybWlzc2lvbnNcclxuICAgICAgICBXSEVSRSB0ZW5hbnRfaWQgPSAkMVxyXG4gICAgICAgIEFORCByb2xlX2lkID0gJDI6OnV1aWRcclxuICAgICAgICBPUkRFUiBCWSBkb2N0eXBlX25hbWUgQVNDYCxcclxuICAgICAgW3RlbmFudF9pZCwgcm9sZV9pZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBwZXJtaXNzaW9uczogXCIgKyBlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlclBlcm1pc3Npb25zKHRlbmFudF9pZDogc3RyaW5nLCB1c2VyX2lkOiBzdHJpbmcpIHtcclxuICAvLyBjb25zdCByb2xlX2lkX3V1aWQgPSByb2xlX2lkID8gcm9sZV9pZCA6IFwiMDAwMDAwMDAtMDAwMC0wMDAwLTAwMDAtMDAwMDAwMDAwMDAwXCI7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IHVzZXJfcm9sZXMgPSAoYXdhaXQgZ2V0VXNlclJvbGVzKHVzZXJfaWQpKS5tYXAoKHJvbGUpID0+IHJvbGUuaWQpO1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8UGVybWlzc2lvbj4oXHJcbiAgICAgIGBTRUxFQ1QgaWQsIHJvbGVfaWQsIHJvbGVfbmFtZSwgZG9jdHlwZSwgZG9jdHlwZV9uYW1lLCBmdWxsX2FjY2VzcywgZWRpdG9yLCBcclxuICAgICAgICBhdXRob3IsIGNhbl9kZWxldGUsIHJlYWRlciwgYWNjZXNzX2J5X3RhZ3MsIG9yX3RhZ3MsIGFuZF90YWdzLCBub190YWdzLCB0ZW5hbnRfaWQsIHRlbmFudF9uYW1lXHJcbiAgICAgICAgRlJPTSBwZXJtaXNzaW9uc1xyXG4gICAgICAgIFdIRVJFIHRlbmFudF9pZCA9ICQxXHJcbiAgICAgICAgQU5EIHJvbGVfaWQgPSBBTlkoJDI6OnV1aWRbXSlcclxuICAgICAgICBPUkRFUiBCWSBkb2N0eXBlX25hbWUgQVNDYCxcclxuICAgICAgW3RlbmFudF9pZCwgdXNlcl9yb2xlc11cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBwZXJtaXNzaW9uczogXCIgKyBlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoUGVybWlzc2lvbihpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PFBlcm1pc3Npb24+KFxyXG4gICAgICBgU0VMRUNUIGlkLCByb2xlX2lkLCByb2xlX25hbWUsIGRvY3R5cGUsIGRvY3R5cGVfbmFtZSwgZnVsbF9hY2Nlc3MsIGVkaXRvciwgYXV0aG9yLCBcclxuICAgICAgICBjYW5fZGVsZXRlLCByZWFkZXIsIGFjY2Vzc19ieV90YWdzLCBvcl90YWdzLCBhbmRfdGFncywgbm9fdGFncywgdGVuYW50X2lkLCB0ZW5hbnRfbmFtZVxyXG4gICAgICAgIEZST00gcGVybWlzc2lvbnNcclxuICAgICAgICBXSEVSRSBpZCA9ICQxYCxcclxuICAgICAgW2lkXVxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzWzBdO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHBlcm1pc3Npb246IFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hEb2N0eXBlcygpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8eyB0YWJsZV9uYW1lOiBzdHJpbmcgfT4oXHJcbiAgICAgIGBTRUxFQ1QgdGFibGVfbmFtZVxyXG4gICAgICAgIEZST00gaW5mb3JtYXRpb25fc2NoZW1hLnRhYmxlc1xyXG4gICAgICAgIFdIRVJFIHRhYmxlX3NjaGVtYSA9ICdwdWJsaWMnXHJcbiAgICAgICAgQU5EIHRhYmxlX3R5cGUgPSAnQkFTRSBUQUJMRSdcclxuICAgICAgICBBTkQgdGFibGVfbmFtZSBOT1QgSU4gKCd1c2VycycsICdyb2xlcycsICdzZWN0aW9ucycsICd0ZW5hbnRzJywgJ3VzZXJzLWlkLW51bSdcclxuICAgICAgICAsICdwZXJtaXNzaW9ucycsICdzdG9ja19iYWxhbmNlcycsICdzdG9ja19tb3ZlbWVudHMnLCAndGFncycsICdwZXJpb2RzJywgJ3ZhdF9pbnZvaWNlX2dvb2RzJylcclxuICAgICAgICBPUkRFUiBCWSB0YWJsZV9uYW1lIEFTQ2BcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBkb2N0eXBlczogXCIgKyBlcnIpO1xyXG4gIH1cclxufVxyXG5cclxuLy8gY3JlYXRlUGVybWlzc2lvblxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVBlcm1pc3Npb24oXHJcbiAgZG9jdHlwZTogc3RyaW5nLFxyXG4gIGRvY3R5cGVfbmFtZTogc3RyaW5nLFxyXG4gIHJvbGVfaWQ6IHN0cmluZyxcclxuICByb2xlX25hbWU6IHN0cmluZyxcclxuICB0ZW5hbnRfaWQ6IHN0cmluZyxcclxuICB0ZW5hbnRfbmFtZTogc3RyaW5nXHJcbikge1xyXG4gIGlmIChkb2N0eXBlID09PSBcIlwiKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJkb2N0eXBlIGlzIHJlcXVpcmVkISDQndC10L7QsdGF0L7QtNC90L4g0YPQutCw0LfQsNGC0Ywg0KLQuNC/INC00L7QutGD0LzQtdC90YLQsCFcIik7XHJcbiAgfVxyXG4gIGlmIChyb2xlX2lkID09PSBcIlwiKSB7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJyb2xlIGlzIHJlcXVpcmVkISDQndC10L7QsdGF0L7QtNC90L4g0YPQutCw0LfQsNGC0Ywg0KDQvtC70YwhXCIpO1xyXG4gIH1cclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYElOU0VSVCBJTlRPIHBlcm1pc3Npb25zIChkb2N0eXBlLCBkb2N0eXBlX25hbWUsIHJvbGVfaWQsIHJvbGVfbmFtZSwgdGVuYW50X2lkLCB0ZW5hbnRfbmFtZSlcclxuICAgICAgIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1LCAkNilcclxuICAgICAgICBSRVRVUk5JTkcgaWQgICAgICAgXHJcbiAgICBgLFxyXG4gICAgICBbZG9jdHlwZSwgZG9jdHlwZV9uYW1lLCByb2xlX2lkLCByb2xlX25hbWUsIHRlbmFudF9pZCwgdGVuYW50X25hbWVdXHJcbiAgICApO1xyXG4gICAgY29uc3QgaWQgPSByZXN1bHQucm93c1swXS5pZDtcclxuICAgIHJldmFsaWRhdGVQYXRoKFwiL2FkbWluL3Blcm1pc3Npb25zXCIpO1xyXG4gICAgcmV0dXJuIGlkO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGNyZWF0ZSBQZXJtaXNzaW9uOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gY3JlYXRlIFBlcm1pc3Npb246XCIgKyBlcnJvcik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlUGVybWlzc2lvbihpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIHBlcm1pc3Npb25zIFdIRVJFIGlkID0gJDFgLCBbaWRdKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yLCBGYWlsZWQgdG8gZGVsZXRlIFBlcm1pc3Npb246XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkRhdGFiYXNlIEVycm9yOiBGYWlsZWQgdG8gZGVsZXRlIFBlcm1pc3Npb246IFwiICsgZXJyb3IpO1xyXG4gIH1cclxuXHJcbiAgcmV2YWxpZGF0ZVBhdGgoXCIvYWRtaW4vcGVybWlzc2lvbnNcIik7XHJcbn1cclxuXHJcbi8vdXBkYXRlUGVybWlzc2lvblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlUGVybWlzc2lvbihwZXJtaXNzaW9uOiBQZXJtaXNzaW9uKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoXHJcbiAgICAgIGBVUERBVEUgcGVybWlzc2lvbnNcclxuICAgICAgIFNFVCBcclxuICAgICAgIGlkID0gJDEsIHJvbGVfaWQgPSAkMiwgcm9sZV9uYW1lID0gJDMsIGRvY3R5cGUgPSAkNCwgZG9jdHlwZV9uYW1lID0gJDUsIFxyXG4gICAgICAgZnVsbF9hY2Nlc3MgPSAkNiwgZWRpdG9yID0gJDcsIGF1dGhvciA9ICQ4LCBjYW5fZGVsZXRlID0gJDksIHJlYWRlciA9ICQxMCwgXHJcbiAgICAgICBhY2Nlc3NfYnlfdGFncyA9ICQxMSwgb3JfdGFncyA9ICQxMiwgYW5kX3RhZ3MgPSAkMTMsIG5vX3RhZ3MgPSAkMTQsIFxyXG4gICAgICAgdGVuYW50X2lkID0gJDE1LCB0ZW5hbnRfbmFtZSA9ICQxNlxyXG4gICAgICAgV0hFUkUgaWQgPSAkMWAsXHJcbiAgICAgIFtcclxuICAgICAgICBwZXJtaXNzaW9uLmlkLFxyXG4gICAgICAgIHBlcm1pc3Npb24ucm9sZV9pZCxcclxuICAgICAgICBwZXJtaXNzaW9uLnJvbGVfbmFtZSxcclxuICAgICAgICBwZXJtaXNzaW9uLmRvY3R5cGUsXHJcbiAgICAgICAgcGVybWlzc2lvbi5kb2N0eXBlX25hbWUsXHJcbiAgICAgICAgcGVybWlzc2lvbi5mdWxsX2FjY2VzcyxcclxuICAgICAgICBwZXJtaXNzaW9uLmVkaXRvcixcclxuICAgICAgICBwZXJtaXNzaW9uLmF1dGhvcixcclxuICAgICAgICBwZXJtaXNzaW9uLmNhbl9kZWxldGUsXHJcbiAgICAgICAgcGVybWlzc2lvbi5yZWFkZXIsXHJcbiAgICAgICAgcGVybWlzc2lvbi5hY2Nlc3NfYnlfdGFncyxcclxuICAgICAgICBKU09OLnN0cmluZ2lmeShwZXJtaXNzaW9uLm9yX3RhZ3MpLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHBlcm1pc3Npb24uYW5kX3RhZ3MpLFxyXG4gICAgICAgIEpTT04uc3RyaW5naWZ5KHBlcm1pc3Npb24ubm9fdGFncyksXHJcbiAgICAgICAgcGVybWlzc2lvbi50ZW5hbnRfaWQsXHJcbiAgICAgICAgcGVybWlzc2lvbi50ZW5hbnRfbmFtZSxcclxuICAgICAgXVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgcGVybWlzc2lvbjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSBwZXJtaXNzaW9uOiBcIiArIGVycm9yKTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJvVEErTnNCLDZMQUFBIn0=
}),
"[project]/app/ui/ref-search.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RefSearch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/use-debounce/dist/index.module.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function RefSearch({ callback, term, elementIdPrefix }) {
    _s();
    const handleSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedCallback"])({
        "RefSearch.useDebouncedCallback[handleSearch]": (term)=>{
            callback(term);
        }
    }["RefSearch.useDebouncedCallback[handleSearch]"], 100);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative flex flex-1 flex-shrink-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: elementIdPrefix + 'search',
                className: "sr-only",
                children: "Search"
            }, void 0, false, {
                fileName: "[project]/app/ui/ref-search.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                id: elementIdPrefix + 'search',
                className: "peer block w-full h-10 rounded-md border border-gray-300 group-focus-within:border-blue-500   py-[9px] pl-10 text-sm placeholder:text-gray-500",
                placeholder: "найти ...",
                onChange: (e)=>{
                    handleSearch(e.target.value);
                },
                onFocus: (e)=>e.target.style.borderColor = '#3b82f6',
                onBlur: (e)=>e.target.style.borderColor = '#d2d6dc',
                value: term
            }, void 0, false, {
                fileName: "[project]/app/ui/ref-search.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__MagnifyingGlassIcon$3e$__["MagnifyingGlassIcon"], {
                className: "absolute left-3 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-gray-500 peer-focus:text-gray-900"
            }, void 0, false, {
                fileName: "[project]/app/ui/ref-search.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/ui/ref-search.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_s(RefSearch, "HFdfYUdpR2RsesUyL2Qu9GdfQic=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$debounce$2f$dist$2f$index$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedCallback"]
    ];
});
_c = RefSearch;
var _c;
__turbopack_context__.k.register(_c, "RefSearch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/roles/lib/roles-ref-table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RolesRefTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/ui/ref-search.tsx [app-client] (ecmascript)");
;
;
function RolesRefTable(props) {
    const handleSearch = (input)=>{
        props.setTerm(input);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Выберите роль:"
            }, void 0, false, {
                fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                lineNumber: 24,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                callback: handleSearch,
                term: props.term,
                elementIdPrefix: ""
            }, void 0, false, {
                fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                lineNumber: 25,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0 flow-root",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto md:block hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "inline-block min-w-full align-middle",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-hidden rounded-md bg-gray-50 p-1 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            className: "rounded-md bg-gray-50 text-left text-sm font-normal",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 overflow-hidden px-0 py-5 font-medium sm:pl-6",
                                                        children: "Название"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                                        lineNumber: 34,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 px-3 py-5 font-medium",
                                                        children: "Описание"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                                        lineNumber: 37,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                                lineNumber: 33,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                            lineNumber: 32,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                        lineNumber: 31,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                    lineNumber: 30,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            className: "divide-y divide-gray-200 text-gray-900",
                                            children: props.roles.filter((role)=>role.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((role)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap text-ellipsis bg-white py-1 pl-0 text-left     pr-3 text-sm text-black group-first-of-type:rounded-md group-last-of-type:rounded-md sm:pl-6",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-left gap-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    onClick: (e)=>{
                                                                        props.handleSelectRole(role.id, role.name, role.description, role.tenant_id, role.tenant_name);
                                                                        props.setTerm("");
                                                                        props.closeModal();
                                                                    },
                                                                    className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                                    children: role.name.substring(0, 36)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                                                    lineNumber: 58,
                                                                    columnNumber: 53
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                                                lineNumber: 57,
                                                                columnNumber: 49
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                                            lineNumber: 55,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                            children: role.description
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                                            lineNumber: 68,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, role.id, true, {
                                                    fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                                    lineNumber: 54,
                                                    columnNumber: 41
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                            lineNumber: 47,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                        lineNumber: 46,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                    lineNumber: 45,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                            lineNumber: 29,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                        lineNumber: 28,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "block md:hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2",
                            children: props.roles.filter((role)=>role.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((role)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-gray-200 bg-white p-4 text-sm text-gray-900 last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium text-black",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                onClick: (e)=>{
                                                    props.handleSelectRole(role.id, role.name, role.description, role.tenant_id, role.tenant_name);
                                                    props.setTerm("");
                                                    props.closeModal();
                                                },
                                                className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                children: role.name.substring(0, 36)
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                                lineNumber: 92,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                            lineNumber: 91,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500",
                                            children: role.description
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                            lineNumber: 103,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, role.id, true, {
                                    fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                                    lineNumber: 87,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                            lineNumber: 80,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                        lineNumber: 79,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
                lineNumber: 26,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/roles/lib/roles-ref-table.tsx",
        lineNumber: 23,
        columnNumber: 9
    }, this);
}
_c = RolesRefTable;
var _c;
__turbopack_context__.k.register(_c, "RolesRefTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/roles/lib/btn-roles-ref.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>IBtnRolesRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BookOpenIcon.js [app-client] (ecmascript) <export default as BookOpenIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$roles$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/roles/lib/roles-ref-table.tsx [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = Modal;
function IBtnRolesRef(props) {
    _s();
    // const regions = await fetchRegions();
    const [modal, setModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openModal = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setModal(true);
    // redirect("/dashboard/admin/tenants/1");
    };
    const closeModal = ()=>{
        setModal(false);
    };
    const [term, setTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: openModal,
                className: "rounded-md border border-gray-200 p-2 h-10 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__["BookOpenIcon"], {
                    className: "w-5 h-5 text-gray-800"
                }, void 0, false, {
                    fileName: "[project]/app/admin/roles/lib/btn-roles-ref.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/admin/roles/lib/btn-roles-ref.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Modal, {
                open: modal,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$roles$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        roles: props.roles,
                        handleSelectRole: props.handleSelectRole,
                        closeModal: closeModal,
                        setTerm: setTerm,
                        term: term
                    }, void 0, false, {
                        fileName: "[project]/app/admin/roles/lib/btn-roles-ref.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between space-x-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    alert("действие!");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/roles/lib/btn-roles-ref.tsx",
                                lineNumber: 55,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: closeModal,
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Exit"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/roles/lib/btn-roles-ref.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/roles/lib/btn-roles-ref.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/roles/lib/btn-roles-ref.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/roles/lib/btn-roles-ref.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
}
_s(IBtnRolesRef, "MW/KQDlZppFu/nDnRAs8d7ejpwM=");
_c1 = IBtnRolesRef;
var _c, _c1;
__turbopack_context__.k.register(_c, "Modal");
__turbopack_context__.k.register(_c1, "IBtnRolesRef");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/roles/lib/data:0c6d83 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createRole",
    ()=>$$RSC_SERVER_ACTION_6
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"7c09be398d4f21c6b8b3a95ed45aa805636d50e743":"createRole"},"app/admin/roles/lib/roles-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("7c09be398d4f21c6b8b3a95ed45aa805636d50e743", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "createRole");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcm9sZXMtYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb2xlcyBhY3Rpb25zLnRzXHJcblxyXG5cInVzZSBzZXJ2ZXJcIjtcclxuaW1wb3J0IHsgUm9sZSwgUm9sZUZvcm0gfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcbmltcG9ydCBwb29sIGZyb20gXCJAL2RiXCI7IC8vINCY0LzQv9C+0YDRgiDQv9GD0LvQsCDQv9C+0LTQutC70Y7Rh9C10L3QuNC5XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSBcIm5leHQvY2FjaGVcIjtcclxuLy8gaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tIFwibmV4dC9uYXZpZ2F0aW9uXCI7XHJcblxyXG4vLyNyZWdpb24gZmV0Y2hSb2xlc1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoUm9sZXMoKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PFJvbGU+KFxyXG4gICAgICBgU0VMRUNUIFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIHRlbmFudF9pZCxcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIHNlY3Rpb25faWRzLFxyXG4gICAgICAgIHNlY3Rpb25fbmFtZXMsXHJcbiAgICAgICAgQ09BTEVTQ0UoZGVzY3JpcHRpb24sICcnKSBBUyBkZXNjcmlwdGlvblxyXG4gICAgICBGUk9NIHJvbGVzXHJcbiAgICAgIE9SREVSIEJZIG5hbWUgQVNDYFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFsbCByb2xlcyBcIiArIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hSb2xlKGlkOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Um9sZT4oXHJcbiAgICAgIGBTRUxFQ1QgXHJcbiAgICAgICAgaWQsXHJcbiAgICAgICAgbmFtZSxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZHMsXHJcbiAgICAgICAgc2VjdGlvbl9uYW1lcyxcclxuICAgICAgICBDT0FMRVNDRShkZXNjcmlwdGlvbiwgJycpIEFTIGRlc2NyaXB0aW9uXHJcbiAgICAgIEZST00gcm9sZXNcclxuICAgICAgV0hFUkUgaWQgPSAkMWAsXHJcbiAgICAgIFtpZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCByb2xlIFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJvbGVGb3JtKGlkOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Um9sZUZvcm0+KFxyXG4gICAgICBgU0VMRUNUIFxyXG4gICAgICAgIHIuaWQsXHJcbiAgICAgICAgci5uYW1lLFxyXG4gICAgICAgIHIudGVuYW50X2lkLFxyXG4gICAgICAgIHIuc2VjdGlvbl9pZHMsXHJcbiAgICAgICAgci5zZWN0aW9uX25hbWVzLFxyXG4gICAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShyLmRlc2NyaXB0aW9uLCAnJykgQVMgZGVzY3JpcHRpb25cclxuICAgICAgRlJPTSByb2xlcyByXHJcbiAgICAgIExFRlQgSk9JTiB0ZW5hbnRzIHQgb24gci50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICAgIFdIRVJFIHIuaWQgPSAkMWAsXHJcbiAgICAgIFtpZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCByb2xlRm9ybVwiKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJvbGVzRm9ybVN1cGVyYWRtaW4oKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PFJvbGVGb3JtPihcclxuICAgICAgYFNFTEVDVCBcclxuICAgICAgICByLmlkLFxyXG4gICAgICAgIHIubmFtZSxcclxuICAgICAgICByLnRlbmFudF9pZCxcclxuICAgICAgICByLnNlY3Rpb25faWRzLFxyXG4gICAgICAgIGFycmF5X3RvX3N0cmluZyhyLnNlY3Rpb25fbmFtZXMsICcsICcpIEFTIHNlY3Rpb25fbmFtZXMsXHJcbiAgICAgICAgdC5uYW1lIGFzIHRlbmFudF9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKHIuZGVzY3JpcHRpb24sICcnKSBBUyBkZXNjcmlwdGlvblxyXG4gICAgICBGUk9NIHJvbGVzIHJcclxuICAgICAgTEVGVCBKT0lOIHRlbmFudHMgdCBvbiByLnRlbmFudF9pZCA9IHQuaWRcclxuICAgICAgT1JERVIgQlkgdC5uYW1lYFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFsbCByb2xlcyAoRm9ybSk6IFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJvbGVzRm9ybVdpdGhTZWN0aW9uU3VwZXJhZG1pbihcclxuICBzZWN0aW9uX25hbWU6IHN0cmluZyxcclxuICB0ZW5hbnRJZDogc3RyaW5nXHJcbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxSb2xlRm9ybT4oXHJcbiAgICAgIGBTRUxFQ1QgXHJcbiAgICAgIHIuaWQsXHJcbiAgICAgIHIubmFtZSxcclxuICAgICAgci50ZW5hbnRfaWQsXHJcbiAgICAgIHIuc2VjdGlvbl9pZHMsXHJcbiAgICAgIGFycmF5X3RvX3N0cmluZyhyLnNlY3Rpb25fbmFtZXMsICcsICcpIEFTIHNlY3Rpb25fbmFtZXMsXHJcbiAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgQ09BTEVTQ0Uoci5kZXNjcmlwdGlvbiwgJycpIEFTIGRlc2NyaXB0aW9uXHJcbiAgICBGUk9NIHJvbGVzIHJcclxuICAgIExFRlQgSk9JTiB0ZW5hbnRzIHQgT04gci50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICBXSEVSRSByLnNlY3Rpb25fbmFtZXMgQD4gQVJSQVlbJDE6OnZhcmNoYXJdIEFORCByLnRlbmFudF9pZCA9ICQyXHJcbiAgICBPUkRFUiBCWSB0Lm5hbWVgLFxyXG4gICAgICBbc2VjdGlvbl9uYW1lLCB0ZW5hbnRJZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCByb2xlcyB3aXRoIHNlY3Rpb25zOiBcIiArIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hSb2xlc0Zvcm1BZG1pbih0ZW5hbnRfaWQ6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxSb2xlRm9ybT4oXHJcbiAgICAgIGBTRUxFQ1QgXHJcbiAgICAgICAgci5pZCxcclxuICAgICAgICByLm5hbWUsXHJcbiAgICAgICAgci50ZW5hbnRfaWQsXHJcbiAgICAgICAgci5zZWN0aW9uX2lkcyxcclxuICAgICAgICBhcnJheV90b19zdHJpbmcoci5zZWN0aW9uX25hbWVzLCAnLCAnKSBBUyBzZWN0aW9uX25hbWVzLFxyXG4gICAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShyLmRlc2NyaXB0aW9uLCAnJykgQVMgZGVzY3JpcHRpb25cclxuICAgICAgRlJPTSByb2xlcyByXHJcbiAgICAgIExFRlQgSk9JTiB0ZW5hbnRzIHQgb24gci50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICAgIFdIRVJFIHIudGVuYW50X2lkID0gJDFcclxuICAgICAgT1JERVIgQlkgdC5uYW1lYCxcclxuICAgICAgW3RlbmFudF9pZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBhbGwgcm9sZXMgKEZvcm0pXCIpO1xyXG4gIH1cclxufVxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBSb2xlc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlUm9sZShcclxuICBuYW1lOiBzdHJpbmcsXHJcbiAgZGVzY3JpcHRpb246IHN0cmluZyxcclxuICB0ZW5hbnRfaWQ6IHN0cmluZyxcclxuICBzZWN0aW9uX2lkczogc3RyaW5nLFxyXG4gIHNlY3Rpb25fbmFtZXM6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYElOU0VSVCBJTlRPIHJvbGVzIChuYW1lLCBkZXNjcmlwdGlvbiwgdGVuYW50X2lkLCBzZWN0aW9uX2lkcywgc2VjdGlvbl9uYW1lcylcclxuICAgICAgIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1KVxyXG4gICAgICAgIFJFVFVSTklORyBpZCAgICAgICBcclxuICAgIGAsXHJcbiAgICAgIFtuYW1lLCBkZXNjcmlwdGlvbiwgdGVuYW50X2lkLCBzZWN0aW9uX2lkcywgc2VjdGlvbl9uYW1lc11cclxuICAgICk7XHJcbiAgICBjb25zdCBpZCA9IHJlc3VsdC5yb3dzWzBdLmlkO1xyXG4gICAgcmV0dXJuIGlkO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGNyZWF0ZSByb2xlOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gY3JlYXRlIHJvbGU6XCIgKyBlcnJvcik7XHJcbiAgfVxyXG5cclxuICByZXZhbGlkYXRlUGF0aChcIi9hZG1pbi9yb2xlc1wiKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVJvbGUocm9sZTogUm9sZSkge1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgVVBEQVRFIHJvbGVzXHJcbiAgICAgICBTRVQgbmFtZSA9ICQxLCBkZXNjcmlwdGlvbiA9ICQyLCB0ZW5hbnRfaWQgPSAkMyxcclxuICAgICAgICAgICBzZWN0aW9uX2lkcyA9ICQ0LCBzZWN0aW9uX25hbWVzID0gJDVcclxuICAgICAgIFdIRVJFIGlkID0gJDZgLFxyXG4gICAgICBbXHJcbiAgICAgICAgcm9sZS5uYW1lLFxyXG4gICAgICAgIHJvbGUuZGVzY3JpcHRpb24sXHJcbiAgICAgICAgcm9sZS50ZW5hbnRfaWQsXHJcbiAgICAgICAgcm9sZS5zZWN0aW9uX2lkcyxcclxuICAgICAgICByb2xlLnNlY3Rpb25fbmFtZXMsXHJcbiAgICAgICAgcm9sZS5pZCxcclxuICAgICAgXVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgcm9sZTpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSByb2xlOiBcIiArIGVycm9yKTtcclxuICB9XHJcblxyXG4gIC8vIHJldmFsaWRhdGVQYXRoKFwiL2FkbWluL3JvbGVzXCIpO1xyXG4gIC8vIHJlZGlyZWN0KFwiL2FkbWluL3JvbGVzXCIpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlUm9sZShpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIHJvbGVzIFdIRVJFIGlkID0gJDFgLCBbaWRdKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yLCBGYWlsZWQgdG8gZGVsZXRlIHJvbGU6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkRhdGFiYXNlIEVycm9yOiBGYWlsZWQgdG8gZGVsZXRlIHJvbGU6IFwiICsgZXJyb3IpO1xyXG4gIH1cclxuXHJcbiAgcmV2YWxpZGF0ZVBhdGgoXCIvYWRtaW4vcm9sZXNcIik7XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoibVNBMkpzQix1TEFBQSJ9
}),
"[project]/app/admin/roles/lib/data:073743 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteRole",
    ()=>$$RSC_SERVER_ACTION_8
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"406a1d8643050e5209e12976104dcd3145def77edc":"deleteRole"},"app/admin/roles/lib/roles-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("406a1d8643050e5209e12976104dcd3145def77edc", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteRole");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcm9sZXMtYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb2xlcyBhY3Rpb25zLnRzXHJcblxyXG5cInVzZSBzZXJ2ZXJcIjtcclxuaW1wb3J0IHsgUm9sZSwgUm9sZUZvcm0gfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcbmltcG9ydCBwb29sIGZyb20gXCJAL2RiXCI7IC8vINCY0LzQv9C+0YDRgiDQv9GD0LvQsCDQv9C+0LTQutC70Y7Rh9C10L3QuNC5XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSBcIm5leHQvY2FjaGVcIjtcclxuLy8gaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tIFwibmV4dC9uYXZpZ2F0aW9uXCI7XHJcblxyXG4vLyNyZWdpb24gZmV0Y2hSb2xlc1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoUm9sZXMoKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PFJvbGU+KFxyXG4gICAgICBgU0VMRUNUIFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIHRlbmFudF9pZCxcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIHNlY3Rpb25faWRzLFxyXG4gICAgICAgIHNlY3Rpb25fbmFtZXMsXHJcbiAgICAgICAgQ09BTEVTQ0UoZGVzY3JpcHRpb24sICcnKSBBUyBkZXNjcmlwdGlvblxyXG4gICAgICBGUk9NIHJvbGVzXHJcbiAgICAgIE9SREVSIEJZIG5hbWUgQVNDYFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFsbCByb2xlcyBcIiArIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hSb2xlKGlkOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Um9sZT4oXHJcbiAgICAgIGBTRUxFQ1QgXHJcbiAgICAgICAgaWQsXHJcbiAgICAgICAgbmFtZSxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZHMsXHJcbiAgICAgICAgc2VjdGlvbl9uYW1lcyxcclxuICAgICAgICBDT0FMRVNDRShkZXNjcmlwdGlvbiwgJycpIEFTIGRlc2NyaXB0aW9uXHJcbiAgICAgIEZST00gcm9sZXNcclxuICAgICAgV0hFUkUgaWQgPSAkMWAsXHJcbiAgICAgIFtpZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCByb2xlIFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJvbGVGb3JtKGlkOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Um9sZUZvcm0+KFxyXG4gICAgICBgU0VMRUNUIFxyXG4gICAgICAgIHIuaWQsXHJcbiAgICAgICAgci5uYW1lLFxyXG4gICAgICAgIHIudGVuYW50X2lkLFxyXG4gICAgICAgIHIuc2VjdGlvbl9pZHMsXHJcbiAgICAgICAgci5zZWN0aW9uX25hbWVzLFxyXG4gICAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShyLmRlc2NyaXB0aW9uLCAnJykgQVMgZGVzY3JpcHRpb25cclxuICAgICAgRlJPTSByb2xlcyByXHJcbiAgICAgIExFRlQgSk9JTiB0ZW5hbnRzIHQgb24gci50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICAgIFdIRVJFIHIuaWQgPSAkMWAsXHJcbiAgICAgIFtpZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCByb2xlRm9ybVwiKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJvbGVzRm9ybVN1cGVyYWRtaW4oKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PFJvbGVGb3JtPihcclxuICAgICAgYFNFTEVDVCBcclxuICAgICAgICByLmlkLFxyXG4gICAgICAgIHIubmFtZSxcclxuICAgICAgICByLnRlbmFudF9pZCxcclxuICAgICAgICByLnNlY3Rpb25faWRzLFxyXG4gICAgICAgIGFycmF5X3RvX3N0cmluZyhyLnNlY3Rpb25fbmFtZXMsICcsICcpIEFTIHNlY3Rpb25fbmFtZXMsXHJcbiAgICAgICAgdC5uYW1lIGFzIHRlbmFudF9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKHIuZGVzY3JpcHRpb24sICcnKSBBUyBkZXNjcmlwdGlvblxyXG4gICAgICBGUk9NIHJvbGVzIHJcclxuICAgICAgTEVGVCBKT0lOIHRlbmFudHMgdCBvbiByLnRlbmFudF9pZCA9IHQuaWRcclxuICAgICAgT1JERVIgQlkgdC5uYW1lYFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFsbCByb2xlcyAoRm9ybSk6IFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJvbGVzRm9ybVdpdGhTZWN0aW9uU3VwZXJhZG1pbihcclxuICBzZWN0aW9uX25hbWU6IHN0cmluZyxcclxuICB0ZW5hbnRJZDogc3RyaW5nXHJcbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxSb2xlRm9ybT4oXHJcbiAgICAgIGBTRUxFQ1QgXHJcbiAgICAgIHIuaWQsXHJcbiAgICAgIHIubmFtZSxcclxuICAgICAgci50ZW5hbnRfaWQsXHJcbiAgICAgIHIuc2VjdGlvbl9pZHMsXHJcbiAgICAgIGFycmF5X3RvX3N0cmluZyhyLnNlY3Rpb25fbmFtZXMsICcsICcpIEFTIHNlY3Rpb25fbmFtZXMsXHJcbiAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgQ09BTEVTQ0Uoci5kZXNjcmlwdGlvbiwgJycpIEFTIGRlc2NyaXB0aW9uXHJcbiAgICBGUk9NIHJvbGVzIHJcclxuICAgIExFRlQgSk9JTiB0ZW5hbnRzIHQgT04gci50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICBXSEVSRSByLnNlY3Rpb25fbmFtZXMgQD4gQVJSQVlbJDE6OnZhcmNoYXJdIEFORCByLnRlbmFudF9pZCA9ICQyXHJcbiAgICBPUkRFUiBCWSB0Lm5hbWVgLFxyXG4gICAgICBbc2VjdGlvbl9uYW1lLCB0ZW5hbnRJZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCByb2xlcyB3aXRoIHNlY3Rpb25zOiBcIiArIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hSb2xlc0Zvcm1BZG1pbih0ZW5hbnRfaWQ6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxSb2xlRm9ybT4oXHJcbiAgICAgIGBTRUxFQ1QgXHJcbiAgICAgICAgci5pZCxcclxuICAgICAgICByLm5hbWUsXHJcbiAgICAgICAgci50ZW5hbnRfaWQsXHJcbiAgICAgICAgci5zZWN0aW9uX2lkcyxcclxuICAgICAgICBhcnJheV90b19zdHJpbmcoci5zZWN0aW9uX25hbWVzLCAnLCAnKSBBUyBzZWN0aW9uX25hbWVzLFxyXG4gICAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShyLmRlc2NyaXB0aW9uLCAnJykgQVMgZGVzY3JpcHRpb25cclxuICAgICAgRlJPTSByb2xlcyByXHJcbiAgICAgIExFRlQgSk9JTiB0ZW5hbnRzIHQgb24gci50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICAgIFdIRVJFIHIudGVuYW50X2lkID0gJDFcclxuICAgICAgT1JERVIgQlkgdC5uYW1lYCxcclxuICAgICAgW3RlbmFudF9pZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBhbGwgcm9sZXMgKEZvcm0pXCIpO1xyXG4gIH1cclxufVxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBSb2xlc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlUm9sZShcclxuICBuYW1lOiBzdHJpbmcsXHJcbiAgZGVzY3JpcHRpb246IHN0cmluZyxcclxuICB0ZW5hbnRfaWQ6IHN0cmluZyxcclxuICBzZWN0aW9uX2lkczogc3RyaW5nLFxyXG4gIHNlY3Rpb25fbmFtZXM6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYElOU0VSVCBJTlRPIHJvbGVzIChuYW1lLCBkZXNjcmlwdGlvbiwgdGVuYW50X2lkLCBzZWN0aW9uX2lkcywgc2VjdGlvbl9uYW1lcylcclxuICAgICAgIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1KVxyXG4gICAgICAgIFJFVFVSTklORyBpZCAgICAgICBcclxuICAgIGAsXHJcbiAgICAgIFtuYW1lLCBkZXNjcmlwdGlvbiwgdGVuYW50X2lkLCBzZWN0aW9uX2lkcywgc2VjdGlvbl9uYW1lc11cclxuICAgICk7XHJcbiAgICBjb25zdCBpZCA9IHJlc3VsdC5yb3dzWzBdLmlkO1xyXG4gICAgcmV0dXJuIGlkO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGNyZWF0ZSByb2xlOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gY3JlYXRlIHJvbGU6XCIgKyBlcnJvcik7XHJcbiAgfVxyXG5cclxuICByZXZhbGlkYXRlUGF0aChcIi9hZG1pbi9yb2xlc1wiKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVJvbGUocm9sZTogUm9sZSkge1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgVVBEQVRFIHJvbGVzXHJcbiAgICAgICBTRVQgbmFtZSA9ICQxLCBkZXNjcmlwdGlvbiA9ICQyLCB0ZW5hbnRfaWQgPSAkMyxcclxuICAgICAgICAgICBzZWN0aW9uX2lkcyA9ICQ0LCBzZWN0aW9uX25hbWVzID0gJDVcclxuICAgICAgIFdIRVJFIGlkID0gJDZgLFxyXG4gICAgICBbXHJcbiAgICAgICAgcm9sZS5uYW1lLFxyXG4gICAgICAgIHJvbGUuZGVzY3JpcHRpb24sXHJcbiAgICAgICAgcm9sZS50ZW5hbnRfaWQsXHJcbiAgICAgICAgcm9sZS5zZWN0aW9uX2lkcyxcclxuICAgICAgICByb2xlLnNlY3Rpb25fbmFtZXMsXHJcbiAgICAgICAgcm9sZS5pZCxcclxuICAgICAgXVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgcm9sZTpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSByb2xlOiBcIiArIGVycm9yKTtcclxuICB9XHJcblxyXG4gIC8vIHJldmFsaWRhdGVQYXRoKFwiL2FkbWluL3JvbGVzXCIpO1xyXG4gIC8vIHJlZGlyZWN0KFwiL2FkbWluL3JvbGVzXCIpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlUm9sZShpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIHJvbGVzIFdIRVJFIGlkID0gJDFgLCBbaWRdKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yLCBGYWlsZWQgdG8gZGVsZXRlIHJvbGU6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkRhdGFiYXNlIEVycm9yOiBGYWlsZWQgdG8gZGVsZXRlIHJvbGU6IFwiICsgZXJyb3IpO1xyXG4gIH1cclxuXHJcbiAgcmV2YWxpZGF0ZVBhdGgoXCIvYWRtaW4vcm9sZXNcIik7XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoibVNBNk1zQix1TEFBQSJ9
}),
"[project]/app/admin/roles/lib/data:eed918 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateRole",
    ()=>$$RSC_SERVER_ACTION_7
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"404df822e404e61bf1d65a40da88e834ff63ed8a73":"updateRole"},"app/admin/roles/lib/roles-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("404df822e404e61bf1d65a40da88e834ff63ed8a73", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateRole");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vcm9sZXMtYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBSb2xlcyBhY3Rpb25zLnRzXHJcblxyXG5cInVzZSBzZXJ2ZXJcIjtcclxuaW1wb3J0IHsgUm9sZSwgUm9sZUZvcm0gfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcbmltcG9ydCBwb29sIGZyb20gXCJAL2RiXCI7IC8vINCY0LzQv9C+0YDRgiDQv9GD0LvQsCDQv9C+0LTQutC70Y7Rh9C10L3QuNC5XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSBcIm5leHQvY2FjaGVcIjtcclxuLy8gaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tIFwibmV4dC9uYXZpZ2F0aW9uXCI7XHJcblxyXG4vLyNyZWdpb24gZmV0Y2hSb2xlc1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoUm9sZXMoKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PFJvbGU+KFxyXG4gICAgICBgU0VMRUNUIFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIHRlbmFudF9pZCxcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIHNlY3Rpb25faWRzLFxyXG4gICAgICAgIHNlY3Rpb25fbmFtZXMsXHJcbiAgICAgICAgQ09BTEVTQ0UoZGVzY3JpcHRpb24sICcnKSBBUyBkZXNjcmlwdGlvblxyXG4gICAgICBGUk9NIHJvbGVzXHJcbiAgICAgIE9SREVSIEJZIG5hbWUgQVNDYFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFsbCByb2xlcyBcIiArIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hSb2xlKGlkOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Um9sZT4oXHJcbiAgICAgIGBTRUxFQ1QgXHJcbiAgICAgICAgaWQsXHJcbiAgICAgICAgbmFtZSxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZHMsXHJcbiAgICAgICAgc2VjdGlvbl9uYW1lcyxcclxuICAgICAgICBDT0FMRVNDRShkZXNjcmlwdGlvbiwgJycpIEFTIGRlc2NyaXB0aW9uXHJcbiAgICAgIEZST00gcm9sZXNcclxuICAgICAgV0hFUkUgaWQgPSAkMWAsXHJcbiAgICAgIFtpZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCByb2xlIFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJvbGVGb3JtKGlkOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Um9sZUZvcm0+KFxyXG4gICAgICBgU0VMRUNUIFxyXG4gICAgICAgIHIuaWQsXHJcbiAgICAgICAgci5uYW1lLFxyXG4gICAgICAgIHIudGVuYW50X2lkLFxyXG4gICAgICAgIHIuc2VjdGlvbl9pZHMsXHJcbiAgICAgICAgci5zZWN0aW9uX25hbWVzLFxyXG4gICAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShyLmRlc2NyaXB0aW9uLCAnJykgQVMgZGVzY3JpcHRpb25cclxuICAgICAgRlJPTSByb2xlcyByXHJcbiAgICAgIExFRlQgSk9JTiB0ZW5hbnRzIHQgb24gci50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICAgIFdIRVJFIHIuaWQgPSAkMWAsXHJcbiAgICAgIFtpZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93c1swXTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCByb2xlRm9ybVwiKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJvbGVzRm9ybVN1cGVyYWRtaW4oKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PFJvbGVGb3JtPihcclxuICAgICAgYFNFTEVDVCBcclxuICAgICAgICByLmlkLFxyXG4gICAgICAgIHIubmFtZSxcclxuICAgICAgICByLnRlbmFudF9pZCxcclxuICAgICAgICByLnNlY3Rpb25faWRzLFxyXG4gICAgICAgIGFycmF5X3RvX3N0cmluZyhyLnNlY3Rpb25fbmFtZXMsICcsICcpIEFTIHNlY3Rpb25fbmFtZXMsXHJcbiAgICAgICAgdC5uYW1lIGFzIHRlbmFudF9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKHIuZGVzY3JpcHRpb24sICcnKSBBUyBkZXNjcmlwdGlvblxyXG4gICAgICBGUk9NIHJvbGVzIHJcclxuICAgICAgTEVGVCBKT0lOIHRlbmFudHMgdCBvbiByLnRlbmFudF9pZCA9IHQuaWRcclxuICAgICAgT1JERVIgQlkgdC5uYW1lYFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIGFsbCByb2xlcyAoRm9ybSk6IFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaFJvbGVzRm9ybVdpdGhTZWN0aW9uU3VwZXJhZG1pbihcclxuICBzZWN0aW9uX25hbWU6IHN0cmluZyxcclxuICB0ZW5hbnRJZDogc3RyaW5nXHJcbikge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxSb2xlRm9ybT4oXHJcbiAgICAgIGBTRUxFQ1QgXHJcbiAgICAgIHIuaWQsXHJcbiAgICAgIHIubmFtZSxcclxuICAgICAgci50ZW5hbnRfaWQsXHJcbiAgICAgIHIuc2VjdGlvbl9pZHMsXHJcbiAgICAgIGFycmF5X3RvX3N0cmluZyhyLnNlY3Rpb25fbmFtZXMsICcsICcpIEFTIHNlY3Rpb25fbmFtZXMsXHJcbiAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgQ09BTEVTQ0Uoci5kZXNjcmlwdGlvbiwgJycpIEFTIGRlc2NyaXB0aW9uXHJcbiAgICBGUk9NIHJvbGVzIHJcclxuICAgIExFRlQgSk9JTiB0ZW5hbnRzIHQgT04gci50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICBXSEVSRSByLnNlY3Rpb25fbmFtZXMgQD4gQVJSQVlbJDE6OnZhcmNoYXJdIEFORCByLnRlbmFudF9pZCA9ICQyXHJcbiAgICBPUkRFUiBCWSB0Lm5hbWVgLFxyXG4gICAgICBbc2VjdGlvbl9uYW1lLCB0ZW5hbnRJZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCByb2xlcyB3aXRoIHNlY3Rpb25zOiBcIiArIGVycik7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hSb2xlc0Zvcm1BZG1pbih0ZW5hbnRfaWQ6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxSb2xlRm9ybT4oXHJcbiAgICAgIGBTRUxFQ1QgXHJcbiAgICAgICAgci5pZCxcclxuICAgICAgICByLm5hbWUsXHJcbiAgICAgICAgci50ZW5hbnRfaWQsXHJcbiAgICAgICAgci5zZWN0aW9uX2lkcyxcclxuICAgICAgICBhcnJheV90b19zdHJpbmcoci5zZWN0aW9uX25hbWVzLCAnLCAnKSBBUyBzZWN0aW9uX25hbWVzLFxyXG4gICAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShyLmRlc2NyaXB0aW9uLCAnJykgQVMgZGVzY3JpcHRpb25cclxuICAgICAgRlJPTSByb2xlcyByXHJcbiAgICAgIExFRlQgSk9JTiB0ZW5hbnRzIHQgb24gci50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICAgIFdIRVJFIHIudGVuYW50X2lkID0gJDFcclxuICAgICAgT1JERVIgQlkgdC5uYW1lYCxcclxuICAgICAgW3RlbmFudF9pZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBhbGwgcm9sZXMgKEZvcm0pXCIpO1xyXG4gIH1cclxufVxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBSb2xlc1xyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY3JlYXRlUm9sZShcclxuICBuYW1lOiBzdHJpbmcsXHJcbiAgZGVzY3JpcHRpb246IHN0cmluZyxcclxuICB0ZW5hbnRfaWQ6IHN0cmluZyxcclxuICBzZWN0aW9uX2lkczogc3RyaW5nLFxyXG4gIHNlY3Rpb25fbmFtZXM6IHN0cmluZ1xyXG4pIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYElOU0VSVCBJTlRPIHJvbGVzIChuYW1lLCBkZXNjcmlwdGlvbiwgdGVuYW50X2lkLCBzZWN0aW9uX2lkcywgc2VjdGlvbl9uYW1lcylcclxuICAgICAgIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1KVxyXG4gICAgICAgIFJFVFVSTklORyBpZCAgICAgICBcclxuICAgIGAsXHJcbiAgICAgIFtuYW1lLCBkZXNjcmlwdGlvbiwgdGVuYW50X2lkLCBzZWN0aW9uX2lkcywgc2VjdGlvbl9uYW1lc11cclxuICAgICk7XHJcbiAgICBjb25zdCBpZCA9IHJlc3VsdC5yb3dzWzBdLmlkO1xyXG4gICAgcmV0dXJuIGlkO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIGNyZWF0ZSByb2xlOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gY3JlYXRlIHJvbGU6XCIgKyBlcnJvcik7XHJcbiAgfVxyXG5cclxuICByZXZhbGlkYXRlUGF0aChcIi9hZG1pbi9yb2xlc1wiKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVJvbGUocm9sZTogUm9sZSkge1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgVVBEQVRFIHJvbGVzXHJcbiAgICAgICBTRVQgbmFtZSA9ICQxLCBkZXNjcmlwdGlvbiA9ICQyLCB0ZW5hbnRfaWQgPSAkMyxcclxuICAgICAgICAgICBzZWN0aW9uX2lkcyA9ICQ0LCBzZWN0aW9uX25hbWVzID0gJDVcclxuICAgICAgIFdIRVJFIGlkID0gJDZgLFxyXG4gICAgICBbXHJcbiAgICAgICAgcm9sZS5uYW1lLFxyXG4gICAgICAgIHJvbGUuZGVzY3JpcHRpb24sXHJcbiAgICAgICAgcm9sZS50ZW5hbnRfaWQsXHJcbiAgICAgICAgcm9sZS5zZWN0aW9uX2lkcyxcclxuICAgICAgICByb2xlLnNlY3Rpb25fbmFtZXMsXHJcbiAgICAgICAgcm9sZS5pZCxcclxuICAgICAgXVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgcm9sZTpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSByb2xlOiBcIiArIGVycm9yKTtcclxuICB9XHJcblxyXG4gIC8vIHJldmFsaWRhdGVQYXRoKFwiL2FkbWluL3JvbGVzXCIpO1xyXG4gIC8vIHJlZGlyZWN0KFwiL2FkbWluL3JvbGVzXCIpO1xyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlUm9sZShpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIHJvbGVzIFdIRVJFIGlkID0gJDFgLCBbaWRdKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yLCBGYWlsZWQgdG8gZGVsZXRlIHJvbGU6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkRhdGFiYXNlIEVycm9yOiBGYWlsZWQgdG8gZGVsZXRlIHJvbGU6IFwiICsgZXJyb3IpO1xyXG4gIH1cclxuXHJcbiAgcmV2YWxpZGF0ZVBhdGgoXCIvYWRtaW4vcm9sZXNcIik7XHJcbn1cclxuLy8jZW5kcmVnaW9uXHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoibVNBb0xzQix1TEFBQSJ9
}),
"[project]/app/admin/users/lib/data:2967d2 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "fetchUsersWithRoleAdmin",
    ()=>$$RSC_SERVER_ACTION_6
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"609cc6b33acb12df54186aa9a09ca9a16ae1ebe474":"fetchUsersWithRoleAdmin"},"app/admin/users/lib/users-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("609cc6b33acb12df54186aa9a09ca9a16ae1ebe474", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "fetchUsersWithRoleAdmin");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vdXNlcnMtYWN0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBVc2VycyBhY3Rpb25zLnRzXHJcblxyXG5cInVzZSBzZXJ2ZXJcIjtcclxuXHJcbmltcG9ydCBwb29sIGZyb20gXCJAL2RiXCI7XHJcbmltcG9ydCB7IHJldmFsaWRhdGVQYXRoIH0gZnJvbSBcIm5leHQvY2FjaGVcIjtcclxuaW1wb3J0IHR5cGUgeyBVc2VyLCBVc2VyRm9ybSB9IGZyb20gXCJAL2FwcC9saWIvZGVmaW5pdGlvbnNcIjtcclxuaW1wb3J0IGJjcnlwdCBmcm9tIFwiYmNyeXB0XCI7XHJcblxyXG4vLyNyZWdpb24gVXNlcnNcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVVzZXIoXHJcbiAgZW1haWw6IHN0cmluZyxcclxuICBwYXNzd29yZDogc3RyaW5nLFxyXG4gIHRlbmFudF9pZDogc3RyaW5nLFxyXG4gIGlzX2FkbWluOiBib29sZWFuID0gZmFsc2VcclxuKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICBjb25zdCBzYWx0T3JSb3VuZHMgPSAxMDtcclxuICBjb25zdCBoYXNoID0gYXdhaXQgYmNyeXB0Lmhhc2gocGFzc3dvcmQsIHNhbHRPclJvdW5kcyk7XHJcblxyXG4gIGNvbnN0IG5ld1VzZXI6IFVzZXIgPSB7XHJcbiAgICBpZDogXCJcIixcclxuICAgIG5hbWU6IGVtYWlsLFxyXG4gICAgZW1haWw6IGVtYWlsLFxyXG4gICAgcGFzc3dvcmQ6IGhhc2gsXHJcbiAgICB0ZW5hbnRfaWQ6IHRlbmFudF9pZCxcclxuICAgIGlzX2FkbWluOiBpc19hZG1pbixcclxuICAgIGlzX3N1cGVyYWRtaW46IGZhbHNlLFxyXG4gICAgcm9sZV9pZHM6IFwie31cIixcclxuICB9O1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYElOU0VSVCBJTlRPIHVzZXJzIChuYW1lLCBlbWFpbCwgcGFzc3dvcmQsIGlzX2FkbWluLCB0ZW5hbnRfaWQpXHJcbiAgICAgICBWQUxVRVMgKCQxLCAkMiwgJDMsICQ0LCAkNSlcclxuICAgICAgIFJFVFVSTklORyBpZGAsXHJcbiAgICAgIFtuZXdVc2VyLm5hbWUsIG5ld1VzZXIuZW1haWwsIG5ld1VzZXIucGFzc3dvcmQsIG5ld1VzZXIuaXNfYWRtaW4sIG5ld1VzZXIudGVuYW50X2lkXVxyXG4gICAgKTtcclxuICAgIGNvbnN0IGlkID0gcmVzdWx0LnJvd3NbMF0uaWQ7XHJcbiAgICByZXR1cm4gaWQ7ICBcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBjcmVhdGUgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGNyZWF0ZSB1c2VyOiBcIiArIGVycm9yKTtcclxuICB9XHJcbiAgcmV2YWxpZGF0ZVBhdGgoXCIvYWRtaW4vdXNlcnNcIik7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVVc2VyKHVzZXI6IFVzZXIpIHtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYFVQREFURSB1c2Vyc1xyXG4gICAgICAgU0VUIG5hbWUgPSAkMSwgXHJcbiAgICAgICAgICAgZW1haWwgPSAkMiwgXHJcbiAgICAgICAgICAgaXNfYWRtaW4gPSAkMywgXHJcbiAgICAgICAgICAgdGVuYW50X2lkID0gJDQsXHJcbiAgICAgICAgICAgcm9sZV9pZHMgPSAkNVxyXG4gICAgICAgV0hFUkUgaWQgPSAkNmAsXHJcbiAgICAgIFt1c2VyLm5hbWUsIHVzZXIuZW1haWwsIHVzZXIuaXNfYWRtaW4sIHVzZXIudGVuYW50X2lkLCB1c2VyLnJvbGVfaWRzLCB1c2VyLmlkXVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byB1cGRhdGUgdXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHVwZGF0ZSB1c2VyLlwiKTtcclxuICB9XHJcbiAgcmV2YWxpZGF0ZVBhdGgoXCIvYWRtaW4vdXNlcnNcIik7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVVc2VyKGVtYWlsOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYERFTEVURSBGUk9NIHVzZXJzIFdIRVJFIGVtYWlsID0gJDFgLFxyXG4gICAgICBbZW1haWxdXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgRXJyb3IsIEZhaWxlZCB0byBEZWxldGUgVXNlcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRGF0YWJhc2UgRXJyb3I6IEZhaWxlZCB0byBEZWxldGUgVXNlclwiKTtcclxuICB9XHJcbiAgcmV2YWxpZGF0ZVBhdGgoXCIvYWRtaW5cIik7XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVVc2VyQnlJZChpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoXHJcbiAgICAgIGBERUxFVEUgRlJPTSB1c2VycyBXSEVSRSBpZCA9ICQxYCxcclxuICAgICAgW2lkXVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yLCBGYWlsZWQgdG8gRGVsZXRlIFVzZXIgYnkgaWQ6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkRhdGFiYXNlIEVycm9yOiBGYWlsZWQgdG8gRGVsZXRlIFVzZXIgYnkgaWRcIik7XHJcbiAgfVxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL2FkbWluL3VzZXJzXCIpO1xyXG59XHJcbi8vI2VuZHJlZ2lvblxyXG5cclxuLy8jcmVnaW9uIGZldGNoVXNlcnNcclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlcnNTdXBlcmFkbWluKCkge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb29sLnF1ZXJ5PFVzZXJGb3JtPihcclxuICAgICAgYFNFTEVDVFxyXG4gICAgICAgICB1LmlkIGFzIGlkLFxyXG4gICAgICAgICB1Lm5hbWUgYXMgbmFtZSxcclxuICAgICAgICAgdS5lbWFpbCBhcyBlbWFpbCxcclxuICAgICAgICAgdS5pc19hZG1pbiBhcyBpc19hZG1pbixcclxuICAgICAgICAgdS5pc19zdXBlcmFkbWluIGFzIGlzX3N1cGVyYWRtaW4sXHJcbiAgICAgICAgIHUudGVuYW50X2lkIGFzIHRlbmFudF9pZCxcclxuICAgICAgICAgdC5uYW1lIGFzIHRlbmFudF9uYW1lLFxyXG4gICAgICAgICB1LnJvbGVfaWRzIGFzIHJvbGVfaWRzXHJcbiAgICAgICBGUk9NIHVzZXJzIHUgXHJcbiAgICAgICBKT0lOIHRlbmFudHMgdCBPTiB1LnRlbmFudF9pZCA9IHQuaWRcclxuICAgICAgIE9SREVSIEJZIHRlbmFudF9pZCBBU0NgXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiByZXN1bHQucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBhbGwgdXNlcnMuXCIpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlcnNBZG1pbih0ZW5hbnRfaWQ6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb29sLnF1ZXJ5PFVzZXJGb3JtPihcclxuICAgICAgYFNFTEVDVFxyXG4gICAgICAgICB1LmlkIGFzIGlkLFxyXG4gICAgICAgICB1Lm5hbWUgYXMgbmFtZSxcclxuICAgICAgICAgdS5lbWFpbCBhcyBlbWFpbCxcclxuICAgICAgICAgdS5pc19hZG1pbiBhcyBpc19hZG1pbixcclxuICAgICAgICAgdS5pc19zdXBlcmFkbWluIGFzIGlzX3N1cGVyYWRtaW4sXHJcbiAgICAgICAgIHUudGVuYW50X2lkIGFzIHRlbmFudF9pZCxcclxuICAgICAgICAgdC5uYW1lIGFzIHRlbmFudF9uYW1lLFxyXG4gICAgICAgICB1LnJvbGVfaWRzIGFzIHJvbGVfaWRzXHJcbiAgICAgICBGUk9NIHVzZXJzIHUgXHJcbiAgICAgICBKT0lOIHRlbmFudHMgdCBPTiB1LnRlbmFudF9pZCA9IHQuaWRcclxuICAgICAgIFdIRVJFIHUudGVuYW50X2lkID0gJDFcclxuICAgICAgIE9SREVSIEJZIHRlbmFudF9pZCBBU0NgLFxyXG4gICAgICBbdGVuYW50X2lkXVxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gcmVzdWx0LnJvd3M7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgRXJyb3I6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggYWxsIHVzZXJzLlwiKTtcclxuICB9XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlcnNXaXRoUm9sZUFkbWluKHJvbGVfaWQ6IHN0cmluZywgdGVuYW50X2lkOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9vbC5xdWVyeTxVc2VyRm9ybT4oXHJcbiAgICAgIGBTRUxFQ1RcclxuICAgICAgICAgdS5pZCBhcyBpZCxcclxuICAgICAgICAgdS5uYW1lIGFzIG5hbWUsXHJcbiAgICAgICAgIHUuZW1haWwgYXMgZW1haWwsXHJcbiAgICAgICAgIHUuaXNfYWRtaW4gYXMgaXNfYWRtaW4sXHJcbiAgICAgICAgIHUuaXNfc3VwZXJhZG1pbiBhcyBpc19zdXBlcmFkbWluLFxyXG4gICAgICAgICB1LnRlbmFudF9pZCBhcyB0ZW5hbnRfaWQsXHJcbiAgICAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgICAgdS5yb2xlX2lkcyBhcyByb2xlX2lkc1xyXG4gICAgICAgRlJPTSB1c2VycyB1IFxyXG4gICAgICAgSk9JTiB0ZW5hbnRzIHQgT04gdS50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICAgICBXSEVSRSB1LnRlbmFudF9pZCA9ICQxIEFORCB1LnJvbGVfaWRzIEA+IEFSUkFZWyQyOjp1dWlkXVxyXG4gICAgICAgT1JERVIgQlkgdGVuYW50X2lkIEFTQ2AsXHJcbiAgICAgIFt0ZW5hbnRfaWQsIHJvbGVfaWRdXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiByZXN1bHQucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCB1c2VycyB3aXRoIHJvbGU6IFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlcnNVc2VyKGVtYWlsOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcG9vbC5xdWVyeTxVc2VyRm9ybT4oXHJcbiAgICAgIGBTRUxFQ1RcclxuICAgICAgICAgdS5pZCBhcyBpZCxcclxuICAgICAgICAgdS5uYW1lIGFzIG5hbWUsXHJcbiAgICAgICAgIHUuZW1haWwgYXMgZW1haWwsXHJcbiAgICAgICAgIHUuaXNfYWRtaW4gYXMgaXNfYWRtaW4sXHJcbiAgICAgICAgIHUuaXNfc3VwZXJhZG1pbiBhcyBpc19zdXBlcmFkbWluLFxyXG4gICAgICAgICB1LnRlbmFudF9pZCBhcyB0ZW5hbnRfaWQsXHJcbiAgICAgICAgIHQubmFtZSBhcyB0ZW5hbnRfbmFtZSxcclxuICAgICAgICAgdS5yb2xlX2lkcyBhcyByb2xlX2lkc1xyXG4gICAgICAgRlJPTSB1c2VycyB1IFxyXG4gICAgICAgSk9JTiB0ZW5hbnRzIHQgT04gdS50ZW5hbnRfaWQgPSB0LmlkXHJcbiAgICAgICBXSEVSRSB1LmVtYWlsID0gJDFcclxuICAgICAgIE9SREVSIEJZIHRlbmFudF9pZCBBU0NgLFxyXG4gICAgICBbZW1haWxdXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiByZXN1bHQucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCJEYXRhYmFzZSBFcnJvcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byBmZXRjaCBhbGwgdXNlcnMuXCIpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoVXNlckJ5SWQoaWQ6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBwb29sLnF1ZXJ5PFVzZXJGb3JtPihcclxuICAgICAgYFNFTEVDVFxyXG4gICAgICAgICB1LmlkIGFzIGlkLFxyXG4gICAgICAgICB1Lm5hbWUgYXMgbmFtZSxcclxuICAgICAgICAgdS5lbWFpbCBhcyBlbWFpbCxcclxuICAgICAgICAgdS5pc19hZG1pbiBhcyBpc19hZG1pbixcclxuICAgICAgICAgdS5pc19zdXBlcmFkbWluIGFzIGlzX3N1cGVyYWRtaW4sXHJcbiAgICAgICAgIHUudGVuYW50X2lkIGFzIHRlbmFudF9pZCxcclxuICAgICAgICAgdC5uYW1lIGFzIHRlbmFudF9uYW1lLFxyXG4gICAgICAgICB1LnJvbGVfaWRzIGFzIHJvbGVfaWRzXHJcbiAgICAgICBGUk9NIHVzZXJzIHUgXHJcbiAgICAgICBKT0lOIHRlbmFudHMgdCBPTiB1LnRlbmFudF9pZCA9IHQuaWRcclxuICAgICAgIFdIRVJFIHUuaWQgPSAkMWAsXHJcbiAgICAgIFtpZF1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIHJlc3VsdC5yb3dzWzBdO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcIkRhdGFiYXNlIEVycm9yOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGZldGNoIHVzZXIgYnkgaWQuXCIpO1xyXG4gIH1cclxufVxyXG4vLyNlbmRyZWdpb24iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6ImdUQThJc0Isb01BQUEifQ==
}),
"[project]/app/admin/roles/lib/store/use-role-store.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "addRole",
    ()=>addRole,
    "delRole",
    ()=>delRole,
    "fillRoles",
    ()=>fillRoles,
    "updRole",
    ()=>updRole,
    "useRoles",
    ()=>useRoles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$data$3a$0c6d83__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/admin/roles/lib/data:0c6d83 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$data$3a$073743__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/admin/roles/lib/data:073743 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$data$3a$eed918__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/admin/roles/lib/data:eed918 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$users$2f$lib$2f$data$3a$2967d2__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/admin/users/lib/data:2967d2 [app-client] (ecmascript) <text/javascript>");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const initialState = {
    roles: []
};
const roleStore = (set)=>({
        ...initialState,
        fillRoles: (roles)=>{
            set({
                roles
            }, false, "fillRoles");
        },
        addRole: async (name, description, tenantId, tenantName, sectionIds, sectionNames)=>{
            try {
                const newRoleId = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$data$3a$0c6d83__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["createRole"])(name, description, tenantId, sectionIds, sectionNames);
                const newRole = {
                    id: newRoleId,
                    name,
                    description,
                    tenant_id: tenantId,
                    section_ids: sectionIds,
                    section_names: ""
                };
                set((state)=>{
                    state.roles.push({
                        ...newRole,
                        tenant_name: tenantName
                    });
                    state.roles.sort((a, b)=>a.name > b.name ? 1 : -1);
                }, false, "addRole");
            } catch (error) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])(String(error));
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
            }
        },
        updRole: (id, newRole)=>{
            set((state)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$data$3a$eed918__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updateRole"])(newRole);
                const index = state.roles.findIndex((r)=>r.id === id);
                if (index !== -1) {
                    state.roles[index] = newRole;
                }
            }, false, "updRole");
        },
        delRole: async (role)=>{
            try {
                const users = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$users$2f$lib$2f$data$3a$2967d2__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["fetchUsersWithRoleAdmin"])(role.id, role.tenant_id);
                if (users.length > 0) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])(`Роль: ${role.name} \nНельзя удалить Роль, используемую Пользователем: ${users[0].email} в Организации: ${users[0].tenant_name}`);
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
                    return;
                }
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$data$3a$073743__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["deleteRole"])(role.id);
                set((state)=>{
                    const index = state.roles.findIndex((r)=>r.id === role.id);
                    if (index !== -1) {
                        state.roles.splice(index, 1);
                    // console.log("splice roles index: " + index);
                    }
                }, false, "delRole");
            } catch (error) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])(String(error));
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
            }
        }
    });
const useRoleStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["immer"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["devtools"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["persist"])(roleStore, {
    name: "role-storage",
    storage: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createJSONStorage"])(()=>localStorage),
    partialize: (state)=>({
            roles: state.roles
        })
}), {
    name: "Roles"
})));
const useRoles = ()=>{
    _s();
    return useRoleStore({
        "useRoles.useRoleStore": (state)=>state.roles
    }["useRoles.useRoleStore"]);
};
_s(useRoles, "lFQeE/PyW+U9b+YSuYE3Cu5JXc0=", false, function() {
    return [
        useRoleStore
    ];
});
const fillRoles = (roles)=>useRoleStore.getState().fillRoles(roles);
const addRole = (name, description, tenantId, tenantName, sectionIds, sectionNames)=>useRoleStore.getState().addRole(name, description, tenantId, tenantName, sectionIds, sectionNames);
const updRole = (id, newRole)=>useRoleStore.getState().updRole(id, newRole);
const delRole = async (role)=>useRoleStore.getState().delRole(role); // (конец образца)
 // // вот как определены типы Role и RoleForm
 // export type Role = {
 //   id: string;
 //   name: string;
 //   description: string;
 //   tenant_id: string;
 //   section_ids: string;
 //   section_names: string;
 // };
 // export type RoleForm = {
 //   id: string;
 //   name: string;
 //   description: string;
 //   tenant_id: string;
 //   tenant_name: string;
 //   section_ids?: string;
 //   section_names?: string;
 // };
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/collapsible-section.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client'; // Обязательно для клиентских компонентов в Next.js 13+
;
const CollapsibleSection = (props)=>{
    _s();
    const [isCollapsed, setIsCollapsed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "border border-gray-300 rounded-lg p-4 max-w-[1300px] ",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "cursor-pointer font-semibold text-blue-600 flex items-center",
                onClick: ()=>setIsCollapsed(!isCollapsed),
                children: [
                    isCollapsed ? '▼' : '▲',
                    " ",
                    props.header
                ]
            }, void 0, true, {
                fileName: "[project]/app/lib/collapsible-section.tsx",
                lineNumber: 15,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                // className={`overflow-hidden transition-all duration-300 ease-in-out ${isCollapsed ? 'max-h-0 opacity-0' : 'max-h-96 opacity-100'
                //     }`}
                className: `overflow-hidden transition-all duration-300 ease-in-out ${isCollapsed ? 'max-h-0 opacity-0' : 'max-h-[2000px] opacity-100'}`,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-2 text-gray-700",
                    children: props.children
                }, void 0, false, {
                    fileName: "[project]/app/lib/collapsible-section.tsx",
                    lineNumber: 31,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/app/lib/collapsible-section.tsx",
                lineNumber: 23,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/lib/collapsible-section.tsx",
        lineNumber: 13,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_s(CollapsibleSection, "dVskpeWS3kgv81sO7C75cVYWMrM=");
_c = CollapsibleSection;
const __TURBOPACK__default__export__ = CollapsibleSection;
var _c;
__turbopack_context__.k.register(_c, "CollapsibleSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/tags/data:2a949a [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "upsertTags",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"6049de3b6fb4fd72700d349c1fc27174b5d55d449a":"upsertTags"},"app/lib/tags/tags-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("6049de3b6fb4fd72700d349c1fc27174b5d55d449a", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "upsertTags");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vdGFncy1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFRhZ3MgYWN0aW9uc1xyXG5cclxuXCJ1c2Ugc2VydmVyXCI7XHJcblxyXG5pbXBvcnQgcG9vbCBmcm9tIFwiQC9kYlwiO1xyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQWxsVGFncyh0ZW5hbnRfaWQ6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nW10+IHtcclxuICB0cnkge1xyXG4gICAgLy8g0JLQsNGA0LjQsNC90YIg0LHQtdC3INGD0YfQtdGC0LAgdGVuYW50X2lmICjQtNC70Y8g0L7RgtC70LDQtNC60LgpXHJcbiAgICAvLyAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PHsgbmFtZTogc3RyaW5nIH0+KFxyXG4gICAgLy8gICAgIGBcclxuICAgIC8vICAgICBTRUxFQ1QgbmFtZVxyXG4gICAgLy8gICAgIEZST00gdGFnc1xyXG4gICAgLy8gICAgIE9SREVSIEJZIG5hbWUgQVNDXHJcbiAgICAvLyAgIGBcclxuICAgIC8vICAgKTtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PHsgbmFtZTogc3RyaW5nIH0+KFxyXG4gICAgICBgXHJcbiAgICAgIFNFTEVDVCBuYW1lXHJcbiAgICAgIEZST00gdGFnc1xyXG4gICAgICBXSEVSRSB0ZW5hbnRfaWQgPSAkMVxyXG4gICAgICBPUkRFUiBCWSBuYW1lIEFTQ1xyXG4gICAgYCxcclxuICAgICAgW3RlbmFudF9pZF1cclxuICAgICk7XHJcbiAgICBjb25zdCB0YWdzID0gZGF0YS5yb3dzLm1hcCgocm93KSA9PiByb3cubmFtZSk7IC8vIOKGkCDQuNC30LLQu9C10LrQsNC10Lwg0YLQvtC70YzQutC+INGB0YLRgNC+0LrQuFxyXG4gICAgcmV0dXJuIHRhZ3M7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRGF0YWJhc2UgRXJyb3I6XCIsIGVycik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gZmV0Y2ggYWxsIHRhZ3M6IFwiICsgZXJyKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cHNlcnRUYWdzKFxyXG4gIHRhZ05hbWVzOiBzdHJpbmdbXSxcclxuICB0ZW5hbnRfaWQ6IHN0cmluZ1xyXG4pOiBQcm9taXNlPHZvaWQ+IHtcclxuaWYgKCF0YWdOYW1lcyB8fCB0YWdOYW1lcy5sZW5ndGggPT09IDApIHJldHVybjtcclxuICB0cnkge1xyXG4gICAgYXdhaXQgcG9vbC5xdWVyeShcclxuICAgICAgYFxyXG4gICAgICBJTlNFUlQgSU5UTyB0YWdzIChuYW1lLCB0ZW5hbnRfaWQpXHJcbiAgICAgIFNFTEVDVCB1bm5lc3QoJDE6OnRleHRbXSksICQyXHJcbiAgICAgIE9OIENPTkZMSUNUIChuYW1lLCB0ZW5hbnRfaWQpIERPIE5PVEhJTkdcclxuICAgICAgYCxcclxuICAgICAgW3RhZ05hbWVzLCB0ZW5hbnRfaWRdXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwiRmFpbGVkIHRvIHVwc2VydCB0YWdzOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gdXBzZXJ0IHRhZ3MuXCIpO1xyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjJSQWlDc0IsdUxBQUEifQ==
}),
"[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PermissionEditForm,
    "useAndTagStore",
    ()=>useAndTagStore,
    "useNoTagStore",
    ()=>useNoTagStore,
    "useOrTagStore",
    ()=>useOrTagStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$tenants$2f$lib$2f$btn$2d$tenants$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/tenants/lib/btn-tenants-ref.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$fonts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/app/ui/fonts.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__ = __turbopack_context__.i("[next]/internal/font/google/lusitana_99639ffe.js [app-client] (ecmascript) <export default as lusitana>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$message$2d$box$2d$ok$2d$cancel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/message-box-ok-cancel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$permissions$2f$lib$2f$data$3a$ce6d6a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/admin/permissions/lib/data:ce6d6a [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$btn$2d$roles$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/roles/lib/btn-roles-ref.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$store$2f$use$2d$role$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/roles/lib/store/use-role-store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$collapsible$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/collapsible-section.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/tags/tag-store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/tags/tag-input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$2a949a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/lib/tags/data:2a949a [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
// Permission EditForm
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
const useOrTagStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTagStore"])();
const useAndTagStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTagStore"])();
const useNoTagStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createTagStore"])();
function PermissionEditForm(props) {
    _s();
    const [permission, setPermission] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(props.permission);
    const isDocumentChanged = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsDocumentChanged"])();
    const msgBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"])();
    const roles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$store$2f$use$2d$role$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRoles"])().filter((role)=>role.tenant_id === permission.tenant_id);
    // const { setAllTags, addTag } = useOrTagStore();
    const addOrTag = useOrTagStore().addTag;
    const addAndTag = useAndTagStore().addTag;
    const addNoTag = useNoTagStore().addTag;
    const docChanged = ()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(true);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Документ изменен. Закрыть без сохранения?');
    };
    const handleChangeDoctypeName = (event)=>{
        setPermission((prev)=>({
                ...prev,
                doctype_name: event.target.value
            }));
        docChanged();
    };
    const handleChangeDoctype = (event)=>{
        setPermission((prev)=>({
                ...prev,
                doctype: event.target.value
            }));
        docChanged();
    };
    const handleChangeOrTags = (event)=>{
        const currentTags = useOrTagStore.getState().selectedTags;
        setPermission((prev)=>({
                ...prev,
                or_tags: currentTags
            }));
        docChanged();
    };
    const handleChangeAndTags = (event)=>{
        const currentTags = useAndTagStore.getState().selectedTags;
        setPermission((prev)=>({
                ...prev,
                and_tags: currentTags
            }));
        docChanged();
    };
    const handleChangeNoTags = (event)=>{
        const currentTags = useNoTagStore.getState().selectedTags;
        setPermission((prev)=>({
                ...prev,
                no_tags: currentTags
            }));
        docChanged();
    };
    const handleSelectTenant = (tenant_id, tenant_name)=>{
        setPermission((prev)=>({
                ...prev,
                tenant_id: tenant_id,
                tenant_name: tenant_name
            }));
        docChanged();
    };
    const handleSelectRole = (role_id, role_name)=>{
        setPermission((prev)=>({
                ...prev,
                role_id: role_id,
                role_name: role_name
            }));
        docChanged();
    };
    const handleBackClick = (e)=>{
        e.preventDefault();
        if (isDocumentChanged && !msgBox.isOKButtonPressed) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(true);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
        } else if (isDocumentChanged && msgBox.isOKButtonPressed) {} else if (!isDocumentChanged) {
            window.history.back(); // Возвращает пользователя на предыдущую страницу
        }
    };
    const handleSaveClick = async (e)=>{
        e.preventDefault();
        if (permission.can_delete && !(permission.editor || permission.author) && !permission.full_access) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Право удалять (окончательно) не имеет смысла если нет прав Редактор или Автор.');
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
            return;
        }
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$2a949a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["upsertTags"])(permission.or_tags, permission.tenant_id);
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().addAllTags(permission.or_tags);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$2a949a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["upsertTags"])(permission.and_tags, permission.tenant_id);
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().addAllTags(permission.and_tags);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$2a949a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["upsertTags"])(permission.no_tags, permission.tenant_id);
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().addAllTags(permission.no_tags);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$permissions$2f$lib$2f$data$3a$ce6d6a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updatePermission"])(permission);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Документ сохранен.');
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Документ не сохранен.' + String(error));
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(false);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PermissionEditForm.useEffect": ()=>{
            __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setAllTags(props.allTags);
        }
    }["PermissionEditForm.useEffect"], [
        props.allTags
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PermissionEditForm.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(true);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('');
        }
    }["PermissionEditForm.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PermissionEditForm.useEffect": ()=>{
            if (msgBox.isOKButtonPressed && msgBox.messageBoxText === 'Документ изменен. Закрыть без сохранения?') {
                // router.push('/admin/roles/');
                window.history.back();
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsOKButtonPressed"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsCancelButtonPressed"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(true);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(false);
        }
    }["PermissionEditForm.useEffect"], [
        msgBox.isOKButtonPressed
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                id: "header",
                className: "flex flex-col md:flex-row gap-4 w-full",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-2 w-full md:w-1/2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "role_name",
                                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-2/8 font-medium flex items-center p-2 text-gray-500`,
                                        children: "Роль (выберите):"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 171,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "role_name",
                                        type: "text",
                                        className: "w-13/16 pointer-events-none control rounded-md border border-gray-200 p-2",
                                        value: permission.role_name,
                                        readOnly: true,
                                        onChange: (e)=>setPermission((prev)=>({
                                                    ...prev,
                                                    role_name: e.target.value
                                                }))
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 176,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$btn$2d$roles$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        roles: roles,
                                        handleSelectRole: handleSelectRole
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 184,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 170,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "doctype",
                                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-2/8 font-medium flex items-center p-2 text-gray-500`,
                                        children: "Таблица (выберите):"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 188,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "doctype",
                                        type: "text",
                                        className: "w-13/16 control rounded-md border border-gray-200 p-2",
                                        value: permission.doctype_name,
                                        onChange: (e)=>handleChangeDoctype(e)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 194,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 187,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "doctype_name",
                                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-2/8 font-medium flex items-center p-2 text-gray-500`,
                                        children: "Тип документа:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 204,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        disabled: true,
                                        id: "doctype_name",
                                        type: "text",
                                        className: "w-13/16 control rounded-md text-gray-400 border border-gray-200 p-2",
                                        value: permission.doctype_name,
                                        onChange: (e)=>handleChangeDoctypeName(e)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 210,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 203,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "tenant_name",
                                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-2/8 font-medium flex items-center p-2 text-gray-500`,
                                        children: "Организация:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 221,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        disabled: true,
                                        id: "tenant_name",
                                        type: "text",
                                        className: "w-13/16 pointer-events-none control rounded-md text-gray-400 border border-gray-200 p-2",
                                        value: permission.tenant_name,
                                        readOnly: true,
                                        onChange: (e)=>setPermission((prev)=>({
                                                    ...prev,
                                                    tenant_name: e.target.value
                                                }))
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 226,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$tenants$2f$lib$2f$btn$2d$tenants$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        tenants: props.tenants,
                                        handleSelectTenant: handleSelectTenant
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 234,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                        lineNumber: 168,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col gap-2 w-full md:w-1/2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between w-1/2 mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "full_access",
                                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-7/10 font-medium flex items-center p-2 text-gray-500`,
                                        children: "Полные права:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 242,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "full_access",
                                        type: "checkbox",
                                        className: "w-3/10 control rounded-md p-2",
                                        checked: permission.full_access,
                                        onChange: (e)=>{
                                            setPermission((prev)=>({
                                                    ...prev,
                                                    full_access: e.target.checked
                                                }));
                                            docChanged();
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 247,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 241,
                                columnNumber: 11
                            }, this),
                            !permission.full_access && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between w-1/2 mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "editor",
                                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-7/10 font-medium flex items-center p-2 text-gray-500`,
                                        children: "Редактор:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 257,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "editor",
                                        type: "checkbox",
                                        className: "w-3/10 control rounded-md p-2",
                                        checked: permission.editor,
                                        onChange: (e)=>{
                                            setPermission((prev)=>({
                                                    ...prev,
                                                    editor: e.target.checked
                                                }));
                                            docChanged();
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 262,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 256,
                                columnNumber: 39
                            }, this),
                            !permission.full_access && !permission.editor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between w-1/2 mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "author",
                                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-7/10 font-medium flex items-center p-2 text-gray-500`,
                                        children: "Автор:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 273,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "author",
                                        type: "checkbox",
                                        className: "w-3/10 control rounded-md p-2",
                                        checked: permission.author,
                                        onChange: (e)=>{
                                            setPermission((prev)=>({
                                                    ...prev,
                                                    author: e.target.checked
                                                }));
                                            docChanged();
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 278,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 272,
                                columnNumber: 13
                            }, this),
                            !permission.full_access && !permission.editor && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between w-1/2 mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "reader",
                                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-7/10 font-medium flex items-center p-2 text-gray-500`,
                                        children: "Читатель:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 289,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "reader",
                                        type: "checkbox",
                                        className: "w-3/10 control rounded-md p-2",
                                        checked: permission.reader,
                                        onChange: (e)=>{
                                            setPermission((prev)=>({
                                                    ...prev,
                                                    reader: e.target.checked
                                                }));
                                            docChanged();
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 294,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 288,
                                columnNumber: 13
                            }, this),
                            (!permission.full_access && (permission.author || permission.reader) && !(permission.reader && !permission.full_access && !permission.editor && !permission.author) || permission.editor && !permission.full_access && !permission.author || permission.can_delete && permission.reader && !permission.full_access && !permission.editor && !permission.author) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex justify-between w-1/2 mt-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        htmlFor: "can_delete",
                                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-7/10 font-medium flex items-center p-2 text-gray-500`,
                                        children: "Физ.удаление:"
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 310,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        id: "can_delete",
                                        type: "checkbox",
                                        className: "w-3/10 control rounded-md p-2",
                                        checked: permission.can_delete,
                                        onChange: (e)=>{
                                            setPermission((prev)=>({
                                                    ...prev,
                                                    can_delete: e.target.checked
                                                }));
                                            docChanged();
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                        lineNumber: 315,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 309,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                        lineNumber: 239,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex max-w-[1150px] mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "or_tags",
                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-[110px] font-medium flex items-center p-2 text-gray-500`,
                        children: "OR-Тэги:"
                    }, void 0, false, {
                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                        lineNumber: 328,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TagInput"], {
                        id: "or_tags",
                        value: permission.or_tags,
                        onAdd: addOrTag,
                        handleFormInputChange: handleChangeOrTags,
                        readonly: false
                    }, void 0, false, {
                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                        lineNumber: 333,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                lineNumber: 327,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex max-w-[1150px] mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "and_tags",
                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-[110px] font-medium flex items-center p-2 text-gray-500`,
                        children: "AND-Тэги:"
                    }, void 0, false, {
                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                        lineNumber: 337,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TagInput"], {
                        id: "and_tags",
                        value: permission.and_tags,
                        onAdd: addAndTag,
                        handleFormInputChange: handleChangeAndTags,
                        readonly: false
                    }, void 0, false, {
                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                        lineNumber: 342,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                lineNumber: 336,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex max-w-[1150px] mt-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        htmlFor: "no_tags",
                        className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-[110px] font-medium flex items-center p-2 text-gray-500`,
                        children: "NO-Тэги:"
                    }, void 0, false, {
                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                        lineNumber: 346,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TagInput"], {
                        id: "no_tags",
                        value: permission.no_tags,
                        onAdd: addNoTag,
                        handleFormInputChange: handleChangeNoTags,
                        readonly: false
                    }, void 0, false, {
                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                        lineNumber: 351,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                lineNumber: 345,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between mt-4 mr-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex w-full md:w-1/2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full md:w-1/2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleSaveClick,
                                className: "bg-blue-400 text-white w-full rounded-md border p-2    hover:bg-blue-100 hover:text-gray-500 cursor-pointer",
                                children: "Сохранить"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 357,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                            lineNumber: 356,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-full md:w-1/2",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "#",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: handleBackClick,
                                    className: "bg-blue-400 text-white w-full rounded-md border p-2   hover:bg-blue-100 hover:text-gray-500 cursor-pointer",
                                    children: "Закрыть"
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                    lineNumber: 367,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 366,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                            lineNumber: 365,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                    lineNumber: 355,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                lineNumber: 354,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-[1150px] mt-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$collapsible$2d$section$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    header: "Описание прав доступа",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Полные права"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 382,
                                columnNumber: 13
                            }, this),
                            " - читает все записи. физически: создает/изменяет/удаляет. ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 382,
                                columnNumber: 101
                            }, this),
                            "логически: делегирует, утверждает, отзывает статус утверждения, удаляет, восстанавливает удаленные",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 383,
                                columnNumber: 111
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Читатель"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 384,
                                columnNumber: 13
                            }, this),
                            " - читает (только утвержденные!) документы всех Авторов, без возможности отзыва/редактирования/удаления/восстановления",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 384,
                                columnNumber: 156
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Автор"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 385,
                                columnNumber: 13
                            }, this),
                            " - читает (только свои!) draft/active/deleted документы, ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 385,
                                columnNumber: 92
                            }, this),
                            "создает draft/изменяет draft/утверждает draft/отзывает active/удаляет draft/восстанавливает deleted (только свои!) документы.",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 386,
                                columnNumber: 138
                            }, this),
                            "Если Автор не является Читателем, - он не видит документы других Авторов.",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 387,
                                columnNumber: 86
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Редактор"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 388,
                                columnNumber: 13
                            }, this),
                            " - имеет права Автора над документами других Авторов и сам является Автором своих документов. ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 388,
                                columnNumber: 132
                            }, this),
                            'После изменения "чужого" документа не становится Автором - его имя (user_id) остается в поле "editor". ',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 389,
                                columnNumber: 116
                            }, this),
                            "Имеет право делегировать авторство другому пользователю, в том числе себе.",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 390,
                                columnNumber: 87
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Физическое удаление"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 391,
                                columnNumber: 13
                            }, this),
                            " - без влияния на чтение. Имеет право физического удаления только логически-удаленных документов, тех, которые имеет право видеть, то есть Автор - свои, Редактор - все, Читателю нечего удалять - он не видит логически удаленные.",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 392,
                                columnNumber: 142
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: "Доступ по тэгам"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 393,
                                columnNumber: 13
                            }, this),
                            ' - при указанном данном признаке(tags-access) доступ осуществляется при наличии в документе указанных тэгов - поле "tags" (тип JSONB). В полномочиях отдельно указываются тэги, учитывающиеся по "И", по "ИЛИ" и по "НЕ"',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 394,
                                columnNumber: 137
                            }, this),
                            "Например доступ по ИЛИ-тэгам : SELECT * FROM records WHERE tags ? 'internal' OR tags ? 'спб'",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                                lineNumber: 395,
                                columnNumber: 105
                            }, this),
                            "Доступ по НЕ-тэгам : SELECT * FROM records WHERE NOT (tags ? 'confidential')"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                        lineNumber: 381,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                    lineNumber: 379,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                lineNumber: 378,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$message$2d$box$2d$ok$2d$cancel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
                lineNumber: 400,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx",
        lineNumber: 165,
        columnNumber: 5
    }, this);
}
_s(PermissionEditForm, "OdLGQU5A6VXfG2cA9dZ3QBjVI64=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsDocumentChanged"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$roles$2f$lib$2f$store$2f$use$2d$role$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRoles"],
        useOrTagStore,
        useAndTagStore,
        useNoTagStore
    ];
});
_c = PermissionEditForm;
var _c;
__turbopack_context__.k.register(_c, "PermissionEditForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/tags/tag-input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TagInput",
    ()=>TagInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$permissions$2f5b$id$5d2f$edit$2f$permission$2d$edit$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/permissions/[id]/edit/permission-edit-form.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/tags/tag-store.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
function TagInput({ id, value, onAdd, handleFormInputChange, readonly }) {
    _s();
    const { input, selectedTags, setInput, setSelectedTags, getSuggestions, removeTag } = id === 'user_tags' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserTagStore"])() : id === 'access_tags' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccessTagStore"])() : id === 'or_tags' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$permissions$2f5b$id$5d2f$edit$2f$permission$2d$edit$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOrTagStore"])() : id === 'and_tags' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$permissions$2f5b$id$5d2f$edit$2f$permission$2d$edit$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAndTagStore"])() : id === 'no_tags' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$permissions$2f5b$id$5d2f$edit$2f$permission$2d$edit$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNoTagStore"])() : (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTagStore"])();
    const [suggestions, setSuggestions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [highlightedIndex, setHighlightedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const suggestionRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TagInput.useEffect": ()=>{
            setSuggestions(getSuggestions());
            setHighlightedIndex(-1); // сброс при обновлении списка
        }
    }["TagInput.useEffect"], [
        input,
        selectedTags,
        getSuggestions
    ]);
    // 🟢 Инициализируем selectedTags из value при монтировании (и при обновлении value)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TagInput.useEffect": ()=>{
            if (value) setSelectedTags(value);
        }
    }["TagInput.useEffect"], [
        value,
        setSelectedTags
    ]);
    const selectSuggestion = (suggestion)=>{
        onAdd(suggestion);
        handleFormInputChange(selectedTags);
        setHighlightedIndex(-1);
    };
    const handleKeyDown = (e)=>{
        if (suggestions.length === 0) {
            // Если подсказок нет, обрабатываем только Enter/Comma
            if (e.key === 'Enter' || e.key === ',') {
                e.preventDefault();
                if (input.trim()) {
                    onAdd(input);
                    handleFormInputChange(selectedTags);
                }
            }
            return;
        }
        switch(e.key){
            case 'ArrowDown':
                e.preventDefault();
                setHighlightedIndex((prev)=>prev < suggestions.length - 1 ? prev + 1 : prev);
                break;
            case 'ArrowUp':
                e.preventDefault();
                setHighlightedIndex((prev)=>prev > 0 ? prev - 1 : -1);
                break;
            case 'Enter':
            case ' ':
                e.preventDefault();
                if (highlightedIndex >= 0) {
                    selectSuggestion(suggestions[highlightedIndex]);
                } else if (e.key === 'Enter' && input.trim()) {
                    // Если ничего не выделено — добавляем введённый тег по Enter
                    onAdd(input);
                    handleFormInputChange(selectedTags);
                }
                break;
            case 'Escape':
                setHighlightedIndex(-1);
                break;
            case ',':
                e.preventDefault();
                if (input.trim()) {
                    onAdd(input);
                    handleFormInputChange(selectedTags);
                }
                break;
            default:
                break;
        }
    };
    // Прокручиваем выделенный элемент в видимую область
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TagInput.useEffect": ()=>{
            if (highlightedIndex >= 0 && suggestionRefs.current[highlightedIndex]) {
                suggestionRefs.current[highlightedIndex]?.scrollIntoView({
                    block: 'nearest'
                });
            }
        }
    }["TagInput.useEffect"], [
        highlightedIndex
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: id,
        className: "relative w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-1 border border-gray-200 rounded-lg p-2",
                children: [
                    selectedTags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "bg-blue-100 px-2 py-1 rounded flex items-center",
                            children: [
                                tag,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    disabled: readonly,
                                    type: "button",
                                    onClick: ()=>{
                                        removeTag(tag);
                                        handleFormInputChange(selectedTags);
                                    },
                                    className: "ml-1 text-xs",
                                    children: "×"
                                }, void 0, false, {
                                    fileName: "[project]/app/lib/tags/tag-input.tsx",
                                    lineNumber: 109,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, tag, true, {
                            fileName: "[project]/app/lib/tags/tag-input.tsx",
                            lineNumber: 107,
                            columnNumber: 21
                        }, this)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "text",
                        disabled: readonly,
                        value: input,
                        onChange: (e)=>setInput(e.target.value),
                        onKeyDown: handleKeyDown,
                        className: "outline-none flex-1 min-w-[80px]",
                        placeholder: "Введите теги..."
                    }, void 0, false, {
                        fileName: "[project]/app/lib/tags/tag-input.tsx",
                        lineNumber: 122,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/lib/tags/tag-input.tsx",
                lineNumber: 105,
                columnNumber: 13
            }, this),
            suggestions.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "absolute z-10 mt-1 w-full bg-white border rounded shadow max-h-40 overflow-auto",
                children: suggestions.map((sug, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        ref: (el)=>{
                            suggestionRefs.current[index] = el;
                        },
                        className: `p-2 cursor-pointer ${highlightedIndex === index ? 'bg-blue-100' : 'hover:bg-gray-100'}`,
                        onClick: ()=>selectSuggestion(sug),
                        children: sug
                    }, sug, false, {
                        fileName: "[project]/app/lib/tags/tag-input.tsx",
                        lineNumber: 137,
                        columnNumber: 25
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/lib/tags/tag-input.tsx",
                lineNumber: 135,
                columnNumber: 17
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/lib/tags/tag-input.tsx",
        lineNumber: 104,
        columnNumber: 9
    }, this);
}
_s(TagInput, "AKOTt6Izbq/pSK77P86knHoV/Ko=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserTagStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccessTagStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$permissions$2f5b$id$5d2f$edit$2f$permission$2d$edit$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOrTagStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$permissions$2f5b$id$5d2f$edit$2f$permission$2d$edit$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAndTagStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$permissions$2f5b$id$5d2f$edit$2f$permission$2d$edit$2d$form$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNoTagStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTagStore"]
    ];
});
_c = TagInput;
var _c;
__turbopack_context__.k.register(_c, "TagInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/sections/lib/sections-ref-table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SectionsRefTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/ui/ref-search.tsx [app-client] (ecmascript)");
;
;
function SectionsRefTable(props) {
    const handleSearch = (input)=>{
        props.setTerm(input);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Выберите раздел:"
            }, void 0, false, {
                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                lineNumber: 23,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                callback: handleSearch,
                term: props.term,
                elementIdPrefix: ""
            }, void 0, false, {
                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                lineNumber: 24,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0 flow-root",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto md:block hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "inline-block min-w-full align-middle",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-hidden rounded-md bg-gray-50 p-1 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            className: "rounded-md bg-gray-50 text-left text-sm font-normal",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 overflow-hidden px-0 py-5 font-medium sm:pl-6",
                                                        children: "Название"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                        lineNumber: 33,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 px-3 py-5 font-medium",
                                                        children: "Организация"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                        lineNumber: 36,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                lineNumber: 32,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                            lineNumber: 31,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                        lineNumber: 30,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                    lineNumber: 29,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            className: "divide-y divide-gray-200 text-gray-900",
                                            children: props.sections.filter((section)=>section.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap text-ellipsis bg-white py-1 pl-0 text-left     pr-3 text-sm text-black group-first-of-type:rounded-md group-last-of-type:rounded-md sm:pl-6",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-left gap-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    onClick: (e)=>{
                                                                        props.handleSelectSection(section.id, section.name, section.tenant_id, section.tenant_name);
                                                                        props.setTerm("");
                                                                        props.closeModal();
                                                                    },
                                                                    // href={"#"}
                                                                    className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                                    children: section.name.substring(0, 36)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                                    lineNumber: 57,
                                                                    columnNumber: 53
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                                lineNumber: 56,
                                                                columnNumber: 49
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                            lineNumber: 54,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                            children: section.tenant_name
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                            lineNumber: 68,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, section.id, true, {
                                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                    lineNumber: 53,
                                                    columnNumber: 41
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                            lineNumber: 46,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                        lineNumber: 45,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                    lineNumber: 44,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                            lineNumber: 28,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                        lineNumber: 27,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "block md:hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2",
                            children: props.sections.filter((section)=>section.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((section)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-gray-200 bg-white p-4 text-sm text-gray-900 last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium text-black",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                onClick: (e)=>{
                                                    props.handleSelectSection(section.id, section.name, section.tenant_id, section.tenant_name);
                                                    props.setTerm("");
                                                    props.closeModal();
                                                },
                                                className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                children: section.name.substring(0, 36)
                                            }, void 0, false, {
                                                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                                lineNumber: 92,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                            lineNumber: 91,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500",
                                            children: section.tenant_name
                                        }, void 0, false, {
                                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                            lineNumber: 103,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, section.id, true, {
                                    fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                                    lineNumber: 87,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                            lineNumber: 80,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                        lineNumber: 79,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
                lineNumber: 25,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/sections/lib/sections-ref-table.tsx",
        lineNumber: 22,
        columnNumber: 9
    }, this);
}
_c = SectionsRefTable;
var _c;
__turbopack_context__.k.register(_c, "SectionsRefTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/admin/sections/lib/btn-sections-ref.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BtnSectionsRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import Modal from "@/app/lib/modal";
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BookOpenIcon.js [app-client] (ecmascript) <export default as BookOpenIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$sections$2f$lib$2f$sections$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/sections/lib/sections-ref-table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = Modal;
function BtnSectionsRef(props) {
    _s();
    const sections = props.sections ? props.sections : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().userSections;
    const [modal, setModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openModal = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setModal(true);
    };
    const closeModal = ()=>{
        setModal(false);
    };
    const [term, setTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: openModal,
                className: "rounded-md border border-gray-200 p-2 h-10 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__["BookOpenIcon"], {
                    className: "w-5 h-5 text-gray-800"
                }, void 0, false, {
                    fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Modal, {
                open: modal,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$sections$2f$lib$2f$sections$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        sections: sections,
                        handleSelectSection: props.handleSelectSection,
                        closeModal: closeModal,
                        setTerm: setTerm,
                        term: term
                    }, void 0, false, {
                        fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between space-x-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    alert("действие!");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                                lineNumber: 55,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: closeModal,
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Exit"
                            }, void 0, false, {
                                fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                        lineNumber: 54,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/admin/sections/lib/btn-sections-ref.tsx",
        lineNumber: 37,
        columnNumber: 5
    }, this);
} // export default BtnRefLegalEntity;
_s(BtnSectionsRef, "MW/KQDlZppFu/nDnRAs8d7ejpwM=");
_c1 = BtnSectionsRef;
var _c, _c1;
__turbopack_context__.k.register(_c, "Modal");
__turbopack_context__.k.register(_c1, "BtnSectionsRef");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/regions/lib/regions-ref-table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RegionsRefTable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/ui/ref-search.tsx [app-client] (ecmascript)");
;
;
function RegionsRefTable(props) {
    // const [term, setTerm] = useState<string>("");
    const handleSearch = (input)=>{
        props.setTerm(input);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                children: "Выберите регион:"
            }, void 0, false, {
                fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                lineNumber: 20,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$ref$2d$search$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                callback: handleSearch,
                term: props.term,
                elementIdPrefix: ""
            }, void 0, false, {
                fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                lineNumber: 21,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-0 flow-root",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto md:block hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "inline-block min-w-full align-middle",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "overflow-hidden rounded-md bg-gray-50 p-1 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                            className: "rounded-md bg-gray-50 text-left text-sm font-normal",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/2 overflow-hidden px-0 py-5 font-medium sm:pl-6",
                                                        children: "Название"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                        lineNumber: 30,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-6/16 px-3 py-5 font-medium",
                                                        children: "Округ"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                        lineNumber: 33,
                                                        columnNumber: 41
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                        scope: "col",
                                                        className: "w-1/8 px-3 py-5 font-medium",
                                                        children: "Код"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                        lineNumber: 36,
                                                        columnNumber: 41
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                lineNumber: 29,
                                                columnNumber: 37
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                            lineNumber: 28,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                        lineNumber: 27,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                    lineNumber: 26,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2 md:pt-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                        className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                            className: "divide-y divide-gray-200 text-gray-900",
                                            children: props.regions.map((region)=>(region.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                    className: "group",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/2 overflow-hidden whitespace-nowrap text-ellipsis bg-white py-1 pl-0 text-left     pr-3 text-sm text-black group-first-of-type:rounded-md group-last-of-type:rounded-md sm:pl-6",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-left gap-3",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                                    onClick: (e)=>{
                                                                        e.preventDefault();
                                                                        e.stopPropagation();
                                                                        props.handleSelectRegion(region.id, region.name);
                                                                        props.setTerm("");
                                                                        props.closeModal();
                                                                    },
                                                                    // href={"#"}
                                                                    className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                                    children: region.name.substring(0, 36)
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                                    lineNumber: 54,
                                                                    columnNumber: 53
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                                lineNumber: 53,
                                                                columnNumber: 49
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                            lineNumber: 51,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-6/16 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                            children: region.area
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                            lineNumber: 67,
                                                            columnNumber: 45
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                            className: "w-1/8 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                            children: region.code
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                            lineNumber: 70,
                                                            columnNumber: 45
                                                        }, this)
                                                    ]
                                                }, region.id, true, {
                                                    fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                    lineNumber: 50,
                                                    columnNumber: 41
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                            lineNumber: 46,
                                            columnNumber: 33
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                        lineNumber: 45,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                    lineNumber: 44,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                            lineNumber: 25,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                        lineNumber: 24,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "block md:hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-h-[300px] overflow-y-auto rounded-md bg-gray-50 p-2",
                            children: props.regions.filter((region)=>region.name.toLowerCase().includes(props.term.toLowerCase()) || props.term.length === 0).map((region)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-b border-gray-200 bg-white p-4 text-sm text-gray-900 last:border-b-0",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "font-medium text-black",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                onClick: (e)=>{
                                                    props.handleSelectRegion(region.id, region.name);
                                                    props.setTerm("");
                                                    props.closeModal();
                                                },
                                                className: "text-blue-800 underline cursor-pointer hover:text-blue-600",
                                                children: region.name.substring(0, 36)
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                                lineNumber: 94,
                                                columnNumber: 41
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                            lineNumber: 93,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500",
                                            children: region.area
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                            lineNumber: 105,
                                            columnNumber: 37
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "text-gray-500",
                                            children: region.code
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                            lineNumber: 106,
                                            columnNumber: 37
                                        }, this)
                                    ]
                                }, region.id, true, {
                                    fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                                    lineNumber: 89,
                                    columnNumber: 33
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                            lineNumber: 82,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                        lineNumber: 81,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
                lineNumber: 22,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/regions/lib/regions-ref-table.tsx",
        lineNumber: 19,
        columnNumber: 9
    }, this);
}
_c = RegionsRefTable;
var _c;
__turbopack_context__.k.register(_c, "RegionsRefTable");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/regions/lib/btn-regions-ref.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BtnRegionsRef
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// import Modal from "@/app/lib/modal";
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/BookOpenIcon.js [app-client] (ecmascript) <export default as BookOpenIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$regions$2f$lib$2f$regions$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/regions/lib/regions-ref-table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
;
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
const Modal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = Modal;
function BtnRegionsRef(props) {
    _s();
    // const regions = await fetchRegions();
    const [modal, setModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const openModal = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setModal(true);
    // redirect("/dashboard/admin/tenants/1");
    };
    const closeModal = ()=>{
        // setTenant((prev) => ({
        //   ...props.tenant,
        // }));
        setModal(false);
    };
    const [term, setTerm] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                onClick: openModal,
                className: "rounded-md border border-gray-200 p-2 h-10 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$BookOpenIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__BookOpenIcon$3e$__["BookOpenIcon"], {
                    className: "w-5 h-5 text-gray-800"
                }, void 0, false, {
                    fileName: "[project]/app/erp/regions/lib/btn-regions-ref.tsx",
                    lineNumber: 39,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/erp/regions/lib/btn-regions-ref.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Modal, {
                open: modal,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$regions$2f$lib$2f$regions$2d$ref$2d$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        regions: props.regions,
                        handleSelectRegion: props.handleSelectRegion,
                        closeModal: closeModal,
                        setTerm: setTerm,
                        term: term
                    }, void 0, false, {
                        fileName: "[project]/app/erp/regions/lib/btn-regions-ref.tsx",
                        lineNumber: 43,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between space-x-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    alert("действие!");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Save"
                            }, void 0, false, {
                                fileName: "[project]/app/erp/regions/lib/btn-regions-ref.tsx",
                                lineNumber: 53,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>{
                                    closeModal();
                                    setTerm("");
                                },
                                className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
                                children: "Exit"
                            }, void 0, false, {
                                fileName: "[project]/app/erp/regions/lib/btn-regions-ref.tsx",
                                lineNumber: 61,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/regions/lib/btn-regions-ref.tsx",
                        lineNumber: 52,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/regions/lib/btn-regions-ref.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/regions/lib/btn-regions-ref.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
_s(BtnRegionsRef, "MW/KQDlZppFu/nDnRAs8d7ejpwM=");
_c1 = BtnRegionsRef;
var _c, _c1;
__turbopack_context__.k.register(_c, "Modal");
__turbopack_context__.k.register(_c1, "BtnRegionsRef");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/message-box-srv.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
'use client';
;
const MessageBox = (props)=>{
    if (!props.isMessageBoxOpen) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        id: "message-box",
        className: "fixed inset-0 flex items-center justify-center z-50",
        style: {
            backgroundColor: 'rgba(0, 0, 0, 0.3)'
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-white p-6 rounded-lg shadow-lg max-w-md w-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-lg mb-4 whitespace-pre-line",
                    children: String(props.messageBoxText)
                }, void 0, false, {
                    fileName: "[project]/app/lib/message-box-srv.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-end space-x-3",
                    children: [
                        props.isShowCancel && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: props.cbCancel,
                            className: "px-4 py-2 bg-gray-300 rounded-md hover:bg-gray-400 focus:outline-none",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/app/lib/message-box-srv.tsx",
                            lineNumber: 20,
                            columnNumber: 34
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: props.cbOk,
                            className: "px-4 py-2 bg-red-300 text-white rounded-md hover:bg-red-700 focus:outline-none",
                            children: "OK"
                        }, void 0, false, {
                            fileName: "[project]/app/lib/message-box-srv.tsx",
                            lineNumber: 26,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/lib/message-box-srv.tsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/app/lib/message-box-srv.tsx",
            lineNumber: 17,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/app/lib/message-box-srv.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_c = MessageBox;
const __TURBOPACK__default__export__ = MessageBox;
var _c;
__turbopack_context__.k.register(_c, "MessageBox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/cars/lib/data:da99f9 [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deleteCar",
    ()=>$$RSC_SERVER_ACTION_2
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"4044b0f6bf9c27721ce6998a5862392073f4b186c2":"deleteCar"},"app/erp/cars/lib/cars-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_2 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("4044b0f6bf9c27721ce6998a5862392073f4b186c2", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "deleteCar");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vY2Fycy1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIENhcnMgYWN0aW9uc1xyXG5cclxuXCJ1c2Ugc2VydmVyXCI7XHJcblxyXG4vLyBpbXBvcnQgeyB6IH0gZnJvbSBcInpvZFwiO1xyXG5pbXBvcnQgcG9vbCBmcm9tIFwiQC9kYlwiO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gXCJuZXh0L2NhY2hlXCI7XHJcbi8vIGltcG9ydCB7IHJlZGlyZWN0IH0gZnJvbSBcIm5leHQvbmF2aWdhdGlvblwiO1xyXG5pbXBvcnQgeyBhdXRoIH0gZnJvbSBcIkAvYXV0aFwiO1xyXG5pbXBvcnQgeyBDYXJGb3JtLCBDYXIgfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcblxyXG5jb25zdCBJVEVNU19QRVJfUEFHRSA9IDg7XHJcblxyXG4vLyNyZWdpb24gQ3JlYXRlIFRhc2tcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVDYXIoY2FyOiBDYXIpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYXV0aCgpO1xyXG4gIGNvbnN0IHVzZXJuYW1lID0gc2Vzc2lvbj8udXNlcj8ubmFtZTtcclxuICBjb25zdCBkYXRlX2NyZWF0ZWQgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcbiAgY29uc3Qge1xyXG4gICAgbmFtZSxcclxuICAgIG1vZGVsLFxyXG4gICAgZ29zX251bWJlcixcclxuICAgIG1ha2UsXHJcbiAgICB2aW4sXHJcbiAgICB5ZWFyLFxyXG4gICAgY3VzdG9tZXJfaWQsXHJcbiAgICBjYXJfc3RhdHVzLFxyXG4gICAgdW5pdF9pZCxcclxuICAgIGxvY2F0aW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHRlbmFudF9pZCxcclxuICAgIGF1dGhvcl9pZCxcclxuICB9ID0gY2FyO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIElOU0VSVCBJTlRPIGNhcnMgKFxyXG4gICAgICAgIG5hbWUsIG1vZGVsLCBnb3NfbnVtYmVyLCBtYWtlLCB2aW4sIHllYXIsIGN1c3RvbWVyX2lkLFxyXG4gICAgICAgIGNhcl9zdGF0dXMsIHVuaXRfaWQsIGxvY2F0aW9uX2lkLFxyXG4gICAgICAgIHVzZXJuYW1lLCBzZWN0aW9uX2lkLCB0aW1lc3RhbXB0eixcclxuICAgICAgICB0ZW5hbnRfaWQsIGF1dGhvcl9pZFxyXG4gICAgICApIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1LCAkNiwgJDcsICQ4LCAkOSwgJDEwLCAkMTEsICQxMiwgJDEzLCAkMTQsICQxNSlcclxuICAgIGAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIG1vZGVsLFxyXG4gICAgICAgIGdvc19udW1iZXIsXHJcbiAgICAgICAgbWFrZSxcclxuICAgICAgICB2aW4sXHJcbiAgICAgICAgeWVhcixcclxuICAgICAgICBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLFxyXG4gICAgICAgIHVuaXRfaWQsXHJcbiAgICAgICAgbG9jYXRpb25faWQsXHJcbiAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICBkYXRlX2NyZWF0ZWQsXHJcbiAgICAgICAgdGVuYW50X2lkLFxyXG4gICAgICAgIGF1dGhvcl9pZCxcclxuICAgICAgXSxcclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIGNhcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0LfQtNCw0YLRjCBjYXI6XCIgKyBTdHJpbmcoZXJyb3IpKTtcclxuICB9XHJcblxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL3JlcGFpci9jYXJzXCIpO1xyXG59XHJcblxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBVcGRhdGUvRGVsZXRlIGNhclxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUNhcihjYXI6IENhcikge1xyXG4gIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBhdXRoKCk7XHJcbiAgY29uc3QgdXNlcm5hbWUgPSBzZXNzaW9uPy51c2VyPy5uYW1lO1xyXG5cclxuICBjb25zdCB7XHJcbiAgICBpZCxcclxuICAgIG5hbWUsXHJcbiAgICBtb2RlbCxcclxuICAgIGdvc19udW1iZXIsXHJcbiAgICBtYWtlLFxyXG4gICAgdmluLFxyXG4gICAgeWVhcixcclxuICAgIGN1c3RvbWVyX2lkLFxyXG4gICAgY2FyX3N0YXR1cyxcclxuICAgIHVuaXRfaWQsXHJcbiAgICBsb2NhdGlvbl9pZCxcclxuICAgIHNlY3Rpb25faWQsXHJcbiAgICB0ZW5hbnRfaWQsXHJcbiAgICBhdXRob3JfaWQsXHJcbiAgICBkb2Nfc3RhdHVzLFxyXG4gIH0gPSBjYXI7XHJcblxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIFVQREFURSBjYXJzIFNFVFxyXG4gICAgICAgIG5hbWUgPSAkMSwgbW9kZWwgPSAkMiwgZ29zX251bWJlciA9ICQzLCBtYWtlID0gJDQsIHZpbiA9ICQ1LCB5ZWFyID0gJDYsXHJcbiAgICAgICAgY3VzdG9tZXJfaWQgPSAkNywgXHJcbiAgICAgICAgY2FyX3N0YXR1cyA9ICQ4LCBcclxuICAgICAgICB1bml0X2lkID0gJDksIFxyXG4gICAgICAgIGxvY2F0aW9uX2lkID0gJDEwLFxyXG4gICAgICAgIHVzZXJuYW1lID0gJDExLFxyXG4gICAgICAgIHNlY3Rpb25faWQgPSAkMTIsXHJcbiAgICAgICAgdGVuYW50X2lkID0gJDEzLFxyXG4gICAgICAgIGF1dGhvcl9pZCA9ICQxNCxcclxuICAgICAgICBkb2Nfc3RhdHVzID0gJDE1LFxyXG4gICAgICAgIHRpbWVzdGFtcHR6ID0gbm93KClcclxuICAgICAgV0hFUkUgaWQgPSAkMTZcclxuICAgIGAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIG1vZGVsLFxyXG4gICAgICAgIGdvc19udW1iZXIsXHJcbiAgICAgICAgbWFrZSxcclxuICAgICAgICB2aW4sXHJcbiAgICAgICAgeWVhcixcclxuICAgICAgICBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLFxyXG4gICAgICAgIHVuaXRfaWQsXHJcbiAgICAgICAgbG9jYXRpb25faWQsXHJcbiAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGRvY19zdGF0dXMsXHJcbiAgICAgICAgaWQsXHJcbiAgICAgIF0sXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtCx0L3QvtCy0LjRgtGMIGNhcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICBcItCe0YjQuNCx0LrQsCDQsdCw0LfRiyDQtNCw0L3QvdGL0YU6INCd0LUg0YPQtNCw0LvQvtGB0Ywg0L7QsdC90L7QstC40YLRjCBjYXI6IFwiICsgU3RyaW5nKGVycm9yKSxcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXZhbGlkYXRlUGF0aChcIi9yZXBhaXIvY2Fyc1wiKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUNhcihpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIGNhcnMgV0hFUkUgaWQgPSAkMWAsIFtpZF0pO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINGD0LTQsNC70LXQvdC40Y8gY2FyOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgIFwi0J7RiNC40LHQutCwINCx0LDQt9GLINC00LDQvdC90YvRhTog0J3QtSDRg9C00LDQu9C+0YHRjCDRg9C00LDQu9C40YLRjCBjYXI6IFwiICsgU3RyaW5nKGVycm9yKSxcclxuICAgICk7XHJcbiAgfVxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL3JlcGFpci9jYXJzXCIpO1xyXG59XHJcblxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBGZXRjaCBjYXJzXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hDYXIoaWQ6IHN0cmluZywgY3VycmVudF9zZWN0aW9uczogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PENhcj4oXHJcbiAgICAgIGBcclxuICAgICAgV0lUSCB5b3VyX2NhcnMgQVMgKCBTRUxFQ1QgKiBGUk9NIGNhcnMgd2hlcmUgc2VjdGlvbl9pZCA9IFxyXG4gICAgICAgIEFOWSAoJDE6OnV1aWRbXSkpXHJcblxyXG4gICAgICBTRUxFQ1RcclxuICAgICAgICBpZCxcclxuICAgICAgICBuYW1lLCBtb2RlbCwgZ29zX251bWJlciwgbWFrZSwgdmluLCB5ZWFyLCBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLCB1bml0X2lkLCBsb2NhdGlvbl9pZCxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICBlZGl0aW5nX2J5X3VzZXJfaWQsXHJcbiAgICAgICAgZWRpdGluZ19zaW5jZSxcclxuICAgICAgICB0aW1lc3RhbXB0eixcclxuICAgICAgICBkYXRlX2NyZWF0ZWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGVkaXRvcl9pZCxcclxuICAgICAgICBkb2Nfc3RhdHVzXHJcbiAgICAgIEZST00geW91cl9jYXJzXHJcbiAgICAgIFdIRVJFIGlkID0gJDJcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zLCBpZF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyBjYXIg0L/QviBJRDpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCBjYXI6XCIgKyBTdHJpbmcoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hDYXJGb3JtKGlkOiBzdHJpbmcsIGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxDYXJGb3JtPihcclxuICAgICAgYFxyXG4gICAgICBXSVRIIHlvdXJfY2FycyBBUyAoIFNFTEVDVCAqIEZST00gY2FycyB3aGVyZSBzZWN0aW9uX2lkID0gXHJcbiAgICAgICAgQU5ZICgkMTo6dXVpZFtdKSlcclxuXHJcbiAgICAgIFNFTEVDVFxyXG4gICAgICAgIGNhcnMuaWQsXHJcbiAgICAgICAgY2Fycy5uYW1lLCBjYXJzLm5hbWUsIGNhcnMubW9kZWwsIGNhcnMuZ29zX251bWJlciwgY2Fycy5tYWtlLCBjYXJzLnZpbiwgY2Fycy55ZWFyLFxyXG4gICAgICAgIGNhcnMuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgY2Fycy5jYXJfc3RhdHVzLCBcclxuICAgICAgICBjYXJzLnVuaXRfaWQsIFxyXG4gICAgICAgIGNhcnMubG9jYXRpb25faWQsXHJcbiAgICAgICAgY2Fycy51c2VybmFtZSxcclxuICAgICAgICBjYXJzLnNlY3Rpb25faWQsXHJcbiAgICAgICAgY2Fycy50ZW5hbnRfaWQsXHJcbiAgICAgICAgY2Fycy5hdXRob3JfaWQsXHJcbiAgICAgICAgY2Fycy5lZGl0b3JfaWQsXHJcbiAgICAgICAgY2Fycy5kb2Nfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMuZWRpdGluZ19ieV91c2VyX2lkLFxyXG4gICAgICAgIGNhcnMuZWRpdGluZ19zaW5jZSxcclxuICAgICAgICBjYXJzLnRpbWVzdGFtcHR6LFxyXG4gICAgICAgIHNlY3Rpb25zLm5hbWUgQVMgc2VjdGlvbl9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKHVuaXRzLm5hbWUsICcnKSBhcyB1bml0X25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UobG9jYXRpb25zLm5hbWUsICcnKSBhcyBsb2NhdGlvbl9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKGN1c3RvbWVycy5uYW1lLCAnJykgYXMgY3VzdG9tZXJfbmFtZVxyXG4gICAgICBGUk9NIHlvdXJfY2FycyBjYXJzXHJcbiAgICAgIExFRlQgSk9JTiBzZWN0aW9ucyBPTiBjYXJzLnNlY3Rpb25faWQgPSBzZWN0aW9ucy5pZFxyXG4gICAgICBMRUZUIEpPSU4gdW5pdHMgT04gY2Fycy51bml0X2lkID0gdW5pdHMuaWRcclxuICAgICAgTEVGVCBKT0lOIGxvY2F0aW9ucyBPTiBjYXJzLmxvY2F0aW9uX2lkID0gbG9jYXRpb25zLmlkXHJcbiAgICAgIExFRlQgSk9JTiBsZWdhbF9lbnRpdGllcyBBUyBjdXN0b21lcnMgT04gY2Fycy5jdXN0b21lcl9pZCA9IGN1c3RvbWVycy5pZFxyXG4gICAgICBXSEVSRSBjYXJzLmlkID0gJDJcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zLCBpZF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyDRhNC+0YDQvNGLIGNhcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCDQtNCw0L3QvdGL0LUg0YTQvtGA0LzRiyBjYXI6IFwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQ2FycyhjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Q2FyPihcclxuICAgICAgYFxyXG4gICAgICBXSVRIIHlvdXJfY2FycyBBUyAoIFNFTEVDVCAqIEZST00gY2FycyB3aGVyZSBzZWN0aW9uX2lkID0gXHJcbiAgICAgICAgQU5ZICgkMTo6dXVpZFtdKSlcclxuXHJcbiAgICAgIFNFTEVDVFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIG5hbWUsIG1vZGVsLCBnb3NfbnVtYmVyLCBtYWtlLCB2aW4sIHllYXIsIGN1c3RvbWVyX2lkLFxyXG4gICAgICAgIGNhcl9zdGF0dXMsIHVuaXRfaWQsIGxvY2F0aW9uX2lkLFxyXG4gICAgICAgIHNlY3Rpb25faWQsXHJcbiAgICAgICAgdGVuYW50X2lkLFxyXG4gICAgICAgIGF1dGhvcl9pZCxcclxuICAgICAgICBlZGl0b3JfaWQsXHJcbiAgICAgICAgZG9jX3N0YXR1cyxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICB0aW1lc3RhbXB0eixcclxuICAgICAgICBkYXRlX2NyZWF0ZWRcclxuICAgICAgRlJPTSB5b3VyX2NhcnNcclxuICAgICAgT1JERVIgQlkgbmFtZSBBU0NcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zXSxcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0L/QvtC70YPRh9C10L3QuNGPINGB0L/QuNGB0LrQsCDQt9Cw0LTQsNGHOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQt9Cw0LPRgNGD0LfQuNGC0Ywg0YHQv9C40YHQvtC6INC30LDQtNCw0Yc6IFwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQ2Fyc0Zvcm0oXHJcbiAgY3VycmVudF9zZWN0aW9uczogc3RyaW5nLFxyXG4gIGxlZ2FsRW50aXR5SWQ/OiBzdHJpbmcsXHJcbikge1xyXG4gIGNvbnN0IGN1c3RvbWVySWQgPSBsZWdhbEVudGl0eUlkID8/IG51bGw7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PENhckZvcm0+KFxyXG4gICAgICBgXHJcbiAgICAgIFdJVEggeW91cl9jYXJzIEFTICggU0VMRUNUICogRlJPTSBjYXJzIHdoZXJlIHNlY3Rpb25faWQgPSBcclxuICAgICAgICBBTlkgKCQxOjp1dWlkW10pKVxyXG5cclxuICAgICAgU0VMRUNUXHJcbiAgICAgICAgY2Fycy5pZCxcclxuICAgICAgICBjYXJzLm5hbWUsXHJcbiAgICAgICAgY2Fycy51bml0X2lkLFxyXG4gICAgICAgIGNhcnMubG9jYXRpb25faWQsXHJcbiAgICAgICAgY2Fycy5jYXJfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMubW9kZWwsXHJcbiAgICAgICAgY2Fycy5nb3NfbnVtYmVyLCBjYXJzLm1ha2UsIGNhcnMudmluLCBjYXJzLnllYXIsIGNhcnMuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgY2Fycy5zZWN0aW9uX2lkLFxyXG4gICAgICAgIGNhcnMudGVuYW50X2lkLFxyXG4gICAgICAgIGNhcnMuYXV0aG9yX2lkLFxyXG4gICAgICAgIGNhcnMuZWRpdG9yX2lkLFxyXG4gICAgICAgIGNhcnMuZG9jX3N0YXR1cyxcclxuICAgICAgICBjYXJzLmRhdGVfY3JlYXRlZCxcclxuICAgICAgICBjYXJzLnVzZXJuYW1lLFxyXG4gICAgICAgIGNhcnMudGltZXN0YW1wdHosXHJcbiAgICAgICAgc2VjdGlvbnMubmFtZSBBUyBzZWN0aW9uX25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UodW5pdHMubmFtZSwgJycpIGFzIHVuaXRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShsb2NhdGlvbnMubmFtZSwgJycpIGFzIGxvY2F0aW9uX25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UoY3VzdG9tZXJzLm5hbWUsICcnKSBhcyBjdXN0b21lcl9uYW1lXHJcbiAgICAgIEZST00geW91cl9jYXJzIGNhcnNcclxuICAgICAgTEVGVCBKT0lOIHNlY3Rpb25zIE9OIGNhcnMuc2VjdGlvbl9pZCA9IHNlY3Rpb25zLmlkXHJcbiAgICAgIExFRlQgSk9JTiB1bml0cyBPTiBjYXJzLnVuaXRfaWQgPSB1bml0cy5pZFxyXG4gICAgICBMRUZUIEpPSU4gbG9jYXRpb25zIE9OIGNhcnMubG9jYXRpb25faWQgPSBsb2NhdGlvbnMuaWRcclxuICAgICAgTEVGVCBKT0lOIGxlZ2FsX2VudGl0aWVzIEFTIGN1c3RvbWVycyBPTiBjYXJzLmN1c3RvbWVyX2lkID0gY3VzdG9tZXJzLmlkXHJcbiAgICAgIFdIRVJFICQyOjp1dWlkIElTIE5VTEwgT1IgY2Fycy5jdXN0b21lcl9pZCA9ICQyOjp1dWlkXHJcbiAgICAgIE9SREVSIEJZIGNhcnMubmFtZSBBU0NcclxuICAgICAgYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGN1c3RvbWVySWRdLFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YTQvtGA0LwgY2FyczpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINGE0L7RgNC80YsgY2FyczpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbi8vI2VuZHJlZ2lvblxyXG5cclxuLy8jcmVnaW9uIEZpbHRlcmVkIGNhcnNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaEZpbHRlcmVkQ2FycyhcclxuICBxdWVyeTogc3RyaW5nLFxyXG4gIGN1cnJlbnRQYWdlOiBudW1iZXIsXHJcbiAgY3VycmVudF9zZWN0aW9uczogc3RyaW5nLFxyXG4pIHtcclxuICBjb25zdCBvZmZzZXQgPSAoY3VycmVudFBhZ2UgLSAxKSAqIElURU1TX1BFUl9QQUdFO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgY2FycyA9IGF3YWl0IHBvb2wucXVlcnk8Q2FyRm9ybT4oXHJcbiAgICAgIGBcclxuICAgICAgV0lUSCB5b3VyX2NhcnMgQVMgKCBTRUxFQ1QgKiBGUk9NIGNhcnMgd2hlcmUgc2VjdGlvbl9pZCA9IFxyXG4gICAgICAgIEFOWSAoJDE6OnV1aWRbXSkpXHJcblxyXG4gICAgICBTRUxFQ1RcclxuICAgICAgICBjYXJzLmlkLFxyXG4gICAgICAgIGNhcnMubmFtZSxcclxuICAgICAgICBjYXJzLnVuaXRfaWQsXHJcbiAgICAgICAgY2Fycy5sb2NhdGlvbl9pZCxcclxuICAgICAgICBjYXJzLmNhcl9zdGF0dXMsXHJcbiAgICAgICAgY2Fycy5tb2RlbCxcclxuICAgICAgICBjYXJzLmdvc19udW1iZXIsIGNhcnMubWFrZSwgY2Fycy52aW4sIGNhcnMueWVhciwgY2Fycy5jdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJzLnNlY3Rpb25faWQsXHJcbiAgICAgICAgY2Fycy50ZW5hbnRfaWQsXHJcbiAgICAgICAgY2Fycy5hdXRob3JfaWQsXHJcbiAgICAgICAgY2Fycy5lZGl0b3JfaWQsXHJcbiAgICAgICAgY2Fycy5kb2Nfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMudXNlcm5hbWUsXHJcbiAgICAgICAgY2Fycy50aW1lc3RhbXB0eixcclxuICAgICAgICBzZWN0aW9ucy5uYW1lIEFTIHNlY3Rpb25fbmFtZSxcclxuICAgICAgICBDT0FMRVNDRSh1bml0cy5uYW1lLCAnJykgYXMgdW5pdF9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKGxvY2F0aW9ucy5uYW1lLCAnJykgYXMgbG9jYXRpb25fbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShjdXN0b21lcnMubmFtZSwgJycpIGFzIGN1c3RvbWVyX25hbWVcclxuICAgICAgRlJPTSB5b3VyX2NhcnMgY2Fyc1xyXG4gICAgICBMRUZUIEpPSU4gc2VjdGlvbnMgT04gY2Fycy5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuICAgICAgTEVGVCBKT0lOIHVuaXRzIE9OIGNhcnMudW5pdF9pZCA9IHVuaXRzLmlkXHJcbiAgICAgIExFRlQgSk9JTiBsb2NhdGlvbnMgT04gY2Fycy5sb2NhdGlvbl9pZCA9IGxvY2F0aW9ucy5pZFxyXG4gICAgICBMRUZUIEpPSU4gbGVnYWxfZW50aXRpZXMgQVMgY3VzdG9tZXJzIE9OIGNhcnMuY3VzdG9tZXJfaWQgPSBjdXN0b21lcnMuaWRcclxuICAgICAgV0hFUkVcclxuICAgICAgICBjYXJzLm5hbWUgSUxJS0UgJDIgXHJcbiAgICAgIC0tIEFORCAoJDUgPSAn0L/QsNGA0LonIE9SICQ1ID0gJ9C/0LXRgNGB0L7QvdCw0LsnIE9SIGNhcnMuY2FyX3N0YXR1cyA9ICQ1KVxyXG4gICAgICBPUkRFUiBCWSBjYXJzLm5hbWUgQVNDXHJcbiAgICAgIExJTUlUICQzIE9GRlNFVCAkNFxyXG4gICAgYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGAlJHtxdWVyeX0lYCwgSVRFTVNfUEVSX1BBR0UsIG9mZnNldF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBjYXJzLnJvd3M7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0YTQuNC70YzRgtGA0LDRhtC40Lgg0JDQstGC0L7QvNC+0LHQuNC70LXQuSjRgtCw0LHQu9C40YbQsCBjYXJzKTpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINC+0YLRhNC40LvRjNGC0YDQvtCy0LDQvdC90YvQtSDQkNCy0YLQvtC80L7QsdC40LvQuDogXCIgKyBTdHJpbmcoZXJyb3IpLFxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaENhcnNQYWdlcyhxdWVyeTogc3RyaW5nLCBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY291bnQgPSBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIFdJVEggeW91cl9jYXJzIEFTICggU0VMRUNUICogRlJPTSBjYXJzIHdoZXJlIHNlY3Rpb25faWQgPSBcclxuICAgICAgICBBTlkgKCQxOjp1dWlkW10pKVxyXG5cclxuICAgICAgU0VMRUNUIENPVU5UKCopIEZST00geW91cl9jYXJzXHJcbiAgICAgIFdIRVJFIHlvdXJfY2Fycy5uYW1lIElMSUtFICQyXHJcbiAgICBgLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgYCUke3F1ZXJ5fSVgXSxcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgdG90YWxQYWdlcyA9IE1hdGguY2VpbChOdW1iZXIoY291bnQucm93c1swXS5jb3VudCkgLyBJVEVNU19QRVJfUEFHRSk7XHJcbiAgICByZXR1cm4gdG90YWxQYWdlcztcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LTRgdGH0ZHRgtCwINGB0YLRgNCw0L3QuNGGIGNhcnM6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgXCLQndC1INGD0LTQsNC70L7RgdGMINC+0L/RgNC10LTQtdC70LjRgtGMINC60L7Qu9C40YfQtdGB0YLQstC+INGB0YLRgNCw0L3QuNGGOiBcIiArIFN0cmluZyhlcnJvciksXHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuLy8jZW5kcmVnaW9uXHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOFJBOElzQixzTEFBQSJ9
}),
"[project]/app/erp/cars/lib/btn-delete-car.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BtnDeleteCar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TrashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/TrashIcon.js [app-client] (ecmascript) <export default as TrashIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$message$2d$box$2d$srv$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/message-box-srv.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$data$3a$da99f9__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/erp/cars/lib/data:da99f9 [app-client] (ecmascript) <text/javascript>");
;
var _s = __turbopack_context__.k.signature();
// Delete car button.tsx
'use client';
;
;
;
;
function BtnDeleteCar({ id, name, onDelete }) {
    _s();
    const [isMessageBoxOpen, setIsMessageBoxOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [messageBoxText, setMessageBoxText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const idToDelete = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])('');
    const askUserForDeleting = (id, name)=>{
        setIsMessageBoxOpen(true);
        idToDelete.current = id;
        setMessageBoxText(`Машина: ${name} \nУдалить мшину?`);
    };
    const deleteTaskWithId = askUserForDeleting.bind(null, id, name);
    const handleOK = ()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$data$3a$da99f9__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["deleteCar"])(idToDelete.current);
        onDelete();
        setIsMessageBoxOpen(false);
    };
    const handleCancel = ()=>{
        setIsMessageBoxOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: "rounded-md border border-gray-200 p-2 h-10 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-blue-500",
                onClick: deleteTaskWithId,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "sr-only",
                        children: "Delete"
                    }, void 0, false, {
                        fileName: "[project]/app/erp/cars/lib/btn-delete-car.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$TrashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__TrashIcon$3e$__["TrashIcon"], {
                        className: "w-5 h-5 text-gray-800"
                    }, void 0, false, {
                        fileName: "[project]/app/erp/cars/lib/btn-delete-car.tsx",
                        lineNumber: 41,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/cars/lib/btn-delete-car.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$message$2d$box$2d$srv$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isMessageBoxOpen: isMessageBoxOpen,
                messageBoxText: messageBoxText,
                isShowCancel: true,
                isShowOk: true,
                cbOk: handleOK,
                cbCancel: handleCancel
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/lib/btn-delete-car.tsx",
                lineNumber: 43,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(BtnDeleteCar, "K25S8/nbSwf1klHzMFBwNEtNqcY=");
_c = BtnDeleteCar;
var _c;
__turbopack_context__.k.register(_c, "BtnDeleteCar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/cars/lib/data:0cdc7e [app-client] (ecmascript) <text/javascript>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "updateCar",
    ()=>$$RSC_SERVER_ACTION_1
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)");
/* __next_internal_action_entry_do_not_use__ [{"40214baa60beea4f68365a033df51fb458f6133f96":"updateCar"},"app/erp/cars/lib/cars-actions.ts",""] */ "use turbopack no side effects";
;
const $$RSC_SERVER_ACTION_1 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createServerReference"])("40214baa60beea4f68365a033df51fb458f6133f96", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["callServer"], void 0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$next$2d$flight$2d$loader$2f$action$2d$client$2d$wrapper$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findSourceMapURL"], "updateCar");
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4vY2Fycy1hY3Rpb25zLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIENhcnMgYWN0aW9uc1xyXG5cclxuXCJ1c2Ugc2VydmVyXCI7XHJcblxyXG4vLyBpbXBvcnQgeyB6IH0gZnJvbSBcInpvZFwiO1xyXG5pbXBvcnQgcG9vbCBmcm9tIFwiQC9kYlwiO1xyXG5pbXBvcnQgeyByZXZhbGlkYXRlUGF0aCB9IGZyb20gXCJuZXh0L2NhY2hlXCI7XHJcbi8vIGltcG9ydCB7IHJlZGlyZWN0IH0gZnJvbSBcIm5leHQvbmF2aWdhdGlvblwiO1xyXG5pbXBvcnQgeyBhdXRoIH0gZnJvbSBcIkAvYXV0aFwiO1xyXG5pbXBvcnQgeyBDYXJGb3JtLCBDYXIgfSBmcm9tIFwiQC9hcHAvbGliL2RlZmluaXRpb25zXCI7XHJcblxyXG5jb25zdCBJVEVNU19QRVJfUEFHRSA9IDg7XHJcblxyXG4vLyNyZWdpb24gQ3JlYXRlIFRhc2tcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjcmVhdGVDYXIoY2FyOiBDYXIpIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgYXV0aCgpO1xyXG4gIGNvbnN0IHVzZXJuYW1lID0gc2Vzc2lvbj8udXNlcj8ubmFtZTtcclxuICBjb25zdCBkYXRlX2NyZWF0ZWQgPSBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCk7XHJcbiAgY29uc3Qge1xyXG4gICAgbmFtZSxcclxuICAgIG1vZGVsLFxyXG4gICAgZ29zX251bWJlcixcclxuICAgIG1ha2UsXHJcbiAgICB2aW4sXHJcbiAgICB5ZWFyLFxyXG4gICAgY3VzdG9tZXJfaWQsXHJcbiAgICBjYXJfc3RhdHVzLFxyXG4gICAgdW5pdF9pZCxcclxuICAgIGxvY2F0aW9uX2lkLFxyXG4gICAgc2VjdGlvbl9pZCxcclxuICAgIHRlbmFudF9pZCxcclxuICAgIGF1dGhvcl9pZCxcclxuICB9ID0gY2FyO1xyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIElOU0VSVCBJTlRPIGNhcnMgKFxyXG4gICAgICAgIG5hbWUsIG1vZGVsLCBnb3NfbnVtYmVyLCBtYWtlLCB2aW4sIHllYXIsIGN1c3RvbWVyX2lkLFxyXG4gICAgICAgIGNhcl9zdGF0dXMsIHVuaXRfaWQsIGxvY2F0aW9uX2lkLFxyXG4gICAgICAgIHVzZXJuYW1lLCBzZWN0aW9uX2lkLCB0aW1lc3RhbXB0eixcclxuICAgICAgICB0ZW5hbnRfaWQsIGF1dGhvcl9pZFxyXG4gICAgICApIFZBTFVFUyAoJDEsICQyLCAkMywgJDQsICQ1LCAkNiwgJDcsICQ4LCAkOSwgJDEwLCAkMTEsICQxMiwgJDEzLCAkMTQsICQxNSlcclxuICAgIGAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIG1vZGVsLFxyXG4gICAgICAgIGdvc19udW1iZXIsXHJcbiAgICAgICAgbWFrZSxcclxuICAgICAgICB2aW4sXHJcbiAgICAgICAgeWVhcixcclxuICAgICAgICBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLFxyXG4gICAgICAgIHVuaXRfaWQsXHJcbiAgICAgICAgbG9jYXRpb25faWQsXHJcbiAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICBkYXRlX2NyZWF0ZWQsXHJcbiAgICAgICAgdGVuYW50X2lkLFxyXG4gICAgICAgIGF1dGhvcl9pZCxcclxuICAgICAgXSxcclxuICAgICk7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQndC1INGD0LTQsNC70L7RgdGMINGB0L7Qt9C00LDRgtGMIGNhcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDRgdC+0LfQtNCw0YLRjCBjYXI6XCIgKyBTdHJpbmcoZXJyb3IpKTtcclxuICB9XHJcblxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL3JlcGFpci9jYXJzXCIpO1xyXG59XHJcblxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBVcGRhdGUvRGVsZXRlIGNhclxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZUNhcihjYXI6IENhcikge1xyXG4gIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBhdXRoKCk7XHJcbiAgY29uc3QgdXNlcm5hbWUgPSBzZXNzaW9uPy51c2VyPy5uYW1lO1xyXG5cclxuICBjb25zdCB7XHJcbiAgICBpZCxcclxuICAgIG5hbWUsXHJcbiAgICBtb2RlbCxcclxuICAgIGdvc19udW1iZXIsXHJcbiAgICBtYWtlLFxyXG4gICAgdmluLFxyXG4gICAgeWVhcixcclxuICAgIGN1c3RvbWVyX2lkLFxyXG4gICAgY2FyX3N0YXR1cyxcclxuICAgIHVuaXRfaWQsXHJcbiAgICBsb2NhdGlvbl9pZCxcclxuICAgIHNlY3Rpb25faWQsXHJcbiAgICB0ZW5hbnRfaWQsXHJcbiAgICBhdXRob3JfaWQsXHJcbiAgICBkb2Nfc3RhdHVzLFxyXG4gIH0gPSBjYXI7XHJcblxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIFVQREFURSBjYXJzIFNFVFxyXG4gICAgICAgIG5hbWUgPSAkMSwgbW9kZWwgPSAkMiwgZ29zX251bWJlciA9ICQzLCBtYWtlID0gJDQsIHZpbiA9ICQ1LCB5ZWFyID0gJDYsXHJcbiAgICAgICAgY3VzdG9tZXJfaWQgPSAkNywgXHJcbiAgICAgICAgY2FyX3N0YXR1cyA9ICQ4LCBcclxuICAgICAgICB1bml0X2lkID0gJDksIFxyXG4gICAgICAgIGxvY2F0aW9uX2lkID0gJDEwLFxyXG4gICAgICAgIHVzZXJuYW1lID0gJDExLFxyXG4gICAgICAgIHNlY3Rpb25faWQgPSAkMTIsXHJcbiAgICAgICAgdGVuYW50X2lkID0gJDEzLFxyXG4gICAgICAgIGF1dGhvcl9pZCA9ICQxNCxcclxuICAgICAgICBkb2Nfc3RhdHVzID0gJDE1LFxyXG4gICAgICAgIHRpbWVzdGFtcHR6ID0gbm93KClcclxuICAgICAgV0hFUkUgaWQgPSAkMTZcclxuICAgIGAsXHJcbiAgICAgIFtcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIG1vZGVsLFxyXG4gICAgICAgIGdvc19udW1iZXIsXHJcbiAgICAgICAgbWFrZSxcclxuICAgICAgICB2aW4sXHJcbiAgICAgICAgeWVhcixcclxuICAgICAgICBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLFxyXG4gICAgICAgIHVuaXRfaWQsXHJcbiAgICAgICAgbG9jYXRpb25faWQsXHJcbiAgICAgICAgdXNlcm5hbWUsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGRvY19zdGF0dXMsXHJcbiAgICAgICAgaWQsXHJcbiAgICAgIF0sXHJcbiAgICApO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQvtCx0L3QvtCy0LjRgtGMIGNhcjpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICBcItCe0YjQuNCx0LrQsCDQsdCw0LfRiyDQtNCw0L3QvdGL0YU6INCd0LUg0YPQtNCw0LvQvtGB0Ywg0L7QsdC90L7QstC40YLRjCBjYXI6IFwiICsgU3RyaW5nKGVycm9yKSxcclxuICAgICk7XHJcbiAgfVxyXG5cclxuICByZXZhbGlkYXRlUGF0aChcIi9yZXBhaXIvY2Fyc1wiKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUNhcihpZDogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IHBvb2wucXVlcnkoYERFTEVURSBGUk9NIGNhcnMgV0hFUkUgaWQgPSAkMWAsIFtpZF0pO1xyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINGD0LTQsNC70LXQvdC40Y8gY2FyOlwiLCBlcnJvcik7XHJcbiAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgIFwi0J7RiNC40LHQutCwINCx0LDQt9GLINC00LDQvdC90YvRhTog0J3QtSDRg9C00LDQu9C+0YHRjCDRg9C00LDQu9C40YLRjCBjYXI6IFwiICsgU3RyaW5nKGVycm9yKSxcclxuICAgICk7XHJcbiAgfVxyXG4gIHJldmFsaWRhdGVQYXRoKFwiL3JlcGFpci9jYXJzXCIpO1xyXG59XHJcblxyXG4vLyNlbmRyZWdpb25cclxuXHJcbi8vI3JlZ2lvbiBGZXRjaCBjYXJzXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hDYXIoaWQ6IHN0cmluZywgY3VycmVudF9zZWN0aW9uczogc3RyaW5nKSB7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PENhcj4oXHJcbiAgICAgIGBcclxuICAgICAgV0lUSCB5b3VyX2NhcnMgQVMgKCBTRUxFQ1QgKiBGUk9NIGNhcnMgd2hlcmUgc2VjdGlvbl9pZCA9IFxyXG4gICAgICAgIEFOWSAoJDE6OnV1aWRbXSkpXHJcblxyXG4gICAgICBTRUxFQ1RcclxuICAgICAgICBpZCxcclxuICAgICAgICBuYW1lLCBtb2RlbCwgZ29zX251bWJlciwgbWFrZSwgdmluLCB5ZWFyLCBjdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJfc3RhdHVzLCB1bml0X2lkLCBsb2NhdGlvbl9pZCxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICBlZGl0aW5nX2J5X3VzZXJfaWQsXHJcbiAgICAgICAgZWRpdGluZ19zaW5jZSxcclxuICAgICAgICB0aW1lc3RhbXB0eixcclxuICAgICAgICBkYXRlX2NyZWF0ZWQsXHJcbiAgICAgICAgc2VjdGlvbl9pZCxcclxuICAgICAgICB0ZW5hbnRfaWQsXHJcbiAgICAgICAgYXV0aG9yX2lkLFxyXG4gICAgICAgIGVkaXRvcl9pZCxcclxuICAgICAgICBkb2Nfc3RhdHVzXHJcbiAgICAgIEZST00geW91cl9jYXJzXHJcbiAgICAgIFdIRVJFIGlkID0gJDJcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zLCBpZF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyBjYXIg0L/QviBJRDpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCBjYXI6XCIgKyBTdHJpbmcoZXJyKSk7XHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hDYXJGb3JtKGlkOiBzdHJpbmcsIGN1cnJlbnRfc2VjdGlvbnM6IHN0cmluZykge1xyXG4gIHRyeSB7XHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcG9vbC5xdWVyeTxDYXJGb3JtPihcclxuICAgICAgYFxyXG4gICAgICBXSVRIIHlvdXJfY2FycyBBUyAoIFNFTEVDVCAqIEZST00gY2FycyB3aGVyZSBzZWN0aW9uX2lkID0gXHJcbiAgICAgICAgQU5ZICgkMTo6dXVpZFtdKSlcclxuXHJcbiAgICAgIFNFTEVDVFxyXG4gICAgICAgIGNhcnMuaWQsXHJcbiAgICAgICAgY2Fycy5uYW1lLCBjYXJzLm5hbWUsIGNhcnMubW9kZWwsIGNhcnMuZ29zX251bWJlciwgY2Fycy5tYWtlLCBjYXJzLnZpbiwgY2Fycy55ZWFyLFxyXG4gICAgICAgIGNhcnMuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgY2Fycy5jYXJfc3RhdHVzLCBcclxuICAgICAgICBjYXJzLnVuaXRfaWQsIFxyXG4gICAgICAgIGNhcnMubG9jYXRpb25faWQsXHJcbiAgICAgICAgY2Fycy51c2VybmFtZSxcclxuICAgICAgICBjYXJzLnNlY3Rpb25faWQsXHJcbiAgICAgICAgY2Fycy50ZW5hbnRfaWQsXHJcbiAgICAgICAgY2Fycy5hdXRob3JfaWQsXHJcbiAgICAgICAgY2Fycy5lZGl0b3JfaWQsXHJcbiAgICAgICAgY2Fycy5kb2Nfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMuZWRpdGluZ19ieV91c2VyX2lkLFxyXG4gICAgICAgIGNhcnMuZWRpdGluZ19zaW5jZSxcclxuICAgICAgICBjYXJzLnRpbWVzdGFtcHR6LFxyXG4gICAgICAgIHNlY3Rpb25zLm5hbWUgQVMgc2VjdGlvbl9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKHVuaXRzLm5hbWUsICcnKSBhcyB1bml0X25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UobG9jYXRpb25zLm5hbWUsICcnKSBhcyBsb2NhdGlvbl9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKGN1c3RvbWVycy5uYW1lLCAnJykgYXMgY3VzdG9tZXJfbmFtZVxyXG4gICAgICBGUk9NIHlvdXJfY2FycyBjYXJzXHJcbiAgICAgIExFRlQgSk9JTiBzZWN0aW9ucyBPTiBjYXJzLnNlY3Rpb25faWQgPSBzZWN0aW9ucy5pZFxyXG4gICAgICBMRUZUIEpPSU4gdW5pdHMgT04gY2Fycy51bml0X2lkID0gdW5pdHMuaWRcclxuICAgICAgTEVGVCBKT0lOIGxvY2F0aW9ucyBPTiBjYXJzLmxvY2F0aW9uX2lkID0gbG9jYXRpb25zLmlkXHJcbiAgICAgIExFRlQgSk9JTiBsZWdhbF9lbnRpdGllcyBBUyBjdXN0b21lcnMgT04gY2Fycy5jdXN0b21lcl9pZCA9IGN1c3RvbWVycy5pZFxyXG4gICAgICBXSEVSRSBjYXJzLmlkID0gJDJcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zLCBpZF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBkYXRhLnJvd3NbMF07XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKFwi0J7RiNC40LHQutCwINC/0L7Qu9GD0YfQtdC90LjRjyDRhNC+0YDQvNGLIGNhcjpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0L/QvtC70YPRh9C40YLRjCDQtNCw0L3QvdGL0LUg0YTQvtGA0LzRiyBjYXI6IFwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQ2FycyhjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHBvb2wucXVlcnk8Q2FyPihcclxuICAgICAgYFxyXG4gICAgICBXSVRIIHlvdXJfY2FycyBBUyAoIFNFTEVDVCAqIEZST00gY2FycyB3aGVyZSBzZWN0aW9uX2lkID0gXHJcbiAgICAgICAgQU5ZICgkMTo6dXVpZFtdKSlcclxuXHJcbiAgICAgIFNFTEVDVFxyXG4gICAgICAgIGlkLFxyXG4gICAgICAgIG5hbWUsIG1vZGVsLCBnb3NfbnVtYmVyLCBtYWtlLCB2aW4sIHllYXIsIGN1c3RvbWVyX2lkLFxyXG4gICAgICAgIGNhcl9zdGF0dXMsIHVuaXRfaWQsIGxvY2F0aW9uX2lkLFxyXG4gICAgICAgIHNlY3Rpb25faWQsXHJcbiAgICAgICAgdGVuYW50X2lkLFxyXG4gICAgICAgIGF1dGhvcl9pZCxcclxuICAgICAgICBlZGl0b3JfaWQsXHJcbiAgICAgICAgZG9jX3N0YXR1cyxcclxuICAgICAgICB1c2VybmFtZSxcclxuICAgICAgICB0aW1lc3RhbXB0eixcclxuICAgICAgICBkYXRlX2NyZWF0ZWRcclxuICAgICAgRlJPTSB5b3VyX2NhcnNcclxuICAgICAgT1JERVIgQlkgbmFtZSBBU0NcclxuICAgIGAsXHJcbiAgICAgIFtjdXJyZW50X3NlY3Rpb25zXSxcclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIGRhdGEucm93cztcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0L/QvtC70YPRh9C10L3QuNGPINGB0L/QuNGB0LrQsCDQt9Cw0LTQsNGHOlwiLCBlcnIpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwi0J3QtSDRg9C00LDQu9C+0YHRjCDQt9Cw0LPRgNGD0LfQuNGC0Ywg0YHQv9C40YHQvtC6INC30LDQtNCw0Yc6IFwiICsgU3RyaW5nKGVycikpO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZldGNoQ2Fyc0Zvcm0oXHJcbiAgY3VycmVudF9zZWN0aW9uczogc3RyaW5nLFxyXG4gIGxlZ2FsRW50aXR5SWQ/OiBzdHJpbmcsXHJcbikge1xyXG4gIGNvbnN0IGN1c3RvbWVySWQgPSBsZWdhbEVudGl0eUlkID8/IG51bGw7XHJcbiAgdHJ5IHtcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBwb29sLnF1ZXJ5PENhckZvcm0+KFxyXG4gICAgICBgXHJcbiAgICAgIFdJVEggeW91cl9jYXJzIEFTICggU0VMRUNUICogRlJPTSBjYXJzIHdoZXJlIHNlY3Rpb25faWQgPSBcclxuICAgICAgICBBTlkgKCQxOjp1dWlkW10pKVxyXG5cclxuICAgICAgU0VMRUNUXHJcbiAgICAgICAgY2Fycy5pZCxcclxuICAgICAgICBjYXJzLm5hbWUsXHJcbiAgICAgICAgY2Fycy51bml0X2lkLFxyXG4gICAgICAgIGNhcnMubG9jYXRpb25faWQsXHJcbiAgICAgICAgY2Fycy5jYXJfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMubW9kZWwsXHJcbiAgICAgICAgY2Fycy5nb3NfbnVtYmVyLCBjYXJzLm1ha2UsIGNhcnMudmluLCBjYXJzLnllYXIsIGNhcnMuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgY2Fycy5zZWN0aW9uX2lkLFxyXG4gICAgICAgIGNhcnMudGVuYW50X2lkLFxyXG4gICAgICAgIGNhcnMuYXV0aG9yX2lkLFxyXG4gICAgICAgIGNhcnMuZWRpdG9yX2lkLFxyXG4gICAgICAgIGNhcnMuZG9jX3N0YXR1cyxcclxuICAgICAgICBjYXJzLmRhdGVfY3JlYXRlZCxcclxuICAgICAgICBjYXJzLnVzZXJuYW1lLFxyXG4gICAgICAgIGNhcnMudGltZXN0YW1wdHosXHJcbiAgICAgICAgc2VjdGlvbnMubmFtZSBBUyBzZWN0aW9uX25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UodW5pdHMubmFtZSwgJycpIGFzIHVuaXRfbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShsb2NhdGlvbnMubmFtZSwgJycpIGFzIGxvY2F0aW9uX25hbWUsXHJcbiAgICAgICAgQ09BTEVTQ0UoY3VzdG9tZXJzLm5hbWUsICcnKSBhcyBjdXN0b21lcl9uYW1lXHJcbiAgICAgIEZST00geW91cl9jYXJzIGNhcnNcclxuICAgICAgTEVGVCBKT0lOIHNlY3Rpb25zIE9OIGNhcnMuc2VjdGlvbl9pZCA9IHNlY3Rpb25zLmlkXHJcbiAgICAgIExFRlQgSk9JTiB1bml0cyBPTiBjYXJzLnVuaXRfaWQgPSB1bml0cy5pZFxyXG4gICAgICBMRUZUIEpPSU4gbG9jYXRpb25zIE9OIGNhcnMubG9jYXRpb25faWQgPSBsb2NhdGlvbnMuaWRcclxuICAgICAgTEVGVCBKT0lOIGxlZ2FsX2VudGl0aWVzIEFTIGN1c3RvbWVycyBPTiBjYXJzLmN1c3RvbWVyX2lkID0gY3VzdG9tZXJzLmlkXHJcbiAgICAgIFdIRVJFICQyOjp1dWlkIElTIE5VTEwgT1IgY2Fycy5jdXN0b21lcl9pZCA9ICQyOjp1dWlkXHJcbiAgICAgIE9SREVSIEJZIGNhcnMubmFtZSBBU0NcclxuICAgICAgYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGN1c3RvbWVySWRdLFxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YS5yb3dzO1xyXG4gIH0gY2F0Y2ggKGVycikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LvRg9GH0LXQvdC40Y8g0YTQvtGA0LwgY2FyczpcIiwgZXJyKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINGE0L7RgNC80YsgY2FyczpcIiArIFN0cmluZyhlcnIpKTtcclxuICB9XHJcbn1cclxuXHJcbi8vI2VuZHJlZ2lvblxyXG5cclxuLy8jcmVnaW9uIEZpbHRlcmVkIGNhcnNcclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaEZpbHRlcmVkQ2FycyhcclxuICBxdWVyeTogc3RyaW5nLFxyXG4gIGN1cnJlbnRQYWdlOiBudW1iZXIsXHJcbiAgY3VycmVudF9zZWN0aW9uczogc3RyaW5nLFxyXG4pIHtcclxuICBjb25zdCBvZmZzZXQgPSAoY3VycmVudFBhZ2UgLSAxKSAqIElURU1TX1BFUl9QQUdFO1xyXG5cclxuICB0cnkge1xyXG4gICAgY29uc3QgY2FycyA9IGF3YWl0IHBvb2wucXVlcnk8Q2FyRm9ybT4oXHJcbiAgICAgIGBcclxuICAgICAgV0lUSCB5b3VyX2NhcnMgQVMgKCBTRUxFQ1QgKiBGUk9NIGNhcnMgd2hlcmUgc2VjdGlvbl9pZCA9IFxyXG4gICAgICAgIEFOWSAoJDE6OnV1aWRbXSkpXHJcblxyXG4gICAgICBTRUxFQ1RcclxuICAgICAgICBjYXJzLmlkLFxyXG4gICAgICAgIGNhcnMubmFtZSxcclxuICAgICAgICBjYXJzLnVuaXRfaWQsXHJcbiAgICAgICAgY2Fycy5sb2NhdGlvbl9pZCxcclxuICAgICAgICBjYXJzLmNhcl9zdGF0dXMsXHJcbiAgICAgICAgY2Fycy5tb2RlbCxcclxuICAgICAgICBjYXJzLmdvc19udW1iZXIsIGNhcnMubWFrZSwgY2Fycy52aW4sIGNhcnMueWVhciwgY2Fycy5jdXN0b21lcl9pZCxcclxuICAgICAgICBjYXJzLnNlY3Rpb25faWQsXHJcbiAgICAgICAgY2Fycy50ZW5hbnRfaWQsXHJcbiAgICAgICAgY2Fycy5hdXRob3JfaWQsXHJcbiAgICAgICAgY2Fycy5lZGl0b3JfaWQsXHJcbiAgICAgICAgY2Fycy5kb2Nfc3RhdHVzLFxyXG4gICAgICAgIGNhcnMudXNlcm5hbWUsXHJcbiAgICAgICAgY2Fycy50aW1lc3RhbXB0eixcclxuICAgICAgICBzZWN0aW9ucy5uYW1lIEFTIHNlY3Rpb25fbmFtZSxcclxuICAgICAgICBDT0FMRVNDRSh1bml0cy5uYW1lLCAnJykgYXMgdW5pdF9uYW1lLFxyXG4gICAgICAgIENPQUxFU0NFKGxvY2F0aW9ucy5uYW1lLCAnJykgYXMgbG9jYXRpb25fbmFtZSxcclxuICAgICAgICBDT0FMRVNDRShjdXN0b21lcnMubmFtZSwgJycpIGFzIGN1c3RvbWVyX25hbWVcclxuICAgICAgRlJPTSB5b3VyX2NhcnMgY2Fyc1xyXG4gICAgICBMRUZUIEpPSU4gc2VjdGlvbnMgT04gY2Fycy5zZWN0aW9uX2lkID0gc2VjdGlvbnMuaWRcclxuICAgICAgTEVGVCBKT0lOIHVuaXRzIE9OIGNhcnMudW5pdF9pZCA9IHVuaXRzLmlkXHJcbiAgICAgIExFRlQgSk9JTiBsb2NhdGlvbnMgT04gY2Fycy5sb2NhdGlvbl9pZCA9IGxvY2F0aW9ucy5pZFxyXG4gICAgICBMRUZUIEpPSU4gbGVnYWxfZW50aXRpZXMgQVMgY3VzdG9tZXJzIE9OIGNhcnMuY3VzdG9tZXJfaWQgPSBjdXN0b21lcnMuaWRcclxuICAgICAgV0hFUkVcclxuICAgICAgICBjYXJzLm5hbWUgSUxJS0UgJDIgXHJcbiAgICAgIC0tIEFORCAoJDUgPSAn0L/QsNGA0LonIE9SICQ1ID0gJ9C/0LXRgNGB0L7QvdCw0LsnIE9SIGNhcnMuY2FyX3N0YXR1cyA9ICQ1KVxyXG4gICAgICBPUkRFUiBCWSBjYXJzLm5hbWUgQVNDXHJcbiAgICAgIExJTUlUICQzIE9GRlNFVCAkNFxyXG4gICAgYCxcclxuICAgICAgW2N1cnJlbnRfc2VjdGlvbnMsIGAlJHtxdWVyeX0lYCwgSVRFTVNfUEVSX1BBR0UsIG9mZnNldF0sXHJcbiAgICApO1xyXG5cclxuICAgIHJldHVybiBjYXJzLnJvd3M7XHJcbiAgfSBjYXRjaCAoZXJyb3IpIHtcclxuICAgIGNvbnNvbGUuZXJyb3IoXCLQntGI0LjQsdC60LAg0YTQuNC70YzRgtGA0LDRhtC40Lgg0JDQstGC0L7QvNC+0LHQuNC70LXQuSjRgtCw0LHQu9C40YbQsCBjYXJzKTpcIiwgZXJyb3IpO1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICBcItCd0LUg0YPQtNCw0LvQvtGB0Ywg0LfQsNCz0YDRg9C30LjRgtGMINC+0YLRhNC40LvRjNGC0YDQvtCy0LDQvdC90YvQtSDQkNCy0YLQvtC80L7QsdC40LvQuDogXCIgKyBTdHJpbmcoZXJyb3IpLFxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmZXRjaENhcnNQYWdlcyhxdWVyeTogc3RyaW5nLCBjdXJyZW50X3NlY3Rpb25zOiBzdHJpbmcpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgY291bnQgPSBhd2FpdCBwb29sLnF1ZXJ5KFxyXG4gICAgICBgXHJcbiAgICAgIFdJVEggeW91cl9jYXJzIEFTICggU0VMRUNUICogRlJPTSBjYXJzIHdoZXJlIHNlY3Rpb25faWQgPSBcclxuICAgICAgICBBTlkgKCQxOjp1dWlkW10pKVxyXG5cclxuICAgICAgU0VMRUNUIENPVU5UKCopIEZST00geW91cl9jYXJzXHJcbiAgICAgIFdIRVJFIHlvdXJfY2Fycy5uYW1lIElMSUtFICQyXHJcbiAgICBgLFxyXG4gICAgICBbY3VycmVudF9zZWN0aW9ucywgYCUke3F1ZXJ5fSVgXSxcclxuICAgICk7XHJcblxyXG4gICAgY29uc3QgdG90YWxQYWdlcyA9IE1hdGguY2VpbChOdW1iZXIoY291bnQucm93c1swXS5jb3VudCkgLyBJVEVNU19QRVJfUEFHRSk7XHJcbiAgICByZXR1cm4gdG90YWxQYWdlcztcclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5lcnJvcihcItCe0YjQuNCx0LrQsCDQv9C+0LTRgdGH0ZHRgtCwINGB0YLRgNCw0L3QuNGGIGNhcnM6XCIsIGVycm9yKTtcclxuICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgXCLQndC1INGD0LTQsNC70L7RgdGMINC+0L/RgNC10LTQtdC70LjRgtGMINC60L7Qu9C40YfQtdGB0YLQstC+INGB0YLRgNCw0L3QuNGGOiBcIiArIFN0cmluZyhlcnJvciksXHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuLy8jZW5kcmVnaW9uXHJcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOFJBMEVzQixzTEFBQSJ9
}),
"[project]/app/erp/cars/lib/cars-buttons.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BtnEditCarLink",
    ()=>BtnEditCarLink,
    "BtnUpdateCar",
    ()=>BtnUpdateCar,
    "CreateCar",
    ()=>CreateCar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// TaskButtons.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PencilIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PencilIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/PencilIcon.js [app-client] (ecmascript) <export default as PencilIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PlusIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/PlusIcon.js [app-client] (ecmascript) <export default as PlusIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$data$3a$0cdc7e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/erp/cars/lib/data:0cdc7e [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
;
;
function CreateCar({ readonly }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: !readonly ? "/erp/cars/create" : "#",
        className: `flex h-10 items-center rounded-lg 
        ${readonly ? 'bg-gray-300 px-4 text-sm font-medium text-gray-500 transition-colors  hover:bg-gray-400' : ' bg-blue-600 px-4 text-sm font-medium text-white transition-colors  hover:bg-blue-500 '}
     focus-visible:outline focus-visible:outline-offset-2 focus-visible:outline-blue-600`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "hidden md:block",
                children: "Создать автомобиль"
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/lib/cars-buttons.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PlusIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PlusIcon$3e$__["PlusIcon"], {
                className: "h-5 md:ml-4"
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/lib/cars-buttons.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/cars/lib/cars-buttons.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_c = CreateCar;
function BtnUpdateCar({ car }) {
    const updateCarWithData = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$data$3a$0cdc7e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updateCar"].bind(null, car);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        action: updateCarWithData,
        className: "w-full",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
            type: "submit",
            className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500",
            children: "Save"
        }, void 0, false, {
            fileName: "[project]/app/erp/cars/lib/cars-buttons.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/erp/cars/lib/cars-buttons.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_c1 = BtnUpdateCar;
function BtnEditCarLink({ id }) {
    const LinkIcon = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$PencilIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__PencilIcon$3e$__["PencilIcon"];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: "/erp/cars/" + id + "/edit",
        className: "flex h-10 items-center justify-center space-x-2 rounded-md border border-gray-200    bg-white p-2 text-sm font-medium hover:bg-gray-100 md:flex-none md:justify-start md:p-2 md:px-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinkIcon, {
                className: "w-5 h-5 text-gray-800"
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/lib/cars-buttons.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "hidden md:block text-gray-700",
                children: "Edit"
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/lib/cars-buttons.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this)
        ]
    }, "Edit", true, {
        fileName: "[project]/app/erp/cars/lib/cars-buttons.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
_c2 = BtnEditCarLink;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "CreateCar");
__turbopack_context__.k.register(_c1, "BtnUpdateCar");
__turbopack_context__.k.register(_c2, "BtnEditCarLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/cars/lib/cars-table-naked.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CarsTableNaked
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$btn$2d$delete$2d$car$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/cars/lib/btn-delete-car.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$cars$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/cars/lib/cars-buttons.tsx [app-client] (ecmascript)");
;
;
;
function CarsTableNaked({ cars, showDeleteButton = false, loadCars }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "w-full",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mt-6 flow-root",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "overflow-x-auto",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "inline-block min-w-full align-middle",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-hidden rounded-md bg-gray-50 p-2 md:pt-0",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                                className: "table-fixed hidden w-full rounded-md text-gray-900 md:table",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                        className: "rounded-md bg-gray-50 text-left text-sm font-normal",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    scope: "col",
                                                    className: "w-2/12 px-4 py-5 font-medium sm:pl-6",
                                                    children: "Автомобиль"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                    lineNumber: 17,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    scope: "col",
                                                    className: "w-2/12 px-4 py-5 font-medium sm:pl-6",
                                                    children: "Клиент"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                    lineNumber: 18,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    scope: "col",
                                                    className: "w-2/12 px-4 py-5 font-medium sm:pl-6",
                                                    children: "Марка"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                    lineNumber: 19,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    scope: "col",
                                                    className: "w-2/12 px-4 py-5 font-medium sm:pl-6",
                                                    children: "Модель"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                    lineNumber: 20,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    scope: "col",
                                                    className: "w-2/12 px-4 py-5 font-medium sm:pl-6",
                                                    children: "Год выпуска"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                    lineNumber: 21,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    scope: "col",
                                                    className: "w-2/12 px-4 py-5 font-medium sm:pl-6",
                                                    children: "Гос.номер"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                    lineNumber: 22,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                    scope: "col",
                                                    className: "w-1/12 px-4 py-5 font-medium"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                    lineNumber: 23,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                            lineNumber: 16,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                        lineNumber: 15,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                        className: "divide-y divide-gray-200 text-gray-900",
                                        children: cars.map((car)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "group",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "w-2/12 overflow-hidden whitespace-nowrap bg-white py-2 pl-6 pr-3 text-sm text-black",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                            href: `/erp/cars/${car.id}/edit`,
                                                            className: "text-blue-800 underline",
                                                            children: car.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                            lineNumber: 31,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                        lineNumber: 30,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "w-2/12 overflow-hidden whitespace-nowrap bg-white py-2 pl-6 pr-3 text-sm text-black",
                                                        children: car.customer_name
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                        lineNumber: 38,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "w-2/12 overflow-hidden whitespace-nowrap bg-white py-2 pl-6 pr-3 text-sm text-black",
                                                        children: car.make
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                        lineNumber: 41,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "w-2/16 overflow-hidden whitespace-nowrap bg-white px-4 py-1 text-sm",
                                                        children: car.model
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                        lineNumber: 44,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "w-2/12 overflow-hidden whitespace-nowrap bg-white py-2 pl-6 pr-3 text-sm text-black",
                                                        children: car.year
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                        lineNumber: 47,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "w-2/12 overflow-hidden whitespace-nowrap bg-white py-2 pl-6 pr-3 text-sm text-black",
                                                        children: car.gos_number
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                        lineNumber: 50,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "w-1/12 whitespace-nowrap py-2 pr-3",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex justify-end gap-3",
                                                            children: showDeleteButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$btn$2d$delete$2d$car$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                id: car.id,
                                                                name: car.name,
                                                                onDelete: loadCars ?? (()=>{})
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                                lineNumber: 55,
                                                                columnNumber: 48
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                            lineNumber: 54,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                        lineNumber: 53,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, car.id, true, {
                                                fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                lineNumber: 29,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                        lineNumber: 27,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                lineNumber: 14,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "md:hidden",
                                children: cars.map((car)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-4 rounded-lg bg-white p-4 shadow-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex justify-between items-center mb-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: "text-lg font-medium text-blue-800 underline",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                            href: `/erp/cars/${car.id}/edit`,
                                                            children: car.name
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                            lineNumber: 72,
                                                            columnNumber: 25
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                        lineNumber: 71,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$cars$2d$buttons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BtnEditCarLink"], {
                                                                id: car.id
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                                lineNumber: 77,
                                                                columnNumber: 25
                                                            }, this),
                                                            showDeleteButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$btn$2d$delete$2d$car$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                id: car.id,
                                                                name: car.name,
                                                                onDelete: loadCars ?? (()=>{})
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                                lineNumber: 78,
                                                                columnNumber: 46
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                        lineNumber: 76,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                lineNumber: 70,
                                                columnNumber: 21
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-2 gap-2"
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                                lineNumber: 81,
                                                columnNumber: 21
                                            }, this)
                                        ]
                                    }, car.id, true, {
                                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                        lineNumber: 66,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                                lineNumber: 64,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                        lineNumber: 12,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                    lineNumber: 11,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
                lineNumber: 10,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
            lineNumber: 9,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/erp/cars/lib/cars-table-naked.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_c = CarsTableNaked;
var _c;
__turbopack_context__.k.register(_c, "CarsTableNaked");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LegalEntityEditForm
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zod/lib/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$message$2d$box$2d$ok$2d$cancel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/message-box-ok-cancel.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/store/useDocumentStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/tags/tag-store.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/input-field.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$data$3a$f8bce7__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/erp/legal-entities/lib/data:f8bce7 [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$data$3a$d6f97e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/erp/legal-entities/lib/data:d6f97e [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$ui$2f$fonts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/app/ui/fonts.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__ = __turbopack_context__.i("[next]/internal/font/google/lusitana_99639ffe.js [app-client] (ecmascript) <export default as lusitana>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/tags/tag-input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$2a949a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__ = __turbopack_context__.i("[project]/app/lib/tags/data:2a949a [app-client] (ecmascript) <text/javascript>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$sections$2f$lib$2f$btn$2d$sections$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/admin/sections/lib/btn-sections-ref.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$regions$2f$lib$2f$btn$2d$regions$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/regions/lib/btn-regions-ref.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$cars$2d$table$2d$naked$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/erp/cars/lib/cars-table-naked.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
// LegalEntity EditForm
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
//#region LegalEntity zod schema
const LegalEntityFormSchemaFull = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].object({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().uuid(),
    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(1, {
        message: "Название обязательно."
    }),
    fullname: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().optional(),
    inn: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().regex(/^\d{10}(\d{2})?$/, {
        message: "ИНН должен содержать 10 или 12 цифр."
    }),
    address_legal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().optional().nullable(),
    phone: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().optional().nullable(),
    email: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().email({
        message: "Некорректный email."
    }).optional().nullable(),
    contact: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().optional().nullable(),
    is_customer: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].boolean(),
    is_supplier: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].boolean(),
    kpp: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().regex(/^\d{9}$/, {
        message: "КПП должен содержать 9 цифр."
    }).optional().nullable(),
    region_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().uuid(),
    section_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().uuid(),
    region_name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(1, {
        message: "Регион обязателен."
    }),
    section_name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().min(1, {
        message: "Раздел обязателен."
    }),
    access_tags: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string()).nullable(),
    user_tags: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string()).nullable(),
    tenant_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().uuid(),
    username: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().optional(),
    author_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().uuid(),
    editor_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().uuid(),
    timestamptz: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().optional(),
    date_created: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].date().optional(),
    editing_by_user_id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().uuid().nullable(),
    editing_since: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$lib$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["z"].string().nullable()
});
const LegalEntityFormSchema = LegalEntityFormSchemaFull.omit({
    id: true,
    timestamptz: true,
    username: true,
    editing_by_user_id: true,
    editing_since: true,
    date_created: true
});
function LegalEntityEditForm(props) {
    _s();
    const userSections = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().userSections;
    const sessionUser = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().sessionUser;
    const addUserTag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserTagStore"])().addTag;
    const addAccessTag = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccessTagStore"])().addTag;
    const docTenantId = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().documentTenantId;
    const [showErrors, setShowErrors] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const isDocumentChanged = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsDocumentChanged"])();
    const msgBox = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const docChanged = ()=>{
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(true);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Документ изменен. Закрыть без сохранения?');
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LegalEntityEditForm.useEffect": ()=>{
            setFormData({
                "LegalEntityEditForm.useEffect": (prev)=>({
                        ...prev,
                        author_id: sessionUser.id,
                        editor_id: sessionUser.id,
                        tenant_id: docTenantId
                    })
            }["LegalEntityEditForm.useEffect"]);
        }
    }["LegalEntityEditForm.useEffect"], [
        sessionUser.id,
        docTenantId
    ]);
    const [formData, setFormData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(props.legalEntity);
    const validate = ()=>{
        const res = LegalEntityFormSchema.safeParse({
            ...formData
        });
        if (res.success) {
            return undefined;
        }
        return res.error.format();
    };
    const handleSubmit = async (e)=>{
        e.preventDefault();
        const errors = validate();
        if (errors) {
            setShowErrors(true);
            return;
        }
        try {
            if (formData.user_tags) {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$2a949a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["upsertTags"])(formData.user_tags, docTenantId);
                __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().addAllTags(formData.user_tags);
            }
            if (formData.access_tags) {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$data$3a$2a949a__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["upsertTags"])(formData.access_tags, docTenantId);
                __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().addAllTags(formData.access_tags);
            }
            if (formData.id === "") {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$data$3a$f8bce7__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["createLegalEntity"])(formData);
                setTimeout(()=>{
                    router.push('erp/legal-entities');
                }, 2000);
            } else {
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$legal$2d$entities$2f$lib$2f$data$3a$d6f97e__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$text$2f$javascript$3e$__["updateLegalEntity"])(formData);
                router.refresh();
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsDocumentChanged"])(false);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Документ сохранен.');
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setMessageBoxText"])('Документ не сохранен! :' + String(error));
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(false);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
    };
    const handleBackClick = async (e)=>{
        e.preventDefault();
        if (props.unlockAction) await props.unlockAction("legal_entities", props.legalEntity.id, sessionUser.id);
        if (isDocumentChanged && !msgBox.isOKButtonPressed) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsShowMessageBoxCancel"])(true);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setIsMessageBoxOpen"])(true);
        } else if (!isDocumentChanged) {
            window.history.back();
        }
    };
    const handleInputChange = (field, value)=>{
        setFormData((prev)=>({
                ...prev,
                [field]: value
            }));
        docChanged();
    };
    const handleChangeUserTags = ()=>{
        const currentTags = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserTagStore"].getState().selectedTags;
        setFormData((prev)=>({
                ...prev,
                user_tags: currentTags
            }));
        docChanged();
    };
    const handleChangeAccessTags = ()=>{
        const currentTags = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccessTagStore"].getState().selectedTags;
        setFormData((prev)=>({
                ...prev,
                access_tags: currentTags
            }));
        docChanged();
    };
    const handleSelectSection = (new_section_id, new_section_name, new_section_tenant_id)=>{
        setFormData((prev)=>({
                ...prev,
                section_id: new_section_id,
                section_name: new_section_name,
                tenant_id: new_section_tenant_id
            }));
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDocumentStore"].getState().setDocumentTenantId(new_section_tenant_id);
        docChanged();
    };
    const handleSelectRegion = (new_region_id, new_region_name)=>{
        setFormData((prev)=>({
                ...prev,
                region_id: new_region_id,
                region_name: new_region_name
            }));
        docChanged();
    };
    const handleCreateClientsCar = ()=>{
        // router.push('/erp/cars/create');
        router.push(`/erp/cars/create?customer_id=${formData.id}`);
    };
    const errors = showErrors ? validate() : undefined;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: handleSubmit,
                className: "flex flex-col gap-4 relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col md:flex-row gap-4 w-full",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-4 w-full md:w-1/2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "name",
                                        value: formData.name,
                                        label: "Название:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('name', value),
                                        readonly: props.readonly,
                                        errors: errors?.name?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 228,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "fullname",
                                        value: formData.fullname || '',
                                        label: "Полное:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('fullname', value),
                                        readonly: props.readonly,
                                        errors: errors?.fullname?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 239,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "inn",
                                        value: formData.inn || '',
                                        label: "ИНН:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('inn', value),
                                        readonly: props.readonly,
                                        errors: errors?.inn?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 250,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "address_legal",
                                        value: formData.address_legal || '',
                                        label: "Юр.адрес:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('address_legal', value),
                                        readonly: props.readonly,
                                        errors: errors?.address_legal?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 261,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "phone",
                                        value: formData.phone || '',
                                        label: "Телефон:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('phone', value),
                                        readonly: props.readonly,
                                        errors: errors?.phone?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 272,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "email",
                                        value: formData.email || '',
                                        label: "Email:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('email', value),
                                        readonly: props.readonly,
                                        errors: errors?.email?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 283,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "contact",
                                        value: formData.contact || '',
                                        label: "Контакт:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('contact', value),
                                        readonly: props.readonly,
                                        errors: errors?.contact?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 294,
                                        columnNumber: 25
                                    }, this),
                                    !errors && formData.is_customer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        id: "add_car",
                                        className: "absolute top-123 left-30 px-2 py-1 bg-green-300 text-sm text-white border-none rounded cursor-pointer z-50",
                                        type: "button",
                                        onClick: handleCreateClientsCar,
                                        children: "добавить"
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 305,
                                        columnNumber: 61
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                lineNumber: 226,
                                columnNumber: 21
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-4 w-full md:w-1/2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "w-6/16 text-sm font-medium p-2",
                                                children: "Клиент?"
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                                lineNumber: 318,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "checkbox",
                                                checked: formData.is_customer,
                                                onChange: (e)=>handleInputChange('is_customer', e.target.checked),
                                                disabled: props.readonly,
                                                className: "ml-2"
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                                lineNumber: 319,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 317,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "w-6/16 text-sm font-medium p-2",
                                                children: "Поставщик?"
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                                lineNumber: 329,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "checkbox",
                                                checked: formData.is_supplier,
                                                onChange: (e)=>handleInputChange('is_supplier', e.target.checked),
                                                disabled: props.readonly,
                                                className: "ml-2"
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                                lineNumber: 330,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 328,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "kpp",
                                        value: formData.kpp || '',
                                        label: "КПП:",
                                        type: "text",
                                        w: [
                                            "w-4/16",
                                            "w-13/16"
                                        ],
                                        onChange: (value)=>handleInputChange('kpp', value),
                                        readonly: props.readonly,
                                        errors: errors?.kpp?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 339,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "region_name",
                                        value: formData.region_name,
                                        label: "Регион:",
                                        type: "text",
                                        w: [
                                            "w-6/16",
                                            "w-11/16"
                                        ],
                                        refBook: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$regions$2f$lib$2f$btn$2d$regions$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            handleSelectRegion: handleSelectRegion,
                                            regions: props.regions
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                            lineNumber: 356,
                                            columnNumber: 38
                                        }, void 0),
                                        onChange: ()=>{},
                                        readonly: props.readonly,
                                        errors: errors?.region_name?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 350,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$input$2d$field$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        name: "section_name",
                                        value: formData.section_name,
                                        label: "Раздел:",
                                        type: "text",
                                        w: [
                                            "w-6/16",
                                            "w-11/16"
                                        ],
                                        onChange: (value)=>{},
                                        refBook: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$admin$2f$sections$2f$lib$2f$btn$2d$sections$2d$ref$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            handleSelectSection: handleSelectSection
                                        }, void 0, false, {
                                            fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                            lineNumber: 369,
                                            columnNumber: 38
                                        }, void 0),
                                        readonly: props.readonly,
                                        errors: errors?.section_name?._errors
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 362,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex max-w-[1150px] mt-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-[130px] font-medium flex items-center p-2 text-gray-500`,
                                                children: "Теги:"
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                                lineNumber: 375,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TagInput"], {
                                                id: "user_tags",
                                                value: formData.user_tags,
                                                onAdd: addUserTag,
                                                handleFormInputChange: handleChangeUserTags,
                                                readonly: props.readonly
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                                lineNumber: 378,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 374,
                                        columnNumber: 25
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex max-w-[1150px] mt-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: `${__TURBOPACK__imported__module__$5b$next$5d2f$internal$2f$font$2f$google$2f$lusitana_99639ffe$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__lusitana$3e$__["lusitana"].className} w-[130px] font-medium flex items-center p-2 text-gray-500`,
                                                children: "Теги доступа:"
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                                lineNumber: 388,
                                                columnNumber: 29
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TagInput"], {
                                                id: "access_tags",
                                                value: formData.access_tags,
                                                onAdd: addAccessTag,
                                                handleFormInputChange: handleChangeAccessTags,
                                                readonly: props.readonly
                                            }, void 0, false, {
                                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                                lineNumber: 391,
                                                columnNumber: 29
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 387,
                                        columnNumber: 25
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                lineNumber: 315,
                                columnNumber: 21
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                        lineNumber: 224,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        id: "form-error",
                        "aria-live": "polite",
                        "aria-atomic": "true",
                        children: errors && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-2 text-sm text-red-500",
                            children: JSON.stringify(errors)
                        }, 'form_errors', false, {
                            fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                            lineNumber: 403,
                            columnNumber: 25
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                        lineNumber: 401,
                        columnNumber: 17
                    }, this),
                    formData.is_customer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$erp$2f$cars$2f$lib$2f$cars$2d$table$2d$naked$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        cars: props.clients_cars,
                        showDeleteButton: false
                    }, void 0, false, {
                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                        lineNumber: 409,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-between mt-4 mr-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex w-full md:w-3/4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full md:w-1/2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        disabled: props.readonly,
                                        className: `w-full rounded-md border p-2 ${props.readonly ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-blue-400 text-white hover:bg-blue-100 hover:text-gray-500 cursor-pointer'}`,
                                        type: "submit",
                                        children: "Сохранить"
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 413,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                    lineNumber: 412,
                                    columnNumber: 25
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "w-full md:w-1/2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: handleBackClick,
                                        className: "bg-blue-400 text-white w-full rounded-md border p-2 hover:bg-blue-100 hover:text-gray-500 cursor-pointer",
                                        children: props.readonly ? 'Закрыть' : 'Закрыть и освободить'
                                    }, void 0, false, {
                                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                        lineNumber: 425,
                                        columnNumber: 29
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                                    lineNumber: 424,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                            lineNumber: 411,
                            columnNumber: 21
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                        lineNumber: 410,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                lineNumber: 223,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$message$2d$box$2d$ok$2d$cancel$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
                lineNumber: 435,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/erp/legal-entities/[id]/edit/legal-entity-edit-form.tsx",
        lineNumber: 222,
        columnNumber: 9
    }, this);
}
_s(LegalEntityEditForm, "i/g7ydRRF57io9V5qYLGqN+zDYo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUserTagStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$tags$2f$tag$2d$store$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccessTagStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsDocumentChanged"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$store$2f$useDocumentStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMessageBox"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = LegalEntityEditForm;
var _c;
__turbopack_context__.k.register(_c, "LegalEntityEditForm");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__e30fe2d4._.js.map