(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/next/dist/build/webpack/loaders/next-flight-loader/action-client-wrapper.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// This file must be bundled in the app's client layer, it shouldn't be directly
// imported by the server.
Object.defineProperty(exports, "__esModule", {
    value: true
});
0 && (module.exports = {
    callServer: null,
    createServerReference: null,
    findSourceMapURL: null
});
function _export(target, all) {
    for(var name in all)Object.defineProperty(target, name, {
        enumerable: true,
        get: all[name]
    });
}
_export(exports, {
    callServer: function() {
        return _appcallserver.callServer;
    },
    createServerReference: function() {
        return _client.createServerReference;
    },
    findSourceMapURL: function() {
        return _appfindsourcemapurl.findSourceMapURL;
    }
});
const _appcallserver = __turbopack_context__.r("[project]/node_modules/next/dist/client/app-call-server.js [app-client] (ecmascript)");
const _appfindsourcemapurl = __turbopack_context__.r("[project]/node_modules/next/dist/client/app-find-source-map-url.js [app-client] (ecmascript)");
const _client = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react-server-dom-turbopack/client.js [app-client] (ecmascript)"); //# sourceMappingURL=action-client-wrapper.js.map
}),
"[project]/node_modules/next/dist/shared/lib/lazy-dynamic/dynamic-bailout-to-csr.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "BailoutToCSR", {
    enumerable: true,
    get: function() {
        return BailoutToCSR;
    }
});
const _bailouttocsr = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/bailout-to-csr.js [app-client] (ecmascript)");
function BailoutToCSR({ reason, children }) {
    if (typeof window === 'undefined') {
        throw Object.defineProperty(new _bailouttocsr.BailoutToCSRError(reason), "__NEXT_ERROR_CODE", {
            value: "E394",
            enumerable: false,
            configurable: true
        });
    }
    return children;
} //# sourceMappingURL=dynamic-bailout-to-csr.js.map
}),
"[project]/node_modules/next/dist/shared/lib/encode-uri-path.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "encodeURIPath", {
    enumerable: true,
    get: function() {
        return encodeURIPath;
    }
});
function encodeURIPath(file) {
    return file.split('/').map((p)=>encodeURIComponent(p)).join('/');
} //# sourceMappingURL=encode-uri-path.js.map
}),
"[project]/node_modules/next/dist/shared/lib/lazy-dynamic/preload-chunks.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "PreloadChunks", {
    enumerable: true,
    get: function() {
        return PreloadChunks;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _reactdom = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
const _workasyncstorageexternal = __turbopack_context__.r("[project]/node_modules/next/dist/server/app-render/work-async-storage.external.js [app-client] (ecmascript)");
const _encodeuripath = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/encode-uri-path.js [app-client] (ecmascript)");
const _deploymentid = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/deployment-id.js [app-client] (ecmascript)");
function PreloadChunks({ moduleIds }) {
    // Early return in client compilation and only load requestStore on server side
    if (typeof window !== 'undefined') {
        return null;
    }
    const workStore = _workasyncstorageexternal.workAsyncStorage.getStore();
    if (workStore === undefined) {
        return null;
    }
    const allFiles = [];
    // Search the current dynamic call unique key id in react loadable manifest,
    // and find the corresponding CSS files to preload
    if (workStore.reactLoadableManifest && moduleIds) {
        const manifest = workStore.reactLoadableManifest;
        for (const key of moduleIds){
            if (!manifest[key]) continue;
            const chunks = manifest[key].files;
            allFiles.push(...chunks);
        }
    }
    if (allFiles.length === 0) {
        return null;
    }
    const dplId = (0, _deploymentid.getDeploymentIdQueryOrEmptyString)();
    return /*#__PURE__*/ (0, _jsxruntime.jsx)(_jsxruntime.Fragment, {
        children: allFiles.map((chunk)=>{
            const href = `${workStore.assetPrefix}/_next/${(0, _encodeuripath.encodeURIPath)(chunk)}${dplId}`;
            const isCss = chunk.endsWith('.css');
            // If it's stylesheet we use `precedence` o help hoist with React Float.
            // For stylesheets we actually need to render the CSS because nothing else is going to do it so it needs to be part of the component tree.
            // The `preload` for stylesheet is not optional.
            if (isCss) {
                return /*#__PURE__*/ (0, _jsxruntime.jsx)("link", {
                    // @ts-ignore
                    precedence: "dynamic",
                    href: href,
                    rel: "stylesheet",
                    as: "style",
                    nonce: workStore.nonce
                }, chunk);
            } else {
                // If it's script we use ReactDOM.preload to preload the resources
                (0, _reactdom.preload)(href, {
                    as: 'script',
                    fetchPriority: 'low',
                    nonce: workStore.nonce
                });
                return null;
            }
        })
    });
} //# sourceMappingURL=preload-chunks.js.map
}),
"[project]/node_modules/next/dist/shared/lib/lazy-dynamic/loadable.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return _default;
    }
});
const _jsxruntime = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
const _react = __turbopack_context__.r("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
const _dynamicbailouttocsr = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/dynamic-bailout-to-csr.js [app-client] (ecmascript)");
const _preloadchunks = __turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/preload-chunks.js [app-client] (ecmascript)");
// Normalize loader to return the module as form { default: Component } for `React.lazy`.
// Also for backward compatible since next/dynamic allows to resolve a component directly with loader
// Client component reference proxy need to be converted to a module.
function convertModule(mod) {
    // Check "default" prop before accessing it, as it could be client reference proxy that could break it reference.
    // Cases:
    // mod: { default: Component }
    // mod: Component
    // mod: { default: proxy(Component) }
    // mod: proxy(Component)
    const hasDefault = mod && 'default' in mod;
    return {
        default: hasDefault ? mod.default : mod
    };
}
const defaultOptions = {
    loader: ()=>Promise.resolve(convertModule(()=>null)),
    loading: null,
    ssr: true
};
function Loadable(options) {
    const opts = {
        ...defaultOptions,
        ...options
    };
    const Lazy = /*#__PURE__*/ (0, _react.lazy)(()=>opts.loader().then(convertModule));
    const Loading = opts.loading;
    function LoadableComponent(props) {
        const fallbackElement = Loading ? /*#__PURE__*/ (0, _jsxruntime.jsx)(Loading, {
            isLoading: true,
            pastDelay: true,
            error: null
        }) : null;
        // If it's non-SSR or provided a loading component, wrap it in a suspense boundary
        const hasSuspenseBoundary = !opts.ssr || !!opts.loading;
        const Wrap = hasSuspenseBoundary ? _react.Suspense : _react.Fragment;
        const wrapProps = hasSuspenseBoundary ? {
            fallback: fallbackElement
        } : {};
        const children = opts.ssr ? /*#__PURE__*/ (0, _jsxruntime.jsxs)(_jsxruntime.Fragment, {
            children: [
                typeof window === 'undefined' ? /*#__PURE__*/ (0, _jsxruntime.jsx)(_preloadchunks.PreloadChunks, {
                    moduleIds: opts.modules
                }) : null,
                /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                    ...props
                })
            ]
        }) : /*#__PURE__*/ (0, _jsxruntime.jsx)(_dynamicbailouttocsr.BailoutToCSR, {
            reason: "next/dynamic",
            children: /*#__PURE__*/ (0, _jsxruntime.jsx)(Lazy, {
                ...props
            })
        });
        return /*#__PURE__*/ (0, _jsxruntime.jsx)(Wrap, {
            ...wrapProps,
            children: children
        });
    }
    LoadableComponent.displayName = 'LoadableComponent';
    return LoadableComponent;
}
const _default = Loadable; //# sourceMappingURL=loadable.js.map
}),
"[project]/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return dynamic;
    }
});
const _interop_require_default = __turbopack_context__.r("[project]/node_modules/next/node_modules/@swc/helpers/cjs/_interop_require_default.cjs [app-client] (ecmascript)");
const _loadable = /*#__PURE__*/ _interop_require_default._(__turbopack_context__.r("[project]/node_modules/next/dist/shared/lib/lazy-dynamic/loadable.js [app-client] (ecmascript)"));
function dynamic(dynamicOptions, options) {
    const loadableOptions = {};
    if (typeof dynamicOptions === 'function') {
        loadableOptions.loader = dynamicOptions;
    }
    const mergedOptions = {
        ...loadableOptions,
        ...options
    };
    return (0, _loadable.default)({
        ...mergedOptions,
        modules: mergedOptions.loadableGenerated?.modules
    });
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=app-dynamic.js.map
}),
"[project]/node_modules/next/dist/compiled/buffer/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

(function() {
    var e = {
        675: function(e, r) {
            "use strict";
            r.byteLength = byteLength;
            r.toByteArray = toByteArray;
            r.fromByteArray = fromByteArray;
            var t = [];
            var f = [];
            var n = typeof Uint8Array !== "undefined" ? Uint8Array : Array;
            var i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
            for(var o = 0, u = i.length; o < u; ++o){
                t[o] = i[o];
                f[i.charCodeAt(o)] = o;
            }
            f["-".charCodeAt(0)] = 62;
            f["_".charCodeAt(0)] = 63;
            function getLens(e) {
                var r = e.length;
                if (r % 4 > 0) {
                    throw new Error("Invalid string. Length must be a multiple of 4");
                }
                var t = e.indexOf("=");
                if (t === -1) t = r;
                var f = t === r ? 0 : 4 - t % 4;
                return [
                    t,
                    f
                ];
            }
            function byteLength(e) {
                var r = getLens(e);
                var t = r[0];
                var f = r[1];
                return (t + f) * 3 / 4 - f;
            }
            function _byteLength(e, r, t) {
                return (r + t) * 3 / 4 - t;
            }
            function toByteArray(e) {
                var r;
                var t = getLens(e);
                var i = t[0];
                var o = t[1];
                var u = new n(_byteLength(e, i, o));
                var a = 0;
                var s = o > 0 ? i - 4 : i;
                var h;
                for(h = 0; h < s; h += 4){
                    r = f[e.charCodeAt(h)] << 18 | f[e.charCodeAt(h + 1)] << 12 | f[e.charCodeAt(h + 2)] << 6 | f[e.charCodeAt(h + 3)];
                    u[a++] = r >> 16 & 255;
                    u[a++] = r >> 8 & 255;
                    u[a++] = r & 255;
                }
                if (o === 2) {
                    r = f[e.charCodeAt(h)] << 2 | f[e.charCodeAt(h + 1)] >> 4;
                    u[a++] = r & 255;
                }
                if (o === 1) {
                    r = f[e.charCodeAt(h)] << 10 | f[e.charCodeAt(h + 1)] << 4 | f[e.charCodeAt(h + 2)] >> 2;
                    u[a++] = r >> 8 & 255;
                    u[a++] = r & 255;
                }
                return u;
            }
            function tripletToBase64(e) {
                return t[e >> 18 & 63] + t[e >> 12 & 63] + t[e >> 6 & 63] + t[e & 63];
            }
            function encodeChunk(e, r, t) {
                var f;
                var n = [];
                for(var i = r; i < t; i += 3){
                    f = (e[i] << 16 & 16711680) + (e[i + 1] << 8 & 65280) + (e[i + 2] & 255);
                    n.push(tripletToBase64(f));
                }
                return n.join("");
            }
            function fromByteArray(e) {
                var r;
                var f = e.length;
                var n = f % 3;
                var i = [];
                var o = 16383;
                for(var u = 0, a = f - n; u < a; u += o){
                    i.push(encodeChunk(e, u, u + o > a ? a : u + o));
                }
                if (n === 1) {
                    r = e[f - 1];
                    i.push(t[r >> 2] + t[r << 4 & 63] + "==");
                } else if (n === 2) {
                    r = (e[f - 2] << 8) + e[f - 1];
                    i.push(t[r >> 10] + t[r >> 4 & 63] + t[r << 2 & 63] + "=");
                }
                return i.join("");
            }
        },
        72: function(e, r, t) {
            "use strict";
            /*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */ var f = t(675);
            var n = t(783);
            var i = typeof Symbol === "function" && typeof Symbol.for === "function" ? Symbol.for("nodejs.util.inspect.custom") : null;
            r.Buffer = Buffer;
            r.SlowBuffer = SlowBuffer;
            r.INSPECT_MAX_BYTES = 50;
            var o = 2147483647;
            r.kMaxLength = o;
            Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport();
            if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== "undefined" && typeof console.error === "function") {
                console.error("This browser lacks typed array (Uint8Array) support which is required by " + "`buffer` v5.x. Use `buffer` v4.x if you require old browser support.");
            }
            function typedArraySupport() {
                try {
                    var e = new Uint8Array(1);
                    var r = {
                        foo: function() {
                            return 42;
                        }
                    };
                    Object.setPrototypeOf(r, Uint8Array.prototype);
                    Object.setPrototypeOf(e, r);
                    return e.foo() === 42;
                } catch (e) {
                    return false;
                }
            }
            Object.defineProperty(Buffer.prototype, "parent", {
                enumerable: true,
                get: function() {
                    if (!Buffer.isBuffer(this)) return undefined;
                    return this.buffer;
                }
            });
            Object.defineProperty(Buffer.prototype, "offset", {
                enumerable: true,
                get: function() {
                    if (!Buffer.isBuffer(this)) return undefined;
                    return this.byteOffset;
                }
            });
            function createBuffer(e) {
                if (e > o) {
                    throw new RangeError('The value "' + e + '" is invalid for option "size"');
                }
                var r = new Uint8Array(e);
                Object.setPrototypeOf(r, Buffer.prototype);
                return r;
            }
            function Buffer(e, r, t) {
                if (typeof e === "number") {
                    if (typeof r === "string") {
                        throw new TypeError('The "string" argument must be of type string. Received type number');
                    }
                    return allocUnsafe(e);
                }
                return from(e, r, t);
            }
            Buffer.poolSize = 8192;
            function from(e, r, t) {
                if (typeof e === "string") {
                    return fromString(e, r);
                }
                if (ArrayBuffer.isView(e)) {
                    return fromArrayLike(e);
                }
                if (e == null) {
                    throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, " + "or Array-like Object. Received type " + typeof e);
                }
                if (isInstance(e, ArrayBuffer) || e && isInstance(e.buffer, ArrayBuffer)) {
                    return fromArrayBuffer(e, r, t);
                }
                if (typeof SharedArrayBuffer !== "undefined" && (isInstance(e, SharedArrayBuffer) || e && isInstance(e.buffer, SharedArrayBuffer))) {
                    return fromArrayBuffer(e, r, t);
                }
                if (typeof e === "number") {
                    throw new TypeError('The "value" argument must not be of type number. Received type number');
                }
                var f = e.valueOf && e.valueOf();
                if (f != null && f !== e) {
                    return Buffer.from(f, r, t);
                }
                var n = fromObject(e);
                if (n) return n;
                if (typeof Symbol !== "undefined" && Symbol.toPrimitive != null && typeof e[Symbol.toPrimitive] === "function") {
                    return Buffer.from(e[Symbol.toPrimitive]("string"), r, t);
                }
                throw new TypeError("The first argument must be one of type string, Buffer, ArrayBuffer, Array, " + "or Array-like Object. Received type " + typeof e);
            }
            Buffer.from = function(e, r, t) {
                return from(e, r, t);
            };
            Object.setPrototypeOf(Buffer.prototype, Uint8Array.prototype);
            Object.setPrototypeOf(Buffer, Uint8Array);
            function assertSize(e) {
                if (typeof e !== "number") {
                    throw new TypeError('"size" argument must be of type number');
                } else if (e < 0) {
                    throw new RangeError('The value "' + e + '" is invalid for option "size"');
                }
            }
            function alloc(e, r, t) {
                assertSize(e);
                if (e <= 0) {
                    return createBuffer(e);
                }
                if (r !== undefined) {
                    return typeof t === "string" ? createBuffer(e).fill(r, t) : createBuffer(e).fill(r);
                }
                return createBuffer(e);
            }
            Buffer.alloc = function(e, r, t) {
                return alloc(e, r, t);
            };
            function allocUnsafe(e) {
                assertSize(e);
                return createBuffer(e < 0 ? 0 : checked(e) | 0);
            }
            Buffer.allocUnsafe = function(e) {
                return allocUnsafe(e);
            };
            Buffer.allocUnsafeSlow = function(e) {
                return allocUnsafe(e);
            };
            function fromString(e, r) {
                if (typeof r !== "string" || r === "") {
                    r = "utf8";
                }
                if (!Buffer.isEncoding(r)) {
                    throw new TypeError("Unknown encoding: " + r);
                }
                var t = byteLength(e, r) | 0;
                var f = createBuffer(t);
                var n = f.write(e, r);
                if (n !== t) {
                    f = f.slice(0, n);
                }
                return f;
            }
            function fromArrayLike(e) {
                var r = e.length < 0 ? 0 : checked(e.length) | 0;
                var t = createBuffer(r);
                for(var f = 0; f < r; f += 1){
                    t[f] = e[f] & 255;
                }
                return t;
            }
            function fromArrayBuffer(e, r, t) {
                if (r < 0 || e.byteLength < r) {
                    throw new RangeError('"offset" is outside of buffer bounds');
                }
                if (e.byteLength < r + (t || 0)) {
                    throw new RangeError('"length" is outside of buffer bounds');
                }
                var f;
                if (r === undefined && t === undefined) {
                    f = new Uint8Array(e);
                } else if (t === undefined) {
                    f = new Uint8Array(e, r);
                } else {
                    f = new Uint8Array(e, r, t);
                }
                Object.setPrototypeOf(f, Buffer.prototype);
                return f;
            }
            function fromObject(e) {
                if (Buffer.isBuffer(e)) {
                    var r = checked(e.length) | 0;
                    var t = createBuffer(r);
                    if (t.length === 0) {
                        return t;
                    }
                    e.copy(t, 0, 0, r);
                    return t;
                }
                if (e.length !== undefined) {
                    if (typeof e.length !== "number" || numberIsNaN(e.length)) {
                        return createBuffer(0);
                    }
                    return fromArrayLike(e);
                }
                if (e.type === "Buffer" && Array.isArray(e.data)) {
                    return fromArrayLike(e.data);
                }
            }
            function checked(e) {
                if (e >= o) {
                    throw new RangeError("Attempt to allocate Buffer larger than maximum " + "size: 0x" + o.toString(16) + " bytes");
                }
                return e | 0;
            }
            function SlowBuffer(e) {
                if (+e != e) {
                    e = 0;
                }
                return Buffer.alloc(+e);
            }
            Buffer.isBuffer = function isBuffer(e) {
                return e != null && e._isBuffer === true && e !== Buffer.prototype;
            };
            Buffer.compare = function compare(e, r) {
                if (isInstance(e, Uint8Array)) e = Buffer.from(e, e.offset, e.byteLength);
                if (isInstance(r, Uint8Array)) r = Buffer.from(r, r.offset, r.byteLength);
                if (!Buffer.isBuffer(e) || !Buffer.isBuffer(r)) {
                    throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
                }
                if (e === r) return 0;
                var t = e.length;
                var f = r.length;
                for(var n = 0, i = Math.min(t, f); n < i; ++n){
                    if (e[n] !== r[n]) {
                        t = e[n];
                        f = r[n];
                        break;
                    }
                }
                if (t < f) return -1;
                if (f < t) return 1;
                return 0;
            };
            Buffer.isEncoding = function isEncoding(e) {
                switch(String(e).toLowerCase()){
                    case "hex":
                    case "utf8":
                    case "utf-8":
                    case "ascii":
                    case "latin1":
                    case "binary":
                    case "base64":
                    case "ucs2":
                    case "ucs-2":
                    case "utf16le":
                    case "utf-16le":
                        return true;
                    default:
                        return false;
                }
            };
            Buffer.concat = function concat(e, r) {
                if (!Array.isArray(e)) {
                    throw new TypeError('"list" argument must be an Array of Buffers');
                }
                if (e.length === 0) {
                    return Buffer.alloc(0);
                }
                var t;
                if (r === undefined) {
                    r = 0;
                    for(t = 0; t < e.length; ++t){
                        r += e[t].length;
                    }
                }
                var f = Buffer.allocUnsafe(r);
                var n = 0;
                for(t = 0; t < e.length; ++t){
                    var i = e[t];
                    if (isInstance(i, Uint8Array)) {
                        i = Buffer.from(i);
                    }
                    if (!Buffer.isBuffer(i)) {
                        throw new TypeError('"list" argument must be an Array of Buffers');
                    }
                    i.copy(f, n);
                    n += i.length;
                }
                return f;
            };
            function byteLength(e, r) {
                if (Buffer.isBuffer(e)) {
                    return e.length;
                }
                if (ArrayBuffer.isView(e) || isInstance(e, ArrayBuffer)) {
                    return e.byteLength;
                }
                if (typeof e !== "string") {
                    throw new TypeError('The "string" argument must be one of type string, Buffer, or ArrayBuffer. ' + "Received type " + typeof e);
                }
                var t = e.length;
                var f = arguments.length > 2 && arguments[2] === true;
                if (!f && t === 0) return 0;
                var n = false;
                for(;;){
                    switch(r){
                        case "ascii":
                        case "latin1":
                        case "binary":
                            return t;
                        case "utf8":
                        case "utf-8":
                            return utf8ToBytes(e).length;
                        case "ucs2":
                        case "ucs-2":
                        case "utf16le":
                        case "utf-16le":
                            return t * 2;
                        case "hex":
                            return t >>> 1;
                        case "base64":
                            return base64ToBytes(e).length;
                        default:
                            if (n) {
                                return f ? -1 : utf8ToBytes(e).length;
                            }
                            r = ("" + r).toLowerCase();
                            n = true;
                    }
                }
            }
            Buffer.byteLength = byteLength;
            function slowToString(e, r, t) {
                var f = false;
                if (r === undefined || r < 0) {
                    r = 0;
                }
                if (r > this.length) {
                    return "";
                }
                if (t === undefined || t > this.length) {
                    t = this.length;
                }
                if (t <= 0) {
                    return "";
                }
                t >>>= 0;
                r >>>= 0;
                if (t <= r) {
                    return "";
                }
                if (!e) e = "utf8";
                while(true){
                    switch(e){
                        case "hex":
                            return hexSlice(this, r, t);
                        case "utf8":
                        case "utf-8":
                            return utf8Slice(this, r, t);
                        case "ascii":
                            return asciiSlice(this, r, t);
                        case "latin1":
                        case "binary":
                            return latin1Slice(this, r, t);
                        case "base64":
                            return base64Slice(this, r, t);
                        case "ucs2":
                        case "ucs-2":
                        case "utf16le":
                        case "utf-16le":
                            return utf16leSlice(this, r, t);
                        default:
                            if (f) throw new TypeError("Unknown encoding: " + e);
                            e = (e + "").toLowerCase();
                            f = true;
                    }
                }
            }
            Buffer.prototype._isBuffer = true;
            function swap(e, r, t) {
                var f = e[r];
                e[r] = e[t];
                e[t] = f;
            }
            Buffer.prototype.swap16 = function swap16() {
                var e = this.length;
                if (e % 2 !== 0) {
                    throw new RangeError("Buffer size must be a multiple of 16-bits");
                }
                for(var r = 0; r < e; r += 2){
                    swap(this, r, r + 1);
                }
                return this;
            };
            Buffer.prototype.swap32 = function swap32() {
                var e = this.length;
                if (e % 4 !== 0) {
                    throw new RangeError("Buffer size must be a multiple of 32-bits");
                }
                for(var r = 0; r < e; r += 4){
                    swap(this, r, r + 3);
                    swap(this, r + 1, r + 2);
                }
                return this;
            };
            Buffer.prototype.swap64 = function swap64() {
                var e = this.length;
                if (e % 8 !== 0) {
                    throw new RangeError("Buffer size must be a multiple of 64-bits");
                }
                for(var r = 0; r < e; r += 8){
                    swap(this, r, r + 7);
                    swap(this, r + 1, r + 6);
                    swap(this, r + 2, r + 5);
                    swap(this, r + 3, r + 4);
                }
                return this;
            };
            Buffer.prototype.toString = function toString() {
                var e = this.length;
                if (e === 0) return "";
                if (arguments.length === 0) return utf8Slice(this, 0, e);
                return slowToString.apply(this, arguments);
            };
            Buffer.prototype.toLocaleString = Buffer.prototype.toString;
            Buffer.prototype.equals = function equals(e) {
                if (!Buffer.isBuffer(e)) throw new TypeError("Argument must be a Buffer");
                if (this === e) return true;
                return Buffer.compare(this, e) === 0;
            };
            Buffer.prototype.inspect = function inspect() {
                var e = "";
                var t = r.INSPECT_MAX_BYTES;
                e = this.toString("hex", 0, t).replace(/(.{2})/g, "$1 ").trim();
                if (this.length > t) e += " ... ";
                return "<Buffer " + e + ">";
            };
            if (i) {
                Buffer.prototype[i] = Buffer.prototype.inspect;
            }
            Buffer.prototype.compare = function compare(e, r, t, f, n) {
                if (isInstance(e, Uint8Array)) {
                    e = Buffer.from(e, e.offset, e.byteLength);
                }
                if (!Buffer.isBuffer(e)) {
                    throw new TypeError('The "target" argument must be one of type Buffer or Uint8Array. ' + "Received type " + typeof e);
                }
                if (r === undefined) {
                    r = 0;
                }
                if (t === undefined) {
                    t = e ? e.length : 0;
                }
                if (f === undefined) {
                    f = 0;
                }
                if (n === undefined) {
                    n = this.length;
                }
                if (r < 0 || t > e.length || f < 0 || n > this.length) {
                    throw new RangeError("out of range index");
                }
                if (f >= n && r >= t) {
                    return 0;
                }
                if (f >= n) {
                    return -1;
                }
                if (r >= t) {
                    return 1;
                }
                r >>>= 0;
                t >>>= 0;
                f >>>= 0;
                n >>>= 0;
                if (this === e) return 0;
                var i = n - f;
                var o = t - r;
                var u = Math.min(i, o);
                var a = this.slice(f, n);
                var s = e.slice(r, t);
                for(var h = 0; h < u; ++h){
                    if (a[h] !== s[h]) {
                        i = a[h];
                        o = s[h];
                        break;
                    }
                }
                if (i < o) return -1;
                if (o < i) return 1;
                return 0;
            };
            function bidirectionalIndexOf(e, r, t, f, n) {
                if (e.length === 0) return -1;
                if (typeof t === "string") {
                    f = t;
                    t = 0;
                } else if (t > 2147483647) {
                    t = 2147483647;
                } else if (t < -2147483648) {
                    t = -2147483648;
                }
                t = +t;
                if (numberIsNaN(t)) {
                    t = n ? 0 : e.length - 1;
                }
                if (t < 0) t = e.length + t;
                if (t >= e.length) {
                    if (n) return -1;
                    else t = e.length - 1;
                } else if (t < 0) {
                    if (n) t = 0;
                    else return -1;
                }
                if (typeof r === "string") {
                    r = Buffer.from(r, f);
                }
                if (Buffer.isBuffer(r)) {
                    if (r.length === 0) {
                        return -1;
                    }
                    return arrayIndexOf(e, r, t, f, n);
                } else if (typeof r === "number") {
                    r = r & 255;
                    if (typeof Uint8Array.prototype.indexOf === "function") {
                        if (n) {
                            return Uint8Array.prototype.indexOf.call(e, r, t);
                        } else {
                            return Uint8Array.prototype.lastIndexOf.call(e, r, t);
                        }
                    }
                    return arrayIndexOf(e, [
                        r
                    ], t, f, n);
                }
                throw new TypeError("val must be string, number or Buffer");
            }
            function arrayIndexOf(e, r, t, f, n) {
                var i = 1;
                var o = e.length;
                var u = r.length;
                if (f !== undefined) {
                    f = String(f).toLowerCase();
                    if (f === "ucs2" || f === "ucs-2" || f === "utf16le" || f === "utf-16le") {
                        if (e.length < 2 || r.length < 2) {
                            return -1;
                        }
                        i = 2;
                        o /= 2;
                        u /= 2;
                        t /= 2;
                    }
                }
                function read(e, r) {
                    if (i === 1) {
                        return e[r];
                    } else {
                        return e.readUInt16BE(r * i);
                    }
                }
                var a;
                if (n) {
                    var s = -1;
                    for(a = t; a < o; a++){
                        if (read(e, a) === read(r, s === -1 ? 0 : a - s)) {
                            if (s === -1) s = a;
                            if (a - s + 1 === u) return s * i;
                        } else {
                            if (s !== -1) a -= a - s;
                            s = -1;
                        }
                    }
                } else {
                    if (t + u > o) t = o - u;
                    for(a = t; a >= 0; a--){
                        var h = true;
                        for(var c = 0; c < u; c++){
                            if (read(e, a + c) !== read(r, c)) {
                                h = false;
                                break;
                            }
                        }
                        if (h) return a;
                    }
                }
                return -1;
            }
            Buffer.prototype.includes = function includes(e, r, t) {
                return this.indexOf(e, r, t) !== -1;
            };
            Buffer.prototype.indexOf = function indexOf(e, r, t) {
                return bidirectionalIndexOf(this, e, r, t, true);
            };
            Buffer.prototype.lastIndexOf = function lastIndexOf(e, r, t) {
                return bidirectionalIndexOf(this, e, r, t, false);
            };
            function hexWrite(e, r, t, f) {
                t = Number(t) || 0;
                var n = e.length - t;
                if (!f) {
                    f = n;
                } else {
                    f = Number(f);
                    if (f > n) {
                        f = n;
                    }
                }
                var i = r.length;
                if (f > i / 2) {
                    f = i / 2;
                }
                for(var o = 0; o < f; ++o){
                    var u = parseInt(r.substr(o * 2, 2), 16);
                    if (numberIsNaN(u)) return o;
                    e[t + o] = u;
                }
                return o;
            }
            function utf8Write(e, r, t, f) {
                return blitBuffer(utf8ToBytes(r, e.length - t), e, t, f);
            }
            function asciiWrite(e, r, t, f) {
                return blitBuffer(asciiToBytes(r), e, t, f);
            }
            function latin1Write(e, r, t, f) {
                return asciiWrite(e, r, t, f);
            }
            function base64Write(e, r, t, f) {
                return blitBuffer(base64ToBytes(r), e, t, f);
            }
            function ucs2Write(e, r, t, f) {
                return blitBuffer(utf16leToBytes(r, e.length - t), e, t, f);
            }
            Buffer.prototype.write = function write(e, r, t, f) {
                if (r === undefined) {
                    f = "utf8";
                    t = this.length;
                    r = 0;
                } else if (t === undefined && typeof r === "string") {
                    f = r;
                    t = this.length;
                    r = 0;
                } else if (isFinite(r)) {
                    r = r >>> 0;
                    if (isFinite(t)) {
                        t = t >>> 0;
                        if (f === undefined) f = "utf8";
                    } else {
                        f = t;
                        t = undefined;
                    }
                } else {
                    throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                }
                var n = this.length - r;
                if (t === undefined || t > n) t = n;
                if (e.length > 0 && (t < 0 || r < 0) || r > this.length) {
                    throw new RangeError("Attempt to write outside buffer bounds");
                }
                if (!f) f = "utf8";
                var i = false;
                for(;;){
                    switch(f){
                        case "hex":
                            return hexWrite(this, e, r, t);
                        case "utf8":
                        case "utf-8":
                            return utf8Write(this, e, r, t);
                        case "ascii":
                            return asciiWrite(this, e, r, t);
                        case "latin1":
                        case "binary":
                            return latin1Write(this, e, r, t);
                        case "base64":
                            return base64Write(this, e, r, t);
                        case "ucs2":
                        case "ucs-2":
                        case "utf16le":
                        case "utf-16le":
                            return ucs2Write(this, e, r, t);
                        default:
                            if (i) throw new TypeError("Unknown encoding: " + f);
                            f = ("" + f).toLowerCase();
                            i = true;
                    }
                }
            };
            Buffer.prototype.toJSON = function toJSON() {
                return {
                    type: "Buffer",
                    data: Array.prototype.slice.call(this._arr || this, 0)
                };
            };
            function base64Slice(e, r, t) {
                if (r === 0 && t === e.length) {
                    return f.fromByteArray(e);
                } else {
                    return f.fromByteArray(e.slice(r, t));
                }
            }
            function utf8Slice(e, r, t) {
                t = Math.min(e.length, t);
                var f = [];
                var n = r;
                while(n < t){
                    var i = e[n];
                    var o = null;
                    var u = i > 239 ? 4 : i > 223 ? 3 : i > 191 ? 2 : 1;
                    if (n + u <= t) {
                        var a, s, h, c;
                        switch(u){
                            case 1:
                                if (i < 128) {
                                    o = i;
                                }
                                break;
                            case 2:
                                a = e[n + 1];
                                if ((a & 192) === 128) {
                                    c = (i & 31) << 6 | a & 63;
                                    if (c > 127) {
                                        o = c;
                                    }
                                }
                                break;
                            case 3:
                                a = e[n + 1];
                                s = e[n + 2];
                                if ((a & 192) === 128 && (s & 192) === 128) {
                                    c = (i & 15) << 12 | (a & 63) << 6 | s & 63;
                                    if (c > 2047 && (c < 55296 || c > 57343)) {
                                        o = c;
                                    }
                                }
                                break;
                            case 4:
                                a = e[n + 1];
                                s = e[n + 2];
                                h = e[n + 3];
                                if ((a & 192) === 128 && (s & 192) === 128 && (h & 192) === 128) {
                                    c = (i & 15) << 18 | (a & 63) << 12 | (s & 63) << 6 | h & 63;
                                    if (c > 65535 && c < 1114112) {
                                        o = c;
                                    }
                                }
                        }
                    }
                    if (o === null) {
                        o = 65533;
                        u = 1;
                    } else if (o > 65535) {
                        o -= 65536;
                        f.push(o >>> 10 & 1023 | 55296);
                        o = 56320 | o & 1023;
                    }
                    f.push(o);
                    n += u;
                }
                return decodeCodePointsArray(f);
            }
            var u = 4096;
            function decodeCodePointsArray(e) {
                var r = e.length;
                if (r <= u) {
                    return String.fromCharCode.apply(String, e);
                }
                var t = "";
                var f = 0;
                while(f < r){
                    t += String.fromCharCode.apply(String, e.slice(f, f += u));
                }
                return t;
            }
            function asciiSlice(e, r, t) {
                var f = "";
                t = Math.min(e.length, t);
                for(var n = r; n < t; ++n){
                    f += String.fromCharCode(e[n] & 127);
                }
                return f;
            }
            function latin1Slice(e, r, t) {
                var f = "";
                t = Math.min(e.length, t);
                for(var n = r; n < t; ++n){
                    f += String.fromCharCode(e[n]);
                }
                return f;
            }
            function hexSlice(e, r, t) {
                var f = e.length;
                if (!r || r < 0) r = 0;
                if (!t || t < 0 || t > f) t = f;
                var n = "";
                for(var i = r; i < t; ++i){
                    n += s[e[i]];
                }
                return n;
            }
            function utf16leSlice(e, r, t) {
                var f = e.slice(r, t);
                var n = "";
                for(var i = 0; i < f.length; i += 2){
                    n += String.fromCharCode(f[i] + f[i + 1] * 256);
                }
                return n;
            }
            Buffer.prototype.slice = function slice(e, r) {
                var t = this.length;
                e = ~~e;
                r = r === undefined ? t : ~~r;
                if (e < 0) {
                    e += t;
                    if (e < 0) e = 0;
                } else if (e > t) {
                    e = t;
                }
                if (r < 0) {
                    r += t;
                    if (r < 0) r = 0;
                } else if (r > t) {
                    r = t;
                }
                if (r < e) r = e;
                var f = this.subarray(e, r);
                Object.setPrototypeOf(f, Buffer.prototype);
                return f;
            };
            function checkOffset(e, r, t) {
                if (e % 1 !== 0 || e < 0) throw new RangeError("offset is not uint");
                if (e + r > t) throw new RangeError("Trying to access beyond buffer length");
            }
            Buffer.prototype.readUIntLE = function readUIntLE(e, r, t) {
                e = e >>> 0;
                r = r >>> 0;
                if (!t) checkOffset(e, r, this.length);
                var f = this[e];
                var n = 1;
                var i = 0;
                while(++i < r && (n *= 256)){
                    f += this[e + i] * n;
                }
                return f;
            };
            Buffer.prototype.readUIntBE = function readUIntBE(e, r, t) {
                e = e >>> 0;
                r = r >>> 0;
                if (!t) {
                    checkOffset(e, r, this.length);
                }
                var f = this[e + --r];
                var n = 1;
                while(r > 0 && (n *= 256)){
                    f += this[e + --r] * n;
                }
                return f;
            };
            Buffer.prototype.readUInt8 = function readUInt8(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 1, this.length);
                return this[e];
            };
            Buffer.prototype.readUInt16LE = function readUInt16LE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 2, this.length);
                return this[e] | this[e + 1] << 8;
            };
            Buffer.prototype.readUInt16BE = function readUInt16BE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 2, this.length);
                return this[e] << 8 | this[e + 1];
            };
            Buffer.prototype.readUInt32LE = function readUInt32LE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 4, this.length);
                return (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + this[e + 3] * 16777216;
            };
            Buffer.prototype.readUInt32BE = function readUInt32BE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 4, this.length);
                return this[e] * 16777216 + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]);
            };
            Buffer.prototype.readIntLE = function readIntLE(e, r, t) {
                e = e >>> 0;
                r = r >>> 0;
                if (!t) checkOffset(e, r, this.length);
                var f = this[e];
                var n = 1;
                var i = 0;
                while(++i < r && (n *= 256)){
                    f += this[e + i] * n;
                }
                n *= 128;
                if (f >= n) f -= Math.pow(2, 8 * r);
                return f;
            };
            Buffer.prototype.readIntBE = function readIntBE(e, r, t) {
                e = e >>> 0;
                r = r >>> 0;
                if (!t) checkOffset(e, r, this.length);
                var f = r;
                var n = 1;
                var i = this[e + --f];
                while(f > 0 && (n *= 256)){
                    i += this[e + --f] * n;
                }
                n *= 128;
                if (i >= n) i -= Math.pow(2, 8 * r);
                return i;
            };
            Buffer.prototype.readInt8 = function readInt8(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 1, this.length);
                if (!(this[e] & 128)) return this[e];
                return (255 - this[e] + 1) * -1;
            };
            Buffer.prototype.readInt16LE = function readInt16LE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 2, this.length);
                var t = this[e] | this[e + 1] << 8;
                return t & 32768 ? t | 4294901760 : t;
            };
            Buffer.prototype.readInt16BE = function readInt16BE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 2, this.length);
                var t = this[e + 1] | this[e] << 8;
                return t & 32768 ? t | 4294901760 : t;
            };
            Buffer.prototype.readInt32LE = function readInt32LE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 4, this.length);
                return this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24;
            };
            Buffer.prototype.readInt32BE = function readInt32BE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 4, this.length);
                return this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3];
            };
            Buffer.prototype.readFloatLE = function readFloatLE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 4, this.length);
                return n.read(this, e, true, 23, 4);
            };
            Buffer.prototype.readFloatBE = function readFloatBE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 4, this.length);
                return n.read(this, e, false, 23, 4);
            };
            Buffer.prototype.readDoubleLE = function readDoubleLE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 8, this.length);
                return n.read(this, e, true, 52, 8);
            };
            Buffer.prototype.readDoubleBE = function readDoubleBE(e, r) {
                e = e >>> 0;
                if (!r) checkOffset(e, 8, this.length);
                return n.read(this, e, false, 52, 8);
            };
            function checkInt(e, r, t, f, n, i) {
                if (!Buffer.isBuffer(e)) throw new TypeError('"buffer" argument must be a Buffer instance');
                if (r > n || r < i) throw new RangeError('"value" argument is out of bounds');
                if (t + f > e.length) throw new RangeError("Index out of range");
            }
            Buffer.prototype.writeUIntLE = function writeUIntLE(e, r, t, f) {
                e = +e;
                r = r >>> 0;
                t = t >>> 0;
                if (!f) {
                    var n = Math.pow(2, 8 * t) - 1;
                    checkInt(this, e, r, t, n, 0);
                }
                var i = 1;
                var o = 0;
                this[r] = e & 255;
                while(++o < t && (i *= 256)){
                    this[r + o] = e / i & 255;
                }
                return r + t;
            };
            Buffer.prototype.writeUIntBE = function writeUIntBE(e, r, t, f) {
                e = +e;
                r = r >>> 0;
                t = t >>> 0;
                if (!f) {
                    var n = Math.pow(2, 8 * t) - 1;
                    checkInt(this, e, r, t, n, 0);
                }
                var i = t - 1;
                var o = 1;
                this[r + i] = e & 255;
                while(--i >= 0 && (o *= 256)){
                    this[r + i] = e / o & 255;
                }
                return r + t;
            };
            Buffer.prototype.writeUInt8 = function writeUInt8(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 1, 255, 0);
                this[r] = e & 255;
                return r + 1;
            };
            Buffer.prototype.writeUInt16LE = function writeUInt16LE(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 2, 65535, 0);
                this[r] = e & 255;
                this[r + 1] = e >>> 8;
                return r + 2;
            };
            Buffer.prototype.writeUInt16BE = function writeUInt16BE(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 2, 65535, 0);
                this[r] = e >>> 8;
                this[r + 1] = e & 255;
                return r + 2;
            };
            Buffer.prototype.writeUInt32LE = function writeUInt32LE(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 4, 4294967295, 0);
                this[r + 3] = e >>> 24;
                this[r + 2] = e >>> 16;
                this[r + 1] = e >>> 8;
                this[r] = e & 255;
                return r + 4;
            };
            Buffer.prototype.writeUInt32BE = function writeUInt32BE(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 4, 4294967295, 0);
                this[r] = e >>> 24;
                this[r + 1] = e >>> 16;
                this[r + 2] = e >>> 8;
                this[r + 3] = e & 255;
                return r + 4;
            };
            Buffer.prototype.writeIntLE = function writeIntLE(e, r, t, f) {
                e = +e;
                r = r >>> 0;
                if (!f) {
                    var n = Math.pow(2, 8 * t - 1);
                    checkInt(this, e, r, t, n - 1, -n);
                }
                var i = 0;
                var o = 1;
                var u = 0;
                this[r] = e & 255;
                while(++i < t && (o *= 256)){
                    if (e < 0 && u === 0 && this[r + i - 1] !== 0) {
                        u = 1;
                    }
                    this[r + i] = (e / o >> 0) - u & 255;
                }
                return r + t;
            };
            Buffer.prototype.writeIntBE = function writeIntBE(e, r, t, f) {
                e = +e;
                r = r >>> 0;
                if (!f) {
                    var n = Math.pow(2, 8 * t - 1);
                    checkInt(this, e, r, t, n - 1, -n);
                }
                var i = t - 1;
                var o = 1;
                var u = 0;
                this[r + i] = e & 255;
                while(--i >= 0 && (o *= 256)){
                    if (e < 0 && u === 0 && this[r + i + 1] !== 0) {
                        u = 1;
                    }
                    this[r + i] = (e / o >> 0) - u & 255;
                }
                return r + t;
            };
            Buffer.prototype.writeInt8 = function writeInt8(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 1, 127, -128);
                if (e < 0) e = 255 + e + 1;
                this[r] = e & 255;
                return r + 1;
            };
            Buffer.prototype.writeInt16LE = function writeInt16LE(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 2, 32767, -32768);
                this[r] = e & 255;
                this[r + 1] = e >>> 8;
                return r + 2;
            };
            Buffer.prototype.writeInt16BE = function writeInt16BE(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 2, 32767, -32768);
                this[r] = e >>> 8;
                this[r + 1] = e & 255;
                return r + 2;
            };
            Buffer.prototype.writeInt32LE = function writeInt32LE(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 4, 2147483647, -2147483648);
                this[r] = e & 255;
                this[r + 1] = e >>> 8;
                this[r + 2] = e >>> 16;
                this[r + 3] = e >>> 24;
                return r + 4;
            };
            Buffer.prototype.writeInt32BE = function writeInt32BE(e, r, t) {
                e = +e;
                r = r >>> 0;
                if (!t) checkInt(this, e, r, 4, 2147483647, -2147483648);
                if (e < 0) e = 4294967295 + e + 1;
                this[r] = e >>> 24;
                this[r + 1] = e >>> 16;
                this[r + 2] = e >>> 8;
                this[r + 3] = e & 255;
                return r + 4;
            };
            function checkIEEE754(e, r, t, f, n, i) {
                if (t + f > e.length) throw new RangeError("Index out of range");
                if (t < 0) throw new RangeError("Index out of range");
            }
            function writeFloat(e, r, t, f, i) {
                r = +r;
                t = t >>> 0;
                if (!i) {
                    checkIEEE754(e, r, t, 4, 34028234663852886e22, -34028234663852886e22);
                }
                n.write(e, r, t, f, 23, 4);
                return t + 4;
            }
            Buffer.prototype.writeFloatLE = function writeFloatLE(e, r, t) {
                return writeFloat(this, e, r, true, t);
            };
            Buffer.prototype.writeFloatBE = function writeFloatBE(e, r, t) {
                return writeFloat(this, e, r, false, t);
            };
            function writeDouble(e, r, t, f, i) {
                r = +r;
                t = t >>> 0;
                if (!i) {
                    checkIEEE754(e, r, t, 8, 17976931348623157e292, -17976931348623157e292);
                }
                n.write(e, r, t, f, 52, 8);
                return t + 8;
            }
            Buffer.prototype.writeDoubleLE = function writeDoubleLE(e, r, t) {
                return writeDouble(this, e, r, true, t);
            };
            Buffer.prototype.writeDoubleBE = function writeDoubleBE(e, r, t) {
                return writeDouble(this, e, r, false, t);
            };
            Buffer.prototype.copy = function copy(e, r, t, f) {
                if (!Buffer.isBuffer(e)) throw new TypeError("argument should be a Buffer");
                if (!t) t = 0;
                if (!f && f !== 0) f = this.length;
                if (r >= e.length) r = e.length;
                if (!r) r = 0;
                if (f > 0 && f < t) f = t;
                if (f === t) return 0;
                if (e.length === 0 || this.length === 0) return 0;
                if (r < 0) {
                    throw new RangeError("targetStart out of bounds");
                }
                if (t < 0 || t >= this.length) throw new RangeError("Index out of range");
                if (f < 0) throw new RangeError("sourceEnd out of bounds");
                if (f > this.length) f = this.length;
                if (e.length - r < f - t) {
                    f = e.length - r + t;
                }
                var n = f - t;
                if (this === e && typeof Uint8Array.prototype.copyWithin === "function") {
                    this.copyWithin(r, t, f);
                } else if (this === e && t < r && r < f) {
                    for(var i = n - 1; i >= 0; --i){
                        e[i + r] = this[i + t];
                    }
                } else {
                    Uint8Array.prototype.set.call(e, this.subarray(t, f), r);
                }
                return n;
            };
            Buffer.prototype.fill = function fill(e, r, t, f) {
                if (typeof e === "string") {
                    if (typeof r === "string") {
                        f = r;
                        r = 0;
                        t = this.length;
                    } else if (typeof t === "string") {
                        f = t;
                        t = this.length;
                    }
                    if (f !== undefined && typeof f !== "string") {
                        throw new TypeError("encoding must be a string");
                    }
                    if (typeof f === "string" && !Buffer.isEncoding(f)) {
                        throw new TypeError("Unknown encoding: " + f);
                    }
                    if (e.length === 1) {
                        var n = e.charCodeAt(0);
                        if (f === "utf8" && n < 128 || f === "latin1") {
                            e = n;
                        }
                    }
                } else if (typeof e === "number") {
                    e = e & 255;
                } else if (typeof e === "boolean") {
                    e = Number(e);
                }
                if (r < 0 || this.length < r || this.length < t) {
                    throw new RangeError("Out of range index");
                }
                if (t <= r) {
                    return this;
                }
                r = r >>> 0;
                t = t === undefined ? this.length : t >>> 0;
                if (!e) e = 0;
                var i;
                if (typeof e === "number") {
                    for(i = r; i < t; ++i){
                        this[i] = e;
                    }
                } else {
                    var o = Buffer.isBuffer(e) ? e : Buffer.from(e, f);
                    var u = o.length;
                    if (u === 0) {
                        throw new TypeError('The value "' + e + '" is invalid for argument "value"');
                    }
                    for(i = 0; i < t - r; ++i){
                        this[i + r] = o[i % u];
                    }
                }
                return this;
            };
            var a = /[^+/0-9A-Za-z-_]/g;
            function base64clean(e) {
                e = e.split("=")[0];
                e = e.trim().replace(a, "");
                if (e.length < 2) return "";
                while(e.length % 4 !== 0){
                    e = e + "=";
                }
                return e;
            }
            function utf8ToBytes(e, r) {
                r = r || Infinity;
                var t;
                var f = e.length;
                var n = null;
                var i = [];
                for(var o = 0; o < f; ++o){
                    t = e.charCodeAt(o);
                    if (t > 55295 && t < 57344) {
                        if (!n) {
                            if (t > 56319) {
                                if ((r -= 3) > -1) i.push(239, 191, 189);
                                continue;
                            } else if (o + 1 === f) {
                                if ((r -= 3) > -1) i.push(239, 191, 189);
                                continue;
                            }
                            n = t;
                            continue;
                        }
                        if (t < 56320) {
                            if ((r -= 3) > -1) i.push(239, 191, 189);
                            n = t;
                            continue;
                        }
                        t = (n - 55296 << 10 | t - 56320) + 65536;
                    } else if (n) {
                        if ((r -= 3) > -1) i.push(239, 191, 189);
                    }
                    n = null;
                    if (t < 128) {
                        if ((r -= 1) < 0) break;
                        i.push(t);
                    } else if (t < 2048) {
                        if ((r -= 2) < 0) break;
                        i.push(t >> 6 | 192, t & 63 | 128);
                    } else if (t < 65536) {
                        if ((r -= 3) < 0) break;
                        i.push(t >> 12 | 224, t >> 6 & 63 | 128, t & 63 | 128);
                    } else if (t < 1114112) {
                        if ((r -= 4) < 0) break;
                        i.push(t >> 18 | 240, t >> 12 & 63 | 128, t >> 6 & 63 | 128, t & 63 | 128);
                    } else {
                        throw new Error("Invalid code point");
                    }
                }
                return i;
            }
            function asciiToBytes(e) {
                var r = [];
                for(var t = 0; t < e.length; ++t){
                    r.push(e.charCodeAt(t) & 255);
                }
                return r;
            }
            function utf16leToBytes(e, r) {
                var t, f, n;
                var i = [];
                for(var o = 0; o < e.length; ++o){
                    if ((r -= 2) < 0) break;
                    t = e.charCodeAt(o);
                    f = t >> 8;
                    n = t % 256;
                    i.push(n);
                    i.push(f);
                }
                return i;
            }
            function base64ToBytes(e) {
                return f.toByteArray(base64clean(e));
            }
            function blitBuffer(e, r, t, f) {
                for(var n = 0; n < f; ++n){
                    if (n + t >= r.length || n >= e.length) break;
                    r[n + t] = e[n];
                }
                return n;
            }
            function isInstance(e, r) {
                return e instanceof r || e != null && e.constructor != null && e.constructor.name != null && e.constructor.name === r.name;
            }
            function numberIsNaN(e) {
                return e !== e;
            }
            var s = function() {
                var e = "0123456789abcdef";
                var r = new Array(256);
                for(var t = 0; t < 16; ++t){
                    var f = t * 16;
                    for(var n = 0; n < 16; ++n){
                        r[f + n] = e[t] + e[n];
                    }
                }
                return r;
            }();
        },
        783: function(e, r) {
            /*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */ r.read = function(e, r, t, f, n) {
                var i, o;
                var u = n * 8 - f - 1;
                var a = (1 << u) - 1;
                var s = a >> 1;
                var h = -7;
                var c = t ? n - 1 : 0;
                var l = t ? -1 : 1;
                var p = e[r + c];
                c += l;
                i = p & (1 << -h) - 1;
                p >>= -h;
                h += u;
                for(; h > 0; i = i * 256 + e[r + c], c += l, h -= 8){}
                o = i & (1 << -h) - 1;
                i >>= -h;
                h += f;
                for(; h > 0; o = o * 256 + e[r + c], c += l, h -= 8){}
                if (i === 0) {
                    i = 1 - s;
                } else if (i === a) {
                    return o ? NaN : (p ? -1 : 1) * Infinity;
                } else {
                    o = o + Math.pow(2, f);
                    i = i - s;
                }
                return (p ? -1 : 1) * o * Math.pow(2, i - f);
            };
            r.write = function(e, r, t, f, n, i) {
                var o, u, a;
                var s = i * 8 - n - 1;
                var h = (1 << s) - 1;
                var c = h >> 1;
                var l = n === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
                var p = f ? 0 : i - 1;
                var y = f ? 1 : -1;
                var g = r < 0 || r === 0 && 1 / r < 0 ? 1 : 0;
                r = Math.abs(r);
                if (isNaN(r) || r === Infinity) {
                    u = isNaN(r) ? 1 : 0;
                    o = h;
                } else {
                    o = Math.floor(Math.log(r) / Math.LN2);
                    if (r * (a = Math.pow(2, -o)) < 1) {
                        o--;
                        a *= 2;
                    }
                    if (o + c >= 1) {
                        r += l / a;
                    } else {
                        r += l * Math.pow(2, 1 - c);
                    }
                    if (r * a >= 2) {
                        o++;
                        a /= 2;
                    }
                    if (o + c >= h) {
                        u = 0;
                        o = h;
                    } else if (o + c >= 1) {
                        u = (r * a - 1) * Math.pow(2, n);
                        o = o + c;
                    } else {
                        u = r * Math.pow(2, c - 1) * Math.pow(2, n);
                        o = 0;
                    }
                }
                for(; n >= 8; e[t + p] = u & 255, p += y, u /= 256, n -= 8){}
                o = o << n | u;
                s += n;
                for(; s > 0; e[t + p] = o & 255, p += y, o /= 256, s -= 8){}
                e[t + p - y] |= g * 128;
            };
        }
    };
    var r = {};
    function __nccwpck_require__(t) {
        var f = r[t];
        if (f !== undefined) {
            return f.exports;
        }
        var n = r[t] = {
            exports: {}
        };
        var i = true;
        try {
            e[t](n, n.exports, __nccwpck_require__);
            i = false;
        } finally{
            if (i) delete r[t];
        }
        return n.exports;
    }
    if (typeof __nccwpck_require__ !== "undefined") __nccwpck_require__.ab = ("TURBOPACK compile-time value", "/ROOT/node_modules/next/dist/compiled/buffer") + "/";
    var t = __nccwpck_require__(72);
    module.exports = t;
})();
}),
"[project]/node_modules/next/dist/build/polyfills/object-assign.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var assign = Object.assign.bind(Object);
module.exports = assign;
module.exports.default = module.exports; //# sourceMappingURL=object-assign.js.map
}),
"[project]/node_modules/zustand/esm/vanilla.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStore",
    ()=>createStore
]);
const createStoreImpl = (createState)=>{
    let state;
    const listeners = /* @__PURE__ */ new Set();
    const setState = (partial, replace)=>{
        const nextState = typeof partial === "function" ? partial(state) : partial;
        if (!Object.is(nextState, state)) {
            const previousState = state;
            state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
            listeners.forEach((listener)=>listener(state, previousState));
        }
    };
    const getState = ()=>state;
    const getInitialState = ()=>initialState;
    const subscribe = (listener)=>{
        listeners.add(listener);
        return ()=>listeners.delete(listener);
    };
    const api = {
        setState,
        getState,
        getInitialState,
        subscribe
    };
    const initialState = state = createState(setState, getState, api);
    return api;
};
const createStore = (createState)=>createState ? createStoreImpl(createState) : createStoreImpl;
;
}),
"[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "create",
    ()=>create,
    "useStore",
    ()=>useStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/vanilla.mjs [app-client] (ecmascript)");
;
;
const identity = (arg)=>arg;
function useStore(api, selector = identity) {
    const slice = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useSyncExternalStore(api.subscribe, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useStore.useSyncExternalStore[slice]": ()=>selector(api.getState())
    }["useStore.useSyncExternalStore[slice]"], [
        api,
        selector
    ]), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useCallback({
        "useStore.useSyncExternalStore[slice]": ()=>selector(api.getInitialState())
    }["useStore.useSyncExternalStore[slice]"], [
        api,
        selector
    ]));
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useDebugValue(slice);
    return slice;
}
const createImpl = (createState)=>{
    const api = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$vanilla$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createStore"])(createState);
    const useBoundStore = (selector)=>useStore(api, selector);
    Object.assign(useBoundStore, api);
    return useBoundStore;
};
const create = (createState)=>createState ? createImpl(createState) : createImpl;
;
}),
"[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "combine",
    ()=>combine,
    "createJSONStorage",
    ()=>createJSONStorage,
    "devtools",
    ()=>devtools,
    "persist",
    ()=>persist,
    "redux",
    ()=>redux,
    "subscribeWithSelector",
    ()=>subscribeWithSelector
]);
const __TURBOPACK__import$2e$meta__ = {
    get url () {
        return `file://${__turbopack_context__.P("node_modules/zustand/esm/middleware.mjs")}`;
    }
};
const reduxImpl = (reducer, initial)=>(set, _get, api)=>{
        api.dispatch = (action)=>{
            set((state)=>reducer(state, action), false, action);
            return action;
        };
        api.dispatchFromDevtools = true;
        return {
            dispatch: (...args)=>api.dispatch(...args),
            ...initial
        };
    };
const redux = reduxImpl;
const trackedConnections = /* @__PURE__ */ new Map();
const getTrackedConnectionState = (name)=>{
    const api = trackedConnections.get(name);
    if (!api) return {};
    return Object.fromEntries(Object.entries(api.stores).map(([key, api2])=>[
            key,
            api2.getState()
        ]));
};
const extractConnectionInformation = (store, extensionConnector, options)=>{
    if (store === void 0) {
        return {
            type: "untracked",
            connection: extensionConnector.connect(options)
        };
    }
    const existingConnection = trackedConnections.get(options.name);
    if (existingConnection) {
        return {
            type: "tracked",
            store,
            ...existingConnection
        };
    }
    const newConnection = {
        connection: extensionConnector.connect(options),
        stores: {}
    };
    trackedConnections.set(options.name, newConnection);
    return {
        type: "tracked",
        store,
        ...newConnection
    };
};
const removeStoreFromTrackedConnections = (name, store)=>{
    if (store === void 0) return;
    const connectionInfo = trackedConnections.get(name);
    if (!connectionInfo) return;
    delete connectionInfo.stores[store];
    if (Object.keys(connectionInfo.stores).length === 0) {
        trackedConnections.delete(name);
    }
};
const findCallerName = (stack)=>{
    var _a, _b;
    if (!stack) return void 0;
    const traceLines = stack.split("\n");
    const apiSetStateLineIndex = traceLines.findIndex((traceLine)=>traceLine.includes("api.setState"));
    if (apiSetStateLineIndex < 0) return void 0;
    const callerLine = ((_a = traceLines[apiSetStateLineIndex + 1]) == null ? void 0 : _a.trim()) || "";
    return (_b = /.+ (.+) .+/.exec(callerLine)) == null ? void 0 : _b[1];
};
const devtoolsImpl = (fn, devtoolsOptions = {})=>(set, get, api)=>{
        const { enabled, anonymousActionType, store, ...options } = devtoolsOptions;
        let extensionConnector;
        try {
            extensionConnector = (enabled != null ? enabled : (__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production") && window.__REDUX_DEVTOOLS_EXTENSION__;
        } catch (e) {}
        if (!extensionConnector) {
            return fn(set, get, api);
        }
        const { connection, ...connectionInformation } = extractConnectionInformation(store, extensionConnector, options);
        let isRecording = true;
        api.setState = (state, replace, nameOrAction)=>{
            const r = set(state, replace);
            if (!isRecording) return r;
            const action = nameOrAction === void 0 ? {
                type: anonymousActionType || findCallerName(new Error().stack) || "anonymous"
            } : typeof nameOrAction === "string" ? {
                type: nameOrAction
            } : nameOrAction;
            if (store === void 0) {
                connection == null ? void 0 : connection.send(action, get());
                return r;
            }
            connection == null ? void 0 : connection.send({
                ...action,
                type: `${store}/${action.type}`
            }, {
                ...getTrackedConnectionState(options.name),
                [store]: api.getState()
            });
            return r;
        };
        api.devtools = {
            cleanup: ()=>{
                if (connection && typeof connection.unsubscribe === "function") {
                    connection.unsubscribe();
                }
                removeStoreFromTrackedConnections(options.name, store);
            }
        };
        const setStateFromDevtools = (...a)=>{
            const originalIsRecording = isRecording;
            isRecording = false;
            set(...a);
            isRecording = originalIsRecording;
        };
        const initialState = fn(api.setState, get, api);
        if (connectionInformation.type === "untracked") {
            connection == null ? void 0 : connection.init(initialState);
        } else {
            connectionInformation.stores[connectionInformation.store] = api;
            connection == null ? void 0 : connection.init(Object.fromEntries(Object.entries(connectionInformation.stores).map(([key, store2])=>[
                    key,
                    key === connectionInformation.store ? initialState : store2.getState()
                ])));
        }
        if (api.dispatchFromDevtools && typeof api.dispatch === "function") {
            let didWarnAboutReservedActionType = false;
            const originalDispatch = api.dispatch;
            api.dispatch = (...args)=>{
                if ((__TURBOPACK__import$2e$meta__.env ? __TURBOPACK__import$2e$meta__.env.MODE : void 0) !== "production" && args[0].type === "__setState" && !didWarnAboutReservedActionType) {
                    console.warn('[zustand devtools middleware] "__setState" action type is reserved to set state from the devtools. Avoid using it.');
                    didWarnAboutReservedActionType = true;
                }
                originalDispatch(...args);
            };
        }
        connection.subscribe((message)=>{
            var _a;
            switch(message.type){
                case "ACTION":
                    if (typeof message.payload !== "string") {
                        console.error("[zustand devtools middleware] Unsupported action format");
                        return;
                    }
                    return parseJsonThen(message.payload, (action)=>{
                        if (action.type === "__setState") {
                            if (store === void 0) {
                                setStateFromDevtools(action.state);
                                return;
                            }
                            if (Object.keys(action.state).length !== 1) {
                                console.error(`
                    [zustand devtools middleware] Unsupported __setState action format.
                    When using 'store' option in devtools(), the 'state' should have only one key, which is a value of 'store' that was passed in devtools(),
                    and value of this only key should be a state object. Example: { "type": "__setState", "state": { "abc123Store": { "foo": "bar" } } }
                    `);
                            }
                            const stateFromDevtools = action.state[store];
                            if (stateFromDevtools === void 0 || stateFromDevtools === null) {
                                return;
                            }
                            if (JSON.stringify(api.getState()) !== JSON.stringify(stateFromDevtools)) {
                                setStateFromDevtools(stateFromDevtools);
                            }
                            return;
                        }
                        if (!api.dispatchFromDevtools) return;
                        if (typeof api.dispatch !== "function") return;
                        api.dispatch(action);
                    });
                case "DISPATCH":
                    switch(message.payload.type){
                        case "RESET":
                            setStateFromDevtools(initialState);
                            if (store === void 0) {
                                return connection == null ? void 0 : connection.init(api.getState());
                            }
                            return connection == null ? void 0 : connection.init(getTrackedConnectionState(options.name));
                        case "COMMIT":
                            if (store === void 0) {
                                connection == null ? void 0 : connection.init(api.getState());
                                return;
                            }
                            return connection == null ? void 0 : connection.init(getTrackedConnectionState(options.name));
                        case "ROLLBACK":
                            return parseJsonThen(message.state, (state)=>{
                                if (store === void 0) {
                                    setStateFromDevtools(state);
                                    connection == null ? void 0 : connection.init(api.getState());
                                    return;
                                }
                                setStateFromDevtools(state[store]);
                                connection == null ? void 0 : connection.init(getTrackedConnectionState(options.name));
                            });
                        case "JUMP_TO_STATE":
                        case "JUMP_TO_ACTION":
                            return parseJsonThen(message.state, (state)=>{
                                if (store === void 0) {
                                    setStateFromDevtools(state);
                                    return;
                                }
                                if (JSON.stringify(api.getState()) !== JSON.stringify(state[store])) {
                                    setStateFromDevtools(state[store]);
                                }
                            });
                        case "IMPORT_STATE":
                            {
                                const { nextLiftedState } = message.payload;
                                const lastComputedState = (_a = nextLiftedState.computedStates.slice(-1)[0]) == null ? void 0 : _a.state;
                                if (!lastComputedState) return;
                                if (store === void 0) {
                                    setStateFromDevtools(lastComputedState);
                                } else {
                                    setStateFromDevtools(lastComputedState[store]);
                                }
                                connection == null ? void 0 : connection.send(null, // FIXME no-any
                                nextLiftedState);
                                return;
                            }
                        case "PAUSE_RECORDING":
                            return isRecording = !isRecording;
                    }
                    return;
            }
        });
        return initialState;
    };
const devtools = devtoolsImpl;
const parseJsonThen = (stringified, fn)=>{
    let parsed;
    try {
        parsed = JSON.parse(stringified);
    } catch (e) {
        console.error("[zustand devtools middleware] Could not parse the received json", e);
    }
    if (parsed !== void 0) fn(parsed);
};
const subscribeWithSelectorImpl = (fn)=>(set, get, api)=>{
        const origSubscribe = api.subscribe;
        api.subscribe = (selector, optListener, options)=>{
            let listener = selector;
            if (optListener) {
                const equalityFn = (options == null ? void 0 : options.equalityFn) || Object.is;
                let currentSlice = selector(api.getState());
                listener = (state)=>{
                    const nextSlice = selector(state);
                    if (!equalityFn(currentSlice, nextSlice)) {
                        const previousSlice = currentSlice;
                        optListener(currentSlice = nextSlice, previousSlice);
                    }
                };
                if (options == null ? void 0 : options.fireImmediately) {
                    optListener(currentSlice, currentSlice);
                }
            }
            return origSubscribe(listener);
        };
        const initialState = fn(set, get, api);
        return initialState;
    };
const subscribeWithSelector = subscribeWithSelectorImpl;
function combine(initialState, create) {
    return (...args)=>Object.assign({}, initialState, create(...args));
}
function createJSONStorage(getStorage, options) {
    let storage;
    try {
        storage = getStorage();
    } catch (e) {
        return;
    }
    const persistStorage = {
        getItem: (name)=>{
            var _a;
            const parse = (str2)=>{
                if (str2 === null) {
                    return null;
                }
                return JSON.parse(str2, options == null ? void 0 : options.reviver);
            };
            const str = (_a = storage.getItem(name)) != null ? _a : null;
            if (str instanceof Promise) {
                return str.then(parse);
            }
            return parse(str);
        },
        setItem: (name, newValue)=>storage.setItem(name, JSON.stringify(newValue, options == null ? void 0 : options.replacer)),
        removeItem: (name)=>storage.removeItem(name)
    };
    return persistStorage;
}
const toThenable = (fn)=>(input)=>{
        try {
            const result = fn(input);
            if (result instanceof Promise) {
                return result;
            }
            return {
                then (onFulfilled) {
                    return toThenable(onFulfilled)(result);
                },
                catch (_onRejected) {
                    return this;
                }
            };
        } catch (e) {
            return {
                then (_onFulfilled) {
                    return this;
                },
                catch (onRejected) {
                    return toThenable(onRejected)(e);
                }
            };
        }
    };
const persistImpl = (config, baseOptions)=>(set, get, api)=>{
        let options = {
            storage: createJSONStorage(()=>localStorage),
            partialize: (state)=>state,
            version: 0,
            merge: (persistedState, currentState)=>({
                    ...currentState,
                    ...persistedState
                }),
            ...baseOptions
        };
        let hasHydrated = false;
        const hydrationListeners = /* @__PURE__ */ new Set();
        const finishHydrationListeners = /* @__PURE__ */ new Set();
        let storage = options.storage;
        if (!storage) {
            return config((...args)=>{
                console.warn(`[zustand persist middleware] Unable to update item '${options.name}', the given storage is currently unavailable.`);
                set(...args);
            }, get, api);
        }
        const setItem = ()=>{
            const state = options.partialize({
                ...get()
            });
            return storage.setItem(options.name, {
                state,
                version: options.version
            });
        };
        const savedSetState = api.setState;
        api.setState = (state, replace)=>{
            savedSetState(state, replace);
            return setItem();
        };
        const configResult = config((...args)=>{
            set(...args);
            return setItem();
        }, get, api);
        api.getInitialState = ()=>configResult;
        let stateFromStorage;
        const hydrate = ()=>{
            var _a, _b;
            if (!storage) return;
            hasHydrated = false;
            hydrationListeners.forEach((cb)=>{
                var _a2;
                return cb((_a2 = get()) != null ? _a2 : configResult);
            });
            const postRehydrationCallback = ((_b = options.onRehydrateStorage) == null ? void 0 : _b.call(options, (_a = get()) != null ? _a : configResult)) || void 0;
            return toThenable(storage.getItem.bind(storage))(options.name).then((deserializedStorageValue)=>{
                if (deserializedStorageValue) {
                    if (typeof deserializedStorageValue.version === "number" && deserializedStorageValue.version !== options.version) {
                        if (options.migrate) {
                            const migration = options.migrate(deserializedStorageValue.state, deserializedStorageValue.version);
                            if (migration instanceof Promise) {
                                return migration.then((result)=>[
                                        true,
                                        result
                                    ]);
                            }
                            return [
                                true,
                                migration
                            ];
                        }
                        console.error(`State loaded from storage couldn't be migrated since no migrate function was provided`);
                    } else {
                        return [
                            false,
                            deserializedStorageValue.state
                        ];
                    }
                }
                return [
                    false,
                    void 0
                ];
            }).then((migrationResult)=>{
                var _a2;
                const [migrated, migratedState] = migrationResult;
                stateFromStorage = options.merge(migratedState, (_a2 = get()) != null ? _a2 : configResult);
                set(stateFromStorage, true);
                if (migrated) {
                    return setItem();
                }
            }).then(()=>{
                postRehydrationCallback == null ? void 0 : postRehydrationCallback(stateFromStorage, void 0);
                stateFromStorage = get();
                hasHydrated = true;
                finishHydrationListeners.forEach((cb)=>cb(stateFromStorage));
            }).catch((e)=>{
                postRehydrationCallback == null ? void 0 : postRehydrationCallback(void 0, e);
            });
        };
        api.persist = {
            setOptions: (newOptions)=>{
                options = {
                    ...options,
                    ...newOptions
                };
                if (newOptions.storage) {
                    storage = newOptions.storage;
                }
            },
            clearStorage: ()=>{
                storage == null ? void 0 : storage.removeItem(options.name);
            },
            getOptions: ()=>options,
            rehydrate: ()=>hydrate(),
            hasHydrated: ()=>hasHydrated,
            onHydrate: (cb)=>{
                hydrationListeners.add(cb);
                return ()=>{
                    hydrationListeners.delete(cb);
                };
            },
            onFinishHydration: (cb)=>{
                finishHydrationListeners.add(cb);
                return ()=>{
                    finishHydrationListeners.delete(cb);
                };
            }
        };
        if (!options.skipHydration) {
            hydrate();
        }
        return stateFromStorage || configResult;
    };
const persist = persistImpl;
;
}),
"[project]/node_modules/zustand/esm/middleware/immer.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "immer",
    ()=>immer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)");
;
const immerImpl = (initializer)=>(set, get, store)=>{
        store.setState = (updater, replace, ...args)=>{
            const nextState = typeof updater === "function" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$immer$2f$dist$2f$immer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["produce"])(updater) : updater;
            return set(nextState, replace, ...args);
        };
        return initializer(store.setState, get, store);
    };
const immer = immerImpl;
;
}),
"[project]/node_modules/immer/dist/immer.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Immer",
    ()=>Immer2,
    "applyPatches",
    ()=>applyPatches,
    "castDraft",
    ()=>castDraft,
    "castImmutable",
    ()=>castImmutable,
    "createDraft",
    ()=>createDraft,
    "current",
    ()=>current,
    "enableMapSet",
    ()=>enableMapSet,
    "enablePatches",
    ()=>enablePatches,
    "finishDraft",
    ()=>finishDraft,
    "freeze",
    ()=>freeze,
    "immerable",
    ()=>DRAFTABLE,
    "isDraft",
    ()=>isDraft,
    "isDraftable",
    ()=>isDraftable,
    "nothing",
    ()=>NOTHING,
    "original",
    ()=>original,
    "produce",
    ()=>produce,
    "produceWithPatches",
    ()=>produceWithPatches,
    "setAutoFreeze",
    ()=>setAutoFreeze,
    "setUseStrictIteration",
    ()=>setUseStrictIteration,
    "setUseStrictShallowCopy",
    ()=>setUseStrictShallowCopy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
// src/utils/env.ts
var NOTHING = Symbol.for("immer-nothing");
var DRAFTABLE = Symbol.for("immer-draftable");
var DRAFT_STATE = Symbol.for("immer-state");
// src/utils/errors.ts
var errors = ("TURBOPACK compile-time truthy", 1) ? [
    // All error codes, starting by 0:
    function(plugin) {
        return `The plugin for '${plugin}' has not been loaded into Immer. To enable the plugin, import and call \`enable${plugin}()\` when initializing your application.`;
    },
    function(thing) {
        return `produce can only be called on things that are draftable: plain objects, arrays, Map, Set or classes that are marked with '[immerable]: true'. Got '${thing}'`;
    },
    "This object has been frozen and should not be mutated",
    function(data) {
        return "Cannot use a proxy that has been revoked. Did you pass an object from inside an immer function to an async process? " + data;
    },
    "An immer producer returned a new value *and* modified its draft. Either return a new value *or* modify the draft.",
    "Immer forbids circular references",
    "The first or second argument to `produce` must be a function",
    "The third argument to `produce` must be a function or undefined",
    "First argument to `createDraft` must be a plain object, an array, or an immerable object",
    "First argument to `finishDraft` must be a draft returned by `createDraft`",
    function(thing) {
        return `'current' expects a draft, got: ${thing}`;
    },
    "Object.defineProperty() cannot be used on an Immer draft",
    "Object.setPrototypeOf() cannot be used on an Immer draft",
    "Immer only supports deleting array indices",
    "Immer only supports setting array indices and the 'length' property",
    function(thing) {
        return `'original' expects a draft, got: ${thing}`;
    }
] : "TURBOPACK unreachable";
function die(error, ...args) {
    if ("TURBOPACK compile-time truthy", 1) {
        const e = errors[error];
        const msg = typeof e === "function" ? e.apply(null, args) : e;
        throw new Error(`[Immer] ${msg}`);
    }
    throw new Error(`[Immer] minified error nr: ${error}. Full error at: https://bit.ly/3cXEKWf`);
}
// src/utils/common.ts
var getPrototypeOf = Object.getPrototypeOf;
function isDraft(value) {
    return !!value && !!value[DRAFT_STATE];
}
function isDraftable(value) {
    if (!value) return false;
    return isPlainObject(value) || Array.isArray(value) || !!value[DRAFTABLE] || !!value.constructor?.[DRAFTABLE] || isMap(value) || isSet(value);
}
var objectCtorString = Object.prototype.constructor.toString();
var cachedCtorStrings = /* @__PURE__ */ new WeakMap();
function isPlainObject(value) {
    if (!value || typeof value !== "object") return false;
    const proto = Object.getPrototypeOf(value);
    if (proto === null || proto === Object.prototype) return true;
    const Ctor = Object.hasOwnProperty.call(proto, "constructor") && proto.constructor;
    if (Ctor === Object) return true;
    if (typeof Ctor !== "function") return false;
    let ctorString = cachedCtorStrings.get(Ctor);
    if (ctorString === void 0) {
        ctorString = Function.toString.call(Ctor);
        cachedCtorStrings.set(Ctor, ctorString);
    }
    return ctorString === objectCtorString;
}
function original(value) {
    if (!isDraft(value)) die(15, value);
    return value[DRAFT_STATE].base_;
}
function each(obj, iter, strict = true) {
    if (getArchtype(obj) === 0 /* Object */ ) {
        const keys = strict ? Reflect.ownKeys(obj) : Object.keys(obj);
        keys.forEach((key)=>{
            iter(key, obj[key], obj);
        });
    } else {
        obj.forEach((entry, index)=>iter(index, entry, obj));
    }
}
function getArchtype(thing) {
    const state = thing[DRAFT_STATE];
    return state ? state.type_ : Array.isArray(thing) ? 1 /* Array */  : isMap(thing) ? 2 /* Map */  : isSet(thing) ? 3 /* Set */  : 0 /* Object */ ;
}
function has(thing, prop) {
    return getArchtype(thing) === 2 /* Map */  ? thing.has(prop) : Object.prototype.hasOwnProperty.call(thing, prop);
}
function get(thing, prop) {
    return getArchtype(thing) === 2 /* Map */  ? thing.get(prop) : thing[prop];
}
function set(thing, propOrOldValue, value) {
    const t = getArchtype(thing);
    if (t === 2 /* Map */ ) thing.set(propOrOldValue, value);
    else if (t === 3 /* Set */ ) {
        thing.add(value);
    } else thing[propOrOldValue] = value;
}
function is(x, y) {
    if (x === y) {
        return x !== 0 || 1 / x === 1 / y;
    } else {
        return x !== x && y !== y;
    }
}
function isMap(target) {
    return target instanceof Map;
}
function isSet(target) {
    return target instanceof Set;
}
function latest(state) {
    return state.copy_ || state.base_;
}
function shallowCopy(base, strict) {
    if (isMap(base)) {
        return new Map(base);
    }
    if (isSet(base)) {
        return new Set(base);
    }
    if (Array.isArray(base)) return Array.prototype.slice.call(base);
    const isPlain = isPlainObject(base);
    if (strict === true || strict === "class_only" && !isPlain) {
        const descriptors = Object.getOwnPropertyDescriptors(base);
        delete descriptors[DRAFT_STATE];
        let keys = Reflect.ownKeys(descriptors);
        for(let i = 0; i < keys.length; i++){
            const key = keys[i];
            const desc = descriptors[key];
            if (desc.writable === false) {
                desc.writable = true;
                desc.configurable = true;
            }
            if (desc.get || desc.set) descriptors[key] = {
                configurable: true,
                writable: true,
                // could live with !!desc.set as well here...
                enumerable: desc.enumerable,
                value: base[key]
            };
        }
        return Object.create(getPrototypeOf(base), descriptors);
    } else {
        const proto = getPrototypeOf(base);
        if (proto !== null && isPlain) {
            return {
                ...base
            };
        }
        const obj = Object.create(proto);
        return Object.assign(obj, base);
    }
}
function freeze(obj, deep = false) {
    if (isFrozen(obj) || isDraft(obj) || !isDraftable(obj)) return obj;
    if (getArchtype(obj) > 1) {
        Object.defineProperties(obj, {
            set: dontMutateMethodOverride,
            add: dontMutateMethodOverride,
            clear: dontMutateMethodOverride,
            delete: dontMutateMethodOverride
        });
    }
    Object.freeze(obj);
    if (deep) Object.values(obj).forEach((value)=>freeze(value, true));
    return obj;
}
function dontMutateFrozenCollections() {
    die(2);
}
var dontMutateMethodOverride = {
    value: dontMutateFrozenCollections
};
function isFrozen(obj) {
    if (obj === null || typeof obj !== "object") return true;
    return Object.isFrozen(obj);
}
// src/utils/plugins.ts
var plugins = {};
function getPlugin(pluginKey) {
    const plugin = plugins[pluginKey];
    if (!plugin) {
        die(0, pluginKey);
    }
    return plugin;
}
function loadPlugin(pluginKey, implementation) {
    if (!plugins[pluginKey]) plugins[pluginKey] = implementation;
}
// src/core/scope.ts
var currentScope;
function getCurrentScope() {
    return currentScope;
}
function createScope(parent_, immer_) {
    return {
        drafts_: [],
        parent_,
        immer_,
        // Whenever the modified draft contains a draft from another scope, we
        // need to prevent auto-freezing so the unowned draft can be finalized.
        canAutoFreeze_: true,
        unfinalizedDrafts_: 0
    };
}
function usePatchesInScope(scope, patchListener) {
    if (patchListener) {
        getPlugin("Patches");
        scope.patches_ = [];
        scope.inversePatches_ = [];
        scope.patchListener_ = patchListener;
    }
}
function revokeScope(scope) {
    leaveScope(scope);
    scope.drafts_.forEach(revokeDraft);
    scope.drafts_ = null;
}
function leaveScope(scope) {
    if (scope === currentScope) {
        currentScope = scope.parent_;
    }
}
function enterScope(immer2) {
    return currentScope = createScope(currentScope, immer2);
}
function revokeDraft(draft) {
    const state = draft[DRAFT_STATE];
    if (state.type_ === 0 /* Object */  || state.type_ === 1 /* Array */ ) state.revoke_();
    else state.revoked_ = true;
}
// src/core/finalize.ts
function processResult(result, scope) {
    scope.unfinalizedDrafts_ = scope.drafts_.length;
    const baseDraft = scope.drafts_[0];
    const isReplaced = result !== void 0 && result !== baseDraft;
    if (isReplaced) {
        if (baseDraft[DRAFT_STATE].modified_) {
            revokeScope(scope);
            die(4);
        }
        if (isDraftable(result)) {
            result = finalize(scope, result);
            if (!scope.parent_) maybeFreeze(scope, result);
        }
        if (scope.patches_) {
            getPlugin("Patches").generateReplacementPatches_(baseDraft[DRAFT_STATE].base_, result, scope.patches_, scope.inversePatches_);
        }
    } else {
        result = finalize(scope, baseDraft, []);
    }
    revokeScope(scope);
    if (scope.patches_) {
        scope.patchListener_(scope.patches_, scope.inversePatches_);
    }
    return result !== NOTHING ? result : void 0;
}
function finalize(rootScope, value, path) {
    if (isFrozen(value)) return value;
    const useStrictIteration = rootScope.immer_.shouldUseStrictIteration();
    const state = value[DRAFT_STATE];
    if (!state) {
        each(value, (key, childValue)=>finalizeProperty(rootScope, state, value, key, childValue, path), useStrictIteration);
        return value;
    }
    if (state.scope_ !== rootScope) return value;
    if (!state.modified_) {
        maybeFreeze(rootScope, state.base_, true);
        return state.base_;
    }
    if (!state.finalized_) {
        state.finalized_ = true;
        state.scope_.unfinalizedDrafts_--;
        const result = state.copy_;
        let resultEach = result;
        let isSet2 = false;
        if (state.type_ === 3 /* Set */ ) {
            resultEach = new Set(result);
            result.clear();
            isSet2 = true;
        }
        each(resultEach, (key, childValue)=>finalizeProperty(rootScope, state, result, key, childValue, path, isSet2), useStrictIteration);
        maybeFreeze(rootScope, result, false);
        if (path && rootScope.patches_) {
            getPlugin("Patches").generatePatches_(state, path, rootScope.patches_, rootScope.inversePatches_);
        }
    }
    return state.copy_;
}
function finalizeProperty(rootScope, parentState, targetObject, prop, childValue, rootPath, targetIsSet) {
    if (childValue == null) {
        return;
    }
    if (typeof childValue !== "object" && !targetIsSet) {
        return;
    }
    const childIsFrozen = isFrozen(childValue);
    if (childIsFrozen && !targetIsSet) {
        return;
    }
    if (("TURBOPACK compile-time value", "development") !== "production" && childValue === targetObject) die(5);
    if (isDraft(childValue)) {
        const path = rootPath && parentState && parentState.type_ !== 3 /* Set */  && // Set objects are atomic since they have no keys.
        !has(parentState.assigned_, prop) ? rootPath.concat(prop) : void 0;
        const res = finalize(rootScope, childValue, path);
        set(targetObject, prop, res);
        if (isDraft(res)) {
            rootScope.canAutoFreeze_ = false;
        } else return;
    } else if (targetIsSet) {
        targetObject.add(childValue);
    }
    if (isDraftable(childValue) && !childIsFrozen) {
        if (!rootScope.immer_.autoFreeze_ && rootScope.unfinalizedDrafts_ < 1) {
            return;
        }
        if (parentState && parentState.base_ && parentState.base_[prop] === childValue && childIsFrozen) {
            return;
        }
        finalize(rootScope, childValue);
        if ((!parentState || !parentState.scope_.parent_) && typeof prop !== "symbol" && (isMap(targetObject) ? targetObject.has(prop) : Object.prototype.propertyIsEnumerable.call(targetObject, prop))) maybeFreeze(rootScope, childValue);
    }
}
function maybeFreeze(scope, value, deep = false) {
    if (!scope.parent_ && scope.immer_.autoFreeze_ && scope.canAutoFreeze_) {
        freeze(value, deep);
    }
}
// src/core/proxy.ts
function createProxyProxy(base, parent) {
    const isArray = Array.isArray(base);
    const state = {
        type_: isArray ? 1 /* Array */  : 0 /* Object */ ,
        // Track which produce call this is associated with.
        scope_: parent ? parent.scope_ : getCurrentScope(),
        // True for both shallow and deep changes.
        modified_: false,
        // Used during finalization.
        finalized_: false,
        // Track which properties have been assigned (true) or deleted (false).
        assigned_: {},
        // The parent draft state.
        parent_: parent,
        // The base state.
        base_: base,
        // The base proxy.
        draft_: null,
        // set below
        // The base copy with any updated values.
        copy_: null,
        // Called by the `produce` function.
        revoke_: null,
        isManual_: false
    };
    let target = state;
    let traps = objectTraps;
    if (isArray) {
        target = [
            state
        ];
        traps = arrayTraps;
    }
    const { revoke, proxy } = Proxy.revocable(target, traps);
    state.draft_ = proxy;
    state.revoke_ = revoke;
    return proxy;
}
var objectTraps = {
    get (state, prop) {
        if (prop === DRAFT_STATE) return state;
        const source = latest(state);
        if (!has(source, prop)) {
            return readPropFromProto(state, source, prop);
        }
        const value = source[prop];
        if (state.finalized_ || !isDraftable(value)) {
            return value;
        }
        if (value === peek(state.base_, prop)) {
            prepareCopy(state);
            return state.copy_[prop] = createProxy(value, state);
        }
        return value;
    },
    has (state, prop) {
        return prop in latest(state);
    },
    ownKeys (state) {
        return Reflect.ownKeys(latest(state));
    },
    set (state, prop, value) {
        const desc = getDescriptorFromProto(latest(state), prop);
        if (desc?.set) {
            desc.set.call(state.draft_, value);
            return true;
        }
        if (!state.modified_) {
            const current2 = peek(latest(state), prop);
            const currentState = current2?.[DRAFT_STATE];
            if (currentState && currentState.base_ === value) {
                state.copy_[prop] = value;
                state.assigned_[prop] = false;
                return true;
            }
            if (is(value, current2) && (value !== void 0 || has(state.base_, prop))) return true;
            prepareCopy(state);
            markChanged(state);
        }
        if (state.copy_[prop] === value && // special case: handle new props with value 'undefined'
        (value !== void 0 || prop in state.copy_) || // special case: NaN
        Number.isNaN(value) && Number.isNaN(state.copy_[prop])) return true;
        state.copy_[prop] = value;
        state.assigned_[prop] = true;
        return true;
    },
    deleteProperty (state, prop) {
        if (peek(state.base_, prop) !== void 0 || prop in state.base_) {
            state.assigned_[prop] = false;
            prepareCopy(state);
            markChanged(state);
        } else {
            delete state.assigned_[prop];
        }
        if (state.copy_) {
            delete state.copy_[prop];
        }
        return true;
    },
    // Note: We never coerce `desc.value` into an Immer draft, because we can't make
    // the same guarantee in ES5 mode.
    getOwnPropertyDescriptor (state, prop) {
        const owner = latest(state);
        const desc = Reflect.getOwnPropertyDescriptor(owner, prop);
        if (!desc) return desc;
        return {
            writable: true,
            configurable: state.type_ !== 1 /* Array */  || prop !== "length",
            enumerable: desc.enumerable,
            value: owner[prop]
        };
    },
    defineProperty () {
        die(11);
    },
    getPrototypeOf (state) {
        return getPrototypeOf(state.base_);
    },
    setPrototypeOf () {
        die(12);
    }
};
var arrayTraps = {};
each(objectTraps, (key, fn)=>{
    arrayTraps[key] = function() {
        arguments[0] = arguments[0][0];
        return fn.apply(this, arguments);
    };
});
arrayTraps.deleteProperty = function(state, prop) {
    if (("TURBOPACK compile-time value", "development") !== "production" && isNaN(parseInt(prop))) die(13);
    return arrayTraps.set.call(this, state, prop, void 0);
};
arrayTraps.set = function(state, prop, value) {
    if (("TURBOPACK compile-time value", "development") !== "production" && prop !== "length" && isNaN(parseInt(prop))) die(14);
    return objectTraps.set.call(this, state[0], prop, value, state[0]);
};
function peek(draft, prop) {
    const state = draft[DRAFT_STATE];
    const source = state ? latest(state) : draft;
    return source[prop];
}
function readPropFromProto(state, source, prop) {
    const desc = getDescriptorFromProto(source, prop);
    return desc ? `value` in desc ? desc.value : // This is a very special case, if the prop is a getter defined by the
    // prototype, we should invoke it with the draft as context!
    desc.get?.call(state.draft_) : void 0;
}
function getDescriptorFromProto(source, prop) {
    if (!(prop in source)) return void 0;
    let proto = getPrototypeOf(source);
    while(proto){
        const desc = Object.getOwnPropertyDescriptor(proto, prop);
        if (desc) return desc;
        proto = getPrototypeOf(proto);
    }
    return void 0;
}
function markChanged(state) {
    if (!state.modified_) {
        state.modified_ = true;
        if (state.parent_) {
            markChanged(state.parent_);
        }
    }
}
function prepareCopy(state) {
    if (!state.copy_) {
        state.copy_ = shallowCopy(state.base_, state.scope_.immer_.useStrictShallowCopy_);
    }
}
// src/core/immerClass.ts
var Immer2 = class {
    constructor(config){
        this.autoFreeze_ = true;
        this.useStrictShallowCopy_ = false;
        this.useStrictIteration_ = true;
        /**
     * The `produce` function takes a value and a "recipe function" (whose
     * return value often depends on the base state). The recipe function is
     * free to mutate its first argument however it wants. All mutations are
     * only ever applied to a __copy__ of the base state.
     *
     * Pass only a function to create a "curried producer" which relieves you
     * from passing the recipe function every time.
     *
     * Only plain objects and arrays are made mutable. All other objects are
     * considered uncopyable.
     *
     * Note: This function is __bound__ to its `Immer` instance.
     *
     * @param {any} base - the initial state
     * @param {Function} recipe - function that receives a proxy of the base state as first argument and which can be freely modified
     * @param {Function} patchListener - optional function that will be called with all the patches produced here
     * @returns {any} a new state, or the initial state if nothing was modified
     */ this.produce = (base, recipe, patchListener)=>{
            if (typeof base === "function" && typeof recipe !== "function") {
                const defaultBase = recipe;
                recipe = base;
                const self = this;
                return function curriedProduce(base2 = defaultBase, ...args) {
                    return self.produce(base2, (draft)=>recipe.call(this, draft, ...args));
                };
            }
            if (typeof recipe !== "function") die(6);
            if (patchListener !== void 0 && typeof patchListener !== "function") die(7);
            let result;
            if (isDraftable(base)) {
                const scope = enterScope(this);
                const proxy = createProxy(base, void 0);
                let hasError = true;
                try {
                    result = recipe(proxy);
                    hasError = false;
                } finally{
                    if (hasError) revokeScope(scope);
                    else leaveScope(scope);
                }
                usePatchesInScope(scope, patchListener);
                return processResult(result, scope);
            } else if (!base || typeof base !== "object") {
                result = recipe(base);
                if (result === void 0) result = base;
                if (result === NOTHING) result = void 0;
                if (this.autoFreeze_) freeze(result, true);
                if (patchListener) {
                    const p = [];
                    const ip = [];
                    getPlugin("Patches").generateReplacementPatches_(base, result, p, ip);
                    patchListener(p, ip);
                }
                return result;
            } else die(1, base);
        };
        this.produceWithPatches = (base, recipe)=>{
            if (typeof base === "function") {
                return (state, ...args)=>this.produceWithPatches(state, (draft)=>base(draft, ...args));
            }
            let patches, inversePatches;
            const result = this.produce(base, recipe, (p, ip)=>{
                patches = p;
                inversePatches = ip;
            });
            return [
                result,
                patches,
                inversePatches
            ];
        };
        if (typeof config?.autoFreeze === "boolean") this.setAutoFreeze(config.autoFreeze);
        if (typeof config?.useStrictShallowCopy === "boolean") this.setUseStrictShallowCopy(config.useStrictShallowCopy);
        if (typeof config?.useStrictIteration === "boolean") this.setUseStrictIteration(config.useStrictIteration);
    }
    createDraft(base) {
        if (!isDraftable(base)) die(8);
        if (isDraft(base)) base = current(base);
        const scope = enterScope(this);
        const proxy = createProxy(base, void 0);
        proxy[DRAFT_STATE].isManual_ = true;
        leaveScope(scope);
        return proxy;
    }
    finishDraft(draft, patchListener) {
        const state = draft && draft[DRAFT_STATE];
        if (!state || !state.isManual_) die(9);
        const { scope_: scope } = state;
        usePatchesInScope(scope, patchListener);
        return processResult(void 0, scope);
    }
    /**
   * Pass true to automatically freeze all copies created by Immer.
   *
   * By default, auto-freezing is enabled.
   */ setAutoFreeze(value) {
        this.autoFreeze_ = value;
    }
    /**
   * Pass true to enable strict shallow copy.
   *
   * By default, immer does not copy the object descriptors such as getter, setter and non-enumrable properties.
   */ setUseStrictShallowCopy(value) {
        this.useStrictShallowCopy_ = value;
    }
    /**
   * Pass false to use faster iteration that skips non-enumerable properties
   * but still handles symbols for compatibility.
   *
   * By default, strict iteration is enabled (includes all own properties).
   */ setUseStrictIteration(value) {
        this.useStrictIteration_ = value;
    }
    shouldUseStrictIteration() {
        return this.useStrictIteration_;
    }
    applyPatches(base, patches) {
        let i;
        for(i = patches.length - 1; i >= 0; i--){
            const patch = patches[i];
            if (patch.path.length === 0 && patch.op === "replace") {
                base = patch.value;
                break;
            }
        }
        if (i > -1) {
            patches = patches.slice(i + 1);
        }
        const applyPatchesImpl = getPlugin("Patches").applyPatches_;
        if (isDraft(base)) {
            return applyPatchesImpl(base, patches);
        }
        return this.produce(base, (draft)=>applyPatchesImpl(draft, patches));
    }
};
function createProxy(value, parent) {
    const draft = isMap(value) ? getPlugin("MapSet").proxyMap_(value, parent) : isSet(value) ? getPlugin("MapSet").proxySet_(value, parent) : createProxyProxy(value, parent);
    const scope = parent ? parent.scope_ : getCurrentScope();
    scope.drafts_.push(draft);
    return draft;
}
// src/core/current.ts
function current(value) {
    if (!isDraft(value)) die(10, value);
    return currentImpl(value);
}
function currentImpl(value) {
    if (!isDraftable(value) || isFrozen(value)) return value;
    const state = value[DRAFT_STATE];
    let copy;
    let strict = true;
    if (state) {
        if (!state.modified_) return state.base_;
        state.finalized_ = true;
        copy = shallowCopy(value, state.scope_.immer_.useStrictShallowCopy_);
        strict = state.scope_.immer_.shouldUseStrictIteration();
    } else {
        copy = shallowCopy(value, true);
    }
    each(copy, (key, childValue)=>{
        set(copy, key, currentImpl(childValue));
    }, strict);
    if (state) {
        state.finalized_ = false;
    }
    return copy;
}
// src/plugins/patches.ts
function enablePatches() {
    const errorOffset = 16;
    if ("TURBOPACK compile-time truthy", 1) {
        errors.push('Sets cannot have "replace" patches.', function(op) {
            return "Unsupported patch operation: " + op;
        }, function(path) {
            return "Cannot apply patch, path doesn't resolve: " + path;
        }, "Patching reserved attributes like __proto__, prototype and constructor is not allowed");
    }
    const REPLACE = "replace";
    const ADD = "add";
    const REMOVE = "remove";
    function generatePatches_(state, basePath, patches, inversePatches) {
        switch(state.type_){
            case 0 /* Object */ :
            case 2 /* Map */ :
                return generatePatchesFromAssigned(state, basePath, patches, inversePatches);
            case 1 /* Array */ :
                return generateArrayPatches(state, basePath, patches, inversePatches);
            case 3 /* Set */ :
                return generateSetPatches(state, basePath, patches, inversePatches);
        }
    }
    function generateArrayPatches(state, basePath, patches, inversePatches) {
        let { base_, assigned_ } = state;
        let copy_ = state.copy_;
        if (copy_.length < base_.length) {
            ;
            [base_, copy_] = [
                copy_,
                base_
            ];
            [patches, inversePatches] = [
                inversePatches,
                patches
            ];
        }
        for(let i = 0; i < base_.length; i++){
            if (assigned_[i] && copy_[i] !== base_[i]) {
                const path = basePath.concat([
                    i
                ]);
                patches.push({
                    op: REPLACE,
                    path,
                    // Need to maybe clone it, as it can in fact be the original value
                    // due to the base/copy inversion at the start of this function
                    value: clonePatchValueIfNeeded(copy_[i])
                });
                inversePatches.push({
                    op: REPLACE,
                    path,
                    value: clonePatchValueIfNeeded(base_[i])
                });
            }
        }
        for(let i = base_.length; i < copy_.length; i++){
            const path = basePath.concat([
                i
            ]);
            patches.push({
                op: ADD,
                path,
                // Need to maybe clone it, as it can in fact be the original value
                // due to the base/copy inversion at the start of this function
                value: clonePatchValueIfNeeded(copy_[i])
            });
        }
        for(let i = copy_.length - 1; base_.length <= i; --i){
            const path = basePath.concat([
                i
            ]);
            inversePatches.push({
                op: REMOVE,
                path
            });
        }
    }
    function generatePatchesFromAssigned(state, basePath, patches, inversePatches) {
        const { base_, copy_ } = state;
        each(state.assigned_, (key, assignedValue)=>{
            const origValue = get(base_, key);
            const value = get(copy_, key);
            const op = !assignedValue ? REMOVE : has(base_, key) ? REPLACE : ADD;
            if (origValue === value && op === REPLACE) return;
            const path = basePath.concat(key);
            patches.push(op === REMOVE ? {
                op,
                path
            } : {
                op,
                path,
                value
            });
            inversePatches.push(op === ADD ? {
                op: REMOVE,
                path
            } : op === REMOVE ? {
                op: ADD,
                path,
                value: clonePatchValueIfNeeded(origValue)
            } : {
                op: REPLACE,
                path,
                value: clonePatchValueIfNeeded(origValue)
            });
        });
    }
    function generateSetPatches(state, basePath, patches, inversePatches) {
        let { base_, copy_ } = state;
        let i = 0;
        base_.forEach((value)=>{
            if (!copy_.has(value)) {
                const path = basePath.concat([
                    i
                ]);
                patches.push({
                    op: REMOVE,
                    path,
                    value
                });
                inversePatches.unshift({
                    op: ADD,
                    path,
                    value
                });
            }
            i++;
        });
        i = 0;
        copy_.forEach((value)=>{
            if (!base_.has(value)) {
                const path = basePath.concat([
                    i
                ]);
                patches.push({
                    op: ADD,
                    path,
                    value
                });
                inversePatches.unshift({
                    op: REMOVE,
                    path,
                    value
                });
            }
            i++;
        });
    }
    function generateReplacementPatches_(baseValue, replacement, patches, inversePatches) {
        patches.push({
            op: REPLACE,
            path: [],
            value: replacement === NOTHING ? void 0 : replacement
        });
        inversePatches.push({
            op: REPLACE,
            path: [],
            value: baseValue
        });
    }
    function applyPatches_(draft, patches) {
        patches.forEach((patch)=>{
            const { path, op } = patch;
            let base = draft;
            for(let i = 0; i < path.length - 1; i++){
                const parentType = getArchtype(base);
                let p = path[i];
                if (typeof p !== "string" && typeof p !== "number") {
                    p = "" + p;
                }
                if ((parentType === 0 /* Object */  || parentType === 1 /* Array */ ) && (p === "__proto__" || p === "constructor")) die(errorOffset + 3);
                if (typeof base === "function" && p === "prototype") die(errorOffset + 3);
                base = get(base, p);
                if (typeof base !== "object") die(errorOffset + 2, path.join("/"));
            }
            const type = getArchtype(base);
            const value = deepClonePatchValue(patch.value);
            const key = path[path.length - 1];
            switch(op){
                case REPLACE:
                    switch(type){
                        case 2 /* Map */ :
                            return base.set(key, value);
                        case 3 /* Set */ :
                            die(errorOffset);
                        default:
                            return base[key] = value;
                    }
                case ADD:
                    switch(type){
                        case 1 /* Array */ :
                            return key === "-" ? base.push(value) : base.splice(key, 0, value);
                        case 2 /* Map */ :
                            return base.set(key, value);
                        case 3 /* Set */ :
                            return base.add(value);
                        default:
                            return base[key] = value;
                    }
                case REMOVE:
                    switch(type){
                        case 1 /* Array */ :
                            return base.splice(key, 1);
                        case 2 /* Map */ :
                            return base.delete(key);
                        case 3 /* Set */ :
                            return base.delete(patch.value);
                        default:
                            return delete base[key];
                    }
                default:
                    die(errorOffset + 1, op);
            }
        });
        return draft;
    }
    function deepClonePatchValue(obj) {
        if (!isDraftable(obj)) return obj;
        if (Array.isArray(obj)) return obj.map(deepClonePatchValue);
        if (isMap(obj)) return new Map(Array.from(obj.entries()).map(([k, v])=>[
                k,
                deepClonePatchValue(v)
            ]));
        if (isSet(obj)) return new Set(Array.from(obj).map(deepClonePatchValue));
        const cloned = Object.create(getPrototypeOf(obj));
        for(const key in obj)cloned[key] = deepClonePatchValue(obj[key]);
        if (has(obj, DRAFTABLE)) cloned[DRAFTABLE] = obj[DRAFTABLE];
        return cloned;
    }
    function clonePatchValueIfNeeded(obj) {
        if (isDraft(obj)) {
            return deepClonePatchValue(obj);
        } else return obj;
    }
    loadPlugin("Patches", {
        applyPatches_,
        generatePatches_,
        generateReplacementPatches_
    });
}
// src/plugins/mapset.ts
function enableMapSet() {
    class DraftMap extends Map {
        constructor(target, parent){
            super();
            this[DRAFT_STATE] = {
                type_: 2 /* Map */ ,
                parent_: parent,
                scope_: parent ? parent.scope_ : getCurrentScope(),
                modified_: false,
                finalized_: false,
                copy_: void 0,
                assigned_: void 0,
                base_: target,
                draft_: this,
                isManual_: false,
                revoked_: false
            };
        }
        get size() {
            return latest(this[DRAFT_STATE]).size;
        }
        has(key) {
            return latest(this[DRAFT_STATE]).has(key);
        }
        set(key, value) {
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            if (!latest(state).has(key) || latest(state).get(key) !== value) {
                prepareMapCopy(state);
                markChanged(state);
                state.assigned_.set(key, true);
                state.copy_.set(key, value);
                state.assigned_.set(key, true);
            }
            return this;
        }
        delete(key) {
            if (!this.has(key)) {
                return false;
            }
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            prepareMapCopy(state);
            markChanged(state);
            if (state.base_.has(key)) {
                state.assigned_.set(key, false);
            } else {
                state.assigned_.delete(key);
            }
            state.copy_.delete(key);
            return true;
        }
        clear() {
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            if (latest(state).size) {
                prepareMapCopy(state);
                markChanged(state);
                state.assigned_ = /* @__PURE__ */ new Map();
                each(state.base_, (key)=>{
                    state.assigned_.set(key, false);
                });
                state.copy_.clear();
            }
        }
        forEach(cb, thisArg) {
            const state = this[DRAFT_STATE];
            latest(state).forEach((_value, key, _map)=>{
                cb.call(thisArg, this.get(key), key, this);
            });
        }
        get(key) {
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            const value = latest(state).get(key);
            if (state.finalized_ || !isDraftable(value)) {
                return value;
            }
            if (value !== state.base_.get(key)) {
                return value;
            }
            const draft = createProxy(value, state);
            prepareMapCopy(state);
            state.copy_.set(key, draft);
            return draft;
        }
        keys() {
            return latest(this[DRAFT_STATE]).keys();
        }
        values() {
            const iterator = this.keys();
            return {
                [Symbol.iterator]: ()=>this.values(),
                next: ()=>{
                    const r = iterator.next();
                    if (r.done) return r;
                    const value = this.get(r.value);
                    return {
                        done: false,
                        value
                    };
                }
            };
        }
        entries() {
            const iterator = this.keys();
            return {
                [Symbol.iterator]: ()=>this.entries(),
                next: ()=>{
                    const r = iterator.next();
                    if (r.done) return r;
                    const value = this.get(r.value);
                    return {
                        done: false,
                        value: [
                            r.value,
                            value
                        ]
                    };
                }
            };
        }
        [(DRAFT_STATE, Symbol.iterator)]() {
            return this.entries();
        }
    }
    function proxyMap_(target, parent) {
        return new DraftMap(target, parent);
    }
    function prepareMapCopy(state) {
        if (!state.copy_) {
            state.assigned_ = /* @__PURE__ */ new Map();
            state.copy_ = new Map(state.base_);
        }
    }
    class DraftSet extends Set {
        constructor(target, parent){
            super();
            this[DRAFT_STATE] = {
                type_: 3 /* Set */ ,
                parent_: parent,
                scope_: parent ? parent.scope_ : getCurrentScope(),
                modified_: false,
                finalized_: false,
                copy_: void 0,
                base_: target,
                draft_: this,
                drafts_: /* @__PURE__ */ new Map(),
                revoked_: false,
                isManual_: false
            };
        }
        get size() {
            return latest(this[DRAFT_STATE]).size;
        }
        has(value) {
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            if (!state.copy_) {
                return state.base_.has(value);
            }
            if (state.copy_.has(value)) return true;
            if (state.drafts_.has(value) && state.copy_.has(state.drafts_.get(value))) return true;
            return false;
        }
        add(value) {
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            if (!this.has(value)) {
                prepareSetCopy(state);
                markChanged(state);
                state.copy_.add(value);
            }
            return this;
        }
        delete(value) {
            if (!this.has(value)) {
                return false;
            }
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            prepareSetCopy(state);
            markChanged(state);
            return state.copy_.delete(value) || (state.drafts_.has(value) ? state.copy_.delete(state.drafts_.get(value)) : /* istanbul ignore next */ false);
        }
        clear() {
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            if (latest(state).size) {
                prepareSetCopy(state);
                markChanged(state);
                state.copy_.clear();
            }
        }
        values() {
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            prepareSetCopy(state);
            return state.copy_.values();
        }
        entries() {
            const state = this[DRAFT_STATE];
            assertUnrevoked(state);
            prepareSetCopy(state);
            return state.copy_.entries();
        }
        keys() {
            return this.values();
        }
        [(DRAFT_STATE, Symbol.iterator)]() {
            return this.values();
        }
        forEach(cb, thisArg) {
            const iterator = this.values();
            let result = iterator.next();
            while(!result.done){
                cb.call(thisArg, result.value, result.value, this);
                result = iterator.next();
            }
        }
    }
    function proxySet_(target, parent) {
        return new DraftSet(target, parent);
    }
    function prepareSetCopy(state) {
        if (!state.copy_) {
            state.copy_ = /* @__PURE__ */ new Set();
            state.base_.forEach((value)=>{
                if (isDraftable(value)) {
                    const draft = createProxy(value, state);
                    state.drafts_.set(value, draft);
                    state.copy_.add(draft);
                } else {
                    state.copy_.add(value);
                }
            });
        }
    }
    function assertUnrevoked(state) {
        if (state.revoked_) die(3, JSON.stringify(latest(state)));
    }
    loadPlugin("MapSet", {
        proxyMap_,
        proxySet_
    });
}
// src/immer.ts
var immer = new Immer2();
var produce = immer.produce;
var produceWithPatches = /* @__PURE__ */ immer.produceWithPatches.bind(immer);
var setAutoFreeze = /* @__PURE__ */ immer.setAutoFreeze.bind(immer);
var setUseStrictShallowCopy = /* @__PURE__ */ immer.setUseStrictShallowCopy.bind(immer);
var setUseStrictIteration = /* @__PURE__ */ immer.setUseStrictIteration.bind(immer);
var applyPatches = /* @__PURE__ */ immer.applyPatches.bind(immer);
var createDraft = /* @__PURE__ */ immer.createDraft.bind(immer);
var finishDraft = /* @__PURE__ */ immer.finishDraft.bind(immer);
function castDraft(value) {
    return value;
}
function castImmutable(value) {
    return value;
}
;
 //# sourceMappingURL=immer.mjs.map
}),
"[project]/node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function MagnifyingGlassIcon({ title, titleId, ...props }, svgRef) {
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("svg", Object.assign({
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        "aria-hidden": "true",
        "data-slot": "icon",
        ref: svgRef,
        "aria-labelledby": titleId
    }, props), title ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("title", {
        id: titleId
    }, title) : null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "m21 21-5.197-5.197m0 0A7.5 7.5 0 1 0 5.196 5.196a7.5 7.5 0 0 0 10.607 10.607Z"
    }));
}
const ForwardRef = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](MagnifyingGlassIcon);
const __TURBOPACK__default__export__ = ForwardRef;
}),
"[project]/node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js [app-client] (ecmascript) <export default as MagnifyingGlassIcon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MagnifyingGlassIcon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$MagnifyingGlassIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/MagnifyingGlassIcon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@heroicons/react/24/outline/esm/ArrowLeftIcon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function ArrowLeftIcon({ title, titleId, ...props }, svgRef) {
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("svg", Object.assign({
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        "aria-hidden": "true",
        "data-slot": "icon",
        ref: svgRef,
        "aria-labelledby": titleId
    }, props), title ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("title", {
        id: titleId
    }, title) : null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18"
    }));
}
const ForwardRef = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](ArrowLeftIcon);
const __TURBOPACK__default__export__ = ForwardRef;
}),
"[project]/node_modules/@heroicons/react/24/outline/esm/ArrowLeftIcon.js [app-client] (ecmascript) <export default as ArrowLeftIcon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowLeftIcon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ArrowLeftIcon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/@heroicons/react/24/outline/esm/ArrowRightIcon.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function ArrowRightIcon({ title, titleId, ...props }, svgRef) {
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("svg", Object.assign({
        xmlns: "http://www.w3.org/2000/svg",
        fill: "none",
        viewBox: "0 0 24 24",
        strokeWidth: 1.5,
        stroke: "currentColor",
        "aria-hidden": "true",
        "data-slot": "icon",
        ref: svgRef,
        "aria-labelledby": titleId
    }, props), title ? /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("title", {
        id: titleId
    }, title) : null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createElement"]("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        d: "M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
    }));
}
const ForwardRef = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](ArrowRightIcon);
const __TURBOPACK__default__export__ = ForwardRef;
}),
"[project]/node_modules/@heroicons/react/24/outline/esm/ArrowRightIcon.js [app-client] (ecmascript) <export default as ArrowRightIcon>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowRightIcon",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowRightIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowRightIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ArrowRightIcon.js [app-client] (ecmascript)");
}),
"[project]/node_modules/use-debounce/dist/index.module.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDebounce",
    ()=>a,
    "useDebouncedCallback",
    ()=>c,
    "useThrottledCallback",
    ()=>o
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
function c(e, u, c) {
    var i = this, a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), o = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(0), f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]), v = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(), d = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(e), g = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(!0);
    d.current = e;
    var p = "undefined" != typeof window, w = !u && 0 !== u && p;
    if ("function" != typeof e) throw new TypeError("Expected a function");
    u = +u || 0;
    var s = !!(c = c || {}).leading, x = !("trailing" in c) || !!c.trailing, h = "maxWait" in c, y = "debounceOnServer" in c && !!c.debounceOnServer, F = h ? Math.max(+c.maxWait || 0, u) : null;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(function() {
        return g.current = !0, function() {
            g.current = !1;
        };
    }, []);
    var A = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])(function() {
        var r = function(r) {
            var n = l.current, t = v.current;
            return l.current = v.current = null, o.current = r, m.current = d.current.apply(t, n);
        }, n = function(r, n) {
            w && cancelAnimationFrame(f.current), f.current = w ? requestAnimationFrame(r) : setTimeout(r, n);
        }, t = function(r) {
            if (!g.current) return !1;
            var n = r - a.current;
            return !a.current || n >= u || n < 0 || h && r - o.current >= F;
        }, e = function(n) {
            return f.current = null, x && l.current ? r(n) : (l.current = v.current = null, m.current);
        }, c = function r() {
            var c = Date.now();
            if (t(c)) return e(c);
            if (g.current) {
                var i = u - (c - a.current), f = h ? Math.min(i, F - (c - o.current)) : i;
                n(r, f);
            }
        }, A = function() {
            if (p || y) {
                var e = Date.now(), d = t(e);
                if (l.current = [].slice.call(arguments), v.current = i, a.current = e, d) {
                    if (!f.current && g.current) return o.current = a.current, n(c, u), s ? r(a.current) : m.current;
                    if (h) return n(c, u), r(a.current);
                }
                return f.current || n(c, u), m.current;
            }
        };
        return A.cancel = function() {
            f.current && (w ? cancelAnimationFrame(f.current) : clearTimeout(f.current)), o.current = 0, l.current = a.current = v.current = f.current = null;
        }, A.isPending = function() {
            return !!f.current;
        }, A.flush = function() {
            return f.current ? e(Date.now()) : m.current;
        }, A;
    }, [
        s,
        h,
        u,
        F,
        x,
        w,
        p,
        y
    ]);
    return A;
}
function i(r, n) {
    return r === n;
}
function a(n, t, a) {
    var o = a && a.equalityFn || i, f = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(n), l = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({})[1], v = c((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])(function(r) {
        f.current = r, l({});
    }, [
        l
    ]), t, a), m = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(n);
    return o(m.current, n) || (v(n), m.current = n), [
        f.current,
        v
    ];
}
function o(r, n, t) {
    var e = void 0 === t ? {} : t, u = e.leading, i = e.trailing;
    return c(r, n, {
        maxWait: n,
        leading: void 0 === u || u,
        trailing: void 0 === i || i
    });
}
;
 //# sourceMappingURL=index.module.js.map
}),
"[project]/node_modules/@react-pdf/primitives/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Canvas",
    ()=>Canvas,
    "Checkbox",
    ()=>Checkbox,
    "Circle",
    ()=>Circle,
    "ClipPath",
    ()=>ClipPath,
    "Defs",
    ()=>Defs,
    "Document",
    ()=>Document,
    "Ellipse",
    ()=>Ellipse,
    "FieldSet",
    ()=>FieldSet,
    "G",
    ()=>G,
    "Image",
    ()=>Image,
    "Line",
    ()=>Line,
    "LinearGradient",
    ()=>LinearGradient,
    "Link",
    ()=>Link,
    "List",
    ()=>List,
    "Note",
    ()=>Note,
    "Page",
    ()=>Page,
    "Path",
    ()=>Path,
    "Polygon",
    ()=>Polygon,
    "Polyline",
    ()=>Polyline,
    "RadialGradient",
    ()=>RadialGradient,
    "Rect",
    ()=>Rect,
    "Select",
    ()=>Select,
    "Stop",
    ()=>Stop,
    "Svg",
    ()=>Svg,
    "Text",
    ()=>Text,
    "TextInput",
    ()=>TextInput,
    "TextInstance",
    ()=>TextInstance,
    "Tspan",
    ()=>Tspan,
    "View",
    ()=>View
]);
const G = 'G';
const Svg = 'SVG';
const View = 'VIEW';
const Text = 'TEXT';
const Link = 'LINK';
const Page = 'PAGE';
const Note = 'NOTE';
const Path = 'PATH';
const Rect = 'RECT';
const Line = 'LINE';
const FieldSet = 'FIELD_SET';
const TextInput = 'TEXT_INPUT';
const Select = 'SELECT';
const Checkbox = 'CHECKBOX';
const List = 'LIST';
const Stop = 'STOP';
const Defs = 'DEFS';
const Image = 'IMAGE';
const Tspan = 'TSPAN';
const Canvas = 'CANVAS';
const Circle = 'CIRCLE';
const Ellipse = 'ELLIPSE';
const Polygon = 'POLYGON';
const Document = 'DOCUMENT';
const Polyline = 'POLYLINE';
const ClipPath = 'CLIP_PATH';
const TextInstance = 'TEXT_INSTANCE';
const LinearGradient = 'LINEAR_GRADIENT';
const RadialGradient = 'RADIAL_GRADIENT';
;
}),
"[project]/node_modules/inherits/inherits_browser.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

if (typeof Object.create === 'function') {
    // implementation from standard node.js 'util' module
    module.exports = function inherits(ctor, superCtor) {
        if (superCtor) {
            ctor.super_ = superCtor;
            ctor.prototype = Object.create(superCtor.prototype, {
                constructor: {
                    value: ctor,
                    enumerable: false,
                    writable: true,
                    configurable: true
                }
            });
        }
    };
} else {
    // old school shim for old browsers
    module.exports = function inherits(ctor, superCtor) {
        if (superCtor) {
            ctor.super_ = superCtor;
            var TempCtor = function() {};
            TempCtor.prototype = superCtor.prototype;
            ctor.prototype = new TempCtor();
            ctor.prototype.constructor = ctor;
        }
    };
}
}),
"[project]/node_modules/events/events.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.
var R = typeof Reflect === 'object' ? Reflect : null;
var ReflectApply = R && typeof R.apply === 'function' ? R.apply : function ReflectApply(target, receiver, args) {
    return Function.prototype.apply.call(target, receiver, args);
};
var ReflectOwnKeys;
if (R && typeof R.ownKeys === 'function') {
    ReflectOwnKeys = R.ownKeys;
} else if (Object.getOwnPropertySymbols) {
    ReflectOwnKeys = function ReflectOwnKeys(target) {
        return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
    };
} else {
    ReflectOwnKeys = function ReflectOwnKeys(target) {
        return Object.getOwnPropertyNames(target);
    };
}
function ProcessEmitWarning(warning) {
    if (console && console.warn) console.warn(warning);
}
var NumberIsNaN = Number.isNaN || function NumberIsNaN(value) {
    return value !== value;
};
function EventEmitter() {
    EventEmitter.init.call(this);
}
module.exports = EventEmitter;
module.exports.once = once;
// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;
EventEmitter.prototype._events = undefined;
EventEmitter.prototype._eventsCount = 0;
EventEmitter.prototype._maxListeners = undefined;
// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
var defaultMaxListeners = 10;
function checkListener(listener) {
    if (typeof listener !== 'function') {
        throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
    }
}
Object.defineProperty(EventEmitter, 'defaultMaxListeners', {
    enumerable: true,
    get: function() {
        return defaultMaxListeners;
    },
    set: function(arg) {
        if (typeof arg !== 'number' || arg < 0 || NumberIsNaN(arg)) {
            throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + '.');
        }
        defaultMaxListeners = arg;
    }
});
EventEmitter.init = function() {
    if (this._events === undefined || this._events === Object.getPrototypeOf(this)._events) {
        this._events = Object.create(null);
        this._eventsCount = 0;
    }
    this._maxListeners = this._maxListeners || undefined;
};
// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
    if (typeof n !== 'number' || n < 0 || NumberIsNaN(n)) {
        throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + '.');
    }
    this._maxListeners = n;
    return this;
};
function _getMaxListeners(that) {
    if (that._maxListeners === undefined) return EventEmitter.defaultMaxListeners;
    return that._maxListeners;
}
EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
    return _getMaxListeners(this);
};
EventEmitter.prototype.emit = function emit(type) {
    var args = [];
    for(var i = 1; i < arguments.length; i++)args.push(arguments[i]);
    var doError = type === 'error';
    var events = this._events;
    if (events !== undefined) doError = doError && events.error === undefined;
    else if (!doError) return false;
    // If there is no 'error' event listener then throw.
    if (doError) {
        var er;
        if (args.length > 0) er = args[0];
        if (er instanceof Error) {
            // Note: The comments on the `throw` lines are intentional, they show
            // up in Node's output if this results in an unhandled exception.
            throw er; // Unhandled 'error' event
        }
        // At least give some kind of context to the user
        var err = new Error('Unhandled error.' + (er ? ' (' + er.message + ')' : ''));
        err.context = er;
        throw err; // Unhandled 'error' event
    }
    var handler = events[type];
    if (handler === undefined) return false;
    if (typeof handler === 'function') {
        ReflectApply(handler, this, args);
    } else {
        var len = handler.length;
        var listeners = arrayClone(handler, len);
        for(var i = 0; i < len; ++i)ReflectApply(listeners[i], this, args);
    }
    return true;
};
function _addListener(target, type, listener, prepend) {
    var m;
    var events;
    var existing;
    checkListener(listener);
    events = target._events;
    if (events === undefined) {
        events = target._events = Object.create(null);
        target._eventsCount = 0;
    } else {
        // To avoid recursion in the case that type === "newListener"! Before
        // adding it to the listeners, first emit "newListener".
        if (events.newListener !== undefined) {
            target.emit('newListener', type, listener.listener ? listener.listener : listener);
            // Re-assign `events` because a newListener handler could have caused the
            // this._events to be assigned to a new object
            events = target._events;
        }
        existing = events[type];
    }
    if (existing === undefined) {
        // Optimize the case of one listener. Don't need the extra array object.
        existing = events[type] = listener;
        ++target._eventsCount;
    } else {
        if (typeof existing === 'function') {
            // Adding the second element, need to change to array.
            existing = events[type] = prepend ? [
                listener,
                existing
            ] : [
                existing,
                listener
            ];
        // If we've already got an array, just append.
        } else if (prepend) {
            existing.unshift(listener);
        } else {
            existing.push(listener);
        }
        // Check for listener leak
        m = _getMaxListeners(target);
        if (m > 0 && existing.length > m && !existing.warned) {
            existing.warned = true;
            // No error code for this since it is a Warning
            // eslint-disable-next-line no-restricted-syntax
            var w = new Error('Possible EventEmitter memory leak detected. ' + existing.length + ' ' + String(type) + ' listeners ' + 'added. Use emitter.setMaxListeners() to ' + 'increase limit');
            w.name = 'MaxListenersExceededWarning';
            w.emitter = target;
            w.type = type;
            w.count = existing.length;
            ProcessEmitWarning(w);
        }
    }
    return target;
}
EventEmitter.prototype.addListener = function addListener(type, listener) {
    return _addListener(this, type, listener, false);
};
EventEmitter.prototype.on = EventEmitter.prototype.addListener;
EventEmitter.prototype.prependListener = function prependListener(type, listener) {
    return _addListener(this, type, listener, true);
};
function onceWrapper() {
    if (!this.fired) {
        this.target.removeListener(this.type, this.wrapFn);
        this.fired = true;
        if (arguments.length === 0) return this.listener.call(this.target);
        return this.listener.apply(this.target, arguments);
    }
}
function _onceWrap(target, type, listener) {
    var state = {
        fired: false,
        wrapFn: undefined,
        target: target,
        type: type,
        listener: listener
    };
    var wrapped = onceWrapper.bind(state);
    wrapped.listener = listener;
    state.wrapFn = wrapped;
    return wrapped;
}
EventEmitter.prototype.once = function once(type, listener) {
    checkListener(listener);
    this.on(type, _onceWrap(this, type, listener));
    return this;
};
EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
    checkListener(listener);
    this.prependListener(type, _onceWrap(this, type, listener));
    return this;
};
// Emits a 'removeListener' event if and only if the listener was removed.
EventEmitter.prototype.removeListener = function removeListener(type, listener) {
    var list, events, position, i, originalListener;
    checkListener(listener);
    events = this._events;
    if (events === undefined) return this;
    list = events[type];
    if (list === undefined) return this;
    if (list === listener || list.listener === listener) {
        if (--this._eventsCount === 0) this._events = Object.create(null);
        else {
            delete events[type];
            if (events.removeListener) this.emit('removeListener', type, list.listener || listener);
        }
    } else if (typeof list !== 'function') {
        position = -1;
        for(i = list.length - 1; i >= 0; i--){
            if (list[i] === listener || list[i].listener === listener) {
                originalListener = list[i].listener;
                position = i;
                break;
            }
        }
        if (position < 0) return this;
        if (position === 0) list.shift();
        else {
            spliceOne(list, position);
        }
        if (list.length === 1) events[type] = list[0];
        if (events.removeListener !== undefined) this.emit('removeListener', type, originalListener || listener);
    }
    return this;
};
EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
    var listeners, events, i;
    events = this._events;
    if (events === undefined) return this;
    // not listening for removeListener, no need to emit
    if (events.removeListener === undefined) {
        if (arguments.length === 0) {
            this._events = Object.create(null);
            this._eventsCount = 0;
        } else if (events[type] !== undefined) {
            if (--this._eventsCount === 0) this._events = Object.create(null);
            else delete events[type];
        }
        return this;
    }
    // emit removeListener for all listeners on all events
    if (arguments.length === 0) {
        var keys = Object.keys(events);
        var key;
        for(i = 0; i < keys.length; ++i){
            key = keys[i];
            if (key === 'removeListener') continue;
            this.removeAllListeners(key);
        }
        this.removeAllListeners('removeListener');
        this._events = Object.create(null);
        this._eventsCount = 0;
        return this;
    }
    listeners = events[type];
    if (typeof listeners === 'function') {
        this.removeListener(type, listeners);
    } else if (listeners !== undefined) {
        // LIFO order
        for(i = listeners.length - 1; i >= 0; i--){
            this.removeListener(type, listeners[i]);
        }
    }
    return this;
};
function _listeners(target, type, unwrap) {
    var events = target._events;
    if (events === undefined) return [];
    var evlistener = events[type];
    if (evlistener === undefined) return [];
    if (typeof evlistener === 'function') return unwrap ? [
        evlistener.listener || evlistener
    ] : [
        evlistener
    ];
    return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
}
EventEmitter.prototype.listeners = function listeners(type) {
    return _listeners(this, type, true);
};
EventEmitter.prototype.rawListeners = function rawListeners(type) {
    return _listeners(this, type, false);
};
EventEmitter.listenerCount = function(emitter, type) {
    if (typeof emitter.listenerCount === 'function') {
        return emitter.listenerCount(type);
    } else {
        return listenerCount.call(emitter, type);
    }
};
EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(type) {
    var events = this._events;
    if (events !== undefined) {
        var evlistener = events[type];
        if (typeof evlistener === 'function') {
            return 1;
        } else if (evlistener !== undefined) {
            return evlistener.length;
        }
    }
    return 0;
}
EventEmitter.prototype.eventNames = function eventNames() {
    return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
};
function arrayClone(arr, n) {
    var copy = new Array(n);
    for(var i = 0; i < n; ++i)copy[i] = arr[i];
    return copy;
}
function spliceOne(list, index) {
    for(; index + 1 < list.length; index++)list[index] = list[index + 1];
    list.pop();
}
function unwrapListeners(arr) {
    var ret = new Array(arr.length);
    for(var i = 0; i < ret.length; ++i){
        ret[i] = arr[i].listener || arr[i];
    }
    return ret;
}
function once(emitter, name) {
    return new Promise(function(resolve, reject) {
        function errorListener(err) {
            emitter.removeListener(name, resolver);
            reject(err);
        }
        function resolver() {
            if (typeof emitter.removeListener === 'function') {
                emitter.removeListener('error', errorListener);
            }
            resolve([].slice.call(arguments));
        }
        ;
        eventTargetAgnosticAddListener(emitter, name, resolver, {
            once: true
        });
        if (name !== 'error') {
            addErrorHandlerIfEventEmitter(emitter, errorListener, {
                once: true
            });
        }
    });
}
function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
    if (typeof emitter.on === 'function') {
        eventTargetAgnosticAddListener(emitter, 'error', handler, flags);
    }
}
function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
    if (typeof emitter.on === 'function') {
        if (flags.once) {
            emitter.once(name, listener);
        } else {
            emitter.on(name, listener);
        }
    } else if (typeof emitter.addEventListener === 'function') {
        // EventTarget does not have `error` event semantics like Node
        // EventEmitters, we do not listen for `error` events here.
        emitter.addEventListener(name, function wrapListener(arg) {
            // IE does not have builtin `{ once: true }` support so we
            // have to do it manually.
            if (flags.once) {
                emitter.removeEventListener(name, wrapListener);
            }
            listener(arg);
        });
    } else {
        throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
    }
}
}),
"[project]/node_modules/queue/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var inherits = __turbopack_context__.r("[project]/node_modules/inherits/inherits_browser.js [app-client] (ecmascript)");
var EventEmitter = __turbopack_context__.r("[project]/node_modules/events/events.js [app-client] (ecmascript)").EventEmitter;
module.exports = Queue;
module.exports.default = Queue;
function Queue(options) {
    if (!(this instanceof Queue)) {
        return new Queue(options);
    }
    EventEmitter.call(this);
    options = options || {};
    this.concurrency = options.concurrency || Infinity;
    this.timeout = options.timeout || 0;
    this.autostart = options.autostart || false;
    this.results = options.results || null;
    this.pending = 0;
    this.session = 0;
    this.running = false;
    this.jobs = [];
    this.timers = {};
}
inherits(Queue, EventEmitter);
var arrayMethods = [
    'pop',
    'shift',
    'indexOf',
    'lastIndexOf'
];
arrayMethods.forEach(function(method) {
    Queue.prototype[method] = function() {
        return Array.prototype[method].apply(this.jobs, arguments);
    };
});
Queue.prototype.slice = function(begin, end) {
    this.jobs = this.jobs.slice(begin, end);
    return this;
};
Queue.prototype.reverse = function() {
    this.jobs.reverse();
    return this;
};
var arrayAddMethods = [
    'push',
    'unshift',
    'splice'
];
arrayAddMethods.forEach(function(method) {
    Queue.prototype[method] = function() {
        var methodResult = Array.prototype[method].apply(this.jobs, arguments);
        if (this.autostart) {
            this.start();
        }
        return methodResult;
    };
});
Object.defineProperty(Queue.prototype, 'length', {
    get: function() {
        return this.pending + this.jobs.length;
    }
});
Queue.prototype.start = function(cb) {
    if (cb) {
        callOnErrorOrEnd.call(this, cb);
    }
    this.running = true;
    if (this.pending >= this.concurrency) {
        return;
    }
    if (this.jobs.length === 0) {
        if (this.pending === 0) {
            done.call(this);
        }
        return;
    }
    var self = this;
    var job = this.jobs.shift();
    var once = true;
    var session = this.session;
    var timeoutId = null;
    var didTimeout = false;
    var resultIndex = null;
    var timeout = job.hasOwnProperty('timeout') ? job.timeout : this.timeout;
    function next(err, result) {
        if (once && self.session === session) {
            once = false;
            self.pending--;
            if (timeoutId !== null) {
                delete self.timers[timeoutId];
                clearTimeout(timeoutId);
            }
            if (err) {
                self.emit('error', err, job);
            } else if (didTimeout === false) {
                if (resultIndex !== null) {
                    self.results[resultIndex] = Array.prototype.slice.call(arguments, 1);
                }
                self.emit('success', result, job);
            }
            if (self.session === session) {
                if (self.pending === 0 && self.jobs.length === 0) {
                    done.call(self);
                } else if (self.running) {
                    self.start();
                }
            }
        }
    }
    if (timeout) {
        timeoutId = setTimeout(function() {
            didTimeout = true;
            if (self.listeners('timeout').length > 0) {
                self.emit('timeout', next, job);
            } else {
                next();
            }
        }, timeout);
        this.timers[timeoutId] = timeoutId;
    }
    if (this.results) {
        resultIndex = this.results.length;
        this.results[resultIndex] = null;
    }
    this.pending++;
    self.emit('start', job);
    var promise = job(next);
    if (promise && promise.then && typeof promise.then === 'function') {
        promise.then(function(result) {
            return next(null, result);
        }).catch(function(err) {
            return next(err || true);
        });
    }
    if (this.running && this.jobs.length > 0) {
        this.start();
    }
};
Queue.prototype.stop = function() {
    this.running = false;
};
Queue.prototype.end = function(err) {
    clearTimers.call(this);
    this.jobs.length = 0;
    this.pending = 0;
    done.call(this, err);
};
function clearTimers() {
    for(var key in this.timers){
        var timeoutId = this.timers[key];
        delete this.timers[key];
        clearTimeout(timeoutId);
    }
}
function callOnErrorOrEnd(cb) {
    var self = this;
    this.on('error', onerror);
    this.on('end', onend);
    function onerror(err) {
        self.end(err);
    }
    function onend(err) {
        self.removeListener('error', onerror);
        self.removeListener('end', onend);
        cb(err, this.results);
    }
}
function done(err) {
    this.session++;
    this.running = false;
    this.emit('end', err);
}
}),
"[project]/node_modules/is-url/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Expose `isUrl`.
 */ module.exports = isUrl;
/**
 * RegExps.
 * A URL must match #1 and then at least one of #2/#3.
 * Use two levels of REs to avoid REDOS.
 */ var protocolAndDomainRE = /^(?:\w+:)?\/\/(\S+)$/;
var localhostDomainRE = /^localhost[\:?\d]*(?:[^\:?\d]\S*)?$/;
var nonLocalhostDomainRE = /^[^\s\.]+\.\S{2,}$/;
/**
 * Loosely validate a URL `string`.
 *
 * @param {String} string
 * @return {Boolean}
 */ function isUrl(string) {
    if (typeof string !== 'string') {
        return false;
    }
    var match = string.match(protocolAndDomainRE);
    if (!match) {
        return false;
    }
    var everythingAfterProtocol = match[1];
    if (!everythingAfterProtocol) {
        return false;
    }
    if (localhostDomainRE.test(everythingAfterProtocol) || nonLocalhostDomainRE.test(everythingAfterProtocol)) {
        return true;
    }
    return false;
}
}),
"[project]/node_modules/restructure/src/DecodeStream.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DecodeStream",
    ()=>DecodeStream
]);
// Node back-compat.
const ENCODING_MAPPING = {
    utf16le: 'utf-16le',
    ucs2: 'utf-16le',
    utf16be: 'utf-16be'
};
class DecodeStream {
    constructor(buffer){
        this.buffer = buffer;
        this.view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
        this.pos = 0;
        this.length = this.buffer.length;
    }
    readString(length, encoding = 'ascii') {
        encoding = ENCODING_MAPPING[encoding] || encoding;
        let buf = this.readBuffer(length);
        try {
            let decoder = new TextDecoder(encoding);
            return decoder.decode(buf);
        } catch (err) {
            return buf;
        }
    }
    readBuffer(length) {
        return this.buffer.slice(this.pos, this.pos += length);
    }
    readUInt24BE() {
        return (this.readUInt16BE() << 8) + this.readUInt8();
    }
    readUInt24LE() {
        return this.readUInt16LE() + (this.readUInt8() << 16);
    }
    readInt24BE() {
        return (this.readInt16BE() << 8) + this.readUInt8();
    }
    readInt24LE() {
        return this.readUInt16LE() + (this.readInt8() << 16);
    }
}
DecodeStream.TYPES = {
    UInt8: 1,
    UInt16: 2,
    UInt24: 3,
    UInt32: 4,
    Int8: 1,
    Int16: 2,
    Int24: 3,
    Int32: 4,
    Float: 4,
    Double: 8
};
for (let key of Object.getOwnPropertyNames(DataView.prototype)){
    if (key.slice(0, 3) === 'get') {
        let type = key.slice(3).replace('Ui', 'UI');
        if (type === 'Float32') {
            type = 'Float';
        } else if (type === 'Float64') {
            type = 'Double';
        }
        let bytes = DecodeStream.TYPES[type];
        DecodeStream.prototype['read' + type + (bytes === 1 ? '' : 'BE')] = function() {
            const ret = this.view[key](this.pos, false);
            this.pos += bytes;
            return ret;
        };
        if (bytes !== 1) {
            DecodeStream.prototype['read' + type + 'LE'] = function() {
                const ret = this.view[key](this.pos, true);
                this.pos += bytes;
                return ret;
            };
        }
    }
}
}),
"[project]/node_modules/restructure/src/EncodeStream.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EncodeStream",
    ()=>EncodeStream
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$DecodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/DecodeStream.js [app-client] (ecmascript)");
;
const textEncoder = new TextEncoder();
const isBigEndian = new Uint8Array(new Uint16Array([
    0x1234
]).buffer)[0] == 0x12;
class EncodeStream {
    constructor(buffer){
        this.buffer = buffer;
        this.view = new DataView(this.buffer.buffer, this.buffer.byteOffset, this.buffer.byteLength);
        this.pos = 0;
    }
    writeBuffer(buffer) {
        this.buffer.set(buffer, this.pos);
        this.pos += buffer.length;
    }
    writeString(string, encoding = 'ascii') {
        let buf;
        switch(encoding){
            case 'utf16le':
            case 'utf16-le':
            case 'ucs2':
                buf = stringToUtf16(string, isBigEndian);
                break;
            case 'utf16be':
            case 'utf16-be':
                buf = stringToUtf16(string, !isBigEndian);
                break;
            case 'utf8':
                buf = textEncoder.encode(string);
                break;
            case 'ascii':
                buf = stringToAscii(string);
                break;
            default:
                throw new Error(`Unsupported encoding: ${encoding}`);
        }
        this.writeBuffer(buf);
    }
    writeUInt24BE(val) {
        this.buffer[this.pos++] = val >>> 16 & 0xff;
        this.buffer[this.pos++] = val >>> 8 & 0xff;
        this.buffer[this.pos++] = val & 0xff;
    }
    writeUInt24LE(val) {
        this.buffer[this.pos++] = val & 0xff;
        this.buffer[this.pos++] = val >>> 8 & 0xff;
        this.buffer[this.pos++] = val >>> 16 & 0xff;
    }
    writeInt24BE(val) {
        if (val >= 0) {
            this.writeUInt24BE(val);
        } else {
            this.writeUInt24BE(val + 0xffffff + 1);
        }
    }
    writeInt24LE(val) {
        if (val >= 0) {
            this.writeUInt24LE(val);
        } else {
            this.writeUInt24LE(val + 0xffffff + 1);
        }
    }
    fill(val, length) {
        if (length < this.buffer.length) {
            this.buffer.fill(val, this.pos, this.pos + length);
            this.pos += length;
        } else {
            const buf = new Uint8Array(length);
            buf.fill(val);
            this.writeBuffer(buf);
        }
    }
}
function stringToUtf16(string, swap) {
    let buf = new Uint16Array(string.length);
    for(let i = 0; i < string.length; i++){
        let code = string.charCodeAt(i);
        if (swap) {
            code = code >> 8 | (code & 0xff) << 8;
        }
        buf[i] = code;
    }
    return new Uint8Array(buf.buffer);
}
function stringToAscii(string) {
    let buf = new Uint8Array(string.length);
    for(let i = 0; i < string.length; i++){
        // Match node.js behavior - encoding allows 8-bit rather than 7-bit.
        buf[i] = string.charCodeAt(i);
    }
    return buf;
}
for (let key of Object.getOwnPropertyNames(DataView.prototype)){
    if (key.slice(0, 3) === 'set') {
        let type = key.slice(3).replace('Ui', 'UI');
        if (type === 'Float32') {
            type = 'Float';
        } else if (type === 'Float64') {
            type = 'Double';
        }
        let bytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$DecodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecodeStream"].TYPES[type];
        EncodeStream.prototype['write' + type + (bytes === 1 ? '' : 'BE')] = function(value) {
            this.view[key](this.pos, value, false);
            this.pos += bytes;
        };
        if (bytes !== 1) {
            EncodeStream.prototype['write' + type + 'LE'] = function(value) {
                this.view[key](this.pos, value, true);
                this.pos += bytes;
            };
        }
    }
}
}),
"[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Base",
    ()=>Base
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$DecodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/DecodeStream.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$EncodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/EncodeStream.js [app-client] (ecmascript)");
;
;
class Base {
    fromBuffer(buffer) {
        let stream = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$DecodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecodeStream"](buffer);
        return this.decode(stream);
    }
    toBuffer(value) {
        let size = this.size(value);
        let buffer = new Uint8Array(size);
        let stream = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$EncodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EncodeStream"](buffer);
        this.encode(stream, value);
        return buffer;
    }
}
}),
"[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Fixed",
    ()=>Fixed,
    "Number",
    ()=>NumberT,
    "double",
    ()=>double,
    "doublebe",
    ()=>doublebe,
    "doublele",
    ()=>doublele,
    "fixed16",
    ()=>fixed16,
    "fixed16be",
    ()=>fixed16be,
    "fixed16le",
    ()=>fixed16le,
    "fixed32",
    ()=>fixed32,
    "fixed32be",
    ()=>fixed32be,
    "fixed32le",
    ()=>fixed32le,
    "float",
    ()=>float,
    "floatbe",
    ()=>floatbe,
    "floatle",
    ()=>floatle,
    "int16",
    ()=>int16,
    "int16be",
    ()=>int16be,
    "int16le",
    ()=>int16le,
    "int24",
    ()=>int24,
    "int24be",
    ()=>int24be,
    "int24le",
    ()=>int24le,
    "int32",
    ()=>int32,
    "int32be",
    ()=>int32be,
    "int32le",
    ()=>int32le,
    "int8",
    ()=>int8,
    "uint16",
    ()=>uint16,
    "uint16be",
    ()=>uint16be,
    "uint16le",
    ()=>uint16le,
    "uint24",
    ()=>uint24,
    "uint24be",
    ()=>uint24be,
    "uint24le",
    ()=>uint24le,
    "uint32",
    ()=>uint32,
    "uint32be",
    ()=>uint32be,
    "uint32le",
    ()=>uint32le,
    "uint8",
    ()=>uint8
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$DecodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/DecodeStream.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
;
;
class NumberT extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(type, endian = 'BE'){
        super();
        this.type = type;
        this.endian = endian;
        this.fn = this.type;
        if (this.type[this.type.length - 1] !== '8') {
            this.fn += this.endian;
        }
    }
    size() {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$DecodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DecodeStream"].TYPES[this.type];
    }
    decode(stream) {
        return stream[`read${this.fn}`]();
    }
    encode(stream, val) {
        return stream[`write${this.fn}`](val);
    }
}
;
const uint8 = new NumberT('UInt8');
const uint16be = new NumberT('UInt16', 'BE');
const uint16 = uint16be;
const uint16le = new NumberT('UInt16', 'LE');
const uint24be = new NumberT('UInt24', 'BE');
const uint24 = uint24be;
const uint24le = new NumberT('UInt24', 'LE');
const uint32be = new NumberT('UInt32', 'BE');
const uint32 = uint32be;
const uint32le = new NumberT('UInt32', 'LE');
const int8 = new NumberT('Int8');
const int16be = new NumberT('Int16', 'BE');
const int16 = int16be;
const int16le = new NumberT('Int16', 'LE');
const int24be = new NumberT('Int24', 'BE');
const int24 = int24be;
const int24le = new NumberT('Int24', 'LE');
const int32be = new NumberT('Int32', 'BE');
const int32 = int32be;
const int32le = new NumberT('Int32', 'LE');
const floatbe = new NumberT('Float', 'BE');
const float = floatbe;
const floatle = new NumberT('Float', 'LE');
const doublebe = new NumberT('Double', 'BE');
const double = doublebe;
const doublele = new NumberT('Double', 'LE');
class Fixed extends NumberT {
    constructor(size, endian, fracBits = size >> 1){
        super(`Int${size}`, endian);
        this._point = 1 << fracBits;
    }
    decode(stream) {
        return super.decode(stream) / this._point;
    }
    encode(stream, val) {
        return super.encode(stream, val * this._point | 0);
    }
}
const fixed16be = new Fixed(16, 'BE');
const fixed16 = fixed16be;
const fixed16le = new Fixed(16, 'LE');
const fixed32be = new Fixed(32, 'BE');
const fixed32 = fixed32be;
const fixed32le = new Fixed(32, 'LE');
}),
"[project]/node_modules/restructure/src/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PropertyDescriptor",
    ()=>PropertyDescriptor,
    "resolveLength",
    ()=>resolveLength
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
;
function resolveLength(length, stream, parent) {
    let res;
    if (typeof length === 'number') {
        res = length;
    } else if (typeof length === 'function') {
        res = length.call(parent, parent);
    } else if (parent && typeof length === 'string') {
        res = parent[length];
    } else if (stream && length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
        res = length.decode(stream);
    }
    if (isNaN(res)) {
        throw new Error('Not a fixed size');
    }
    return res;
}
;
class PropertyDescriptor {
    constructor(opts = {}){
        this.enumerable = true;
        this.configurable = true;
        for(let key in opts){
            const val = opts[key];
            this[key] = val;
        }
    }
}
}),
"[project]/node_modules/restructure/src/Array.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Array",
    ()=>ArrayT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/utils.js [app-client] (ecmascript)");
;
;
;
class ArrayT extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(type, length, lengthType = 'count'){
        super();
        this.type = type;
        this.length = length;
        this.lengthType = lengthType;
    }
    decode(stream, parent) {
        let length;
        const { pos } = stream;
        const res = [];
        let ctx = parent;
        if (this.length != null) {
            length = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveLength"](this.length, stream, parent);
        }
        if (this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            // define hidden properties
            Object.defineProperties(res, {
                parent: {
                    value: parent
                },
                _startOffset: {
                    value: pos
                },
                _currentOffset: {
                    value: 0,
                    writable: true
                },
                _length: {
                    value: length
                }
            });
            ctx = res;
        }
        if (length == null || this.lengthType === 'bytes') {
            const target = length != null ? stream.pos + length : (parent != null ? parent._length : undefined) ? parent._startOffset + parent._length : stream.length;
            while(stream.pos < target){
                res.push(this.type.decode(stream, ctx));
            }
        } else {
            for(let i = 0, end = length; i < end; i++){
                res.push(this.type.decode(stream, ctx));
            }
        }
        return res;
    }
    size(array, ctx, includePointers = true) {
        if (!array) {
            return this.type.size(null, ctx) * __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveLength"](this.length, null, ctx);
        }
        let size = 0;
        if (this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            size += this.length.size();
            ctx = {
                parent: ctx,
                pointerSize: 0
            };
        }
        for (let item of array){
            size += this.type.size(item, ctx);
        }
        if (ctx && includePointers && this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            size += ctx.pointerSize;
        }
        return size;
    }
    encode(stream, array, parent) {
        let ctx = parent;
        if (this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            ctx = {
                pointers: [],
                startOffset: stream.pos,
                parent
            };
            ctx.pointerOffset = stream.pos + this.size(array, ctx, false);
            this.length.encode(stream, array.length);
        }
        for (let item of array){
            this.type.encode(stream, item, ctx);
        }
        if (this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            let i = 0;
            while(i < ctx.pointers.length){
                const ptr = ctx.pointers[i++];
                ptr.type.encode(stream, ptr.val, ptr.parent);
            }
        }
    }
}
;
}),
"[project]/node_modules/restructure/src/LazyArray.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LazyArray",
    ()=>LazyArray
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Array.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/utils.js [app-client] (ecmascript)");
;
;
;
class LazyArray extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Array"] {
    decode(stream, parent) {
        const { pos } = stream;
        const length = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveLength"](this.length, stream, parent);
        if (this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            parent = {
                parent,
                _startOffset: pos,
                _currentOffset: 0,
                _length: length
            };
        }
        const res = new LazyArrayValue(this.type, length, stream, parent);
        stream.pos += length * this.type.size(null, parent);
        return res;
    }
    size(val, ctx) {
        if (val instanceof LazyArrayValue) {
            val = val.toArray();
        }
        return super.size(val, ctx);
    }
    encode(stream, val, ctx) {
        if (val instanceof LazyArrayValue) {
            val = val.toArray();
        }
        return super.encode(stream, val, ctx);
    }
}
class LazyArrayValue {
    constructor(type, length, stream, ctx){
        this.type = type;
        this.length = length;
        this.stream = stream;
        this.ctx = ctx;
        this.base = this.stream.pos;
        this.items = [];
    }
    get(index) {
        if (index < 0 || index >= this.length) {
            return undefined;
        }
        if (this.items[index] == null) {
            const { pos } = this.stream;
            this.stream.pos = this.base + this.type.size(null, this.ctx) * index;
            this.items[index] = this.type.decode(this.stream, this.ctx);
            this.stream.pos = pos;
        }
        return this.items[index];
    }
    toArray() {
        const result = [];
        for(let i = 0, end = this.length; i < end; i++){
            result.push(this.get(i));
        }
        return result;
    }
}
}),
"[project]/node_modules/restructure/src/Bitfield.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Bitfield",
    ()=>Bitfield
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
;
class Bitfield extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(type, flags = []){
        super();
        this.type = type;
        this.flags = flags;
    }
    decode(stream) {
        const val = this.type.decode(stream);
        const res = {};
        for(let i = 0; i < this.flags.length; i++){
            const flag = this.flags[i];
            if (flag != null) {
                res[flag] = !!(val & 1 << i);
            }
        }
        return res;
    }
    size() {
        return this.type.size();
    }
    encode(stream, keys) {
        let val = 0;
        for(let i = 0; i < this.flags.length; i++){
            const flag = this.flags[i];
            if (flag != null) {
                if (keys[flag]) {
                    val |= 1 << i;
                }
            }
        }
        return this.type.encode(stream, val);
    }
}
}),
"[project]/node_modules/restructure/src/Boolean.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Boolean",
    ()=>BooleanT,
    "BooleanT",
    ()=>BooleanT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
;
class BooleanT extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(type){
        super();
        this.type = type;
    }
    decode(stream, parent) {
        return !!this.type.decode(stream, parent);
    }
    size(val, parent) {
        return this.type.size(val, parent);
    }
    encode(stream, val, parent) {
        return this.type.encode(stream, +val, parent);
    }
}
;
}),
"[project]/node_modules/restructure/src/Buffer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Buffer",
    ()=>BufferT,
    "BufferT",
    ()=>BufferT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/compiled/buffer/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/utils.js [app-client] (ecmascript)");
;
;
;
class BufferT extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(length){
        super();
        this.length = length;
    }
    decode(stream, parent) {
        const length = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveLength"](this.length, stream, parent);
        return stream.readBuffer(length);
    }
    size(val, parent) {
        if (!val) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveLength"](this.length, null, parent);
        }
        let len = val.length;
        if (this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            len += this.length.size();
        }
        return len;
    }
    encode(stream, buf, parent) {
        if (this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            this.length.encode(stream, buf.length);
        }
        return stream.writeBuffer(buf);
    }
}
;
}),
"[project]/node_modules/restructure/src/Enum.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Enum",
    ()=>Enum
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
;
class Enum extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(type, options = []){
        super();
        this.type = type;
        this.options = options;
    }
    decode(stream) {
        const index = this.type.decode(stream);
        return this.options[index] || index;
    }
    size() {
        return this.type.size();
    }
    encode(stream, val) {
        const index = this.options.indexOf(val);
        if (index === -1) {
            throw new Error(`Unknown option in enum: ${val}`);
        }
        return this.type.encode(stream, index);
    }
}
}),
"[project]/node_modules/restructure/src/Optional.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Optional",
    ()=>Optional
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
;
class Optional extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(type, condition = true){
        super();
        this.type = type;
        this.condition = condition;
    }
    decode(stream, parent) {
        let { condition } = this;
        if (typeof condition === 'function') {
            condition = condition.call(parent, parent);
        }
        if (condition) {
            return this.type.decode(stream, parent);
        }
    }
    size(val, parent) {
        let { condition } = this;
        if (typeof condition === 'function') {
            condition = condition.call(parent, parent);
        }
        if (condition) {
            return this.type.size(val, parent);
        } else {
            return 0;
        }
    }
    encode(stream, val, parent) {
        let { condition } = this;
        if (typeof condition === 'function') {
            condition = condition.call(parent, parent);
        }
        if (condition) {
            return this.type.encode(stream, val, parent);
        }
    }
}
}),
"[project]/node_modules/restructure/src/Reserved.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Reserved",
    ()=>Reserved
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/utils.js [app-client] (ecmascript)");
;
;
class Reserved extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(type, count = 1){
        super();
        this.type = type;
        this.count = count;
    }
    decode(stream, parent) {
        stream.pos += this.size(null, parent);
        return undefined;
    }
    size(data, parent) {
        const count = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveLength"](this.count, null, parent);
        return this.type.size() * count;
    }
    encode(stream, val, parent) {
        return stream.fill(0, this.size(val, parent));
    }
}
}),
"[project]/node_modules/restructure/src/String.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "String",
    ()=>StringT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/utils.js [app-client] (ecmascript)");
;
;
;
class StringT extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(length, encoding = 'ascii'){
        super();
        this.length = length;
        this.encoding = encoding;
    }
    decode(stream, parent) {
        let length, pos;
        let { encoding } = this;
        if (typeof encoding === 'function') {
            encoding = encoding.call(parent, parent) || 'ascii';
        }
        let width = encodingWidth(encoding);
        if (this.length != null) {
            length = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveLength"](this.length, stream, parent);
        } else {
            let buffer;
            ({ buffer, length, pos } = stream);
            while(pos < length - width + 1 && (buffer[pos] !== 0x00 || width === 2 && buffer[pos + 1] !== 0x00)){
                pos += width;
            }
            length = pos - stream.pos;
        }
        const string = stream.readString(length, encoding);
        if (this.length == null && stream.pos < stream.length) {
            stream.pos += width;
        }
        return string;
    }
    size(val, parent) {
        // Use the defined value if no value was given
        if (val === undefined || val === null) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveLength"](this.length, null, parent);
        }
        let { encoding } = this;
        if (typeof encoding === 'function') {
            encoding = encoding.call(parent != null ? parent.val : undefined, parent != null ? parent.val : undefined) || 'ascii';
        }
        if (encoding === 'utf16be') {
            encoding = 'utf16le';
        }
        let size = byteLength(val, encoding);
        if (this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            size += this.length.size();
        }
        if (this.length == null) {
            size += encodingWidth(encoding);
        }
        return size;
    }
    encode(stream, val, parent) {
        let { encoding } = this;
        if (typeof encoding === 'function') {
            encoding = encoding.call(parent != null ? parent.val : undefined, parent != null ? parent.val : undefined) || 'ascii';
        }
        if (this.length instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Number"]) {
            this.length.encode(stream, byteLength(val, encoding));
        }
        stream.writeString(val, encoding);
        if (this.length == null) {
            return encodingWidth(encoding) == 2 ? stream.writeUInt16LE(0x0000) : stream.writeUInt8(0x00);
        }
    }
}
function encodingWidth(encoding) {
    switch(encoding){
        case 'ascii':
        case 'utf8':
            return 1;
        case 'utf16le':
        case 'utf16-le':
        case 'utf-16be':
        case 'utf-16le':
        case 'utf16be':
        case 'utf16-be':
        case 'ucs2':
            return 2;
        default:
            //TODO: assume all other encodings are 1-byters
            //throw new Error('Unknown encoding ' + encoding);
            return 1;
    }
}
function byteLength(string, encoding) {
    switch(encoding){
        case 'ascii':
            return string.length;
        case 'utf8':
            let len = 0;
            for(let i = 0; i < string.length; i++){
                let c = string.charCodeAt(i);
                if (c >= 0xd800 && c <= 0xdbff && i < string.length - 1) {
                    let c2 = string.charCodeAt(++i);
                    if ((c2 & 0xfc00) === 0xdc00) {
                        c = ((c & 0x3ff) << 10) + (c2 & 0x3ff) + 0x10000;
                    } else {
                        // unmatched surrogate.
                        i--;
                    }
                }
                if ((c & 0xffffff80) === 0) {
                    len++;
                } else if ((c & 0xfffff800) === 0) {
                    len += 2;
                } else if ((c & 0xffff0000) === 0) {
                    len += 3;
                } else if ((c & 0xffe00000) === 0) {
                    len += 4;
                }
            }
            return len;
        case 'utf16le':
        case 'utf16-le':
        case 'utf16be':
        case 'utf16-be':
        case 'ucs2':
            return string.length * 2;
        default:
            throw new Error('Unknown encoding ' + encoding);
    }
}
;
}),
"[project]/node_modules/restructure/src/Struct.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Struct",
    ()=>Struct
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/utils.js [app-client] (ecmascript)");
;
;
class Struct extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(fields = {}){
        super();
        this.fields = fields;
    }
    decode(stream, parent, length = 0) {
        const res = this._setup(stream, parent, length);
        this._parseFields(stream, res, this.fields);
        if (this.process != null) {
            this.process.call(res, stream);
        }
        return res;
    }
    _setup(stream, parent, length) {
        const res = {};
        // define hidden properties
        Object.defineProperties(res, {
            parent: {
                value: parent
            },
            _startOffset: {
                value: stream.pos
            },
            _currentOffset: {
                value: 0,
                writable: true
            },
            _length: {
                value: length
            }
        });
        return res;
    }
    _parseFields(stream, res, fields) {
        for(let key in fields){
            var val;
            const type = fields[key];
            if (typeof type === 'function') {
                val = type.call(res, res);
            } else {
                val = type.decode(stream, res);
            }
            if (val !== undefined) {
                if (val instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PropertyDescriptor"]) {
                    Object.defineProperty(res, key, val);
                } else {
                    res[key] = val;
                }
            }
            res._currentOffset = stream.pos - res._startOffset;
        }
    }
    size(val, parent, includePointers = true) {
        if (val == null) {
            val = {};
        }
        const ctx = {
            parent,
            val,
            pointerSize: 0
        };
        if (this.preEncode != null) {
            this.preEncode.call(val);
        }
        let size = 0;
        for(let key in this.fields){
            const type = this.fields[key];
            if (type.size != null) {
                size += type.size(val[key], ctx);
            }
        }
        if (includePointers) {
            size += ctx.pointerSize;
        }
        return size;
    }
    encode(stream, val, parent) {
        let type;
        if (this.preEncode != null) {
            this.preEncode.call(val, stream);
        }
        const ctx = {
            pointers: [],
            startOffset: stream.pos,
            parent,
            val,
            pointerSize: 0
        };
        ctx.pointerOffset = stream.pos + this.size(val, ctx, false);
        for(let key in this.fields){
            type = this.fields[key];
            if (type.encode != null) {
                type.encode(stream, val[key], ctx);
            }
        }
        let i = 0;
        while(i < ctx.pointers.length){
            const ptr = ctx.pointers[i++];
            ptr.type.encode(stream, ptr.val, ptr.parent);
        }
    }
}
}),
"[project]/node_modules/restructure/src/VersionedStruct.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VersionedStruct",
    ()=>VersionedStruct
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Struct.js [app-client] (ecmascript)");
;
const getPath = (object, pathArray)=>{
    return pathArray.reduce((prevObj, key)=>prevObj && prevObj[key], object);
};
class VersionedStruct extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Struct"] {
    constructor(type, versions = {}){
        super();
        this.type = type;
        this.versions = versions;
        if (typeof type === 'string') {
            this.versionPath = type.split('.');
        }
    }
    decode(stream, parent, length = 0) {
        const res = this._setup(stream, parent, length);
        if (typeof this.type === 'string') {
            res.version = getPath(parent, this.versionPath);
        } else {
            res.version = this.type.decode(stream);
        }
        if (this.versions.header) {
            this._parseFields(stream, res, this.versions.header);
        }
        const fields = this.versions[res.version];
        if (fields == null) {
            throw new Error(`Unknown version ${res.version}`);
        }
        if (fields instanceof VersionedStruct) {
            return fields.decode(stream, parent);
        }
        this._parseFields(stream, res, fields);
        if (this.process != null) {
            this.process.call(res, stream);
        }
        return res;
    }
    size(val, parent, includePointers = true) {
        let key, type;
        if (!val) {
            throw new Error('Not a fixed size');
        }
        if (this.preEncode != null) {
            this.preEncode.call(val);
        }
        const ctx = {
            parent,
            val,
            pointerSize: 0
        };
        let size = 0;
        if (typeof this.type !== 'string') {
            size += this.type.size(val.version, ctx);
        }
        if (this.versions.header) {
            for(key in this.versions.header){
                type = this.versions.header[key];
                if (type.size != null) {
                    size += type.size(val[key], ctx);
                }
            }
        }
        const fields = this.versions[val.version];
        if (fields == null) {
            throw new Error(`Unknown version ${val.version}`);
        }
        for(key in fields){
            type = fields[key];
            if (type.size != null) {
                size += type.size(val[key], ctx);
            }
        }
        if (includePointers) {
            size += ctx.pointerSize;
        }
        return size;
    }
    encode(stream, val, parent) {
        let key, type;
        if (this.preEncode != null) {
            this.preEncode.call(val, stream);
        }
        const ctx = {
            pointers: [],
            startOffset: stream.pos,
            parent,
            val,
            pointerSize: 0
        };
        ctx.pointerOffset = stream.pos + this.size(val, ctx, false);
        if (typeof this.type !== 'string') {
            this.type.encode(stream, val.version);
        }
        if (this.versions.header) {
            for(key in this.versions.header){
                type = this.versions.header[key];
                if (type.encode != null) {
                    type.encode(stream, val[key], ctx);
                }
            }
        }
        const fields = this.versions[val.version];
        for(key in fields){
            type = fields[key];
            if (type.encode != null) {
                type.encode(stream, val[key], ctx);
            }
        }
        let i = 0;
        while(i < ctx.pointers.length){
            const ptr = ctx.pointers[i++];
            ptr.type.encode(stream, ptr.val, ptr.parent);
        }
    }
}
}),
"[project]/node_modules/restructure/src/Pointer.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Pointer",
    ()=>Pointer,
    "VoidPointer",
    ()=>VoidPointer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Base.js [app-client] (ecmascript)");
;
;
class Pointer extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Base$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Base"] {
    constructor(offsetType, type, options = {}){
        super();
        this.offsetType = offsetType;
        this.type = type;
        this.options = options;
        if (this.type === 'void') {
            this.type = null;
        }
        if (this.options.type == null) {
            this.options.type = 'local';
        }
        if (this.options.allowNull == null) {
            this.options.allowNull = true;
        }
        if (this.options.nullValue == null) {
            this.options.nullValue = 0;
        }
        if (this.options.lazy == null) {
            this.options.lazy = false;
        }
        if (this.options.relativeTo) {
            if (typeof this.options.relativeTo !== 'function') {
                throw new Error('relativeTo option must be a function');
            }
            this.relativeToGetter = options.relativeTo;
        }
    }
    decode(stream, ctx) {
        const offset = this.offsetType.decode(stream, ctx);
        // handle NULL pointers
        if (offset === this.options.nullValue && this.options.allowNull) {
            return null;
        }
        let relative;
        switch(this.options.type){
            case 'local':
                relative = ctx._startOffset;
                break;
            case 'immediate':
                relative = stream.pos - this.offsetType.size();
                break;
            case 'parent':
                relative = ctx.parent._startOffset;
                break;
            default:
                var c = ctx;
                while(c.parent){
                    c = c.parent;
                }
                relative = c._startOffset || 0;
        }
        if (this.options.relativeTo) {
            relative += this.relativeToGetter(ctx);
        }
        const ptr = offset + relative;
        if (this.type != null) {
            let val = null;
            const decodeValue = ()=>{
                if (val != null) {
                    return val;
                }
                const { pos } = stream;
                stream.pos = ptr;
                val = this.type.decode(stream, ctx);
                stream.pos = pos;
                return val;
            };
            // If this is a lazy pointer, define a getter to decode only when needed.
            // This obviously only works when the pointer is contained by a Struct.
            if (this.options.lazy) {
                return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PropertyDescriptor"]({
                    get: decodeValue
                });
            }
            return decodeValue();
        } else {
            return ptr;
        }
    }
    size(val, ctx) {
        const parent = ctx;
        switch(this.options.type){
            case 'local':
            case 'immediate':
                break;
            case 'parent':
                ctx = ctx.parent;
                break;
            default:
                while(ctx.parent){
                    ctx = ctx.parent;
                }
        }
        let { type } = this;
        if (type == null) {
            if (!(val instanceof VoidPointer)) {
                throw new Error("Must be a VoidPointer");
            }
            ({ type } = val);
            val = val.value;
        }
        if (val && ctx) {
            // Must be written as two separate lines rather than += in case `type.size` mutates ctx.pointerSize.
            let size = type.size(val, parent);
            ctx.pointerSize += size;
        }
        return this.offsetType.size();
    }
    encode(stream, val, ctx) {
        let relative;
        const parent = ctx;
        if (val == null) {
            this.offsetType.encode(stream, this.options.nullValue);
            return;
        }
        switch(this.options.type){
            case 'local':
                relative = ctx.startOffset;
                break;
            case 'immediate':
                relative = stream.pos + this.offsetType.size(val, parent);
                break;
            case 'parent':
                ctx = ctx.parent;
                relative = ctx.startOffset;
                break;
            default:
                relative = 0;
                while(ctx.parent){
                    ctx = ctx.parent;
                }
        }
        if (this.options.relativeTo) {
            relative += this.relativeToGetter(parent.val);
        }
        this.offsetType.encode(stream, ctx.pointerOffset - relative);
        let { type } = this;
        if (type == null) {
            if (!(val instanceof VoidPointer)) {
                throw new Error("Must be a VoidPointer");
            }
            ({ type } = val);
            val = val.value;
        }
        ctx.pointers.push({
            type,
            val,
            parent
        });
        return ctx.pointerOffset += type.size(val, parent);
    }
}
class VoidPointer {
    constructor(type, value){
        this.type = type;
        this.value = value;
    }
}
}),
"[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$EncodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/EncodeStream.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$DecodeStream$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/DecodeStream.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Array.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$LazyArray$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/LazyArray.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Bitfield$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Bitfield.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Boolean$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Boolean.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Buffer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Enum$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Enum.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Optional$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Optional.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Reserved$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Reserved.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$String$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/String.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Struct.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$VersionedStruct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/VersionedStruct.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/utils.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Pointer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Pointer.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
}),
"[project]/node_modules/next/node_modules/@swc/helpers/esm/_define_property.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>_define_property
]);
function _define_property(obj, key, value) {
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else obj[key] = value;
    return obj;
}
;
}),
"[project]/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__addDisposableResource",
    ()=>__addDisposableResource,
    "__assign",
    ()=>__assign,
    "__asyncDelegator",
    ()=>__asyncDelegator,
    "__asyncGenerator",
    ()=>__asyncGenerator,
    "__asyncValues",
    ()=>__asyncValues,
    "__await",
    ()=>__await,
    "__awaiter",
    ()=>__awaiter,
    "__classPrivateFieldGet",
    ()=>__classPrivateFieldGet,
    "__classPrivateFieldIn",
    ()=>__classPrivateFieldIn,
    "__classPrivateFieldSet",
    ()=>__classPrivateFieldSet,
    "__createBinding",
    ()=>__createBinding,
    "__decorate",
    ()=>__decorate,
    "__disposeResources",
    ()=>__disposeResources,
    "__esDecorate",
    ()=>__esDecorate,
    "__exportStar",
    ()=>__exportStar,
    "__extends",
    ()=>__extends,
    "__generator",
    ()=>__generator,
    "__importDefault",
    ()=>__importDefault,
    "__importStar",
    ()=>__importStar,
    "__makeTemplateObject",
    ()=>__makeTemplateObject,
    "__metadata",
    ()=>__metadata,
    "__param",
    ()=>__param,
    "__propKey",
    ()=>__propKey,
    "__read",
    ()=>__read,
    "__rest",
    ()=>__rest,
    "__rewriteRelativeImportExtension",
    ()=>__rewriteRelativeImportExtension,
    "__runInitializers",
    ()=>__runInitializers,
    "__setFunctionName",
    ()=>__setFunctionName,
    "__spread",
    ()=>__spread,
    "__spreadArray",
    ()=>__spreadArray,
    "__spreadArrays",
    ()=>__spreadArrays,
    "__values",
    ()=>__values,
    "default",
    ()=>__TURBOPACK__default__export__
]);
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */ /* global Reflect, Promise, SuppressedError, Symbol, Iterator */ var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(d, b) {
        d.__proto__ = b;
    } || function(d, b) {
        for(var p in b)if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
    };
    return extendStatics(d, b);
};
function __extends(d, b) {
    if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
        this.constructor = d;
    }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for(var s, i = 1, n = arguments.length; i < n; i++){
            s = arguments[i];
            for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
function __rest(s, e) {
    var t = {};
    for(var p in s)if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function") for(var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++){
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
}
function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for(var i = decorators.length - 1; i >= 0; i--)if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}
function __param(paramIndex, decorator) {
    return function(target, key) {
        decorator(target, key, paramIndex);
    };
}
function __esDecorate(ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) {
        if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected");
        return f;
    }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for(var i = decorators.length - 1; i >= 0; i--){
        var context = {};
        for(var p in contextIn)context[p] = p === "access" ? {} : contextIn[p];
        for(var p in contextIn.access)context.access[p] = contextIn.access[p];
        context.addInitializer = function(f) {
            if (done) throw new TypeError("Cannot add initializers after decoration has completed");
            extraInitializers.push(accept(f || null));
        };
        var result = (0, decorators[i])(kind === "accessor" ? {
            get: descriptor.get,
            set: descriptor.set
        } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        } else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
}
;
function __runInitializers(thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for(var i = 0; i < initializers.length; i++){
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
}
;
function __propKey(x) {
    return typeof x === "symbol" ? x : "".concat(x);
}
;
function __setFunctionName(f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", {
        configurable: true,
        value: prefix ? "".concat(prefix, " ", name) : name
    });
}
;
function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}
function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) {
        return value instanceof P ? value : new P(function(resolve) {
            resolve(value);
        });
    }
    return new (P || (P = Promise))(function(resolve, reject) {
        function fulfilled(value) {
            try {
                step(generator.next(value));
            } catch (e) {
                reject(e);
            }
        }
        function rejected(value) {
            try {
                step(generator["throw"](value));
            } catch (e) {
                reject(e);
            }
        }
        function step(result) {
            result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
        }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}
function __generator(thisArg, body) {
    var _ = {
        label: 0,
        sent: function() {
            if (t[0] & 1) throw t[1];
            return t[1];
        },
        trys: [],
        ops: []
    }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
        return this;
    }), g;
    //TURBOPACK unreachable
    ;
    function verb(n) {
        return function(v) {
            return step([
                n,
                v
            ]);
        };
    }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while(g && (g = 0, op[0] && (_ = 0)), _)try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [
                op[0] & 2,
                t.value
            ];
            switch(op[0]){
                case 0:
                case 1:
                    t = op;
                    break;
                case 4:
                    _.label++;
                    return {
                        value: op[1],
                        done: false
                    };
                case 5:
                    _.label++;
                    y = op[1];
                    op = [
                        0
                    ];
                    continue;
                case 7:
                    op = _.ops.pop();
                    _.trys.pop();
                    continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                        _ = 0;
                        continue;
                    }
                    if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                        _.label = op[1];
                        break;
                    }
                    if (op[0] === 6 && _.label < t[1]) {
                        _.label = t[1];
                        t = op;
                        break;
                    }
                    if (t && _.label < t[2]) {
                        _.label = t[2];
                        _.ops.push(op);
                        break;
                    }
                    if (t[2]) _.ops.pop();
                    _.trys.pop();
                    continue;
            }
            op = body.call(thisArg, _);
        } catch (e) {
            op = [
                6,
                e
            ];
            y = 0;
        } finally{
            f = t = 0;
        }
        if (op[0] & 5) throw op[1];
        return {
            value: op[0] ? op[1] : void 0,
            done: true
        };
    }
}
var __createBinding = Object.create ? function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
            enumerable: true,
            get: function() {
                return m[k];
            }
        };
    }
    Object.defineProperty(o, k2, desc);
} : function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
};
function __exportStar(m, o) {
    for(var p in m)if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}
function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function() {
            if (o && i >= o.length) o = void 0;
            return {
                value: o && o[i++],
                done: !o
            };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while((n === void 0 || n-- > 0) && !(r = i.next()).done)ar.push(r.value);
    } catch (error) {
        e = {
            error: error
        };
    } finally{
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        } finally{
            if (e) throw e.error;
        }
    }
    return ar;
}
function __spread() {
    for(var ar = [], i = 0; i < arguments.length; i++)ar = ar.concat(__read(arguments[i]));
    return ar;
}
function __spreadArrays() {
    for(var s = 0, i = 0, il = arguments.length; i < il; i++)s += arguments[i].length;
    for(var r = Array(s), k = 0, i = 0; i < il; i++)for(var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)r[k] = a[j];
    return r;
}
function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for(var i = 0, l = from.length, ar; i < l; i++){
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}
function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}
function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function() {
        return this;
    }, i;
    //TURBOPACK unreachable
    ;
    function awaitReturn(f) {
        return function(v) {
            return Promise.resolve(v).then(f, reject);
        };
    }
    function verb(n, f) {
        if (g[n]) {
            i[n] = function(v) {
                return new Promise(function(a, b) {
                    q.push([
                        n,
                        v,
                        a,
                        b
                    ]) > 1 || resume(n, v);
                });
            };
            if (f) i[n] = f(i[n]);
        }
    }
    function resume(n, v) {
        try {
            step(g[n](v));
        } catch (e) {
            settle(q[0][3], e);
        }
    }
    function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }
    function fulfill(value) {
        resume("next", value);
    }
    function reject(value) {
        resume("throw", value);
    }
    function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
}
function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function(e) {
        throw e;
    }), verb("return"), i[Symbol.iterator] = function() {
        return this;
    }, i;
    //TURBOPACK unreachable
    ;
    function verb(n, f) {
        i[n] = o[n] ? function(v) {
            return (p = !p) ? {
                value: __await(o[n](v)),
                done: false
            } : f ? f(v) : v;
        } : f;
    }
}
function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
        return this;
    }, i);
    //TURBOPACK unreachable
    ;
    function verb(n) {
        i[n] = o[n] && function(v) {
            return new Promise(function(resolve, reject) {
                v = o[n](v), settle(resolve, reject, v.done, v.value);
            });
        };
    }
    function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function(v) {
            resolve({
                value: v,
                done: d
            });
        }, reject);
    }
}
function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
            value: raw
        });
    } else {
        cooked.raw = raw;
    }
    return cooked;
}
;
var __setModuleDefault = Object.create ? function(o, v) {
    Object.defineProperty(o, "default", {
        enumerable: true,
        value: v
    });
} : function(o, v) {
    o["default"] = v;
};
var ownKeys = function(o) {
    ownKeys = Object.getOwnPropertyNames || function(o) {
        var ar = [];
        for(var k in o)if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
        return ar;
    };
    return ownKeys(o);
};
function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) {
        for(var k = ownKeys(mod), i = 0; i < k.length; i++)if (k[i] !== "default") __createBinding(result, mod, k[i]);
    }
    __setModuleDefault(result, mod);
    return result;
}
function __importDefault(mod) {
    return mod && mod.__esModule ? mod : {
        default: mod
    };
}
function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}
function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
}
function __classPrivateFieldIn(state, receiver) {
    if (receiver === null || typeof receiver !== "object" && typeof receiver !== "function") throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof state === "function" ? receiver === state : state.has(receiver);
}
function __addDisposableResource(env, value, async) {
    if (value !== null && value !== void 0) {
        if (typeof value !== "object" && typeof value !== "function") throw new TypeError("Object expected.");
        var dispose, inner;
        if (async) {
            if (!Symbol.asyncDispose) throw new TypeError("Symbol.asyncDispose is not defined.");
            dispose = value[Symbol.asyncDispose];
        }
        if (dispose === void 0) {
            if (!Symbol.dispose) throw new TypeError("Symbol.dispose is not defined.");
            dispose = value[Symbol.dispose];
            if (async) inner = dispose;
        }
        if (typeof dispose !== "function") throw new TypeError("Object not disposable.");
        if (inner) dispose = function() {
            try {
                inner.call(this);
            } catch (e) {
                return Promise.reject(e);
            }
        };
        env.stack.push({
            value: value,
            dispose: dispose,
            async: async
        });
    } else if (async) {
        env.stack.push({
            async: true
        });
    }
    return value;
}
var _SuppressedError = typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
function __disposeResources(env) {
    function fail(e) {
        env.error = env.hasError ? new _SuppressedError(e, env.error, "An error was suppressed during disposal.") : e;
        env.hasError = true;
    }
    var r, s = 0;
    function next() {
        while(r = env.stack.pop()){
            try {
                if (!r.async && s === 1) return s = 0, env.stack.push(r), Promise.resolve().then(next);
                if (r.dispose) {
                    var result = r.dispose.call(r.value);
                    if (r.async) return s |= 2, Promise.resolve(result).then(next, function(e) {
                        fail(e);
                        return next();
                    });
                } else s |= 1;
            } catch (e) {
                fail(e);
            }
        }
        if (s === 1) return env.hasError ? Promise.reject(env.error) : Promise.resolve();
        if (env.hasError) throw env.error;
    }
    return next();
}
function __rewriteRelativeImportExtension(path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function(m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : d + ext + "." + cm.toLowerCase() + "js";
        });
    }
    return path;
}
const __TURBOPACK__default__export__ = {
    __extends,
    __assign,
    __rest,
    __decorate,
    __param,
    __esDecorate,
    __runInitializers,
    __propKey,
    __setFunctionName,
    __metadata,
    __awaiter,
    __generator,
    __createBinding,
    __exportStar,
    __values,
    __read,
    __spread,
    __spreadArrays,
    __spreadArray,
    __await,
    __asyncGenerator,
    __asyncDelegator,
    __asyncValues,
    __makeTemplateObject,
    __importStar,
    __importDefault,
    __classPrivateFieldGet,
    __classPrivateFieldSet,
    __classPrivateFieldIn,
    __addDisposableResource,
    __disposeResources,
    __rewriteRelativeImportExtension
};
}),
"[project]/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript) <export __decorate as _>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "_",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["__decorate"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tslib$2f$tslib$2e$es6$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tslib/tslib.es6.mjs [app-client] (ecmascript)");
}),
"[project]/node_modules/fast-deep-equal/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

// do not edit .js files directly - edit src/index.jst
module.exports = function equal(a, b) {
    if (a === b) return true;
    if (a && b && typeof a == 'object' && typeof b == 'object') {
        if (a.constructor !== b.constructor) return false;
        var length, i, keys;
        if (Array.isArray(a)) {
            length = a.length;
            if (length != b.length) return false;
            for(i = length; i-- !== 0;)if (!equal(a[i], b[i])) return false;
            return true;
        }
        if (a.constructor === RegExp) return a.source === b.source && a.flags === b.flags;
        if (a.valueOf !== Object.prototype.valueOf) return a.valueOf() === b.valueOf();
        if (a.toString !== Object.prototype.toString) return a.toString() === b.toString();
        keys = Object.keys(a);
        length = keys.length;
        if (length !== Object.keys(b).length) return false;
        for(i = length; i-- !== 0;)if (!Object.prototype.hasOwnProperty.call(b, keys[i])) return false;
        for(i = length; i-- !== 0;){
            var key = keys[i];
            if (!equal(a[key], b[key])) return false;
        }
        return true;
    }
    // true if both NaN, false otherwise
    return a !== a && b !== b;
};
}),
"[project]/node_modules/base64-js/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

exports.byteLength = byteLength;
exports.toByteArray = toByteArray;
exports.fromByteArray = fromByteArray;
var lookup = [];
var revLookup = [];
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array;
var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
for(var i = 0, len = code.length; i < len; ++i){
    lookup[i] = code[i];
    revLookup[code.charCodeAt(i)] = i;
}
// Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications
revLookup['-'.charCodeAt(0)] = 62;
revLookup['_'.charCodeAt(0)] = 63;
function getLens(b64) {
    var len = b64.length;
    if (len % 4 > 0) {
        throw new Error('Invalid string. Length must be a multiple of 4');
    }
    // Trim off extra bytes after placeholder bytes are found
    // See: https://github.com/beatgammit/base64-js/issues/42
    var validLen = b64.indexOf('=');
    if (validLen === -1) validLen = len;
    var placeHoldersLen = validLen === len ? 0 : 4 - validLen % 4;
    return [
        validLen,
        placeHoldersLen
    ];
}
// base64 is 4/3 + up to two characters of the original data
function byteLength(b64) {
    var lens = getLens(b64);
    var validLen = lens[0];
    var placeHoldersLen = lens[1];
    return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
}
function _byteLength(b64, validLen, placeHoldersLen) {
    return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
}
function toByteArray(b64) {
    var tmp;
    var lens = getLens(b64);
    var validLen = lens[0];
    var placeHoldersLen = lens[1];
    var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
    var curByte = 0;
    // if there are placeholders, only get up to the last complete 4 chars
    var len = placeHoldersLen > 0 ? validLen - 4 : validLen;
    var i;
    for(i = 0; i < len; i += 4){
        tmp = revLookup[b64.charCodeAt(i)] << 18 | revLookup[b64.charCodeAt(i + 1)] << 12 | revLookup[b64.charCodeAt(i + 2)] << 6 | revLookup[b64.charCodeAt(i + 3)];
        arr[curByte++] = tmp >> 16 & 0xFF;
        arr[curByte++] = tmp >> 8 & 0xFF;
        arr[curByte++] = tmp & 0xFF;
    }
    if (placeHoldersLen === 2) {
        tmp = revLookup[b64.charCodeAt(i)] << 2 | revLookup[b64.charCodeAt(i + 1)] >> 4;
        arr[curByte++] = tmp & 0xFF;
    }
    if (placeHoldersLen === 1) {
        tmp = revLookup[b64.charCodeAt(i)] << 10 | revLookup[b64.charCodeAt(i + 1)] << 4 | revLookup[b64.charCodeAt(i + 2)] >> 2;
        arr[curByte++] = tmp >> 8 & 0xFF;
        arr[curByte++] = tmp & 0xFF;
    }
    return arr;
}
function tripletToBase64(num) {
    return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F];
}
function encodeChunk(uint8, start, end) {
    var tmp;
    var output = [];
    for(var i = start; i < end; i += 3){
        tmp = (uint8[i] << 16 & 0xFF0000) + (uint8[i + 1] << 8 & 0xFF00) + (uint8[i + 2] & 0xFF);
        output.push(tripletToBase64(tmp));
    }
    return output.join('');
}
function fromByteArray(uint8) {
    var tmp;
    var len = uint8.length;
    var extraBytes = len % 3 // if we have 1 byte left, pad 2 bytes
    ;
    var parts = [];
    var maxChunkLength = 16383 // must be multiple of 3
    ;
    // go through the array every three bytes, we'll deal with trailing stuff later
    for(var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength){
        parts.push(encodeChunk(uint8, i, i + maxChunkLength > len2 ? len2 : i + maxChunkLength));
    }
    // pad the end with zeros, but make sure to not forget the extra bytes
    if (extraBytes === 1) {
        tmp = uint8[len - 1];
        parts.push(lookup[tmp >> 2] + lookup[tmp << 4 & 0x3F] + '==');
    } else if (extraBytes === 2) {
        tmp = (uint8[len - 2] << 8) + uint8[len - 1];
        parts.push(lookup[tmp >> 10] + lookup[tmp >> 4 & 0x3F] + lookup[tmp << 2 & 0x3F] + '=');
    }
    return parts.join('');
}
}),
"[project]/node_modules/linebreak/node_modules/base64-js/lib/b64.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var lookup = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
;
(function(exports1) {
    'use strict';
    var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array;
    var PLUS = '+'.charCodeAt(0);
    var SLASH = '/'.charCodeAt(0);
    var NUMBER = '0'.charCodeAt(0);
    var LOWER = 'a'.charCodeAt(0);
    var UPPER = 'A'.charCodeAt(0);
    var PLUS_URL_SAFE = '-'.charCodeAt(0);
    var SLASH_URL_SAFE = '_'.charCodeAt(0);
    function decode(elt) {
        var code = elt.charCodeAt(0);
        if (code === PLUS || code === PLUS_URL_SAFE) return 62 // '+'
        ;
        if (code === SLASH || code === SLASH_URL_SAFE) return 63 // '/'
        ;
        if (code < NUMBER) return -1 //no match
        ;
        if (code < NUMBER + 10) return code - NUMBER + 26 + 26;
        if (code < UPPER + 26) return code - UPPER;
        if (code < LOWER + 26) return code - LOWER + 26;
    }
    function b64ToByteArray(b64) {
        var i, j, l, tmp, placeHolders, arr;
        if (b64.length % 4 > 0) {
            throw new Error('Invalid string. Length must be a multiple of 4');
        }
        // the number of equal signs (place holders)
        // if there are two placeholders, than the two characters before it
        // represent one byte
        // if there is only one, then the three characters before it represent 2 bytes
        // this is just a cheap hack to not do indexOf twice
        var len = b64.length;
        placeHolders = '=' === b64.charAt(len - 2) ? 2 : '=' === b64.charAt(len - 1) ? 1 : 0;
        // base64 is 4/3 + up to two characters of the original data
        arr = new Arr(b64.length * 3 / 4 - placeHolders);
        // if there are placeholders, only get up to the last complete 4 chars
        l = placeHolders > 0 ? b64.length - 4 : b64.length;
        var L = 0;
        function push(v) {
            arr[L++] = v;
        }
        for(i = 0, j = 0; i < l; i += 4, j += 3){
            tmp = decode(b64.charAt(i)) << 18 | decode(b64.charAt(i + 1)) << 12 | decode(b64.charAt(i + 2)) << 6 | decode(b64.charAt(i + 3));
            push((tmp & 0xFF0000) >> 16);
            push((tmp & 0xFF00) >> 8);
            push(tmp & 0xFF);
        }
        if (placeHolders === 2) {
            tmp = decode(b64.charAt(i)) << 2 | decode(b64.charAt(i + 1)) >> 4;
            push(tmp & 0xFF);
        } else if (placeHolders === 1) {
            tmp = decode(b64.charAt(i)) << 10 | decode(b64.charAt(i + 1)) << 4 | decode(b64.charAt(i + 2)) >> 2;
            push(tmp >> 8 & 0xFF);
            push(tmp & 0xFF);
        }
        return arr;
    }
    function uint8ToBase64(uint8) {
        var i, extraBytes = uint8.length % 3, output = "", temp, length;
        function encode(num) {
            return lookup.charAt(num);
        }
        function tripletToBase64(num) {
            return encode(num >> 18 & 0x3F) + encode(num >> 12 & 0x3F) + encode(num >> 6 & 0x3F) + encode(num & 0x3F);
        }
        // go through the array every three bytes, we'll deal with trailing stuff later
        for(i = 0, length = uint8.length - extraBytes; i < length; i += 3){
            temp = (uint8[i] << 16) + (uint8[i + 1] << 8) + uint8[i + 2];
            output += tripletToBase64(temp);
        }
        // pad the end with zeros, but make sure to not forget the extra bytes
        switch(extraBytes){
            case 1:
                temp = uint8[uint8.length - 1];
                output += encode(temp >> 2);
                output += encode(temp << 4 & 0x3F);
                output += '==';
                break;
            case 2:
                temp = (uint8[uint8.length - 2] << 8) + uint8[uint8.length - 1];
                output += encode(temp >> 10);
                output += encode(temp >> 4 & 0x3F);
                output += encode(temp << 2 & 0x3F);
                output += '=';
                break;
        }
        return output;
    }
    exports1.toByteArray = b64ToByteArray;
    exports1.fromByteArray = uint8ToBase64;
})(("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : exports);
}),
"[project]/node_modules/tiny-inflate/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var TINF_OK = 0;
var TINF_DATA_ERROR = -3;
function Tree() {
    this.table = new Uint16Array(16); /* table of code length counts */ 
    this.trans = new Uint16Array(288); /* code -> symbol translation table */ 
}
function Data(source, dest) {
    this.source = source;
    this.sourceIndex = 0;
    this.tag = 0;
    this.bitcount = 0;
    this.dest = dest;
    this.destLen = 0;
    this.ltree = new Tree(); /* dynamic length/symbol tree */ 
    this.dtree = new Tree(); /* dynamic distance tree */ 
}
/* --------------------------------------------------- *
 * -- uninitialized global data (static structures) -- *
 * --------------------------------------------------- */ var sltree = new Tree();
var sdtree = new Tree();
/* extra bits and base tables for length codes */ var length_bits = new Uint8Array(30);
var length_base = new Uint16Array(30);
/* extra bits and base tables for distance codes */ var dist_bits = new Uint8Array(30);
var dist_base = new Uint16Array(30);
/* special ordering of code length codes */ var clcidx = new Uint8Array([
    16,
    17,
    18,
    0,
    8,
    7,
    9,
    6,
    10,
    5,
    11,
    4,
    12,
    3,
    13,
    2,
    14,
    1,
    15
]);
/* used by tinf_decode_trees, avoids allocations every call */ var code_tree = new Tree();
var lengths = new Uint8Array(288 + 32);
/* ----------------------- *
 * -- utility functions -- *
 * ----------------------- */ /* build extra bits and base tables */ function tinf_build_bits_base(bits, base, delta, first) {
    var i, sum;
    /* build bits table */ for(i = 0; i < delta; ++i)bits[i] = 0;
    for(i = 0; i < 30 - delta; ++i)bits[i + delta] = i / delta | 0;
    /* build base table */ for(sum = first, i = 0; i < 30; ++i){
        base[i] = sum;
        sum += 1 << bits[i];
    }
}
/* build the fixed huffman trees */ function tinf_build_fixed_trees(lt, dt) {
    var i;
    /* build fixed length tree */ for(i = 0; i < 7; ++i)lt.table[i] = 0;
    lt.table[7] = 24;
    lt.table[8] = 152;
    lt.table[9] = 112;
    for(i = 0; i < 24; ++i)lt.trans[i] = 256 + i;
    for(i = 0; i < 144; ++i)lt.trans[24 + i] = i;
    for(i = 0; i < 8; ++i)lt.trans[24 + 144 + i] = 280 + i;
    for(i = 0; i < 112; ++i)lt.trans[24 + 144 + 8 + i] = 144 + i;
    /* build fixed distance tree */ for(i = 0; i < 5; ++i)dt.table[i] = 0;
    dt.table[5] = 32;
    for(i = 0; i < 32; ++i)dt.trans[i] = i;
}
/* given an array of code lengths, build a tree */ var offs = new Uint16Array(16);
function tinf_build_tree(t, lengths, off, num) {
    var i, sum;
    /* clear code length count table */ for(i = 0; i < 16; ++i)t.table[i] = 0;
    /* scan symbol lengths, and sum code length counts */ for(i = 0; i < num; ++i)t.table[lengths[off + i]]++;
    t.table[0] = 0;
    /* compute offset table for distribution sort */ for(sum = 0, i = 0; i < 16; ++i){
        offs[i] = sum;
        sum += t.table[i];
    }
    /* create code->symbol translation table (symbols sorted by code) */ for(i = 0; i < num; ++i){
        if (lengths[off + i]) t.trans[offs[lengths[off + i]]++] = i;
    }
}
/* ---------------------- *
 * -- decode functions -- *
 * ---------------------- */ /* get one bit from source stream */ function tinf_getbit(d) {
    /* check if tag is empty */ if (!d.bitcount--) {
        /* load next tag */ d.tag = d.source[d.sourceIndex++];
        d.bitcount = 7;
    }
    /* shift bit out of tag */ var bit = d.tag & 1;
    d.tag >>>= 1;
    return bit;
}
/* read a num bit value from a stream and add base */ function tinf_read_bits(d, num, base) {
    if (!num) return base;
    while(d.bitcount < 24){
        d.tag |= d.source[d.sourceIndex++] << d.bitcount;
        d.bitcount += 8;
    }
    var val = d.tag & 0xffff >>> 16 - num;
    d.tag >>>= num;
    d.bitcount -= num;
    return val + base;
}
/* given a data stream and a tree, decode a symbol */ function tinf_decode_symbol(d, t) {
    while(d.bitcount < 24){
        d.tag |= d.source[d.sourceIndex++] << d.bitcount;
        d.bitcount += 8;
    }
    var sum = 0, cur = 0, len = 0;
    var tag = d.tag;
    /* get more bits while code value is above sum */ do {
        cur = 2 * cur + (tag & 1);
        tag >>>= 1;
        ++len;
        sum += t.table[len];
        cur -= t.table[len];
    }while (cur >= 0)
    d.tag = tag;
    d.bitcount -= len;
    return t.trans[sum + cur];
}
/* given a data stream, decode dynamic trees from it */ function tinf_decode_trees(d, lt, dt) {
    var hlit, hdist, hclen;
    var i, num, length;
    /* get 5 bits HLIT (257-286) */ hlit = tinf_read_bits(d, 5, 257);
    /* get 5 bits HDIST (1-32) */ hdist = tinf_read_bits(d, 5, 1);
    /* get 4 bits HCLEN (4-19) */ hclen = tinf_read_bits(d, 4, 4);
    for(i = 0; i < 19; ++i)lengths[i] = 0;
    /* read code lengths for code length alphabet */ for(i = 0; i < hclen; ++i){
        /* get 3 bits code length (0-7) */ var clen = tinf_read_bits(d, 3, 0);
        lengths[clcidx[i]] = clen;
    }
    /* build code length tree */ tinf_build_tree(code_tree, lengths, 0, 19);
    /* decode code lengths for the dynamic trees */ for(num = 0; num < hlit + hdist;){
        var sym = tinf_decode_symbol(d, code_tree);
        switch(sym){
            case 16:
                /* copy previous code length 3-6 times (read 2 bits) */ var prev = lengths[num - 1];
                for(length = tinf_read_bits(d, 2, 3); length; --length){
                    lengths[num++] = prev;
                }
                break;
            case 17:
                /* repeat code length 0 for 3-10 times (read 3 bits) */ for(length = tinf_read_bits(d, 3, 3); length; --length){
                    lengths[num++] = 0;
                }
                break;
            case 18:
                /* repeat code length 0 for 11-138 times (read 7 bits) */ for(length = tinf_read_bits(d, 7, 11); length; --length){
                    lengths[num++] = 0;
                }
                break;
            default:
                /* values 0-15 represent the actual code lengths */ lengths[num++] = sym;
                break;
        }
    }
    /* build dynamic trees */ tinf_build_tree(lt, lengths, 0, hlit);
    tinf_build_tree(dt, lengths, hlit, hdist);
}
/* ----------------------------- *
 * -- block inflate functions -- *
 * ----------------------------- */ /* given a stream and two trees, inflate a block of data */ function tinf_inflate_block_data(d, lt, dt) {
    while(1){
        var sym = tinf_decode_symbol(d, lt);
        /* check for end of block */ if (sym === 256) {
            return TINF_OK;
        }
        if (sym < 256) {
            d.dest[d.destLen++] = sym;
        } else {
            var length, dist, offs;
            var i;
            sym -= 257;
            /* possibly get more bits from length code */ length = tinf_read_bits(d, length_bits[sym], length_base[sym]);
            dist = tinf_decode_symbol(d, dt);
            /* possibly get more bits from distance code */ offs = d.destLen - tinf_read_bits(d, dist_bits[dist], dist_base[dist]);
            /* copy match */ for(i = offs; i < offs + length; ++i){
                d.dest[d.destLen++] = d.dest[i];
            }
        }
    }
}
/* inflate an uncompressed block of data */ function tinf_inflate_uncompressed_block(d) {
    var length, invlength;
    var i;
    /* unread from bitbuffer */ while(d.bitcount > 8){
        d.sourceIndex--;
        d.bitcount -= 8;
    }
    /* get length */ length = d.source[d.sourceIndex + 1];
    length = 256 * length + d.source[d.sourceIndex];
    /* get one's complement of length */ invlength = d.source[d.sourceIndex + 3];
    invlength = 256 * invlength + d.source[d.sourceIndex + 2];
    /* check length */ if (length !== (~invlength & 0x0000ffff)) return TINF_DATA_ERROR;
    d.sourceIndex += 4;
    /* copy block */ for(i = length; i; --i)d.dest[d.destLen++] = d.source[d.sourceIndex++];
    /* make sure we start next block on a byte boundary */ d.bitcount = 0;
    return TINF_OK;
}
/* inflate stream from source to dest */ function tinf_uncompress(source, dest) {
    var d = new Data(source, dest);
    var bfinal, btype, res;
    do {
        /* read final block flag */ bfinal = tinf_getbit(d);
        /* read block type (2 bits) */ btype = tinf_read_bits(d, 2, 0);
        /* decompress block */ switch(btype){
            case 0:
                /* decompress uncompressed block */ res = tinf_inflate_uncompressed_block(d);
                break;
            case 1:
                /* decompress block with fixed huffman trees */ res = tinf_inflate_block_data(d, sltree, sdtree);
                break;
            case 2:
                /* decompress block with dynamic huffman trees */ tinf_decode_trees(d, d.ltree, d.dtree);
                res = tinf_inflate_block_data(d, d.ltree, d.dtree);
                break;
            default:
                res = TINF_DATA_ERROR;
        }
        if (res !== TINF_OK) throw new Error('Data error');
    }while (!bfinal)
    if (d.destLen < d.dest.length) {
        if (typeof d.dest.slice === 'function') return d.dest.slice(0, d.destLen);
        else return d.dest.subarray(0, d.destLen);
    }
    return d.dest;
}
/* -------------------- *
 * -- initialization -- *
 * -------------------- */ /* build fixed huffman trees */ tinf_build_fixed_trees(sltree, sdtree);
/* build extra bits and base tables */ tinf_build_bits_base(length_bits, length_base, 4, 3);
tinf_build_bits_base(dist_bits, dist_base, 2, 1);
/* fix a special case */ length_bits[28] = 0;
length_base[28] = 258;
module.exports = tinf_uncompress;
}),
"[project]/node_modules/unicode-trie/swap.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const isBigEndian = new Uint8Array(new Uint32Array([
    0x12345678
]).buffer)[0] === 0x12;
const swap = (b, n, m)=>{
    let i = b[n];
    b[n] = b[m];
    b[m] = i;
};
const swap32 = (array)=>{
    const len = array.length;
    for(let i = 0; i < len; i += 4){
        swap(array, i, i + 3);
        swap(array, i + 1, i + 2);
    }
};
const swap32LE = (array)=>{
    if (isBigEndian) {
        swap32(array);
    }
};
module.exports = {
    swap32LE: swap32LE
};
}),
"[project]/node_modules/unicode-trie/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const inflate = __turbopack_context__.r("[project]/node_modules/tiny-inflate/index.js [app-client] (ecmascript)");
const { swap32LE } = __turbopack_context__.r("[project]/node_modules/unicode-trie/swap.js [app-client] (ecmascript)");
// Shift size for getting the index-1 table offset.
const SHIFT_1 = 6 + 5;
// Shift size for getting the index-2 table offset.
const SHIFT_2 = 5;
// Difference between the two shift sizes,
// for getting an index-1 offset from an index-2 offset. 6=11-5
const SHIFT_1_2 = SHIFT_1 - SHIFT_2;
// Number of index-1 entries for the BMP. 32=0x20
// This part of the index-1 table is omitted from the serialized form.
const OMITTED_BMP_INDEX_1_LENGTH = 0x10000 >> SHIFT_1;
// Number of entries in an index-2 block. 64=0x40
const INDEX_2_BLOCK_LENGTH = 1 << SHIFT_1_2;
// Mask for getting the lower bits for the in-index-2-block offset. */
const INDEX_2_MASK = INDEX_2_BLOCK_LENGTH - 1;
// Shift size for shifting left the index array values.
// Increases possible data size with 16-bit index values at the cost
// of compactability.
// This requires data blocks to be aligned by DATA_GRANULARITY.
const INDEX_SHIFT = 2;
// Number of entries in a data block. 32=0x20
const DATA_BLOCK_LENGTH = 1 << SHIFT_2;
// Mask for getting the lower bits for the in-data-block offset.
const DATA_MASK = DATA_BLOCK_LENGTH - 1;
// The part of the index-2 table for U+D800..U+DBFF stores values for
// lead surrogate code _units_ not code _points_.
// Values for lead surrogate code _points_ are indexed with this portion of the table.
// Length=32=0x20=0x400>>SHIFT_2. (There are 1024=0x400 lead surrogates.)
const LSCP_INDEX_2_OFFSET = 0x10000 >> SHIFT_2;
const LSCP_INDEX_2_LENGTH = 0x400 >> SHIFT_2;
// Count the lengths of both BMP pieces. 2080=0x820
const INDEX_2_BMP_LENGTH = LSCP_INDEX_2_OFFSET + LSCP_INDEX_2_LENGTH;
// The 2-byte UTF-8 version of the index-2 table follows at offset 2080=0x820.
// Length 32=0x20 for lead bytes C0..DF, regardless of SHIFT_2.
const UTF8_2B_INDEX_2_OFFSET = INDEX_2_BMP_LENGTH;
const UTF8_2B_INDEX_2_LENGTH = 0x800 >> 6; // U+0800 is the first code point after 2-byte UTF-8
// The index-1 table, only used for supplementary code points, at offset 2112=0x840.
// Variable length, for code points up to highStart, where the last single-value range starts.
// Maximum length 512=0x200=0x100000>>SHIFT_1.
// (For 0x100000 supplementary code points U+10000..U+10ffff.)
//
// The part of the index-2 table for supplementary code points starts
// after this index-1 table.
//
// Both the index-1 table and the following part of the index-2 table
// are omitted completely if there is only BMP data.
const INDEX_1_OFFSET = UTF8_2B_INDEX_2_OFFSET + UTF8_2B_INDEX_2_LENGTH;
// The alignment size of a data block. Also the granularity for compaction.
const DATA_GRANULARITY = 1 << INDEX_SHIFT;
class UnicodeTrie {
    constructor(data){
        const isBuffer = typeof data.readUInt32BE === 'function' && typeof data.slice === 'function';
        if (isBuffer || data instanceof Uint8Array) {
            // read binary format
            let uncompressedLength;
            if (isBuffer) {
                this.highStart = data.readUInt32LE(0);
                this.errorValue = data.readUInt32LE(4);
                uncompressedLength = data.readUInt32LE(8);
                data = data.slice(12);
            } else {
                const view = new DataView(data.buffer);
                this.highStart = view.getUint32(0, true);
                this.errorValue = view.getUint32(4, true);
                uncompressedLength = view.getUint32(8, true);
                data = data.subarray(12);
            }
            // double inflate the actual trie data
            data = inflate(data, new Uint8Array(uncompressedLength));
            data = inflate(data, new Uint8Array(uncompressedLength));
            // swap bytes from little-endian
            swap32LE(data);
            this.data = new Uint32Array(data.buffer);
        } else {
            // pre-parsed data
            ({ data: this.data, highStart: this.highStart, errorValue: this.errorValue } = data);
        }
    }
    get(codePoint) {
        let index;
        if (codePoint < 0 || codePoint > 0x10ffff) {
            return this.errorValue;
        }
        if (codePoint < 0xd800 || codePoint > 0xdbff && codePoint <= 0xffff) {
            // Ordinary BMP code point, excluding leading surrogates.
            // BMP uses a single level lookup.  BMP index starts at offset 0 in the index.
            // data is stored in the index array itself.
            index = (this.data[codePoint >> SHIFT_2] << INDEX_SHIFT) + (codePoint & DATA_MASK);
            return this.data[index];
        }
        if (codePoint <= 0xffff) {
            // Lead Surrogate Code Point.  A Separate index section is stored for
            // lead surrogate code units and code points.
            //   The main index has the code unit data.
            //   For this function, we need the code point data.
            index = (this.data[LSCP_INDEX_2_OFFSET + (codePoint - 0xd800 >> SHIFT_2)] << INDEX_SHIFT) + (codePoint & DATA_MASK);
            return this.data[index];
        }
        if (codePoint < this.highStart) {
            // Supplemental code point, use two-level lookup.
            index = this.data[INDEX_1_OFFSET - OMITTED_BMP_INDEX_1_LENGTH + (codePoint >> SHIFT_1)];
            index = this.data[index + (codePoint >> SHIFT_2 & INDEX_2_MASK)];
            index = (index << INDEX_SHIFT) + (codePoint & DATA_MASK);
            return this.data[index];
        }
        return this.data[this.data.length - DATA_GRANULARITY];
    }
}
module.exports = UnicodeTrie;
}),
"[project]/node_modules/unicode-properties/dist/module.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$747425b437e121da$export$2e2bcd8739ae039,
    "getCategory",
    ()=>$747425b437e121da$export$410364bbb673ddbc,
    "getCombiningClass",
    ()=>$747425b437e121da$export$c03b919c6651ed55,
    "getEastAsianWidth",
    ()=>$747425b437e121da$export$92f6187db8ca6d26,
    "getNumericValue",
    ()=>$747425b437e121da$export$7d1258ebb7625a0d,
    "getScript",
    ()=>$747425b437e121da$export$941569448d136665,
    "isAlphabetic",
    ()=>$747425b437e121da$export$52c8ea63abd07594,
    "isBaseForm",
    ()=>$747425b437e121da$export$a11bdcffe109e74b,
    "isDigit",
    ()=>$747425b437e121da$export$727d9dbc4fbb948f,
    "isLowerCase",
    ()=>$747425b437e121da$export$7b6804e8df61fcf5,
    "isMark",
    ()=>$747425b437e121da$export$e33ad6871e762338,
    "isPunctuation",
    ()=>$747425b437e121da$export$a5b49f4dc6a07d2c,
    "isTitleCase",
    ()=>$747425b437e121da$export$de8b4ee23b2cf823,
    "isUpperCase",
    ()=>$747425b437e121da$export$aebd617640818cda,
    "isWhiteSpace",
    ()=>$747425b437e121da$export$3c52dd84024ae72c
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/base64-js/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$unicode$2d$trie$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/unicode-trie/index.js [app-client] (ecmascript)");
;
;
function $parcel$interopDefault(a) {
    return a && a.__esModule ? a.default : a;
}
var $f4087201da764553$exports = {};
$f4087201da764553$exports = JSON.parse('{"categories":["Cc","Zs","Po","Sc","Ps","Pe","Sm","Pd","Nd","Lu","Sk","Pc","Ll","So","Lo","Pi","Cf","No","Pf","Lt","Lm","Mn","Me","Mc","Nl","Zl","Zp","Cs","Co"],"combiningClasses":["Not_Reordered","Above","Above_Right","Below","Attached_Above_Right","Attached_Below","Overlay","Iota_Subscript","Double_Below","Double_Above","Below_Right","Above_Left","CCC10","CCC11","CCC12","CCC13","CCC14","CCC15","CCC16","CCC17","CCC18","CCC19","CCC20","CCC21","CCC22","CCC23","CCC24","CCC25","CCC30","CCC31","CCC32","CCC27","CCC28","CCC29","CCC33","CCC34","CCC35","CCC36","Nukta","Virama","CCC84","CCC91","CCC103","CCC107","CCC118","CCC122","CCC129","CCC130","CCC132","Attached_Above","Below_Left","Left","Kana_Voicing","CCC26","Right"],"scripts":["Common","Latin","Bopomofo","Inherited","Greek","Coptic","Cyrillic","Armenian","Hebrew","Arabic","Syriac","Thaana","Nko","Samaritan","Mandaic","Devanagari","Bengali","Gurmukhi","Gujarati","Oriya","Tamil","Telugu","Kannada","Malayalam","Sinhala","Thai","Lao","Tibetan","Myanmar","Georgian","Hangul","Ethiopic","Cherokee","Canadian_Aboriginal","Ogham","Runic","Tagalog","Hanunoo","Buhid","Tagbanwa","Khmer","Mongolian","Limbu","Tai_Le","New_Tai_Lue","Buginese","Tai_Tham","Balinese","Sundanese","Batak","Lepcha","Ol_Chiki","Braille","Glagolitic","Tifinagh","Han","Hiragana","Katakana","Yi","Lisu","Vai","Bamum","Syloti_Nagri","Phags_Pa","Saurashtra","Kayah_Li","Rejang","Javanese","Cham","Tai_Viet","Meetei_Mayek","null","Linear_B","Lycian","Carian","Old_Italic","Gothic","Old_Permic","Ugaritic","Old_Persian","Deseret","Shavian","Osmanya","Osage","Elbasan","Caucasian_Albanian","Linear_A","Cypriot","Imperial_Aramaic","Palmyrene","Nabataean","Hatran","Phoenician","Lydian","Meroitic_Hieroglyphs","Meroitic_Cursive","Kharoshthi","Old_South_Arabian","Old_North_Arabian","Manichaean","Avestan","Inscriptional_Parthian","Inscriptional_Pahlavi","Psalter_Pahlavi","Old_Turkic","Old_Hungarian","Hanifi_Rohingya","Old_Sogdian","Sogdian","Elymaic","Brahmi","Kaithi","Sora_Sompeng","Chakma","Mahajani","Sharada","Khojki","Multani","Khudawadi","Grantha","Newa","Tirhuta","Siddham","Modi","Takri","Ahom","Dogra","Warang_Citi","Nandinagari","Zanabazar_Square","Soyombo","Pau_Cin_Hau","Bhaiksuki","Marchen","Masaram_Gondi","Gunjala_Gondi","Makasar","Cuneiform","Egyptian_Hieroglyphs","Anatolian_Hieroglyphs","Mro","Bassa_Vah","Pahawh_Hmong","Medefaidrin","Miao","Tangut","Nushu","Duployan","SignWriting","Nyiakeng_Puachue_Hmong","Wancho","Mende_Kikakui","Adlam"],"eaw":["N","Na","A","W","H","F"]}');
const $747425b437e121da$var$trie = new (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$unicode$2d$trie$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base64$2d$js$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]).toByteArray("AAARAAAAAADwfAEAZXl5ONRt+/5bPVFZimRfKoTQJNm37CGE7Iw0j3UsTWKsoyI7kwyyTiEUzSD7NiEzhWYijH0wMVkHE4Mx49fzfo+3nuP4/fdZjvv+XNd5n/d9nef1WZvmKhTxiZndzDQBSEYQqxqKwnsKvGQucFh+6t6cJ792ePQBZv5S9yXSwkyjf/P4T7mTNnIAv1dOVhMlR9lflbUL9JeJguqsjvG9NTj/wLb566VAURnLo2vvRi89S3gW/33ihh2eXpDn40BIW7REl/7coRKIhAFlAiOtbLDTt6mMb4GzMF1gNnvX/sBxtbsAIjfztCNcQjcNDtLThRvuXu5M5g/CBjaLBE4lJm4qy/oZD97+IJryApcXfgWYlkvWbhfXgujOJKVu8B+ozqTLbxyJ5kNiR75CxDqfBM9eOlDMmGeoZ0iQbbS5VUplIwI+ZNXEKQVJxlwqjhOY7w3XwPesbLK5JZE+Tt4X8q8km0dzInsPPzbscrjBMVjF5mOHSeRdJVgKUjLTHiHqXSPkep8N/zFk8167KLp75f6RndkvzdfB6Uz3MmqvRArzdCbs1/iRZjYPLLF3U8Qs+H+Rb8iK51a6NIV2V9+07uJsTGFWpPz8J++7iRu2B6eAKlK/kujrLthwaD/7a6J5w90TusnH1JMAc+gNrql4aspOUG/RrsxUKmPzhHgP4Bleru+6Vfc/MBjgXVx7who94nPn7MPFrnwQP7g0k0Dq0h2GSKO6fTZ8nLodN1SiOUj/5EL/Xo1DBvRm0wmrh3x6phcJ20/9CuMr5h8WPqXMSasLoLHoufTmE7mzYrs6B0dY7KjuCogKqsvxnxAwXWvd9Puc9PnE8DOHT2INHxRlIyVHrqZahtfV2E/A2PDdtA3ewlRHMtFIBKO/T4IozWTQZ+mb+gdKuk/ZHrqloucKdsOSJmlWTSntWjcxVMjUmroXLM10I6TwDLnBq4LP69TxgVeyGsd8yHvhF8ydPlrNRSNs9EP7WmeuSE7Lu10JbOuQcJw/63sDp68wB9iwP5AO+mBpV0R5VDDeyQUFCel1G+4KHBgEVFS0YK+m2sXLWLuGTlkVAd97WwKKdacjWElRCuDRauf33l/yVcDF6sVPKeTes99FC1NpNWcpieGSV/IbO8PCTy5pbUR1U8lxzf4T+y6fZMxOz3LshkQLeeDSd0WmUrQgajmbktrxsb2AZ0ACw2Vgni+gV/m+KvCRWLg08Clx7uhql+v9XySGcjjOHlsp8vBw/e8HS7dtiqF6T/XcSXuaMW66GF1g4q9YyBadHqy3Y5jin1c7yZos6BBr6dsomSHxiUHanYtcYQwnMMZhRhOnaYJeyJzaRuukyCUh48+e/BUvk/aEfDp8ag+jD64BHxNnQ5v/E7WRk7eLjGV13I3oqy45YNONi/1op1oDr7rPjkhPsTXgUpQtGDPlIs55KhQaic9kSGs/UrZ2QKQOflB8MTEQxRF9pullToWO7Eplan6mcMRFnUu2441yxi23x+KqKlr7RWWsi9ZXMWlr8vfP3llk1m2PRj0yudccxBuoa7VfIgRmnFPGX6Pm1WIfMm/Rm4n/xTn8IGqA0GWuqgu48pEUO0U9nN+ZdIvFpPb7VDPphIfRZxznlHeVFebkd9l+raXy9BpTMcIUIvBfgHEb6ndGo8VUkxpief14KjzFOcaANfgvFpvyY8lE8lE4raHizLpluPzMks1hx/e1Hok5yV0p7qQH7GaYeMzzZTFvRpv6k6iaJ4yNqzBvN8J7B430h2wFm1IBPcqbou33G7/NWPgopl4Mllla6e24L3TOTVNkza2zv3QKuDWTeDpClCEYgTQ+5vEBSQZs/rMF50+sm4jofTgWLqgX1x3TkrDEVaRqfY/xZizFZ3Y8/DFEFD31VSfBQ5raEB6nHnZh6ddehtclQJ8fBrldyIh99LNnV32HzKEej04hk6SYjdauCa4aYW0ru/QxvQRGzLKOAQszf3ixJypTW3WWL6BLSF2EMCMIw7OUvWBC6A/gDc2D1jvBapMCc7ztx6jYczwTKsRLL6dMNXb83HS8kdD0pTMMj161zbVHkU0mhSHo9SlBDDXdN6hDvRGizmohtIyR3ot8tF5iUG4GLNcXeGvBudSFrHu+bVZb9jirNVG+rQPI51A7Hu8/b0UeaIaZ4UgDO68PkYx3PE2HWpKapJ764Kxt5TFYpywMy4DLQqVRy11I7SOLhxUFmqiEK52NaijWArIfCg6qG8q5eSiwRCJb1R7GDJG74TrYgx/lVq7w9++Kh929xSJEaoSse5fUOQg9nMAnIZv+7fwVRcNv3gOHI46Vb5jYUC66PYHO6lS+TOmvEQjuYmx4RkffYGxqZIp/DPWNHAixbRBc+XKE3JEOgs4jIwu/dSAwhydruOGF39co91aTs85JJ3Z/LpXoF43hUwJsb/M1Chzdn8HX8vLXnqWUKvRhNLpfAF4PTFqva1sBQG0J+59HyYfmQ3oa4/sxZdapVLlo/fooxSXi/dOEQWIWq8E0FkttEyTFXR2aNMPINMIzZwCNEheYTVltsdaLkMyKoEUluPNAYCM2IG3br0DLy0fVNWKHtbSKbBjfiw7Lu06gQFalC7RC9BwRMSpLYDUo9pDtDfzwUiPJKLJ2LGcSphWBadOI/iJjNqUHV7ucG8yC6+iNM9QYElqBR7ECFXrcTgWQ3eG/tCWacT9bxIkfmxPmi3vOd36KxihAJA73vWNJ+Y9oapXNscVSVqS5g15xOWND/WuUCcA9YAAg6WFbjHamrblZ5c0L6Zx1X58ZittGcfDKU697QRSqW/g+RofNRyvrWMrBn44cPvkRe2HdTu/Cq01C5/riWPHZyXPKHuSDDdW8c1XPgd6ogvLh20qEIu8c19sqr4ufyHrwh37ZN5MkvY1dsGmEz9pUBTxWrvvhNyODyX2Q1k/fbX/T/vbHNcBrmjgDtvBdtZrVtiIg5iXQuzO/DEMvRX8Mi1zymSlt92BGILeKItjoShJXE/H7xwnf0Iewb8BFieJ9MflEBCQYEDm8eZniiEPfGoaYiiEdhQxHQNr2AuRdmbL9mcl18Kumh+HEZLp6z+j35ML9zTbUwahUZCyQQOgQrGfdfQtaR/OYJ/9dYXb2TWZFMijfCA8Nov4sa5FFDUe1T68h4q08WDE7JbbDiej4utRMR9ontevxlXv6LuJTXt1YEv8bDzEt683PuSsIN0afvu0rcBu9AbXZbkOG3K3AhtqQ28N23lXm7S3Yn6KXmAhBhz+GeorJJ4XxO/b3vZk2LXp42+QvsVxGSNVpfSctIFMTR1bD9t70i6sfNF3WKz/uKDEDCpzzztwhL45lsw89H2IpWN10sXHRlhDse9KCdpP5qNNpU84cTY+aiqswqR8XZ9ea0KbVRwRuOGQU3csAtV2fSbnq47U6es6rKlWLWhg3s/B9C9g+oTyp6RtIldR51OOkP5/6nSy6itUVPcMNOp4M/hDdKOz3uK6srbdxOrc2cJgr1Sg02oBxxSky6V7JaG+ziNwlfqnjnvh2/uq1lKfbp+qpwq/D/5OI5gkFl5CejKGxfc2YVJfGqc4E0x5e9PHK2ukbHNI7/RZV6LNe65apbTGjoCaQls0txPPbmQbCQn+/upCoXRZy9yzorWJvZ0KWcbXlBxU/d5I4ERUTxMuVWhSMmF677LNN7NnLwsmKawXkCgbrpcluOl0WChR1qhtSrxGXHu251dEItYhYX3snvn1gS2uXuzdTxCJjZtjsip0iT2sDC0qMS7Bk9su2NyXjFK5/f5ZoWwofg3DtTyjaFqspnOOTSh8xK/CKUFS57guVEkw9xoQuRCwwEO9Lu9z2vYxSa9NFV8DvSxv2C4WYLYF8Nrc4DzWkzNsk81JJOlZ/LYJrGCoj4MmZpnf3AXmzxT4rtl9jsqljEyedz468SGKdBiQzyz/qWKEhFg45ZczlZZ3KGL3l6sn+3TTa3zMVMhPa1obGp/z+fvY0QXTrJTf1XAT3EtQdUfYYlmWZyvPZ/6rWwU7UOQei7pVE0osgN94Iy+T1+omE6z4Rh2O20FjgBeK2y1mcoFiMDOJvuZPn5Moy9fmFH3wyfKvn4+TwfLvt/lHTTVnvrtoUWRBiQXhiNM8nE6ZoWeux/Z0b2unRcdUzdDpmL7CAgd1ToRXwgmHTZOgiGtVT+xr1QH9ObebRTT4NzL+XSpLuuWp62GqQvJVTPoZOeJCb6gIwd9XHMftQ+Kc08IKKdKQANSJ1a2gve3JdRhO0+tNiYzWAZfd7isoeBu67W7xuK8WX7nhJURld98Inb0t/dWOSau/kDvV4DJo/cImw9AO2Gvq0F2n0M7yIZKL8amMbjYld+qFls7hq8Acvq97K2PrCaomuUiesu7qNanGupEl6J/iem8lyr/NMnsTr6o41PO0yhQh3hPFN0wJP7S830je9iTBLzUNgYH+gUZpROo3rN2qgCI+6GewpX8w8CH+ro6QrWiStqmcMzVa3vEel+3/dDxMp0rDv1Q6wTMS3K64zTT6RWzK1y643im25Ja7X2ePCV2mTswd/4jshZPo4bLnerqIosq/hy2bKUAmVn9n4oun1+a0DIZ56UhVwmZHdUNpLa8gmPvxS1eNvCF1T0wo1wKPdCJi0qOrWz7oYRTzgTtkzEzZn308XSLwUog4OWGKJzCn/3FfF9iA32dZHSv30pRCM3KBY9WZoRhtdK/ChHk6DEQBsfV6tN2o1Cn0mLtPBfnkS+qy1L2xfFe9TQPtDE1Be44RTl82E9hPT2rS2+93LFbzhQQO3C/hD2jRFH3BWWbasAfuMhRJFcTri73eE835y016s22DjoFJ862WvLj69fu2TgSF3RHia9D5DSitlQAXYCnbdqjPkR287Lh6dCHDapos+eFDvcZPP2edPmTFxznJE/EBLoQQ0Qmn9EkZOyJmHxMbvKYb8o21ZHmv5YLqgsEPk9gWZwYQY9wLqGXuax/8QlV5qDaPbq9pLPT1yp+zOWKmraEy1OUJI7zdEcEmvBpbdwLrDCgEb2xX8S/nxZgjK4bRi+pbOmbh8bEeoPvU/L9ndx9kntlDALbdAvp0O8ZC3zSUnFg4cePsw7jxewWvL7HRSBLUn6J7vTH9uld5N76JFPgBCdXGF221oEJk++XfRwXplLSyrVO7HFWBEs99nTazKveW3HpbD4dH/YmdAl+lwbSt8BQWyTG7jAsACI7bPPUU9hI9XUHWqQOuezHzUjnx5Qqs6T1qNHfTTHleDtmqK7flA9a0gz2nycIpz1FHBuWxKNtUeTdqP29Fb3tv+tl5JyBqXoR+vCsdzZwZUhf6Lu8bvkB9yQP4x7GGegB0ym0Lpl03Q7e+C0cDsm9GSDepCDji7nUslLyYyluPfvLyKaDSX4xpR+nVYQjQQn5F8KbY1gbIVLiK1J3mW90zTyR1bqApX2BlWh7KG8LAY9/S9nWC0XXh9pZZo6xuir12T43rkaGfQssbQyIslA7uJnSHOV22NhlNtUo0czxPAsXhh8tIQYaTM4l/yAlZlydTcXhlG22Gs/n3BxKBd/3ZjYwg3NaUurVXhNB+afVnFfNr9TbC9ksNdvwpNfeHanyJ8M6GrIVfLlYAPv0ILe4dn0Z+BJSbJkN7eZY/c6+6ttDYcIDeUKIDXqUSE42Xdh5nRbuaObozjht0HJ5H1e+em+NJi/+8kQlyjCbJpPckwThZeIF9/u7lrVIKNeJLCN/TpPAeXxvd31/CUDWHK9MuP1V1TJgngzi4V0qzS3SW3Qy5UiGHqg02wQa5tsEl9s/X9nNMosgLlUgZSfCBj1DiypLfhr9/r0nR0XY2tmhDOcUS4E7cqa4EJBhzqvpbZa35Q5Iz5EqmhYiOGDAYk606Tv74+KGfPjKVuP15rIzgW0I7/niOu9el/sn2bRye0gV+GrePDRDMHjwO1lEdeXH8N+UTO3IoN18kpI3tPxz+fY+n2MGMSGFHAx/83tKeJOl+2i+f1O9v6FfEDBbqrw+lpM8Anav7zHNr7hE78nXUtPNodMbCnITWA7Ma/IHlZ50F9hWge/wzOvSbtqFVFtkS8Of2nssjZwbSFdU+VO8z6tCEc9UA9ACxT5zIUeSrkBB/v1krOpm7bVMrGxEKfI6LcnpB4D8bvn2hDKGqKrJaVAJuDaBEY3F7eXyqnFWlOoFV/8ZLspZiZd7orXLhd4mhHQgbuKbHjJWUzrnm0Dxw/LJLzXCkh7slMxKo8uxZIWZfdKHlfI7uj3LP6ARAuWdF7ZmZ7daOKqKGbz5LxOggTgS39oEioYmrqkCeUDvbxkBYKeHhcLmMN8dMF01ZMb32IpL/cH8R7VHQSI5I0YfL14g9d7P/6cjB1JXXxbozEDbsrPdmL8ph7QW10jio+v7YsqHKQ6xrBbOVtxU0/nFfzUGZwIBLwyUvg49ii+54nv9FyECBpURnQK4Ox6N7lw5fsjdd5l/2SwBcAHMJoyjO1Pifye2dagaOwCVMqdJWAo77pvBe0zdJcTWu5fdzPNfV2p1pc7/JKQ8zhKkwsOELUDhXygPJ5oR8Vpk2lsCen3D3QOQp2zdrSZHjVBstDF/wWO98rrkQ6/7zt/Drip7OHIug1lomNdmRaHRrjmqeodn22sesQQPgzimPOMqC60a5+i/UYh51uZm+ijWkkaI2xjrBO2558DZNZMiuDQlaVAvBy2wLn/bR3FrNzfnO/9oDztYqxZrr7JMIhqmrochbqmQnKowxW29bpqTaJu7kW1VotC72QkYX8OoDDdMDwV1kJRk3mufgJBzf+iwFRJ7XWQwO5ujVglgFgHtycWiMLx5N+6XU+TulLabWjOzoao03fniUW0xvIJNPbk7CQlFZd/RCOPvgQbLjh5ITE8NVJeKt3HGr6JTnFdIzcVOlEtwqbIIX0IM7saC+4N5047MTJ9+Wn11EhyEPIlwsHE5utCeXRjQzlrR+R1Cf/qDzcNbqLXdk3J7gQ39VUrrEkS/VMWjjg+t2oYrqB0tUZClcUF6+LBC3EQ7KnGIwm/qjZX4GKPtjTX1zQKV6nPAb2t/Rza5IqKRf8i2DFEhV/YSifX0YwsiF6TQnp48Gr65TFq0zUe6LGjiY7fq0LSGKL1VnC6ESI2yxvt3XqBx53B3gSlGFeJcPbUbonW1E9E9m4NfuwPh+t5QjRxX34lvBPVxwQd7aeTd+r9dw5CiP1pt8wMZoMdni7GapYdo6KPgeQKcmlFfq4UYhvV0IBgeiR3RnTMBaqDqpZrTRyLdsp4l0IXZTdErfH0sN3dqBG5vRIx3VgCYcHmmkqJ8Hyu3s9K9uBD1d8cZUEx3qYcF5vsqeRpF1GOg8emeWM2OmBlWPdZ6qAXwm3nENFyh+kvXk132PfWAlN0kb7yh4fz2T7VWUY/hEXX5DvxGABC03XRpyOG8t/u3Gh5tZdpsSV9AWaxJN7zwhVglgII1gV28tUViyqn4UMdIh5t+Ea2zo7PO48oba0TwQbiSZOH4YhD578kPF3reuaP7LujPMsjHmaDuId9XEaZBCJhbXJbRg5VCk3KJpryH/+8S3wdhR47pdFcmpZG2p0Bpjp/VbvalgIZMllYX5L31aMPdt1J7r/7wbixt0Mnz2ZvNGTARHPVD+2O1D8SGpWXlVnP2ekgon55YiinADDynyaXtZDXueVqbuTi8z8cHHK325pgqM+mWZwzHeEreMvhZopAScXM14SJHpGwZyRljMlDvcMm9FZ/1e9+r/puOnpXOtc9Iu2fmgBfEP9cGW1Fzb1rGlfJ08pACtq1ZW18bf2cevebzVeHbaA50G9qoUp39JWdPHbYkPCRXjt4gzlq3Cxge28Mky8MoS/+On72kc+ZI2xBtgJytpAQHQ1zrEddMIVyR5urX6yBNu8v5lKC8eLdGKTJtbgIZ3ZyTzSfWmx9f+cvcJe8yM39K/djkp2aUTE/9m2Lj5jg7b8vdRAer7DO3SyLNHs1CAm5x5iAdh2yGJYivArZbCBNY88Tw+w+C1Tbt7wK3zl2rzTHo/D8/gb3c3mYrnEIEipYqPUcdWjnTsSw471O3EUN7Gtg4NOAs9PJrxm03VuZKa5xwXAYCjt7Gs01Km6T2DhOYUMoFcCSu7Hk1p3yP1eG+M3v3Q5luAze6WwBnZIYO0TCucPWK+UJ36KoJ8Y+vpavhLO8g5ed704IjlQdfemrMu//EvPYXTQSGIPPfiagJS9nMqP5IvkxN9pvuJz7h8carPXTKMq8jnTeL0STan6dnLTAqwIswcIwWDR2KwbGddAVN8SYWRB7kfBfBRkSXzvHlIF8D6jo64kUzYk5o/n8oLjKqat0rdXvQ86MkwQGMnnlcasqPPT2+mVtUGb32KuH6cyZQenrRG11TArcAl27+nvOMBDe++EKHf4YdyGf7mznzOz33cFFGEcv329p4qG2hoaQ8ULiMyVz6ENcxhoqGnFIdupcn7GICQWuw3yO3W8S33mzCcMYJ8ywc7U7rmaQf/W5K63Gr4bVTpXOyOp4tbaPyIaatBNpXqlmQUTSZXjxPr19+73PSaT+QnI35YsWn6WpfJjRtK8vlJZoTSgjaRU39AGCkWOZtifJrnefCrqwTKDFmuWUCukEsYcRrMzCoit28wYpP7kSVjMD8WJYQiNc2blMjuqYegmf6SsfC1jqz8XzghMlOX+gn/MKZmgljszrmehEa4V98VreJDxYvHr3j7IeJB9/sBZV41BWT/AZAjuC5XorlIPnZgBAniBEhanp0/0+qZmEWDpu8ige1hUPIyTo6T6gDEcFhWSoduNh8YSu65KgMOGBw7VlNYzNIgwHtq9KP2yyTVysqX5v12sf7D+vQUdR2dRDvCV40rIInXSLWT/yrC6ExOQxBJwIDbeZcl3z1yR5Rj3l8IGpxspapnvBL+fwupA3b6fkFceID9wgiM1ILB0cHVdvo/R4xg8yqKXT8efl0GnGX1/27FUYeUW2L/GNRGGWVGp3i91oaJkb4rybENHre9a2P5viz/yqk8ngWUUS+Kv+fu+9BLFnfLiLXOFcIeBJLhnayCiuDRSqcx0Qu68gVsGYc6EHD500Fkt+gpDj6gvr884n8wZ5o6q7xtL5wA0beXQnffWYkZrs2NGIRgQbsc5NB302SVx+R4ROvmgZaR8wBcji128BMfJ9kcvJ4DC+bQ57kRmv5yxgU4ngZfn0/JNZ8JBwxjTqS+s9kjJFG1unGUGLwMiIuXUD9EFhNIJuyCEAmVZSIGKH4G6v1gRR1LyzQKH2ZqiI1DnHMoDEZspbDjTeaFIAbSvjSq3A+n46y9hhVM8wIpnARSXyzmOD96d9UXvFroSPgGw1dq2vdEqDq9fJN1EbL2WulNmHkFDvxSO9ZT/RX/Bw2gA/BrF90XrJACereVfbV/YXaKfp77Nmx5NjEIUlxojsy7iN7nBHSZigfsbFyVOX1ZTeCCxvqnRSExP4lk5ZeYlRu9caaa743TWNdchRIhEWwadsBIe245C8clpaZ4zrPsk+OwXzxWCvRRumyNSLW5KWaSJyJU95cwheK76gr7228spZ3hmTtLyrfM2QRFqZFMR8/Q6yWfVgwTdfX2Ry4w3+eAO/5VT5nFb5NlzXPvBEAWrNZ6Q3jbH0RF4vcbp+fDngf/ywpoyNQtjrfvcq93AVb1RDWRghvyqgI2BkMr1rwYi8gizZ0G9GmPpMeqPerAQ0dJbzx+KAFM4IBq6iSLpZHUroeyfd9o5o+4fR2EtsZBoJORQEA4SW0CmeXSnblx2e9QkCHIodyqV6+g5ETEpZsLqnd/Na60EKPX/tQpPEcO+COIBPcQdszDzSiHGyQFPly/7KciUh1u+mFfxTCHGv9nn2WqndGgeGjQ/kr02qmTBX7Hc1qiEvgiSz1Tz/sy7Es29wvn6FrDGPP7asXlhOaiHxOctPvTptFA1kHFUk8bME7SsTSnGbFbUrssxrq70LhoSh5OwvQna+w84XdXhZb2sloJ4ZsCg3j+PrjJL08/JBi5zGd6ud/ZxhmcGKLOXPcNunQq5ESW92iJvfsuRrNYtawWwSmNhPYoFj2QqWNF0ffLpGt/ad24RJ8vkb5sXkpyKXmvFG5Vcdzf/44k3PBL/ojJ52+kWGzOArnyp5f969oV3J2c4Li27Nkova9VwRNVKqN0V+gV+mTHitgkXV30aWd3A1RSildEleiNPA+5cp+3+T7X+xfHiRZXQ1s4FA9TxIcnveQs9JSZ5r5qNmgqlW4zMtZ6rYNvgmyVcywKtu8ZxnSbS5vXlBV+NXdIfi3+xzrnJ0TkFL+Un8v1PWOC2PPFCjVPq7qTH7mOpzOYj/b4h0ceT+eHgr97Jqhb1ziVfeANzfN8bFUhPKBi7hJBCukQnB0aGjFTYLJPXL26lQ2b80xrOD5cFWgA8hz3St0e69kwNnD3+nX3gy12FjrjO+ddRvvvfyV3SWbXcxqNHfmsb9u1TV+wHTb9B07/L2sB8WUHJ9eeNomDyysEWZ0deqEhH/oWI2oiEh526gvAK1Nx2kIhNvkYR+tPYHEa9j+nd1VBpQP1uzSjIDO+fDDB7uy029rRjDC5Sk6aKczyz1D5uA9Lu+Rrrapl8JXNL3VRllNQH2K1ZFxOpX8LprttfqQ56MbPM0IttUheXWD/mROOeFqGUbL+kUOVlXLTFX/525g4faLEFO4qWWdmOXMNvVjpIVTWt650HfQjX9oT3Dg5Au6+v1/Ci78La6ZOngYCFPT1AUwxQuZ0yt5xKdNXLaDTISMTeCj16XTryhM36K2mfGRIgot71voWs8tTpL/f1rvcwv3LSDf+/G8THCT7NpfHWcW+lsF/ol8q9Bi6MezNTqp0rpp/kJRiVfNrX/w27cRRTu8RIIqtUblBMkxy4jwAVqCjUJkiPBj2cAoVloG8B2/N5deLdMhDb7xs5nhd3dubJhuj8WbaFRyu1L678DHhhA+rMimNo4C1kGpp0tD/qnCfCFHejpf0LJX43OTr578PY0tnIIrlWyNYyuR/ie6j2xNb1OV6u0dOX/1Dtcd7+ya9W+rY2LmnyQMtk8SMLTon8RAdwOaN2tNg5zVnDKlmVeOxPV2vhHIo9QEPV7jc3f+zVDquiNg1OaHX3cZXJDRY5MJpo+VanAcmqp4oasYLG+wrXUL5vJU0kqk2hGEskhP+Jjigrz1l6QnEwp6n8PMVeJp70Ii6ppeaK9GhF6fJE00ceLyxv08tKiPat4QdxZFgSbQknnEiCLD8Qc1rjazVKM3r3gXnnMeONgdz/yFV1q+haaN+wnF3Fn4uYCI9XsKOuVwDD0LsCO/f0gj5cmxCFcr7sclIcefWjvore+3aSU474cyqDVxH7w1RX3CHsaqsMRX17ZLgjsDXws3kLm2XJdM3Ku383UXqaHqsywzPhx7NFir0Fqjym/w6cxD2U9ypa3dx7Z12w/fi3Jps8sqJ8f8Ah8aZAvkHXvIRyrsxK7rrFaNNdNvjI8+3Emri195DCNa858anj2Qdny6Czshkn4N2+1m+k5S8sunX3Ja7I+JutRzg1mc2e9Yc0Zv9PZn1SwhxIdU9sXwZRTd/J5FoUm0e+PYREeHg3oc2YYzGf2xfJxXExt4pT3RfDRHvMXLUmoXOy63xv5pLuhOEax0dRgSywZ/GH+YBXFgCeTU0hZ8SPEFsn8punp1Kurd1KgXxUZ+la3R5+4ePGR4ZF5UQtOa83+Vj8zh80dfzbhxWCeoJnQ4dkZJM4drzknZOOKx2n3WrvJnzFIS8p0xeic+M3ZRVXIp10tV2DyYKwRxLzulPwzHcLlYTxl4PF7v8l106Azr+6wBFejbq/3P72C/0j78cepY9990/d4eAurn2lqdGKLU8FffnMw7cY7pVeXJRMU73Oxwi2g2vh/+4gX8dvbjfojn/eLVhhYl8GthwCQ50KcZq4z2JeW5eeOnJWFQEnVxDoG459TaC4zXybECEoJ0V5q1tXrQbDMtUxeTV6Pdt1/zJuc7TJoV/9YZFWxUtCf6Ou3Vd/vR/vG0138hJQrHkNeoep5dLe+6umcSquKvMaFpm3EZHDBOvCi0XYyIFHMgX7Cqp3JVXlxJFwQfHSaIUEbI2u1lBVUdlNw4Qa9UsLPEK94Qiln3pyKxQVCeNlx8yd7EegVNQBkFLabKvnietYVB4IPZ1fSor82arbgYec8aSdFMaIluYTYuNx32SxfrjKUdPGq+UNp5YpydoEG3xVLixtmHO9zXxKAnHnPuH2fPGrjx0GcuCDEU+yXUtXh6nfUL+cykws1gJ5vkfYFaFBr9PdCXvVf35OJQxzUMmWjv0W6uGJK11uAGDqSpOwCf6rouSIjPVgw57cJCOQ4b9tkI/Y5WNon9Swe72aZryKo8d+HyHBEdWJKrkary0LIGczA4Irq353Wc0Zga3om7UQiAGCvIl8GGyaqz5zH+1gMP5phWUCpKtttWIyicz09vXg76GxkmiGSMQ06Z9X8BUwqOtauDbPIf4rpK/yYoeAHxJ9soXS9VDe1Aw+awOOxaN8foLrif0TXBvQ55dtRtulRq9emFDBxlQcqKCaD8NeTSE7FOHvcjf/+oKbbtRqz9gbofoc2EzQ3pL6W5JdfJzAWmOk8oeoECe90lVMruwl/ltM015P/zIPazqvdvFmLNVHMIZrwiQ2tIKtGh6PDVH+85ew3caqVt2BsDv5rOcu3G9srQWd7NmgtzCRUXLYknYRSwtH9oUtkqyN3CfP20xQ1faXQl4MEmjQehWR6GmGnkdpYNQYeIG408yAX7uCZmYUic9juOfb+Re28+OVOB+scYK4DaPcBe+5wmji9gymtkMpKo4UKqCz7yxzuN8VIlx9yNozpRJpNaWHtaZVEqP45n2JemTlYBSmNIK1FuSYAUQ1yBLnKxevrjayd+h2i8PjdB3YY6b0nr3JuOXGpPMyh4V2dslpR3DFEvgpsBLqhqLDOWP4yEvIL6f21PpA7/8B"));
const $747425b437e121da$var$log2 = Math.log2 || ((n)=>Math.log(n) / Math.LN2);
const $747425b437e121da$var$bits = (n)=>$747425b437e121da$var$log2(n) + 1 | 0;
// compute the number of bits stored for each field
const $747425b437e121da$var$CATEGORY_BITS = $747425b437e121da$var$bits((0, /*@__PURE__*/ $parcel$interopDefault($f4087201da764553$exports)).categories.length - 1);
const $747425b437e121da$var$COMBINING_BITS = $747425b437e121da$var$bits((0, /*@__PURE__*/ $parcel$interopDefault($f4087201da764553$exports)).combiningClasses.length - 1);
const $747425b437e121da$var$SCRIPT_BITS = $747425b437e121da$var$bits((0, /*@__PURE__*/ $parcel$interopDefault($f4087201da764553$exports)).scripts.length - 1);
const $747425b437e121da$var$EAW_BITS = $747425b437e121da$var$bits((0, /*@__PURE__*/ $parcel$interopDefault($f4087201da764553$exports)).eaw.length - 1);
const $747425b437e121da$var$NUMBER_BITS = 10;
// compute shift and mask values for each field
const $747425b437e121da$var$CATEGORY_SHIFT = $747425b437e121da$var$COMBINING_BITS + $747425b437e121da$var$SCRIPT_BITS + $747425b437e121da$var$EAW_BITS + $747425b437e121da$var$NUMBER_BITS;
const $747425b437e121da$var$COMBINING_SHIFT = $747425b437e121da$var$SCRIPT_BITS + $747425b437e121da$var$EAW_BITS + $747425b437e121da$var$NUMBER_BITS;
const $747425b437e121da$var$SCRIPT_SHIFT = $747425b437e121da$var$EAW_BITS + $747425b437e121da$var$NUMBER_BITS;
const $747425b437e121da$var$EAW_SHIFT = $747425b437e121da$var$NUMBER_BITS;
const $747425b437e121da$var$CATEGORY_MASK = (1 << $747425b437e121da$var$CATEGORY_BITS) - 1;
const $747425b437e121da$var$COMBINING_MASK = (1 << $747425b437e121da$var$COMBINING_BITS) - 1;
const $747425b437e121da$var$SCRIPT_MASK = (1 << $747425b437e121da$var$SCRIPT_BITS) - 1;
const $747425b437e121da$var$EAW_MASK = (1 << $747425b437e121da$var$EAW_BITS) - 1;
const $747425b437e121da$var$NUMBER_MASK = (1 << $747425b437e121da$var$NUMBER_BITS) - 1;
function $747425b437e121da$export$410364bbb673ddbc(codePoint) {
    const val = $747425b437e121da$var$trie.get(codePoint);
    return (0, /*@__PURE__*/ $parcel$interopDefault($f4087201da764553$exports)).categories[val >> $747425b437e121da$var$CATEGORY_SHIFT & $747425b437e121da$var$CATEGORY_MASK];
}
function $747425b437e121da$export$c03b919c6651ed55(codePoint) {
    const val = $747425b437e121da$var$trie.get(codePoint);
    return (0, /*@__PURE__*/ $parcel$interopDefault($f4087201da764553$exports)).combiningClasses[val >> $747425b437e121da$var$COMBINING_SHIFT & $747425b437e121da$var$COMBINING_MASK];
}
function $747425b437e121da$export$941569448d136665(codePoint) {
    const val = $747425b437e121da$var$trie.get(codePoint);
    return (0, /*@__PURE__*/ $parcel$interopDefault($f4087201da764553$exports)).scripts[val >> $747425b437e121da$var$SCRIPT_SHIFT & $747425b437e121da$var$SCRIPT_MASK];
}
function $747425b437e121da$export$92f6187db8ca6d26(codePoint) {
    const val = $747425b437e121da$var$trie.get(codePoint);
    return (0, /*@__PURE__*/ $parcel$interopDefault($f4087201da764553$exports)).eaw[val >> $747425b437e121da$var$EAW_SHIFT & $747425b437e121da$var$EAW_MASK];
}
function $747425b437e121da$export$7d1258ebb7625a0d(codePoint) {
    let val = $747425b437e121da$var$trie.get(codePoint);
    let num = val & $747425b437e121da$var$NUMBER_MASK;
    if (num === 0) return null;
    else if (num <= 50) return num - 1;
    else if (num < 0x1e0) {
        const numerator = (num >> 4) - 12;
        const denominator = (num & 0xf) + 1;
        return numerator / denominator;
    } else if (num < 0x300) {
        val = (num >> 5) - 14;
        let exp = (num & 0x1f) + 2;
        while(exp > 0){
            val *= 10;
            exp--;
        }
        return val;
    } else {
        val = (num >> 2) - 0xbf;
        let exp = (num & 3) + 1;
        while(exp > 0){
            val *= 60;
            exp--;
        }
        return val;
    }
}
function $747425b437e121da$export$52c8ea63abd07594(codePoint) {
    const category = $747425b437e121da$export$410364bbb673ddbc(codePoint);
    return category === "Lu" || category === "Ll" || category === "Lt" || category === "Lm" || category === "Lo" || category === "Nl";
}
function $747425b437e121da$export$727d9dbc4fbb948f(codePoint) {
    return $747425b437e121da$export$410364bbb673ddbc(codePoint) === "Nd";
}
function $747425b437e121da$export$a5b49f4dc6a07d2c(codePoint) {
    const category = $747425b437e121da$export$410364bbb673ddbc(codePoint);
    return category === "Pc" || category === "Pd" || category === "Pe" || category === "Pf" || category === "Pi" || category === "Po" || category === "Ps";
}
function $747425b437e121da$export$7b6804e8df61fcf5(codePoint) {
    return $747425b437e121da$export$410364bbb673ddbc(codePoint) === "Ll";
}
function $747425b437e121da$export$aebd617640818cda(codePoint) {
    return $747425b437e121da$export$410364bbb673ddbc(codePoint) === "Lu";
}
function $747425b437e121da$export$de8b4ee23b2cf823(codePoint) {
    return $747425b437e121da$export$410364bbb673ddbc(codePoint) === "Lt";
}
function $747425b437e121da$export$3c52dd84024ae72c(codePoint) {
    const category = $747425b437e121da$export$410364bbb673ddbc(codePoint);
    return category === "Zs" || category === "Zl" || category === "Zp";
}
function $747425b437e121da$export$a11bdcffe109e74b(codePoint) {
    const category = $747425b437e121da$export$410364bbb673ddbc(codePoint);
    return category === "Nd" || category === "No" || category === "Nl" || category === "Lu" || category === "Ll" || category === "Lt" || category === "Lm" || category === "Lo" || category === "Me" || category === "Mc";
}
function $747425b437e121da$export$e33ad6871e762338(codePoint) {
    const category = $747425b437e121da$export$410364bbb673ddbc(codePoint);
    return category === "Mn" || category === "Me" || category === "Mc";
}
var $747425b437e121da$export$2e2bcd8739ae039 = {
    getCategory: $747425b437e121da$export$410364bbb673ddbc,
    getCombiningClass: $747425b437e121da$export$c03b919c6651ed55,
    getScript: $747425b437e121da$export$941569448d136665,
    getEastAsianWidth: $747425b437e121da$export$92f6187db8ca6d26,
    getNumericValue: $747425b437e121da$export$7d1258ebb7625a0d,
    isAlphabetic: $747425b437e121da$export$52c8ea63abd07594,
    isDigit: $747425b437e121da$export$727d9dbc4fbb948f,
    isPunctuation: $747425b437e121da$export$a5b49f4dc6a07d2c,
    isLowerCase: $747425b437e121da$export$7b6804e8df61fcf5,
    isUpperCase: $747425b437e121da$export$aebd617640818cda,
    isTitleCase: $747425b437e121da$export$de8b4ee23b2cf823,
    isWhiteSpace: $747425b437e121da$export$3c52dd84024ae72c,
    isBaseForm: $747425b437e121da$export$a11bdcffe109e74b,
    isMark: $747425b437e121da$export$e33ad6871e762338
};
;
 //# sourceMappingURL=module.mjs.map
}),
"[project]/node_modules/dfa/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var INITIAL_STATE = 1;
var FAIL_STATE = 0;
/**
 * A StateMachine represents a deterministic finite automaton.
 * It can perform matches over a sequence of values, similar to a regular expression.
 */ class StateMachine {
    constructor(dfa){
        this.stateTable = dfa.stateTable;
        this.accepting = dfa.accepting;
        this.tags = dfa.tags;
    }
    /**
   * Returns an iterable object that yields pattern matches over the input sequence.
   * Matches are of the form [startIndex, endIndex, tags].
   */ match(str) {
        var self = this;
        return {
            *[Symbol.iterator] () {
                var state = INITIAL_STATE;
                var startRun = null;
                var lastAccepting = null;
                var lastState = null;
                for(var p = 0; p < str.length; p++){
                    var c = str[p];
                    lastState = state;
                    state = self.stateTable[state][c];
                    if (state === FAIL_STATE) {
                        // yield the last match if any
                        if (startRun != null && lastAccepting != null && lastAccepting >= startRun) {
                            yield [
                                startRun,
                                lastAccepting,
                                self.tags[lastState]
                            ];
                        } // reset the state as if we started over from the initial state
                        state = self.stateTable[INITIAL_STATE][c];
                        startRun = null;
                    } // start a run if not in the failure state
                    if (state !== FAIL_STATE && startRun == null) {
                        startRun = p;
                    } // if accepting, mark the potential match end
                    if (self.accepting[state]) {
                        lastAccepting = p;
                    } // reset the state to the initial state if we get into the failure state
                    if (state === FAIL_STATE) {
                        state = INITIAL_STATE;
                    }
                } // yield the last match if any
                if (startRun != null && lastAccepting != null && lastAccepting >= startRun) {
                    yield [
                        startRun,
                        lastAccepting,
                        self.tags[state]
                    ];
                }
            }
        };
    }
    /**
   * For each match over the input sequence, action functions matching
   * the tag definitions in the input pattern are called with the startIndex,
   * endIndex, and sub-match sequence.
   */ apply(str, actions) {
        for (var [start, end, tags] of this.match(str)){
            for (var tag of tags){
                if (typeof actions[tag] === 'function') {
                    actions[tag](start, end, str.slice(start, end + 1));
                }
            }
        }
    }
}
module.exports = StateMachine; //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/clone/clone.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/compiled/buffer/index.js [app-client] (ecmascript)");
var clone = function() {
    'use strict';
    function _instanceof(obj, type) {
        return type != null && obj instanceof type;
    }
    var nativeMap;
    try {
        nativeMap = Map;
    } catch (_) {
        // maybe a reference error because no `Map`. Give it a dummy value that no
        // value will ever be an instanceof.
        nativeMap = function() {};
    }
    var nativeSet;
    try {
        nativeSet = Set;
    } catch (_) {
        nativeSet = function() {};
    }
    var nativePromise;
    try {
        nativePromise = Promise;
    } catch (_) {
        nativePromise = function() {};
    }
    /**
 * Clones (copies) an Object using deep copying.
 *
 * This function supports circular references by default, but if you are certain
 * there are no circular references in your object, you can save some CPU time
 * by calling clone(obj, false).
 *
 * Caution: if `circular` is false and `parent` contains circular references,
 * your program may enter an infinite loop and crash.
 *
 * @param `parent` - the object to be cloned
 * @param `circular` - set to true if the object to be cloned may contain
 *    circular references. (optional - true by default)
 * @param `depth` - set to a number if the object is only to be cloned to
 *    a particular depth. (optional - defaults to Infinity)
 * @param `prototype` - sets the prototype to be used when cloning an object.
 *    (optional - defaults to parent prototype).
 * @param `includeNonEnumerable` - set to true if the non-enumerable properties
 *    should be cloned as well. Non-enumerable properties on the prototype
 *    chain will be ignored. (optional - false by default)
*/ function clone(parent, circular, depth, prototype, includeNonEnumerable) {
        if (typeof circular === 'object') {
            depth = circular.depth;
            prototype = circular.prototype;
            includeNonEnumerable = circular.includeNonEnumerable;
            circular = circular.circular;
        }
        // maintain two arrays for circular references, where corresponding parents
        // and children have the same index
        var allParents = [];
        var allChildren = [];
        var useBuffer = typeof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"] != 'undefined';
        if (typeof circular == 'undefined') circular = true;
        if (typeof depth == 'undefined') depth = Infinity;
        // recurse this function so we don't reset allParents and allChildren
        function _clone(parent, depth) {
            // cloning null always returns null
            if (parent === null) return null;
            if (depth === 0) return parent;
            var child;
            var proto;
            if (typeof parent != 'object') {
                return parent;
            }
            if (_instanceof(parent, nativeMap)) {
                child = new nativeMap();
            } else if (_instanceof(parent, nativeSet)) {
                child = new nativeSet();
            } else if (_instanceof(parent, nativePromise)) {
                child = new nativePromise(function(resolve, reject) {
                    parent.then(function(value) {
                        resolve(_clone(value, depth - 1));
                    }, function(err) {
                        reject(_clone(err, depth - 1));
                    });
                });
            } else if (clone.__isArray(parent)) {
                child = [];
            } else if (clone.__isRegExp(parent)) {
                child = new RegExp(parent.source, __getRegExpFlags(parent));
                if (parent.lastIndex) child.lastIndex = parent.lastIndex;
            } else if (clone.__isDate(parent)) {
                child = new Date(parent.getTime());
            } else if (useBuffer && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].isBuffer(parent)) {
                if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].allocUnsafe) {
                    // Node.js >= 4.5.0
                    child = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"].allocUnsafe(parent.length);
                } else {
                    // Older Node.js versions
                    child = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$buffer$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"](parent.length);
                }
                parent.copy(child);
                return child;
            } else if (_instanceof(parent, Error)) {
                child = Object.create(parent);
            } else {
                if (typeof prototype == 'undefined') {
                    proto = Object.getPrototypeOf(parent);
                    child = Object.create(proto);
                } else {
                    child = Object.create(prototype);
                    proto = prototype;
                }
            }
            if (circular) {
                var index = allParents.indexOf(parent);
                if (index != -1) {
                    return allChildren[index];
                }
                allParents.push(parent);
                allChildren.push(child);
            }
            if (_instanceof(parent, nativeMap)) {
                parent.forEach(function(value, key) {
                    var keyChild = _clone(key, depth - 1);
                    var valueChild = _clone(value, depth - 1);
                    child.set(keyChild, valueChild);
                });
            }
            if (_instanceof(parent, nativeSet)) {
                parent.forEach(function(value) {
                    var entryChild = _clone(value, depth - 1);
                    child.add(entryChild);
                });
            }
            for(var i in parent){
                var attrs;
                if (proto) {
                    attrs = Object.getOwnPropertyDescriptor(proto, i);
                }
                if (attrs && attrs.set == null) {
                    continue;
                }
                child[i] = _clone(parent[i], depth - 1);
            }
            if (Object.getOwnPropertySymbols) {
                var symbols = Object.getOwnPropertySymbols(parent);
                for(var i = 0; i < symbols.length; i++){
                    // Don't need to worry about cloning a symbol because it is a primitive,
                    // like a number or string.
                    var symbol = symbols[i];
                    var descriptor = Object.getOwnPropertyDescriptor(parent, symbol);
                    if (descriptor && !descriptor.enumerable && !includeNonEnumerable) {
                        continue;
                    }
                    child[symbol] = _clone(parent[symbol], depth - 1);
                    if (!descriptor.enumerable) {
                        Object.defineProperty(child, symbol, {
                            enumerable: false
                        });
                    }
                }
            }
            if (includeNonEnumerable) {
                var allPropertyNames = Object.getOwnPropertyNames(parent);
                for(var i = 0; i < allPropertyNames.length; i++){
                    var propertyName = allPropertyNames[i];
                    var descriptor = Object.getOwnPropertyDescriptor(parent, propertyName);
                    if (descriptor && descriptor.enumerable) {
                        continue;
                    }
                    child[propertyName] = _clone(parent[propertyName], depth - 1);
                    Object.defineProperty(child, propertyName, {
                        enumerable: false
                    });
                }
            }
            return child;
        }
        return _clone(parent, depth);
    }
    /**
 * Simple flat clone using prototype, accepts only objects, usefull for property
 * override on FLAT configuration object (no nested props).
 *
 * USE WITH CAUTION! This may not behave as you wish if you do not know how this
 * works.
 */ clone.clonePrototype = function clonePrototype(parent) {
        if (parent === null) return null;
        var c = function() {};
        c.prototype = parent;
        return new c();
    };
    // private utility functions
    function __objToStr(o) {
        return Object.prototype.toString.call(o);
    }
    clone.__objToStr = __objToStr;
    function __isDate(o) {
        return typeof o === 'object' && __objToStr(o) === '[object Date]';
    }
    clone.__isDate = __isDate;
    function __isArray(o) {
        return typeof o === 'object' && __objToStr(o) === '[object Array]';
    }
    clone.__isArray = __isArray;
    function __isRegExp(o) {
        return typeof o === 'object' && __objToStr(o) === '[object RegExp]';
    }
    clone.__isRegExp = __isRegExp;
    function __getRegExpFlags(re) {
        var flags = '';
        if (re.global) flags += 'g';
        if (re.ignoreCase) flags += 'i';
        if (re.multiline) flags += 'm';
        return flags;
    }
    clone.__getRegExpFlags = __getRegExpFlags;
    return clone;
}();
if (("TURBOPACK compile-time value", "object") === 'object' && module.exports) {
    module.exports = clone;
}
}),
"[project]/node_modules/linebreak/dist/module.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>$557adaaeb0c7885f$exports
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$unicode$2d$trie$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/unicode-trie/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$linebreak$2f$node_modules$2f$base64$2d$js$2f$lib$2f$b64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/linebreak/node_modules/base64-js/lib/b64.js [app-client] (ecmascript)");
;
;
var $557adaaeb0c7885f$exports = {};
"use strict";
const $1627905f8be2ef3f$export$af862512e23cb54 = 0; // Opening punctuation
const $1627905f8be2ef3f$export$9bf3043cb7503aa1 = 1; // Closing punctuation
const $1627905f8be2ef3f$export$6d0b2a5dd774590a = 2; // Closing parenthesis
const $1627905f8be2ef3f$export$bf0b2277bd569ea1 = 3; // Ambiguous quotation
const $1627905f8be2ef3f$export$bad2a840ccda93b6 = 4; // Glue
const $1627905f8be2ef3f$export$fb4028874a74450 = 5; // Non-starters
const $1627905f8be2ef3f$export$463bd1ce0149c55e = 6; // Exclamation/Interrogation
const $1627905f8be2ef3f$export$2e8caadc521d7cbb = 7; // Symbols allowing break after
const $1627905f8be2ef3f$export$bfe27467c1de9413 = 8; // Infix separator
const $1627905f8be2ef3f$export$af5f8d68aad3cd3a = 9; // Prefix
const $1627905f8be2ef3f$export$6b7e017d6825d38f = 10; // Postfix
const $1627905f8be2ef3f$export$8227ca023eb0daaa = 11; // Numeric
const $1627905f8be2ef3f$export$1bb1140fe1358b00 = 12; // Alphabetic
const $1627905f8be2ef3f$export$f3e416a182673355 = 13; // Hebrew Letter
const $1627905f8be2ef3f$export$8be180ec26319f9f = 14; // Ideographic
const $1627905f8be2ef3f$export$70824c8942178d60 = 15; // Inseparable characters
const $1627905f8be2ef3f$export$24aa617c849a894a = 16; // Hyphen
const $1627905f8be2ef3f$export$a73c4d14459b698d = 17; // Break after
const $1627905f8be2ef3f$export$921068d8846a1559 = 18; // Break before
const $1627905f8be2ef3f$export$8b85a4f193482778 = 19; // Break on either side (but not pair)
const $1627905f8be2ef3f$export$b2fd9c01d360241f = 20; // Zero-width space
const $1627905f8be2ef3f$export$dcd191669c0a595f = 21; // Combining marks
const $1627905f8be2ef3f$export$9e5d732f3676a9ba = 22; // Word joiner
const $1627905f8be2ef3f$export$cb94397127ac9363 = 23; // Hangul LV
const $1627905f8be2ef3f$export$746be9e3a3dfff1f = 24; // Hangul LVT
const $1627905f8be2ef3f$export$96e3e682276c47cf = 25; // Hangul L Jamo
const $1627905f8be2ef3f$export$fc2ff69ee2cb01bf = 26; // Hangul V Jamo
const $1627905f8be2ef3f$export$8999624a7bae9d04 = 27; // Hangul T Jamo
const $1627905f8be2ef3f$export$1dff41d5c0caca01 = 28; // Regional Indicator
const $1627905f8be2ef3f$export$ddb7a6c76d9d93eb = 29; // Emoji Base
const $1627905f8be2ef3f$export$7e93eb3105e4786d = 30; // Emoji Modifier
const $1627905f8be2ef3f$export$30a74a373318dec6 = 31; // Zero Width Joiner
const $1627905f8be2ef3f$export$54caeea5e6dab1f = 32; // Contingent break
const $1627905f8be2ef3f$export$d710c5f50fc7496a = 33; // Ambiguous (Alphabetic or Ideograph)
const $1627905f8be2ef3f$export$66498d28055820a9 = 34; // Break (mandatory)
const $1627905f8be2ef3f$export$eb6c6d0b7c8826f2 = 35; // Conditional Japanese Starter
const $1627905f8be2ef3f$export$de92be486109a1df = 36; // Carriage return
const $1627905f8be2ef3f$export$606cfc2a8896c91f = 37; // Line feed
const $1627905f8be2ef3f$export$e51d3c675bb0140d = 38; // Next line
const $1627905f8be2ef3f$export$da51c6332ad11d7b = 39; // South-East Asian
const $1627905f8be2ef3f$export$bea437c40441867d = 40; // Surrogates
const $1627905f8be2ef3f$export$c4c7eecbfed13dc9 = 41; // Space
const $1627905f8be2ef3f$export$98e1f8a379849661 = 42; // Unknown
const $32627af916ac1b00$export$98f50d781a474745 = 0; // Direct break opportunity
const $32627af916ac1b00$export$12ee1f8f5315ca7e = 1; // Indirect break opportunity
const $32627af916ac1b00$export$e4965ce242860454 = 2; // Indirect break opportunity for combining marks
const $32627af916ac1b00$export$8f14048969dcd45e = 3; // Prohibited break for combining marks
const $32627af916ac1b00$export$133eb141bf58aff4 = 4; // Prohibited break
const $32627af916ac1b00$export$5bdb8ccbf5c57afc = [
    //OP   , CL    , CP    , QU    , GL    , NS    , EX    , SY    , IS    , PR    , PO    , NU    , AL    , HL    , ID    , IN    , HY    , BA    , BB    , B2    , ZW    , CM    , WJ    , H2    , H3    , JL    , JV    , JT    , RI    , EB    , EM    , ZWJ   , CB
    [
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$8f14048969dcd45e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ],
    [
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$e4965ce242860454,
        $32627af916ac1b00$export$133eb141bf58aff4,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$98f50d781a474745,
        $32627af916ac1b00$export$12ee1f8f5315ca7e,
        $32627af916ac1b00$export$98f50d781a474745
    ] // CB
];
const $557adaaeb0c7885f$var$data = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$linebreak$2f$node_modules$2f$base64$2d$js$2f$lib$2f$b64$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].toByteArray("AAgOAAAAAAAQ4QAAAQ0P8vDtnQuMXUUZx+eyu7d7797d9m5bHoWltKVUlsjLWE0VJNigQoMVqkStEoNQQUl5GIo1KKmogEgqkKbBRki72lYabZMGKoGAjQRtJJDaCCIRiiigREBQS3z+xzOTnZ3O+3HOhd5NfpkzZx7fN9988zivu2M9hGwB28F94DnwEngd/Asc1EtIs9c/bIPDwCxwLDgezHcodyo4w5C+CCwBS8FnwSXgCnA1uFbI93XwbXAbWAfWgx+CzWAb+An4KfgFeAzsYWWfYuFz4CXwGvgb+Dfo6yNkEEwGh4CZYB44FpwI3g1OY+kfBItZOo2fB84Hy8DF4HJwNbiWpV8PVoO1LH4n2NRXyN+KcAd4kNVP9XsY4aPgcfAbsBfs6SniL4K/sPjfEf6HlanXCRkCw2BGvUh/keWfXS/CY+pFXs7x9XHmM94LTmWIeU2cgbxnS/k/B3kf86jDhU8L9V2E40vAFWAlWFUfb++NOL4F3C7JX4/4GiE+hvgWsF0oS7mXldspnN+F493gyXrh9xTav0cg3EvzgVfBG6wsmVSEkxBOBgdPGpd7JI6PnqRvJ68/xlbHof53gPeA94OzwLngk+ACsAwsByvASrAK3MB0Ws3CtQjvBJvAVrADPMDSHkb4CNijaccTwvnf4fiPEs8Lxy+D18A/QU8/xjgYBjPAbDAKTgYLwOngTHAO+EQ/8wuEF4EvsPiVCFf2+9tsFStzA8LVHuXXBsi6QyqzUYiPMR/7Mc7dAx7oL8bzw/3u/Bw8Bp4Az4AXwCtgHzsmDXP5fiF9iiVvly5d0sHngar16NKlS5cuXbp06fLmYlqHXrcd3ph4P0THUY3iXh49novju4S0tzfs5d+JPKewfAsRntZb3K9ZhOMlrO6lCC8An28U9+OuovcPcPxlVu5rCL/VmHh/iHIrzn3fIPu7SN8Axmg+8AOwEWwCm7tp3bRuWjetm5Y8bSu4B9zbKO6ZVsnORrVU3f4uXTqZ2H3sLoyx3eDXjfDndE9qyj6L838CfwVvgFpzYnof4oNgOhgBc8Fos9DrZIQLmtXPP1MmF6wGj4H+KXoWguvADkXaPil+YpuQy8Am8Ey7ODdtmJDF4HowBp4De6HDTNjhfHAHeBr0DBBy0kDxfPbcgSIusgrcWhtnJ8vL+TPix7UIOQtcBq4C28Cr4KRBnANbwSuDE+s50JgyNNFuXbp06XIgsXjIvPafjvXozKY+fVFz/z0LT1uCtKVSWbrOLWPnztG8e0Xfy7ol8XtZJi7WtG+5od2UFXQ/A12vUeS7jp27yVKHjdsU9lXB869TyNvAzt0lpP2oWbwLdjiO78bx/Sz+EMJHwK9Y/LcIfw+eZ3F67/Hl5vh9xX80J+rwX8SvRDhpgL17iPAQMHNArfPrqHPewLheI+AERV6efwV418B4nOZ/H+IfYHV8GOF5LJ3eAz0fx8sM9S0fUNud39O9CulfGZhY5huI3wzWgNvBelbHZoTbNPVpfYjKQpkHwUNgl0LWblbnk0LbbDxr0OMFpL3iqWdu9nWYPlVAWkXY39LnGdCkDbeqv1YNbfcMQ3t9oe8lzm6NH9N1ZB6Ln4BwfkJZJk7RyFnYKt6b/JDQXx9p5X+eFdqOjzM9P9MB/lUlFzr20aXIdzlY4dmn9F3YqtvoO76/2hp/D/xA5Zue88nNyL8GbFbs075X0tyUig3Qd2MCnf//HjnzpbsR3g9+1kHzzVjdnE71/qVBX9rGPUh/ysNWe1neFzvIDi5zAufV1sT0N0poR22wkFUfTOPfA4N2mbZ5fSrqOHSw+IbkSBbOGSzSRgf91/GTUWYBOB2cIZQ/G8cfBZ8CFwrnL8XxF8FKcA24jqXdiPA7Qr61OF7H4mMItwzuv2/YLth1ISt3Hzu3k4W7EH5JqPdRHD/O4k+z8A8IX5Lq3y7Z4nXE9xn6kX6vQ4bKfy+ok+hH+xf3hq9dnTTHhjKd2GmDuWA242iHMq4cC7A8kJ7i8o1+skSa7Jieo38HCWnoNjKFhdSFBxzpZ7QE6lI8N4S14aASZcryaV/WWHw66f6NHuCoxuQxmvM56GX9QMd8Q4D65ywGP+ZzRJuM+zQvx/MOS2VFeqQ4IXnH26zM9Xe6/E6D+4foAzzuajPZp8Qyw5ayZVDWuH0z0BtYRkeIDqH9KO9VbH1btd/lhNqCzvl8zeLnG0S/hnU6baHfpiuO6yy0rd+DHURo/zYF5H26j03rQsip2ndzz82u1z9N4VjWKWeb68Tedpt95HRVXp7H1R6p+/Wt4FPy/PpWwscOLRJ+PVWF/+W0iVyGzs18TIvXkOJ1Wxm66vSXz+vylenrZcj1ub439W+K8RNCGTJi2p/TJ1K23VaXr35tRpnzmjxequgfcfyk6B/TGBVlyedsNgpdd/h+W1U3P99QyFPNo1X3TwpM/WLTIWYfoBqXrv6iskHZ/RFr79R6hIyHBrH3f1nrUVnjP8SnZZ+rYtzr9Exld5MNbPNErusAPg+77u/eDOPftU9yj39TH7rezxd1LvsZQJlzkWlOirG/79zjMj/mtHUKu7vKy+3/LnXr9okyKedjX5/0He9iP/j63LwOQdarEVlfy8OO/Lqw023j6xcqmwxLiOd6heM2i9cV9LJy8jMJ23yQ+rpbfu7EQ/pXE8KYvUSqvVnb4XzZa6LrHMXHR+zcLvqWbm/Bn0/HzIs6fWPHoat8XfnDKmZGxRxeMbn2UqZ5Q94nmcZRbqqUXbZ8+lcjE+cPX11t814orvvAXNcG8vqj2vvk1MGn3anlj0bIT72v47bvE+Lc98T9b6r7AKn6j+8Duf7D0nnZx/j7Zjn0j9nbpSTndaLr9WNLivP+iN23xF7L+fqv6ZouFyb78jxVXvv5jJ9YUs9/sddO8h7KNg5jrhfaJGztT6G7KF+1d6yCmD5Kdb2fan60rSc552fZr3zeQ9DpnPp+Si5cx5Ktv2QfSzF/mMbWdOm46rFI4XstnU9xeqX4NKb7TKEdcr6pZOK3ID1k/LvFHkVczEuZLEDr499YqvqBym1aEHWgcvoYOtv0M91qQl5TfpO/in6rWx8OVpT1Wedkv3f5xom3T/xeR/6Gx6V86PWAOB4bBpqWdN+yTcVxjIyGRz/FrDGu6w/3d7kPm8StX8RyPu+uuvpNju/vTLJV37GpvoM0oZPnW87VLnL/5pDno1NoW1R6yedU6TyUv3u19a3KFnIbTLYz+ZCLP4T0tU1uivFgso0pnsJ/UtXvarNY28Xq5cvkBDrQP/E5ZaiuQwwfmTlsOiQRU1fMuqrDd/3ISSuwjOwXOfTyGUMpZIXq4GpLn3pUcdfzch2x7XO1u2uZHOPb1G6b3Xg9PH1IIWeEpJlPQtqos2EKW8b0u8rnuP1UeVLoXJb9be0uG9nnbchjU+XTszT5VeNBThPHnc5OKj1U9aj0GTHIVaGy1YhEWT4ixns00DT+XEzWn/7VAsIc63Cov3OdyhwjrnaqQqZvWKXdypRdlq+k8msZ031U+Rm4fA+3TtyeR9hwfW9G9yxDN0fZMN33F+9TE6md4hwoxumfaUzI9fN3PFT3xVV2msrQ3UsnChm6Nulk8TndpS28D3zX9tTIPsF/z7Am5OkTjm1tI1JZW74+4VgsZ0N3L1yXV3WeP5uR7TGHHdvC3JQlxybfpd22tDlk/2eofRK8TzrN/qnar/K/OUTth6I/+jAnEptNbPvFHP2gs40N3+dfMWtwqvVct7/wfd8gtQ7imifial9ZJ9/3IHLYU6eDj3+4PhsNhX+vwvcWLnu6kGfEMe8DuciPfUfGZB8X/7HJy/Gefe5n+VRGFd/wyP2ta7/LO4yh/sbLV/k9lev6kfO9Dt/5U67b1/6u/epqB1U9Me23jfHY9sscAg4tkbLl+e4/U36rJ9ddxfd6sg5vq5ice42Wpk/pb9FOJ36/W9tpv4kbC79nUbZceX8Zu6/qJ+P3WvhvA8v3reh7Jbn2d6rrNC7XNZTLma4Ba0JI9efX2uLzF5scG/w9UNU1ZxW+ymUfzELeTllXlQ1rUuhzjS5fp9c964iFBOqeSz63bU065nZKdU+mDEz3qHIjjifquw0pnb/raRtvrnsYcb46ihT3taoYz6brdNW9l6rWRnE/navdPn1XlR1km7hcz1WlH/elKuSOSvLLuE8U6m8uzwRdfcGl73VyTHuyMvzJ1Sa2cWDTP/Z63Kc94n2B1PYr24dz1JlyHLlcP+S4B6vD1c9EW4q2LWstCvUjeVy63k/LMYdUNd5D1xQfvVTzX1VjkMsUv88N8VH5fReVn/Fjn++/h6X6Q8a6b1/q3g/i/ewi0/Scs8zxXeV6mWIOUPlPzBgdFerW+bZrm2P18dnjuK6HunEp+rHvPMXbr+sHVb/lnL+pTP57jPw9Cvk3PW178JD9qChfzuvTf7Htl38L1QUf/VKu9SFjwWbTWPvFEvu7Uq76y7+31g6QlYPc669pbsm9Xur2LWI9Pu8ypfDXqm3A2z8s1FWGn4ntL9NfQu2oSlftX9uetvTtv7J8Ql4zxfXGZ3zk8PeQ9w59x2uMfqI8/q5eKh/l9cb2rwsu9rSNl06ZP2Pmxtz+rNMx93yno0n2/82rVH7rQ+y9P15H6FyRun9ViH81ATmffI7nJ5r8uXXW6enbP6b/B8/l5OifVHYLnb9S39s2zcc+Ph+rh8+eQgVPS72elzGWY/tUtbbabBpDiI7yN1q6/4th2y+ErAc5+9BVvu/7KamJbWNZeuqI/R4tRf+YyD1HmOZM1bMV3/14Sn10c0Xu+Sj1nOXb5jL73ncdy02uvlXZNde65dOHYl7Vs4KYuS6FzWLn2zJlpZqPXPVPOa5yzKOyn1VhT9lmMfdbfH7D11Wf2PXN5h9y+dD287+qxgSnaYmnIrRtIb8pJe6/Uv9OVer6Whn0zfGO/BEloZI9ojmfAlUflClDd178bTmVHVTpZXOkAlk/lb42UujmI89HH5V+cl7XtowY6vTxLVWok6UrGzoGTHN+bB+6ri05687VNpvfuvRfaP2uMlNQth1D5JjGelm/8yn+9p3p/7qk9gnfeddXZmq/Sm333PJT659Kv1zjNbZ9uv2Oi//67CV8/N1nj1DmviyXDNVeJkaeaX8UsyesYg8cu2+NvdaPfb+lLDu5tvt/");
const $557adaaeb0c7885f$var$classTrie = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$unicode$2d$trie$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]($557adaaeb0c7885f$var$data);
const $557adaaeb0c7885f$var$mapClass = function(c) {
    switch(c){
        case $1627905f8be2ef3f$export$d710c5f50fc7496a:
            return $1627905f8be2ef3f$export$1bb1140fe1358b00;
        case $1627905f8be2ef3f$export$da51c6332ad11d7b:
        case $1627905f8be2ef3f$export$bea437c40441867d:
        case $1627905f8be2ef3f$export$98e1f8a379849661:
            return $1627905f8be2ef3f$export$1bb1140fe1358b00;
        case $1627905f8be2ef3f$export$eb6c6d0b7c8826f2:
            return $1627905f8be2ef3f$export$fb4028874a74450;
        default:
            return c;
    }
};
const $557adaaeb0c7885f$var$mapFirst = function(c) {
    switch(c){
        case $1627905f8be2ef3f$export$606cfc2a8896c91f:
        case $1627905f8be2ef3f$export$e51d3c675bb0140d:
            return $1627905f8be2ef3f$export$66498d28055820a9;
        case $1627905f8be2ef3f$export$c4c7eecbfed13dc9:
            return $1627905f8be2ef3f$export$9e5d732f3676a9ba;
        default:
            return c;
    }
};
class $557adaaeb0c7885f$var$Break {
    constructor(position, required = false){
        this.position = position;
        this.required = required;
    }
}
class $557adaaeb0c7885f$var$LineBreaker {
    nextCodePoint() {
        const code = this.string.charCodeAt(this.pos++);
        const next = this.string.charCodeAt(this.pos);
        // If a surrogate pair
        if (0xd800 <= code && code <= 0xdbff && 0xdc00 <= next && next <= 0xdfff) {
            this.pos++;
            return (code - 0xd800) * 0x400 + (next - 0xdc00) + 0x10000;
        }
        return code;
    }
    nextCharClass() {
        return $557adaaeb0c7885f$var$mapClass($557adaaeb0c7885f$var$classTrie.get(this.nextCodePoint()));
    }
    getSimpleBreak() {
        // handle classes not handled by the pair table
        switch(this.nextClass){
            case $1627905f8be2ef3f$export$c4c7eecbfed13dc9:
                return false;
            case $1627905f8be2ef3f$export$66498d28055820a9:
            case $1627905f8be2ef3f$export$606cfc2a8896c91f:
            case $1627905f8be2ef3f$export$e51d3c675bb0140d:
                this.curClass = $1627905f8be2ef3f$export$66498d28055820a9;
                return false;
            case $1627905f8be2ef3f$export$de92be486109a1df:
                this.curClass = $1627905f8be2ef3f$export$de92be486109a1df;
                return false;
        }
        return null;
    }
    getPairTableBreak(lastClass) {
        // if not handled already, use the pair table
        let shouldBreak = false;
        switch($32627af916ac1b00$export$5bdb8ccbf5c57afc[this.curClass][this.nextClass]){
            case $32627af916ac1b00$export$98f50d781a474745:
                shouldBreak = true;
                break;
            case $32627af916ac1b00$export$12ee1f8f5315ca7e:
                shouldBreak = lastClass === $1627905f8be2ef3f$export$c4c7eecbfed13dc9;
                break;
            case $32627af916ac1b00$export$e4965ce242860454:
                shouldBreak = lastClass === $1627905f8be2ef3f$export$c4c7eecbfed13dc9;
                if (!shouldBreak) {
                    shouldBreak = false;
                    return shouldBreak;
                }
                break;
            case $32627af916ac1b00$export$8f14048969dcd45e:
                if (lastClass !== $1627905f8be2ef3f$export$c4c7eecbfed13dc9) return shouldBreak;
                break;
            case $32627af916ac1b00$export$133eb141bf58aff4:
                break;
        }
        if (this.LB8a) shouldBreak = false;
        // Rule LB21a
        if (this.LB21a && (this.curClass === $1627905f8be2ef3f$export$24aa617c849a894a || this.curClass === $1627905f8be2ef3f$export$a73c4d14459b698d)) {
            shouldBreak = false;
            this.LB21a = false;
        } else this.LB21a = this.curClass === $1627905f8be2ef3f$export$f3e416a182673355;
        // Rule LB30a
        if (this.curClass === $1627905f8be2ef3f$export$1dff41d5c0caca01) {
            this.LB30a++;
            if (this.LB30a == 2 && this.nextClass === $1627905f8be2ef3f$export$1dff41d5c0caca01) {
                shouldBreak = true;
                this.LB30a = 0;
            }
        } else this.LB30a = 0;
        this.curClass = this.nextClass;
        return shouldBreak;
    }
    nextBreak() {
        // get the first char if we're at the beginning of the string
        if (this.curClass == null) {
            let firstClass = this.nextCharClass();
            this.curClass = $557adaaeb0c7885f$var$mapFirst(firstClass);
            this.nextClass = firstClass;
            this.LB8a = firstClass === $1627905f8be2ef3f$export$30a74a373318dec6;
            this.LB30a = 0;
        }
        while(this.pos < this.string.length){
            this.lastPos = this.pos;
            const lastClass = this.nextClass;
            this.nextClass = this.nextCharClass();
            // explicit newline
            if (this.curClass === $1627905f8be2ef3f$export$66498d28055820a9 || this.curClass === $1627905f8be2ef3f$export$de92be486109a1df && this.nextClass !== $1627905f8be2ef3f$export$606cfc2a8896c91f) {
                this.curClass = $557adaaeb0c7885f$var$mapFirst($557adaaeb0c7885f$var$mapClass(this.nextClass));
                return new $557adaaeb0c7885f$var$Break(this.lastPos, true);
            }
            let shouldBreak = this.getSimpleBreak();
            if (shouldBreak === null) shouldBreak = this.getPairTableBreak(lastClass);
            // Rule LB8a
            this.LB8a = this.nextClass === $1627905f8be2ef3f$export$30a74a373318dec6;
            if (shouldBreak) return new $557adaaeb0c7885f$var$Break(this.lastPos);
        }
        if (this.lastPos < this.string.length) {
            this.lastPos = this.string.length;
            return new $557adaaeb0c7885f$var$Break(this.string.length);
        }
        return null;
    }
    constructor(string){
        this.string = string;
        this.pos = 0;
        this.lastPos = 0;
        this.curClass = null;
        this.nextClass = null;
        this.LB8a = false;
        this.LB21a = false;
        this.LB30a = 0;
    }
}
$557adaaeb0c7885f$exports = $557adaaeb0c7885f$var$LineBreaker;
;
 //# sourceMappingURL=module.mjs.map
}),
"[project]/node_modules/jay-peg/src/markers/dac.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Struct.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Buffer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Array.js [app-client] (ecmascript)");
;
const DACTable = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Struct"]({
    identifier: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"](1),
    value: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"](1)
});
const DACMarker = {
    name: ()=>"DAC",
    length: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    tables: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Array"](DACTable, (parent)=>parent.length / 2)
};
const __TURBOPACK__default__export__ = DACMarker;
}),
"[project]/node_modules/jay-peg/src/markers/utils.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "concatenateUint8Arrays",
    ()=>concatenateUint8Arrays,
    "readInt32BE",
    ()=>readInt32BE,
    "readInt32LE",
    ()=>readInt32LE,
    "readUInt16BE",
    ()=>readUInt16BE,
    "readUInt16LE",
    ()=>readUInt16LE,
    "readUInt32BE",
    ()=>readUInt32BE,
    "readUInt32LE",
    ()=>readUInt32LE,
    "readUInt8",
    ()=>readUInt8,
    "uint8ArrayToHexString",
    ()=>uint8ArrayToHexString,
    "uint8ArrayToString",
    ()=>uint8ArrayToString
]);
const readUInt8 = (array, offset)=>{
    return array[offset];
};
const readUInt16BE = (array, offset)=>{
    return array[offset] << 8 | array[offset + 1];
};
const readUInt16LE = (array, offset)=>{
    return array[offset] | array[offset + 1] << 8;
};
const readUInt32BE = (array, offset)=>{
    return readInt32BE(array, offset) >>> 0;
};
const readUInt32LE = (array, offset)=>{
    return readInt32LE(array, offset) >>> 0;
};
const uint8ArrayToHexString = (uint8Array)=>{
    return Array.from(uint8Array, (byte)=>byte.toString(16).padStart(2, "0")).join("");
};
const decoder = new TextDecoder("utf-8");
const uint8ArrayToString = (uint8Array)=>{
    return decoder.decode(uint8Array);
};
const concatenateUint8Arrays = (arrays)=>{
    const totalLength = arrays.reduce((length, arr)=>length + arr.length, 0);
    const concatenatedArray = new Uint8Array(totalLength);
    let offset = 0;
    arrays.forEach((arr)=>{
        concatenatedArray.set(arr, offset);
        offset += arr.length;
    });
    return concatenatedArray;
};
const readInt32BE = (array, offset)=>{
    return array[offset] << 24 | array[offset + 1] << 16 | array[offset + 2] << 8 | array[offset + 3];
};
const readInt32LE = (array, offset)=>{
    return array[offset] | array[offset + 1] << 8 | array[offset + 2] << 16 | array[offset + 3] << 24;
};
}),
"[project]/node_modules/jay-peg/src/markers/dht.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/utils.js [app-client] (ecmascript)");
;
;
class HuffmanTableElements {
    decode(stream, parent) {
        const tables = {};
        let buffer = stream.buffer.slice(stream.pos, stream.pos + parent.length - 2);
        while(buffer.length > 0){
            let offset = 1;
            const elements = [];
            const identifier = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt8"])(buffer, 0);
            const lengths = buffer.slice(offset, offset + 16);
            offset += 16;
            for (const length of lengths){
                elements.push(buffer.slice(offset, offset + length));
                offset += length;
            }
            buffer = buffer.slice(offset);
            tables[identifier] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["concatenateUint8Arrays"])(elements);
        }
        stream.pos += parent.length - 2;
        return tables;
    }
}
const DefineHuffmanTableMarker = {
    name: ()=>"DHT",
    length: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    tables: new HuffmanTableElements()
};
const __TURBOPACK__default__export__ = DefineHuffmanTableMarker;
}),
"[project]/node_modules/jay-peg/src/markers/dqt.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Array.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Struct.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Buffer.js [app-client] (ecmascript)");
;
const DQTMarker = {
    name: ()=>"DQT",
    length: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    tables: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Array"](new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Struct"]({
        identifier: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"](1),
        data: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"](64)
    }), (parent)=>(parent.length - 2) / 65)
};
const __TURBOPACK__default__export__ = DQTMarker;
}),
"[project]/node_modules/jay-peg/src/markers/dri.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
;
const DRIMarker = {
    name: ()=>"DRI",
    length: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    restartInterval: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"]
};
const __TURBOPACK__default__export__ = DRIMarker;
}),
"[project]/node_modules/jay-peg/src/markers/eoi.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Reserved$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Reserved.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
;
const EndOfImageMarker = {
    name: ()=>"EOI",
    afterEOI: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Reserved$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Reserved"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"], Infinity)
};
const __TURBOPACK__default__export__ = EndOfImageMarker;
}),
"[project]/node_modules/jay-peg/src/markers/exif.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Struct.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$String$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/String.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/utils.js [app-client] (ecmascript)");
;
;
const tags = {
    ifd: {
        "010e": "imageDescription",
        "010f": "make",
        "011a": "xResolution",
        "011b": "yResolution",
        "011c": "planarConfiguration",
        "012d": "transferFunction",
        "013b": "artist",
        "013e": "whitePoint",
        "013f": "primaryChromaticities",
        "0100": "imageWidth",
        "0101": "imageHeight",
        "0102": "bitsPerSample",
        "0103": "compression",
        "0106": "photometricInterpretation",
        "0110": "model",
        "0111": "stripOffsets",
        "0112": "orientation",
        "0115": "samplesPerPixel",
        "0116": "rowsPerStrip",
        "0117": "stripByteCounts",
        "0128": "resolutionUnit",
        "0131": "software",
        "0132": "dateTime",
        "0201": "jpegInterchangeFormat",
        "0202": "jpegInterchangeFormatLength",
        "0211": "ycbCrCoefficients",
        "0212": "ycbCrSubSampling",
        "0213": "ycbCrPositioning",
        "0214": "referenceBlackWhite",
        "829a": "exposureTime",
        "829d": "fNumber",
        "920a": "focalLength",
        "927c": "makerNote",
        8298: "copyright",
        8769: "exifIFDPointer",
        8822: "exposureProgram",
        8824: "spectralSensitivity",
        8825: "gpsInfoIFDPointer",
        8827: "photographicSensitivity",
        8828: "oecf",
        8830: "sensitivityType",
        8831: "standardOutputSensitivity",
        8832: "recommendedExposureIndex",
        8833: "isoSpeed",
        8834: "isoSpeedLatitudeyyy",
        8835: "isoSpeedLatitudezzz",
        9000: "exifVersion",
        9003: "dateTimeOriginal",
        9004: "dateTimeDigitized",
        9101: "componentsConfiguration",
        9102: "compressedBitsPerPixel",
        9201: "shutterSpeedValue",
        9202: "apertureValue",
        9203: "brightnessValue",
        9204: "exposureBiasValue",
        9205: "maxApertureValue",
        9206: "subjectDistance",
        9207: "meteringMode",
        9208: "lightSource",
        9209: "flash",
        9214: "subjectArea",
        9286: "userComment",
        9290: "subSecTime",
        9291: "subSecTimeOriginal",
        9292: "subSecTimeDigitized",
        a000: "flashpixVersion",
        a001: "colorSpace",
        a002: "pixelXDimension",
        a003: "pixelYDimension",
        a004: "relatedSoundFile",
        a005: "interoperabilityIFDPointer",
        a20b: "flashEnergy",
        a20c: "spatialFrequencyResponse",
        a20e: "focalPlaneXResolution",
        a20f: "focalPlaneYResolution",
        a40a: "sharpness",
        a40b: "deviceSettingDescription",
        a40c: "subjectDistanceRange",
        a210: "focalPlaneResolutionUnit",
        a214: "subjectLocation",
        a215: "exposureIndex",
        a217: "sensingMethod",
        a300: "fileSource",
        a301: "sceneType",
        a302: "cfaPattern",
        a401: "customRendered",
        a402: "exposureMode",
        a403: "whiteBalance",
        a404: "digitalZoomRatio",
        a405: "focalLengthIn35mmFilm",
        a406: "sceneCaptureType",
        a407: "gainControl",
        a408: "contrast",
        a409: "saturation",
        a420: "imageUniqueID",
        a430: "cameraOwnerName",
        a431: "bodySerialNumber",
        a432: "lensSpecification",
        a433: "lensMake",
        a434: "lensModel",
        a435: "lensSerialNumber",
        a500: "gamma"
    },
    gps: {
        "0000": "gpsVersionID",
        "0001": "gpsLatitudeRef",
        "0002": "gpsLatitude",
        "0003": "gpsLongitudeRef",
        "0004": "gpsLongitude",
        "0005": "gpsAltitudeRef",
        "0006": "gpsAltitude",
        "0007": "gpsTimeStamp",
        "0008": "gpsSatellites",
        "0009": "gpsStatus",
        "000a": "gpsMeasureMode",
        "000b": "gpsDOP",
        "000c": "gpsSpeedRef",
        "000d": "gpsSpeed",
        "000e": "gpsTrackRef",
        "000f": "gpsTrack",
        "0010": "gpsImgDirectionRef",
        "0011": "gpsImgDirection",
        "0012": "gpsMapDatum",
        "0013": "gpsDestLatitudeRef",
        "0014": "gpsDestLatitude",
        "0015": "gpsDestLongitudeRef",
        "0016": "gpsDestLongitude",
        "0017": "gpsDestBearingRef",
        "0018": "gpsDestBearing",
        "0019": "gpsDestDistanceRef",
        "001a": "gpsDestDistance",
        "001b": "gpsProcessingMethod",
        "001c": "gpsAreaInformation",
        "001d": "gpsDateStamp",
        "001e": "gpsDifferential",
        "001f": "gpsHPositioningError"
    }
};
class IDFEntries {
    constructor(bigEndian){
        this.bigEndian = bigEndian;
        this.bytes = [
            0,
            1,
            1,
            2,
            4,
            8,
            1,
            1,
            2,
            4,
            8,
            4,
            8
        ];
    }
    _getTagValue(dataValue, dataFormat, componentsNumber) {
        switch(dataFormat){
            case 2:
                return dataValue.toString("ascii").replace(/\0+$/, "");
            case 129:
                return dataValue.toString("utf8").replace(/\0+$/, "");
            case 7:
                return "0x" + dataValue.toString("hex");
            default:
                return this._getTagValueForNumericalData(dataValue, dataFormat, componentsNumber);
        }
    }
    _getTagValueForNumericalData(dataValue, dataFormat, componentsNumber) {
        const tagValue = [];
        const componentsBytes = this.bytes[dataFormat];
        for(let i = 0; i < componentsNumber; i += 1){
            tagValue.push(this._getSingleTagValueForNumericalData(dataValue, dataFormat, i * componentsBytes));
        }
        return tagValue.length === 1 ? tagValue[0] : tagValue;
    }
    _getSingleTagValueForNumericalData(dataValue, dataFormat, pos) {
        const uint16 = (pos)=>this.bigEndian ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt16BE"])(dataValue, pos) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt16LE"])(dataValue, pos);
        const uint32 = (pos)=>this.bigEndian ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt32BE"])(dataValue, pos) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt32LE"])(dataValue, pos);
        const int32 = (pos)=>this.bigEndian ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readInt32BE"])(dataValue, pos) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readInt32LE"])(dataValue, pos);
        switch(dataFormat){
            case 1:
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt8"])(dataValue, pos);
            case 3:
                return uint16(pos);
            case 4:
                return uint32(pos);
            case 5:
                return uint32(pos) / uint32(pos + 4);
            case 9:
                return int32(pos);
            case 10:
                {
                    return int32(pos) / int32(pos + 4);
                }
        }
    }
    _decodeIDFEntries(buffer, tags, offset, log = false) {
        let pos = 2 + offset;
        const entries = {};
        const uint16 = (pos)=>this.bigEndian ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt16BE"])(buffer, pos) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt16LE"])(buffer, pos);
        const uint32 = (pos)=>this.bigEndian ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt32BE"])(buffer, pos) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt32LE"])(buffer, pos);
        const numberOfEntries = uint16(offset);
        for(let i = 0; i < numberOfEntries; i++){
            const tagAddress = buffer.slice(pos, pos + 2);
            const dataFormat = uint16(pos + 2);
            const componentsNumber = uint32(pos + 4);
            const componentsBytes = this.bytes[dataFormat];
            const dataLength = componentsNumber * componentsBytes;
            let dataValue = buffer.slice(pos + 8, pos + 12);
            if (dataLength > 4) {
                const dataOffset = this.bigEndian ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt32BE"])(dataValue, 0) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["readUInt32LE"])(dataValue, 0);
                dataValue = buffer.slice(dataOffset, dataOffset + dataLength);
            }
            const tagValue = this._getTagValue(dataValue, dataFormat, componentsNumber);
            const tagNumber = this.bigEndian ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8ArrayToHexString"])(tagAddress) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8ArrayToHexString"])(tagAddress.reverse());
            const tagName = tags[tagNumber];
            entries[tagName] = tagValue;
            pos += 12;
        }
        return entries;
    }
    decode(stream, parent) {
        const buffer = stream.buffer.slice(stream.pos - 8);
        const offsetToFirstIFD = parent.offsetToFirstIFD;
        if (offsetToFirstIFD > buffer.length) {
            stream.pos += parent.parent.length - 16;
            return {};
        }
        const entries = this._decodeIDFEntries(buffer, tags.ifd, offsetToFirstIFD);
        const { exifIFDPointer, gpsInfoIFDPointer } = entries;
        if (exifIFDPointer) {
            entries.subExif = this._decodeIDFEntries(buffer, tags.ifd, exifIFDPointer);
        }
        if (gpsInfoIFDPointer) {
            const gps = gpsInfoIFDPointer;
            entries.gpsInfo = this._decodeIDFEntries(buffer, tags.gps, gps, true);
        }
        stream.pos += parent.parent.length - 16;
        return entries;
    }
}
const IFDData = (bigEndian)=>{
    const uint16 = bigEndian ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16le"];
    const uint32 = bigEndian ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint32be"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint32le"];
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Struct"]({
        fortyTwo: uint16,
        offsetToFirstIFD: uint32,
        entries: new IDFEntries(bigEndian)
    });
};
class TIFFHeader {
    decode(stream, parent) {
        const byteOrder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$utils$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8ArrayToString"])(stream.buffer.slice(stream.pos, stream.pos + 2));
        const bigEndian = byteOrder === "MM";
        stream.pos += 2;
        const data = IFDData(bigEndian).decode(stream, parent);
        return data.entries;
    }
}
const EXIFMarker = {
    name: ()=>"EXIF",
    length: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    identifier: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$String$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["String"](6),
    entries: new TIFFHeader()
};
const __TURBOPACK__default__export__ = EXIFMarker;
}),
"[project]/node_modules/jay-peg/src/markers/jfif.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$String$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/String.js [app-client] (ecmascript)");
;
const JFIFMarker = {
    name: ()=>"JFIF",
    length: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    identifier: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$String$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["String"](5),
    version: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    units: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    xDensity: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    yDensity: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    thumbnailWidth: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    thumbnailHeight: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"]
};
const __TURBOPACK__default__export__ = JFIFMarker;
}),
"[project]/node_modules/jay-peg/src/markers/sos.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Struct.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Buffer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Array.js [app-client] (ecmascript)");
;
class ImageData {
    decode(stream) {
        const buffer = stream.buffer.slice(stream.pos);
        let length = 0;
        let i = buffer.indexOf(0xff);
        while(i !== -1){
            length = i;
            const nextByte = buffer[length + 1];
            const comesRestart = nextByte >= 0xd0 && nextByte <= 0xd7;
            if (nextByte !== 0x00 && !comesRestart) break;
            i = buffer.indexOf(0xff, i + 1);
        }
        stream.pos += length;
        return buffer.slice(0, length);
    }
}
const SOSComponentSpecification = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Struct"]({
    scanComponentSelector: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    entropyCodingTable: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"](1)
});
const SOSMarker = {
    name: ()=>"SOS",
    length: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    numberOfImageComponents: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    componentSpecifications: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Array"](SOSComponentSpecification, (parent)=>parent.numberOfImageComponents),
    startOfSpectral: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    endOfSpectral: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    successiveApproximationBit: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"](1),
    data: new ImageData()
};
const __TURBOPACK__default__export__ = SOSMarker;
}),
"[project]/node_modules/jay-peg/src/markers/sof.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Struct.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Array.js [app-client] (ecmascript)");
;
const FrameColorComponent = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Struct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Struct"]({
    id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    samplingFactors: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    quantizationTableId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"]
});
const StartOfFrameMarker = {
    name: ()=>"SOF",
    length: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    precision: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    height: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    width: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    numberOfComponents: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint8"],
    components: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Array"](FrameColorComponent, (parent)=>parent.numberOfComponents)
};
const __TURBOPACK__default__export__ = StartOfFrameMarker;
}),
"[project]/node_modules/jay-peg/src/markers/soi.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const StartOfImageMarker = {
    name: ()=>"SOI"
};
const __TURBOPACK__default__export__ = StartOfImageMarker;
}),
"[project]/node_modules/jay-peg/src/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/restructure/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Number.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Buffer.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$VersionedStruct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/VersionedStruct.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/restructure/src/Array.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$dac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/dac.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$dht$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/dht.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$dqt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/dqt.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$dri$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/dri.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$eoi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/eoi.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$exif$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/exif.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$jfif$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/jfif.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sos$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/sos.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/sof.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$soi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/markers/soi.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const UnknownMarker = {
    length: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"],
    buf: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Buffer$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Buffer"]((parent)=>parent.length - 2)
};
const unknownMarkers = Array(63).fill(0).reduce((acc, v, i)=>({
        ...acc,
        [i + 0xffc0]: UnknownMarker
    }), {});
const Marker = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$VersionedStruct$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["VersionedStruct"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Number$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uint16be"], {
    ...unknownMarkers,
    0xffc0: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffc1: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffc2: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffc3: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffc4: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$dht$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffc5: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffc6: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffc7: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffc9: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffca: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffcb: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffcc: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$dac$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffcd: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffce: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffcf: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sof$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffd8: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$soi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffd9: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$eoi$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffda: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$sos$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffdb: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$dqt$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffdd: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$dri$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffe0: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$jfif$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    0xffe1: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$markers$2f$exif$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
});
const JPEG = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$restructure$2f$src$2f$Array$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Array"](Marker);
const decode = (buffer)=>{
    const markers = JPEG.fromBuffer(buffer);
    return markers.map(({ version, ...rest })=>({
            type: version,
            ...rest
        }));
};
const __TURBOPACK__default__export__ = {
    decode
};
}),
"[project]/node_modules/@react-pdf/font/lib/index.browser.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>FontStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$is$2d$url$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/is-url/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$fontkit$2f$dist$2f$browser$2d$module$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/fontkit/dist/browser-module.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$pdfkit$2f$lib$2f$pdfkit$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/pdfkit/lib/pdfkit.browser.js [app-client] (ecmascript)");
;
;
;
// @ts-expect-error ts being silly
const STANDARD_FONTS = [
    'Courier',
    'Courier-Bold',
    'Courier-Oblique',
    'Courier-BoldOblique',
    'Helvetica',
    'Helvetica-Bold',
    'Helvetica-Oblique',
    'Helvetica-BoldOblique',
    'Times-Roman',
    'Times-Bold',
    'Times-Italic',
    'Times-BoldItalic'
];
class StandardFont {
    name;
    src;
    fullName;
    familyName;
    subfamilyName;
    postscriptName;
    copyright;
    version;
    underlinePosition;
    underlineThickness;
    italicAngle;
    bbox;
    'OS/2';
    hhea;
    numGlyphs;
    characterSet;
    availableFeatures;
    type;
    constructor(src){
        this.name = src;
        this.fullName = src;
        this.familyName = src;
        this.subfamilyName = src;
        this.type = 'STANDARD';
        this.postscriptName = src;
        this.availableFeatures = [];
        this.copyright = '';
        this.version = 1;
        this.underlinePosition = -100;
        this.underlineThickness = 50;
        this.italicAngle = 0;
        this.bbox = {};
        this['OS/2'] = {};
        this.hhea = {};
        this.numGlyphs = 0;
        this.characterSet = [];
        this.src = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$pdfkit$2f$lib$2f$pdfkit$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PDFFont"].open(null, src);
    }
    encode(str) {
        return this.src.encode(str);
    }
    layout(str) {
        const [encoded, positions] = this.encode(str);
        const glyphs = encoded.map((g, i)=>{
            const glyph = this.getGlyph(parseInt(g, 16));
            glyph.advanceWidth = positions[i].advanceWidth;
            return glyph;
        });
        const advanceWidth = positions.reduce((acc, p)=>acc + p.advanceWidth, 0);
        return {
            positions,
            stringIndices: positions.map((_, i)=>i),
            glyphs,
            script: 'latin',
            language: 'dflt',
            direction: 'ltr',
            features: {},
            advanceWidth,
            advanceHeight: 0,
            bbox: undefined
        };
    }
    glyphForCodePoint(codePoint) {
        const glyph = this.getGlyph(codePoint);
        glyph.advanceWidth = 400;
        return glyph;
    }
    getGlyph(id) {
        return {
            id,
            codePoints: [
                id
            ],
            isLigature: false,
            name: this.src.font.characterToGlyph(id),
            _font: this.src,
            // @ts-expect-error assign proper value
            advanceWidth: undefined
        };
    }
    hasGlyphForCodePoint(codePoint) {
        return this.src.font.characterToGlyph(codePoint) !== '.notdef';
    }
    // Based on empirical observation
    get ascent() {
        return 900;
    }
    // Based on empirical observation
    get capHeight() {
        switch(this.name){
            case 'Times-Roman':
            case 'Times-Bold':
            case 'Times-Italic':
            case 'Times-BoldItalic':
                return 650;
            case 'Courier':
            case 'Courier-Bold':
            case 'Courier-Oblique':
            case 'Courier-BoldOblique':
                return 550;
            default:
                return 690;
        }
    }
    // Based on empirical observation
    get xHeight() {
        switch(this.name){
            case 'Times-Roman':
            case 'Times-Bold':
            case 'Times-Italic':
            case 'Times-BoldItalic':
                return 440;
            case 'Courier':
            case 'Courier-Bold':
            case 'Courier-Oblique':
            case 'Courier-BoldOblique':
                return 390;
            default:
                return 490;
        }
    }
    // Based on empirical observation
    get descent() {
        switch(this.name){
            case 'Times-Roman':
            case 'Times-Bold':
            case 'Times-Italic':
            case 'Times-BoldItalic':
                return -220;
            case 'Courier':
            case 'Courier-Bold':
            case 'Courier-Oblique':
            case 'Courier-BoldOblique':
                return -230;
            default:
                return -200;
        }
    }
    get lineGap() {
        return 0;
    }
    get unitsPerEm() {
        return 1000;
    }
    stringsForGlyph() {
        throw new Error('Method not implemented.');
    }
    glyphsForString() {
        throw new Error('Method not implemented.');
    }
    widthOfGlyph() {
        throw new Error('Method not implemented.');
    }
    getAvailableFeatures() {
        throw new Error('Method not implemented.');
    }
    createSubset() {
        throw new Error('Method not implemented.');
    }
    getVariation() {
        throw new Error('Method not implemented.');
    }
    getFont() {
        throw new Error('Method not implemented.');
    }
    getName() {
        throw new Error('Method not implemented.');
    }
    setDefaultLanguage() {
        throw new Error('Method not implemented.');
    }
}
const fetchFont = async (src, options)=>{
    const response = await fetch(src, options);
    const data = await response.arrayBuffer();
    return new Uint8Array(data);
};
const isDataUrl = (dataUrl)=>{
    const header = dataUrl.split(',')[0];
    const hasDataPrefix = header.substring(0, 5) === 'data:';
    const hasBase64Prefix = header.split(';')[1] === 'base64';
    return hasDataPrefix && hasBase64Prefix;
};
class FontSource {
    src;
    fontFamily;
    fontStyle;
    fontWeight;
    data;
    options;
    loadResultPromise;
    constructor(src, fontFamily, fontStyle, fontWeight, options){
        this.src = src;
        this.fontFamily = fontFamily;
        this.fontStyle = fontStyle || 'normal';
        this.fontWeight = fontWeight || 400;
        this.data = null;
        this.options = options || {};
        this.loadResultPromise = null;
    }
    async _load() {
        const { postscriptName } = this.options;
        let data = null;
        if (STANDARD_FONTS.includes(this.src)) {
            data = new StandardFont(this.src);
        } else if (isDataUrl(this.src)) {
            const raw = this.src.split(',')[1];
            const uint8Array = new Uint8Array(atob(raw).split('').map((c)=>c.charCodeAt(0)));
            data = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$fontkit$2f$dist$2f$browser$2d$module$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"](uint8Array, postscriptName);
        } else {
            const { headers, body, method = 'GET' } = this.options;
            const buffer = await fetchFont(this.src, {
                method,
                body,
                headers
            });
            data = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$fontkit$2f$dist$2f$browser$2d$module$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"](buffer, postscriptName);
        }
        if (data && 'fonts' in data) {
            throw new Error('Font collection is not supported');
        }
        this.data = data;
    }
    async load() {
        if (this.loadResultPromise === null) {
            this.loadResultPromise = this._load();
        }
        return this.loadResultPromise;
    }
}
const FONT_WEIGHTS = {
    thin: 100,
    hairline: 100,
    ultralight: 200,
    extralight: 200,
    light: 300,
    normal: 400,
    medium: 500,
    semibold: 600,
    demibold: 600,
    bold: 700,
    ultrabold: 800,
    extrabold: 800,
    heavy: 900,
    black: 900
};
const resolveFontWeight = (value)=>{
    return typeof value === 'string' ? FONT_WEIGHTS[value] : value;
};
const sortByFontWeight = (a, b)=>a.fontWeight - b.fontWeight;
class FontFamily {
    family;
    sources;
    static create(family) {
        return new FontFamily(family);
    }
    constructor(family){
        this.family = family;
        this.sources = [];
    }
    register({ src, fontWeight, fontStyle, ...options }) {
        const numericFontWeight = fontWeight ? resolveFontWeight(fontWeight) : undefined;
        this.sources.push(new FontSource(src, this.family, fontStyle, numericFontWeight, options));
    }
    resolve(descriptor) {
        const { fontWeight = 400, fontStyle = 'normal' } = descriptor;
        const styleSources = this.sources.filter((s)=>s.fontStyle === fontStyle);
        const exactFit = styleSources.find((s)=>s.fontWeight === fontWeight);
        if (exactFit) return exactFit;
        // Weight resolution. https://developer.mozilla.org/en-US/docs/Web/CSS/font-weight#Fallback_weights
        let font = null;
        const numericFontWeight = resolveFontWeight(fontWeight);
        if (numericFontWeight >= 400 && numericFontWeight <= 500) {
            const leftOffset = styleSources.filter((s)=>s.fontWeight <= numericFontWeight);
            const rightOffset = styleSources.filter((s)=>s.fontWeight > 500);
            const fit = styleSources.filter((s)=>s.fontWeight >= numericFontWeight && s.fontWeight < 500);
            font = fit[0] || leftOffset[leftOffset.length - 1] || rightOffset[0];
        }
        const lt = styleSources.filter((s)=>s.fontWeight < numericFontWeight).sort(sortByFontWeight);
        const gt = styleSources.filter((s)=>s.fontWeight > numericFontWeight).sort(sortByFontWeight);
        if (numericFontWeight < 400) {
            font = lt[lt.length - 1] || gt[0];
        }
        if (numericFontWeight > 500) {
            font = gt[0] || lt[lt.length - 1];
        }
        if (!font) {
            throw new Error(`Could not resolve font for ${this.family}, fontWeight ${fontWeight}, fontStyle ${fontStyle}`);
        }
        return font;
    }
}
class FontStore {
    fontFamilies = {};
    emojiSource = null;
    constructor(){
        this.register({
            family: 'Helvetica',
            fonts: [
                {
                    src: 'Helvetica',
                    fontStyle: 'normal',
                    fontWeight: 400
                },
                {
                    src: 'Helvetica-Bold',
                    fontStyle: 'normal',
                    fontWeight: 700
                },
                {
                    src: 'Helvetica-Oblique',
                    fontStyle: 'italic',
                    fontWeight: 400
                },
                {
                    src: 'Helvetica-BoldOblique',
                    fontStyle: 'italic',
                    fontWeight: 700
                }
            ]
        });
        this.register({
            family: 'Courier',
            fonts: [
                {
                    src: 'Courier',
                    fontStyle: 'normal',
                    fontWeight: 400
                },
                {
                    src: 'Courier-Bold',
                    fontStyle: 'normal',
                    fontWeight: 700
                },
                {
                    src: 'Courier-Oblique',
                    fontStyle: 'italic',
                    fontWeight: 400
                },
                {
                    src: 'Courier-BoldOblique',
                    fontStyle: 'italic',
                    fontWeight: 700
                }
            ]
        });
        this.register({
            family: 'Times-Roman',
            fonts: [
                {
                    src: 'Times-Roman',
                    fontStyle: 'normal',
                    fontWeight: 400
                },
                {
                    src: 'Times-Bold',
                    fontStyle: 'normal',
                    fontWeight: 700
                },
                {
                    src: 'Times-Italic',
                    fontStyle: 'italic',
                    fontWeight: 400
                },
                {
                    src: 'Times-BoldItalic',
                    fontStyle: 'italic',
                    fontWeight: 700
                }
            ]
        });
        // For backwards compatibility
        this.register({
            family: 'Helvetica-Bold',
            src: 'Helvetica-Bold'
        });
        this.register({
            family: 'Helvetica-Oblique',
            src: 'Helvetica-Oblique'
        });
        this.register({
            family: 'Helvetica-BoldOblique',
            src: 'Helvetica-BoldOblique'
        });
        this.register({
            family: 'Courier-Bold',
            src: 'Courier-Bold'
        });
        this.register({
            family: 'Courier-Oblique',
            src: 'Courier-Oblique'
        });
        this.register({
            family: 'Courier-BoldOblique',
            src: 'Courier-BoldOblique'
        });
        this.register({
            family: 'Times-Bold',
            src: 'Times-Bold'
        });
        this.register({
            family: 'Times-Italic',
            src: 'Times-Italic'
        });
        this.register({
            family: 'Times-BoldItalic',
            src: 'Times-BoldItalic'
        });
        // Load default fonts
        this.load({
            fontFamily: 'Helvetica',
            fontStyle: 'normal',
            fontWeight: 400
        });
        this.load({
            fontFamily: 'Helvetica',
            fontStyle: 'normal',
            fontWeight: 700
        });
        this.load({
            fontFamily: 'Helvetica',
            fontStyle: 'italic',
            fontWeight: 400
        });
        this.load({
            fontFamily: 'Helvetica',
            fontStyle: 'italic',
            fontWeight: 700
        });
    }
    hyphenationCallback = null;
    register = (data)=>{
        const { family } = data;
        if (!this.fontFamilies[family]) {
            this.fontFamilies[family] = FontFamily.create(family);
        }
        // Bulk loading
        if ('fonts' in data) {
            for(let i = 0; i < data.fonts.length; i += 1){
                const { src, fontStyle, fontWeight, ...options } = data.fonts[i];
                this.fontFamilies[family].register({
                    src,
                    fontStyle,
                    fontWeight,
                    ...options
                });
            }
        } else {
            const { src, fontStyle, fontWeight, ...options } = data;
            this.fontFamilies[family].register({
                src,
                fontStyle,
                fontWeight,
                ...options
            });
        }
    };
    registerEmojiSource = (emojiSource)=>{
        this.emojiSource = emojiSource;
    };
    registerHyphenationCallback = (callback)=>{
        this.hyphenationCallback = callback;
    };
    getFont = (descriptor)=>{
        const { fontFamily } = descriptor;
        if (!this.fontFamilies[fontFamily]) {
            throw new Error(`Font family not registered: ${fontFamily}. Please register it calling Font.register() method.`);
        }
        return this.fontFamilies[fontFamily].resolve(descriptor);
    };
    load = async (descriptor)=>{
        const font = this.getFont(descriptor);
        if (font) await font.load();
    };
    reset = ()=>{
        const keys = Object.keys(this.fontFamilies);
        for(let i = 0; i < keys.length; i += 1){
            const key = keys[i];
            for(let j = 0; j < this.fontFamilies[key].sources.length; j++){
                const fontSource = this.fontFamilies[key].sources[j];
                fontSource.data = null;
            }
        }
    };
    clear = ()=>{
        this.fontFamilies = {};
    };
    getRegisteredFonts = ()=>this.fontFamilies;
    getEmojiSource = ()=>this.emojiSource;
    getHyphenationCallback = ()=>this.hyphenationCallback;
    getRegisteredFontFamilies = ()=>Object.keys(this.fontFamilies);
}
;
}),
"[project]/node_modules/@react-pdf/fns/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "adjust",
    ()=>adjust,
    "asyncCompose",
    ()=>asyncCompose,
    "capitalize",
    ()=>capitalize,
    "castArray",
    ()=>castArray,
    "compose",
    ()=>compose,
    "dropLast",
    ()=>dropLast,
    "evolve",
    ()=>evolve,
    "get",
    ()=>get,
    "isNil",
    ()=>isNil,
    "last",
    ()=>last,
    "mapValues",
    ()=>mapValues,
    "matchPercent",
    ()=>matchPercent,
    "omit",
    ()=>omit,
    "parseFloat",
    ()=>parseFloat$1,
    "pick",
    ()=>pick,
    "repeat",
    ()=>repeat,
    "reverse",
    ()=>reverse,
    "upperFirst",
    ()=>upperFirst,
    "without",
    ()=>without
]);
/**
 * Applies a function to the value at the given index of an array
 *
 * @param index
 * @param fn
 * @param collection
 * @returns Copy of the array with the element at the given index replaced with the result of the function application.
 */ const adjust = (index, fn, collection)=>{
    if (index >= 0 && index >= collection.length) return collection;
    if (index < 0 && Math.abs(index) > collection.length) return collection;
    const i = index < 0 ? collection.length + index : index;
    return Object.assign([], collection, {
        [i]: fn(collection[i])
    });
};
/* eslint-disable no-await-in-loop */ /**
 * Performs right-to-left function composition with async functions support
 *
 * @param fns - Functions
 * @returns Composed function
 */ const asyncCompose = (...fns)=>async (value, ...args)=>{
        let result = value;
        const reversedFns = fns.slice().reverse();
        for(let i = 0; i < reversedFns.length; i += 1){
            const fn = reversedFns[i];
            result = await fn(result, ...args);
        }
        return result;
    };
/**
 * Capitalize first letter of each word
 *
 * @param value - Any string
 * @returns Capitalized string
 */ const capitalize = (value)=>{
    if (!value) return value;
    return value.replace(/(^|\s)\S/g, (l)=>l.toUpperCase());
};
/**
 * Casts value to array
 *
 * @template T - The type of the value.
 * @param value - The value to cast into an array.
 * @returns An array containing the given value.
 */ const castArray = (value)=>{
    return Array.isArray(value) ? value : [
        value
    ];
};
/**
 * Performs right-to-left function composition
 *
 * @param fns - Functions
 * @returns Composed function
 */ const compose = (...fns)=>(value, ...args)=>{
        let result = value;
        const reversedFns = fns.slice().reverse();
        for(let i = 0; i < reversedFns.length; i += 1){
            const fn = reversedFns[i];
            result = fn(result, ...args);
        }
        return result;
    };
/**
 * Drops the last element from an array.
 *
 * @template T
 * @param  array - The array to drop the last element from
 * @returns - The new array with the last element dropped
 */ const dropLast = (array)=>array.slice(0, array.length - 1);
/**
 * Applies a set of transformations to an object and returns a new object with the transformed values.
 *
 * @template T
 * @param transformations - The transformations to apply.
 * @param object - The object to transform.
 * @returns The transformed object.
 */ function evolve(transformations, object) {
    const result = {};
    const keys = Object.keys(object);
    for(let i = 0; i < keys.length; i += 1){
        const key = keys[i];
        const transformation = transformations[key];
        if (typeof transformation === 'function') {
            result[key] = transformation(object[key]);
        } else {
            result[key] = object[key];
        }
    }
    return result;
}
/**
 * Checks if a value is null or undefined.
 *
 * @template T - The type of the value.
 * @param value - The value to check
 * @returns True if the value is null or undefined, false otherwise
 */ const isNil = (value)=>value === null || value === undefined;
/**
 * Retrieves the value at a given path from an object.
 *
 * @param target - The object to retrieve the value from.
 * @param path - The path of the value to retrieve.
 * @param defaultValue - The default value to return if the path does not exist.
 * @returns The value at the given path, or the default value if the path does not exist.
 */ const get = (target, path, defaultValue)=>{
    if (isNil(target)) return defaultValue;
    const _path = castArray(path);
    let result = target;
    for(let i = 0; i < _path.length; i += 1){
        if (isNil(result)) return undefined;
        result = result[_path[i]];
    }
    return isNil(result) ? defaultValue : result;
};
function last(value) {
    return value === '' ? '' : value[value.length - 1];
}
/**
 * Maps over the values of an object and applies a function to each value.
 *
 * @param object - The object to map over
 * @param fn - The function to apply to each value
 * @returns A new object with the mapped values
 */ const mapValues = (object, fn)=>{
    const entries = Object.entries(object);
    const acc = {};
    return entries.reduce((acc, [key, value], index)=>{
        acc[key] = fn(value, key, index);
        return acc;
    }, acc);
};
const isPercent = (value)=>/((-)?\d+\.?\d*)%/g.exec(`${value}`);
/**
 * Get percentage value of input
 *
 * @param value
 * @returns Percent value (if matches)
 */ const matchPercent = (value)=>{
    const match = isPercent(value);
    if (match) {
        const f = parseFloat(match[1]);
        const percent = f / 100;
        return {
            percent,
            value: f
        };
    }
    return null;
};
/**
 * Creates a new object by omitting specified keys from the original object.
 *
 * @param keys - The key or keys to omit
 * @param object - The original object
 * @returns The new object without the omitted keys
 */ const omit = (keys, object)=>{
    const _keys = castArray(keys);
    const copy = Object.assign({}, object);
    _keys.forEach((key)=>{
        delete copy[key];
    });
    return copy;
};
/**
 * Picks the specified keys from an object and returns a new object with only those keys.
 *
 * @param keys - The keys to pick from the object
 * @param object - The object to pick the keys from
 * @returns A new object with only the picked keys
 */ const pick = (keys, obj)=>{
    const result = {};
    for(let i = 0; i < keys.length; i += 1){
        const key = keys[i];
        if (key in obj) result[key] = obj[key];
    }
    return result;
};
/**
 * Repeats an element a specified number of times.
 *
 * @template T
 * @param element - Element to be repeated
 * @param length - Number of times to repeat element
 * @returns Repeated elements
 */ const repeat = (element, length = 0)=>{
    const result = new Array(length);
    for(let i = 0; i < length; i += 1){
        result[i] = element;
    }
    return result;
};
/**
 * Reverses the list
 *
 * @template T
 * @param list - List to be reversed
 * @returns Reversed list
 */ const reverse = (list)=>Array.prototype.slice.call(list, 0).reverse();
/**
 * Capitalize first letter of string
 *
 * @param value - String
 * @returns Capitalized string
 */ const upperFirst = (value)=>{
    if (!value) return value;
    return value.charAt(0).toUpperCase() + value.slice(1);
};
/**
 * Returns a new array with all the values from the original array that are not present in the keys array.
 *
 * @param keys - The keys to pick from the object
 * @param array - Array to filter the values from
 * @returns A new array with without the omitted values
 */ const without = (keys, array)=>{
    const result = [];
    for(let i = 0; i < array.length; i += 1){
        const value = array[i];
        if (!keys.includes(value)) result.push(value);
    }
    return result;
};
/**
 * Parse a string or number to a float
 *
 * @param value - String or number
 * @returns Parsed float
 */ const parseFloat$1 = (value)=>{
    return typeof value === 'string' ? Number.parseFloat(value) : value;
};
;
}),
"[project]/node_modules/abs-svg-path/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = absolutize;
/**
 * redefine `path` with absolute coordinates
 *
 * @param {Array} path
 * @return {Array}
 */ function absolutize(path) {
    var startX = 0;
    var startY = 0;
    var x = 0;
    var y = 0;
    return path.map(function(seg) {
        seg = seg.slice();
        var type = seg[0];
        var command = type.toUpperCase();
        // is relative
        if (type != command) {
            seg[0] = command;
            switch(type){
                case 'a':
                    seg[6] += x;
                    seg[7] += y;
                    break;
                case 'v':
                    seg[1] += y;
                    break;
                case 'h':
                    seg[1] += x;
                    break;
                default:
                    for(var i = 1; i < seg.length;){
                        seg[i++] += x;
                        seg[i++] += y;
                    }
            }
        }
        // update cursor state
        switch(command){
            case 'Z':
                x = startX;
                y = startY;
                break;
            case 'H':
                x = seg[1];
                break;
            case 'V':
                y = seg[1];
                break;
            case 'M':
                x = startX = seg[1];
                y = startY = seg[2];
                break;
            default:
                x = seg[seg.length - 2];
                y = seg[seg.length - 1];
        }
        return seg;
    });
}
}),
"[project]/node_modules/parse-svg-path/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = parse;
/**
 * expected argument lengths
 * @type {Object}
 */ var length = {
    a: 7,
    c: 6,
    h: 1,
    l: 2,
    m: 2,
    q: 4,
    s: 4,
    t: 2,
    v: 1,
    z: 0
};
/**
 * segment pattern
 * @type {RegExp}
 */ var segment = /([astvzqmhlc])([^astvzqmhlc]*)/ig;
/**
 * parse an svg path data string. Generates an Array
 * of commands where each command is an Array of the
 * form `[command, arg1, arg2, ...]`
 *
 * @param {String} path
 * @return {Array}
 */ function parse(path) {
    var data = [];
    path.replace(segment, function(_, command, args) {
        var type = command.toLowerCase();
        args = parseValues(args);
        // overloaded moveTo
        if (type == 'm' && args.length > 2) {
            data.push([
                command
            ].concat(args.splice(0, 2)));
            type = 'l';
            command = command == 'm' ? 'l' : 'L';
        }
        while(true){
            if (args.length == length[type]) {
                args.unshift(command);
                return data.push(args);
            }
            if (args.length < length[type]) throw new Error('malformed path data');
            data.push([
                command
            ].concat(args.splice(0, length[type])));
        }
    });
    return data;
}
var number = /-?[0-9]*\.?[0-9]+(?:e[-+]?\d+)?/ig;
function parseValues(args) {
    var numbers = args.match(number);
    return numbers ? numbers.map(Number) : [];
}
}),
"[project]/node_modules/svg-arc-to-cubic-bezier/modules/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var _slicedToArray = function() {
    function sliceIterator(arr, i) {
        var _arr = [];
        var _n = true;
        var _d = false;
        var _e = undefined;
        try {
            for(var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true){
                _arr.push(_s.value);
                if (i && _arr.length === i) break;
            }
        } catch (err) {
            _d = true;
            _e = err;
        } finally{
            try {
                if (!_n && _i["return"]) _i["return"]();
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
    return function(arr, i) {
        if (Array.isArray(arr)) {
            return arr;
        } else if (Symbol.iterator in Object(arr)) {
            return sliceIterator(arr, i);
        } else {
            throw new TypeError("Invalid attempt to destructure non-iterable instance");
        }
    };
}();
var TAU = Math.PI * 2;
var mapToEllipse = function mapToEllipse(_ref, rx, ry, cosphi, sinphi, centerx, centery) {
    var x = _ref.x, y = _ref.y;
    x *= rx;
    y *= ry;
    var xp = cosphi * x - sinphi * y;
    var yp = sinphi * x + cosphi * y;
    return {
        x: xp + centerx,
        y: yp + centery
    };
};
var approxUnitArc = function approxUnitArc(ang1, ang2) {
    // If 90 degree circular arc, use a constant
    // as derived from http://spencermortensen.com/articles/bezier-circle
    var a = ang2 === 1.5707963267948966 ? 0.551915024494 : ang2 === -1.5707963267948966 ? -0.551915024494 : 4 / 3 * Math.tan(ang2 / 4);
    var x1 = Math.cos(ang1);
    var y1 = Math.sin(ang1);
    var x2 = Math.cos(ang1 + ang2);
    var y2 = Math.sin(ang1 + ang2);
    return [
        {
            x: x1 - y1 * a,
            y: y1 + x1 * a
        },
        {
            x: x2 + y2 * a,
            y: y2 - x2 * a
        },
        {
            x: x2,
            y: y2
        }
    ];
};
var vectorAngle = function vectorAngle(ux, uy, vx, vy) {
    var sign = ux * vy - uy * vx < 0 ? -1 : 1;
    var dot = ux * vx + uy * vy;
    if (dot > 1) {
        dot = 1;
    }
    if (dot < -1) {
        dot = -1;
    }
    return sign * Math.acos(dot);
};
var getArcCenter = function getArcCenter(px, py, cx, cy, rx, ry, largeArcFlag, sweepFlag, sinphi, cosphi, pxp, pyp) {
    var rxsq = Math.pow(rx, 2);
    var rysq = Math.pow(ry, 2);
    var pxpsq = Math.pow(pxp, 2);
    var pypsq = Math.pow(pyp, 2);
    var radicant = rxsq * rysq - rxsq * pypsq - rysq * pxpsq;
    if (radicant < 0) {
        radicant = 0;
    }
    radicant /= rxsq * pypsq + rysq * pxpsq;
    radicant = Math.sqrt(radicant) * (largeArcFlag === sweepFlag ? -1 : 1);
    var centerxp = radicant * rx / ry * pyp;
    var centeryp = radicant * -ry / rx * pxp;
    var centerx = cosphi * centerxp - sinphi * centeryp + (px + cx) / 2;
    var centery = sinphi * centerxp + cosphi * centeryp + (py + cy) / 2;
    var vx1 = (pxp - centerxp) / rx;
    var vy1 = (pyp - centeryp) / ry;
    var vx2 = (-pxp - centerxp) / rx;
    var vy2 = (-pyp - centeryp) / ry;
    var ang1 = vectorAngle(1, 0, vx1, vy1);
    var ang2 = vectorAngle(vx1, vy1, vx2, vy2);
    if (sweepFlag === 0 && ang2 > 0) {
        ang2 -= TAU;
    }
    if (sweepFlag === 1 && ang2 < 0) {
        ang2 += TAU;
    }
    return [
        centerx,
        centery,
        ang1,
        ang2
    ];
};
var arcToBezier = function arcToBezier(_ref2) {
    var px = _ref2.px, py = _ref2.py, cx = _ref2.cx, cy = _ref2.cy, rx = _ref2.rx, ry = _ref2.ry, _ref2$xAxisRotation = _ref2.xAxisRotation, xAxisRotation = _ref2$xAxisRotation === undefined ? 0 : _ref2$xAxisRotation, _ref2$largeArcFlag = _ref2.largeArcFlag, largeArcFlag = _ref2$largeArcFlag === undefined ? 0 : _ref2$largeArcFlag, _ref2$sweepFlag = _ref2.sweepFlag, sweepFlag = _ref2$sweepFlag === undefined ? 0 : _ref2$sweepFlag;
    var curves = [];
    if (rx === 0 || ry === 0) {
        return [];
    }
    var sinphi = Math.sin(xAxisRotation * TAU / 360);
    var cosphi = Math.cos(xAxisRotation * TAU / 360);
    var pxp = cosphi * (px - cx) / 2 + sinphi * (py - cy) / 2;
    var pyp = -sinphi * (px - cx) / 2 + cosphi * (py - cy) / 2;
    if (pxp === 0 && pyp === 0) {
        return [];
    }
    rx = Math.abs(rx);
    ry = Math.abs(ry);
    var lambda = Math.pow(pxp, 2) / Math.pow(rx, 2) + Math.pow(pyp, 2) / Math.pow(ry, 2);
    if (lambda > 1) {
        rx *= Math.sqrt(lambda);
        ry *= Math.sqrt(lambda);
    }
    var _getArcCenter = getArcCenter(px, py, cx, cy, rx, ry, largeArcFlag, sweepFlag, sinphi, cosphi, pxp, pyp), _getArcCenter2 = _slicedToArray(_getArcCenter, 4), centerx = _getArcCenter2[0], centery = _getArcCenter2[1], ang1 = _getArcCenter2[2], ang2 = _getArcCenter2[3];
    // If 'ang2' == 90.0000000001, then `ratio` will evaluate to
    // 1.0000000001. This causes `segments` to be greater than one, which is an
    // unecessary split, and adds extra points to the bezier curve. To alleviate
    // this issue, we round to 1.0 when the ratio is close to 1.0.
    var ratio = Math.abs(ang2) / (TAU / 4);
    if (Math.abs(1.0 - ratio) < 0.0000001) {
        ratio = 1.0;
    }
    var segments = Math.max(Math.ceil(ratio), 1);
    ang2 /= segments;
    for(var i = 0; i < segments; i++){
        curves.push(approxUnitArc(ang1, ang2));
        ang1 += ang2;
    }
    return curves.map(function(curve) {
        var _mapToEllipse = mapToEllipse(curve[0], rx, ry, cosphi, sinphi, centerx, centery), x1 = _mapToEllipse.x, y1 = _mapToEllipse.y;
        var _mapToEllipse2 = mapToEllipse(curve[1], rx, ry, cosphi, sinphi, centerx, centery), x2 = _mapToEllipse2.x, y2 = _mapToEllipse2.y;
        var _mapToEllipse3 = mapToEllipse(curve[2], rx, ry, cosphi, sinphi, centerx, centery), x = _mapToEllipse3.x, y = _mapToEllipse3.y;
        return {
            x1: x1,
            y1: y1,
            x2: x2,
            y2: y2,
            x: x,
            y: y
        };
    });
};
const __TURBOPACK__default__export__ = arcToBezier;
}),
"[project]/node_modules/normalize-svg-path/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>normalize
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$svg$2d$arc$2d$to$2d$cubic$2d$bezier$2f$modules$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/svg-arc-to-cubic-bezier/modules/index.js [app-client] (ecmascript)");
;
function normalize(path) {
    // init state
    var prev;
    var result = [];
    var bezierX = 0;
    var bezierY = 0;
    var startX = 0;
    var startY = 0;
    var quadX = null;
    var quadY = null;
    var x = 0;
    var y = 0;
    for(var i = 0, len = path.length; i < len; i++){
        var seg = path[i];
        var command = seg[0];
        switch(command){
            case 'M':
                startX = seg[1];
                startY = seg[2];
                break;
            case 'A':
                var curves = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$svg$2d$arc$2d$to$2d$cubic$2d$bezier$2f$modules$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    px: x,
                    py: y,
                    cx: seg[6],
                    cy: seg[7],
                    rx: seg[1],
                    ry: seg[2],
                    xAxisRotation: seg[3],
                    largeArcFlag: seg[4],
                    sweepFlag: seg[5]
                });
                // null-curves
                if (!curves.length) continue;
                for(var j = 0, c; j < curves.length; j++){
                    c = curves[j];
                    seg = [
                        'C',
                        c.x1,
                        c.y1,
                        c.x2,
                        c.y2,
                        c.x,
                        c.y
                    ];
                    if (j < curves.length - 1) result.push(seg);
                }
                break;
            case 'S':
                // default control point
                var cx = x;
                var cy = y;
                if (prev == 'C' || prev == 'S') {
                    cx += cx - bezierX; // reflect the previous command's control
                    cy += cy - bezierY; // point relative to the current point
                }
                seg = [
                    'C',
                    cx,
                    cy,
                    seg[1],
                    seg[2],
                    seg[3],
                    seg[4]
                ];
                break;
            case 'T':
                if (prev == 'Q' || prev == 'T') {
                    quadX = x * 2 - quadX; // as with 'S' reflect previous control point
                    quadY = y * 2 - quadY;
                } else {
                    quadX = x;
                    quadY = y;
                }
                seg = quadratic(x, y, quadX, quadY, seg[1], seg[2]);
                break;
            case 'Q':
                quadX = seg[1];
                quadY = seg[2];
                seg = quadratic(x, y, seg[1], seg[2], seg[3], seg[4]);
                break;
            case 'L':
                seg = line(x, y, seg[1], seg[2]);
                break;
            case 'H':
                seg = line(x, y, seg[1], y);
                break;
            case 'V':
                seg = line(x, y, x, seg[1]);
                break;
            case 'Z':
                seg = line(x, y, startX, startY);
                break;
        }
        // update state
        prev = command;
        x = seg[seg.length - 2];
        y = seg[seg.length - 1];
        if (seg.length > 4) {
            bezierX = seg[seg.length - 4];
            bezierY = seg[seg.length - 3];
        } else {
            bezierX = x;
            bezierY = y;
        }
        result.push(seg);
    }
    return result;
}
function line(x1, y1, x2, y2) {
    return [
        'C',
        x1,
        y1,
        x2,
        y2,
        x2,
        y2
    ];
}
function quadratic(x1, y1, cx, cy, x2, y2) {
    return [
        'C',
        x1 / 3 + 2 / 3 * cx,
        y1 / 3 + 2 / 3 * cy,
        x2 / 3 + 2 / 3 * cx,
        y2 / 3 + 2 / 3 * cy,
        x2,
        y2
    ];
}
}),
"[project]/node_modules/color-name/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = {
    "aliceblue": [
        240,
        248,
        255
    ],
    "antiquewhite": [
        250,
        235,
        215
    ],
    "aqua": [
        0,
        255,
        255
    ],
    "aquamarine": [
        127,
        255,
        212
    ],
    "azure": [
        240,
        255,
        255
    ],
    "beige": [
        245,
        245,
        220
    ],
    "bisque": [
        255,
        228,
        196
    ],
    "black": [
        0,
        0,
        0
    ],
    "blanchedalmond": [
        255,
        235,
        205
    ],
    "blue": [
        0,
        0,
        255
    ],
    "blueviolet": [
        138,
        43,
        226
    ],
    "brown": [
        165,
        42,
        42
    ],
    "burlywood": [
        222,
        184,
        135
    ],
    "cadetblue": [
        95,
        158,
        160
    ],
    "chartreuse": [
        127,
        255,
        0
    ],
    "chocolate": [
        210,
        105,
        30
    ],
    "coral": [
        255,
        127,
        80
    ],
    "cornflowerblue": [
        100,
        149,
        237
    ],
    "cornsilk": [
        255,
        248,
        220
    ],
    "crimson": [
        220,
        20,
        60
    ],
    "cyan": [
        0,
        255,
        255
    ],
    "darkblue": [
        0,
        0,
        139
    ],
    "darkcyan": [
        0,
        139,
        139
    ],
    "darkgoldenrod": [
        184,
        134,
        11
    ],
    "darkgray": [
        169,
        169,
        169
    ],
    "darkgreen": [
        0,
        100,
        0
    ],
    "darkgrey": [
        169,
        169,
        169
    ],
    "darkkhaki": [
        189,
        183,
        107
    ],
    "darkmagenta": [
        139,
        0,
        139
    ],
    "darkolivegreen": [
        85,
        107,
        47
    ],
    "darkorange": [
        255,
        140,
        0
    ],
    "darkorchid": [
        153,
        50,
        204
    ],
    "darkred": [
        139,
        0,
        0
    ],
    "darksalmon": [
        233,
        150,
        122
    ],
    "darkseagreen": [
        143,
        188,
        143
    ],
    "darkslateblue": [
        72,
        61,
        139
    ],
    "darkslategray": [
        47,
        79,
        79
    ],
    "darkslategrey": [
        47,
        79,
        79
    ],
    "darkturquoise": [
        0,
        206,
        209
    ],
    "darkviolet": [
        148,
        0,
        211
    ],
    "deeppink": [
        255,
        20,
        147
    ],
    "deepskyblue": [
        0,
        191,
        255
    ],
    "dimgray": [
        105,
        105,
        105
    ],
    "dimgrey": [
        105,
        105,
        105
    ],
    "dodgerblue": [
        30,
        144,
        255
    ],
    "firebrick": [
        178,
        34,
        34
    ],
    "floralwhite": [
        255,
        250,
        240
    ],
    "forestgreen": [
        34,
        139,
        34
    ],
    "fuchsia": [
        255,
        0,
        255
    ],
    "gainsboro": [
        220,
        220,
        220
    ],
    "ghostwhite": [
        248,
        248,
        255
    ],
    "gold": [
        255,
        215,
        0
    ],
    "goldenrod": [
        218,
        165,
        32
    ],
    "gray": [
        128,
        128,
        128
    ],
    "green": [
        0,
        128,
        0
    ],
    "greenyellow": [
        173,
        255,
        47
    ],
    "grey": [
        128,
        128,
        128
    ],
    "honeydew": [
        240,
        255,
        240
    ],
    "hotpink": [
        255,
        105,
        180
    ],
    "indianred": [
        205,
        92,
        92
    ],
    "indigo": [
        75,
        0,
        130
    ],
    "ivory": [
        255,
        255,
        240
    ],
    "khaki": [
        240,
        230,
        140
    ],
    "lavender": [
        230,
        230,
        250
    ],
    "lavenderblush": [
        255,
        240,
        245
    ],
    "lawngreen": [
        124,
        252,
        0
    ],
    "lemonchiffon": [
        255,
        250,
        205
    ],
    "lightblue": [
        173,
        216,
        230
    ],
    "lightcoral": [
        240,
        128,
        128
    ],
    "lightcyan": [
        224,
        255,
        255
    ],
    "lightgoldenrodyellow": [
        250,
        250,
        210
    ],
    "lightgray": [
        211,
        211,
        211
    ],
    "lightgreen": [
        144,
        238,
        144
    ],
    "lightgrey": [
        211,
        211,
        211
    ],
    "lightpink": [
        255,
        182,
        193
    ],
    "lightsalmon": [
        255,
        160,
        122
    ],
    "lightseagreen": [
        32,
        178,
        170
    ],
    "lightskyblue": [
        135,
        206,
        250
    ],
    "lightslategray": [
        119,
        136,
        153
    ],
    "lightslategrey": [
        119,
        136,
        153
    ],
    "lightsteelblue": [
        176,
        196,
        222
    ],
    "lightyellow": [
        255,
        255,
        224
    ],
    "lime": [
        0,
        255,
        0
    ],
    "limegreen": [
        50,
        205,
        50
    ],
    "linen": [
        250,
        240,
        230
    ],
    "magenta": [
        255,
        0,
        255
    ],
    "maroon": [
        128,
        0,
        0
    ],
    "mediumaquamarine": [
        102,
        205,
        170
    ],
    "mediumblue": [
        0,
        0,
        205
    ],
    "mediumorchid": [
        186,
        85,
        211
    ],
    "mediumpurple": [
        147,
        112,
        219
    ],
    "mediumseagreen": [
        60,
        179,
        113
    ],
    "mediumslateblue": [
        123,
        104,
        238
    ],
    "mediumspringgreen": [
        0,
        250,
        154
    ],
    "mediumturquoise": [
        72,
        209,
        204
    ],
    "mediumvioletred": [
        199,
        21,
        133
    ],
    "midnightblue": [
        25,
        25,
        112
    ],
    "mintcream": [
        245,
        255,
        250
    ],
    "mistyrose": [
        255,
        228,
        225
    ],
    "moccasin": [
        255,
        228,
        181
    ],
    "navajowhite": [
        255,
        222,
        173
    ],
    "navy": [
        0,
        0,
        128
    ],
    "oldlace": [
        253,
        245,
        230
    ],
    "olive": [
        128,
        128,
        0
    ],
    "olivedrab": [
        107,
        142,
        35
    ],
    "orange": [
        255,
        165,
        0
    ],
    "orangered": [
        255,
        69,
        0
    ],
    "orchid": [
        218,
        112,
        214
    ],
    "palegoldenrod": [
        238,
        232,
        170
    ],
    "palegreen": [
        152,
        251,
        152
    ],
    "paleturquoise": [
        175,
        238,
        238
    ],
    "palevioletred": [
        219,
        112,
        147
    ],
    "papayawhip": [
        255,
        239,
        213
    ],
    "peachpuff": [
        255,
        218,
        185
    ],
    "peru": [
        205,
        133,
        63
    ],
    "pink": [
        255,
        192,
        203
    ],
    "plum": [
        221,
        160,
        221
    ],
    "powderblue": [
        176,
        224,
        230
    ],
    "purple": [
        128,
        0,
        128
    ],
    "rebeccapurple": [
        102,
        51,
        153
    ],
    "red": [
        255,
        0,
        0
    ],
    "rosybrown": [
        188,
        143,
        143
    ],
    "royalblue": [
        65,
        105,
        225
    ],
    "saddlebrown": [
        139,
        69,
        19
    ],
    "salmon": [
        250,
        128,
        114
    ],
    "sandybrown": [
        244,
        164,
        96
    ],
    "seagreen": [
        46,
        139,
        87
    ],
    "seashell": [
        255,
        245,
        238
    ],
    "sienna": [
        160,
        82,
        45
    ],
    "silver": [
        192,
        192,
        192
    ],
    "skyblue": [
        135,
        206,
        235
    ],
    "slateblue": [
        106,
        90,
        205
    ],
    "slategray": [
        112,
        128,
        144
    ],
    "slategrey": [
        112,
        128,
        144
    ],
    "snow": [
        255,
        250,
        250
    ],
    "springgreen": [
        0,
        255,
        127
    ],
    "steelblue": [
        70,
        130,
        180
    ],
    "tan": [
        210,
        180,
        140
    ],
    "teal": [
        0,
        128,
        128
    ],
    "thistle": [
        216,
        191,
        216
    ],
    "tomato": [
        255,
        99,
        71
    ],
    "turquoise": [
        64,
        224,
        208
    ],
    "violet": [
        238,
        130,
        238
    ],
    "wheat": [
        245,
        222,
        179
    ],
    "white": [
        255,
        255,
        255
    ],
    "whitesmoke": [
        245,
        245,
        245
    ],
    "yellow": [
        255,
        255,
        0
    ],
    "yellowgreen": [
        154,
        205,
        50
    ]
};
}),
"[project]/node_modules/is-arrayish/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

module.exports = function isArrayish(obj) {
    if (!obj || typeof obj === 'string') {
        return false;
    }
    return obj instanceof Array || Array.isArray(obj) || obj.length >= 0 && (obj.splice instanceof Function || Object.getOwnPropertyDescriptor(obj, obj.length - 1) && obj.constructor.name !== 'String');
};
}),
"[project]/node_modules/simple-swizzle/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var isArrayish = __turbopack_context__.r("[project]/node_modules/is-arrayish/index.js [app-client] (ecmascript)");
var concat = Array.prototype.concat;
var slice = Array.prototype.slice;
var swizzle = module.exports = function swizzle(args) {
    var results = [];
    for(var i = 0, len = args.length; i < len; i++){
        var arg = args[i];
        if (isArrayish(arg)) {
            // http://jsperf.com/javascript-array-concat-vs-push/98
            results = concat.call(results, slice.call(arg));
        } else {
            results.push(arg);
        }
    }
    return results;
};
swizzle.wrap = function(fn) {
    return function() {
        return fn(swizzle(arguments));
    };
};
}),
"[project]/node_modules/color-string/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/* MIT license */ var colorNames = __turbopack_context__.r("[project]/node_modules/color-name/index.js [app-client] (ecmascript)");
var swizzle = __turbopack_context__.r("[project]/node_modules/simple-swizzle/index.js [app-client] (ecmascript)");
var hasOwnProperty = Object.hasOwnProperty;
var reverseNames = Object.create(null);
// create a list of reverse color names
for(var name in colorNames){
    if (hasOwnProperty.call(colorNames, name)) {
        reverseNames[colorNames[name]] = name;
    }
}
var cs = module.exports = {
    to: {},
    get: {}
};
cs.get = function(string) {
    var prefix = string.substring(0, 3).toLowerCase();
    var val;
    var model;
    switch(prefix){
        case 'hsl':
            val = cs.get.hsl(string);
            model = 'hsl';
            break;
        case 'hwb':
            val = cs.get.hwb(string);
            model = 'hwb';
            break;
        default:
            val = cs.get.rgb(string);
            model = 'rgb';
            break;
    }
    if (!val) {
        return null;
    }
    return {
        model: model,
        value: val
    };
};
cs.get.rgb = function(string) {
    if (!string) {
        return null;
    }
    var abbr = /^#([a-f0-9]{3,4})$/i;
    var hex = /^#([a-f0-9]{6})([a-f0-9]{2})?$/i;
    var rgba = /^rgba?\(\s*([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)(?=[\s,])\s*(?:,\s*)?([+-]?\d+)\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/;
    var per = /^rgba?\(\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*,?\s*([+-]?[\d\.]+)\%\s*(?:[,|\/]\s*([+-]?[\d\.]+)(%?)\s*)?\)$/;
    var keyword = /^(\w+)$/;
    var rgb = [
        0,
        0,
        0,
        1
    ];
    var match;
    var i;
    var hexAlpha;
    if (match = string.match(hex)) {
        hexAlpha = match[2];
        match = match[1];
        for(i = 0; i < 3; i++){
            // https://jsperf.com/slice-vs-substr-vs-substring-methods-long-string/19
            var i2 = i * 2;
            rgb[i] = parseInt(match.slice(i2, i2 + 2), 16);
        }
        if (hexAlpha) {
            rgb[3] = parseInt(hexAlpha, 16) / 255;
        }
    } else if (match = string.match(abbr)) {
        match = match[1];
        hexAlpha = match[3];
        for(i = 0; i < 3; i++){
            rgb[i] = parseInt(match[i] + match[i], 16);
        }
        if (hexAlpha) {
            rgb[3] = parseInt(hexAlpha + hexAlpha, 16) / 255;
        }
    } else if (match = string.match(rgba)) {
        for(i = 0; i < 3; i++){
            rgb[i] = parseInt(match[i + 1], 0);
        }
        if (match[4]) {
            if (match[5]) {
                rgb[3] = parseFloat(match[4]) * 0.01;
            } else {
                rgb[3] = parseFloat(match[4]);
            }
        }
    } else if (match = string.match(per)) {
        for(i = 0; i < 3; i++){
            rgb[i] = Math.round(parseFloat(match[i + 1]) * 2.55);
        }
        if (match[4]) {
            if (match[5]) {
                rgb[3] = parseFloat(match[4]) * 0.01;
            } else {
                rgb[3] = parseFloat(match[4]);
            }
        }
    } else if (match = string.match(keyword)) {
        if (match[1] === 'transparent') {
            return [
                0,
                0,
                0,
                0
            ];
        }
        if (!hasOwnProperty.call(colorNames, match[1])) {
            return null;
        }
        rgb = colorNames[match[1]];
        rgb[3] = 1;
        return rgb;
    } else {
        return null;
    }
    for(i = 0; i < 3; i++){
        rgb[i] = clamp(rgb[i], 0, 255);
    }
    rgb[3] = clamp(rgb[3], 0, 1);
    return rgb;
};
cs.get.hsl = function(string) {
    if (!string) {
        return null;
    }
    var hsl = /^hsla?\(\s*([+-]?(?:\d{0,3}\.)?\d+)(?:deg)?\s*,?\s*([+-]?[\d\.]+)%\s*,?\s*([+-]?[\d\.]+)%\s*(?:[,|\/]\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/;
    var match = string.match(hsl);
    if (match) {
        var alpha = parseFloat(match[4]);
        var h = (parseFloat(match[1]) % 360 + 360) % 360;
        var s = clamp(parseFloat(match[2]), 0, 100);
        var l = clamp(parseFloat(match[3]), 0, 100);
        var a = clamp(isNaN(alpha) ? 1 : alpha, 0, 1);
        return [
            h,
            s,
            l,
            a
        ];
    }
    return null;
};
cs.get.hwb = function(string) {
    if (!string) {
        return null;
    }
    var hwb = /^hwb\(\s*([+-]?\d{0,3}(?:\.\d+)?)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?(?=\.\d|\d)(?:0|[1-9]\d*)?(?:\.\d*)?(?:[eE][+-]?\d+)?)\s*)?\)$/;
    var match = string.match(hwb);
    if (match) {
        var alpha = parseFloat(match[4]);
        var h = (parseFloat(match[1]) % 360 + 360) % 360;
        var w = clamp(parseFloat(match[2]), 0, 100);
        var b = clamp(parseFloat(match[3]), 0, 100);
        var a = clamp(isNaN(alpha) ? 1 : alpha, 0, 1);
        return [
            h,
            w,
            b,
            a
        ];
    }
    return null;
};
cs.to.hex = function() {
    var rgba = swizzle(arguments);
    return '#' + hexDouble(rgba[0]) + hexDouble(rgba[1]) + hexDouble(rgba[2]) + (rgba[3] < 1 ? hexDouble(Math.round(rgba[3] * 255)) : '');
};
cs.to.rgb = function() {
    var rgba = swizzle(arguments);
    return rgba.length < 4 || rgba[3] === 1 ? 'rgb(' + Math.round(rgba[0]) + ', ' + Math.round(rgba[1]) + ', ' + Math.round(rgba[2]) + ')' : 'rgba(' + Math.round(rgba[0]) + ', ' + Math.round(rgba[1]) + ', ' + Math.round(rgba[2]) + ', ' + rgba[3] + ')';
};
cs.to.rgb.percent = function() {
    var rgba = swizzle(arguments);
    var r = Math.round(rgba[0] / 255 * 100);
    var g = Math.round(rgba[1] / 255 * 100);
    var b = Math.round(rgba[2] / 255 * 100);
    return rgba.length < 4 || rgba[3] === 1 ? 'rgb(' + r + '%, ' + g + '%, ' + b + '%)' : 'rgba(' + r + '%, ' + g + '%, ' + b + '%, ' + rgba[3] + ')';
};
cs.to.hsl = function() {
    var hsla = swizzle(arguments);
    return hsla.length < 4 || hsla[3] === 1 ? 'hsl(' + hsla[0] + ', ' + hsla[1] + '%, ' + hsla[2] + '%)' : 'hsla(' + hsla[0] + ', ' + hsla[1] + '%, ' + hsla[2] + '%, ' + hsla[3] + ')';
};
// hwb is a bit different than rgb(a) & hsl(a) since there is no alpha specific syntax
// (hwb have alpha optional & 1 is default value)
cs.to.hwb = function() {
    var hwba = swizzle(arguments);
    var a = '';
    if (hwba.length >= 4 && hwba[3] !== 1) {
        a = ', ' + hwba[3];
    }
    return 'hwb(' + hwba[0] + ', ' + hwba[1] + '%, ' + hwba[2] + '%' + a + ')';
};
cs.to.keyword = function(rgb) {
    return reverseNames[rgb.slice(0, 3)];
};
// helpers
function clamp(num, min, max) {
    return Math.min(Math.max(min, num), max);
}
function hexDouble(num) {
    var str = Math.round(num).toString(16).toUpperCase();
    return str.length < 2 ? '0' + str : str;
}
}),
"[project]/node_modules/@react-pdf/render/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>render
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/primitives/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/fns/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$abs$2d$svg$2d$path$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/abs-svg-path/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$parse$2d$svg$2d$path$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/parse-svg-path/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$normalize$2d$svg$2d$path$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/normalize-svg-path/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$color$2d$string$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/color-string/index.js [app-client] (ecmascript)");
;
;
;
;
;
;
const renderPath = (ctx, node)=>{
    const d = node.props?.d;
    if (d) ctx.path(node.props.d);
};
const KAPPA$3 = 4.0 * ((Math.sqrt(2) - 1.0) / 3.0);
const renderRect = (ctx, node)=>{
    const x = node.props?.x || 0;
    const y = node.props?.y || 0;
    const rx = node.props?.rx || 0;
    const ry = node.props?.ry || 0;
    const width = node.props?.width || 0;
    const height = node.props?.height || 0;
    if (!width || !height) return;
    if (rx && ry) {
        const krx = rx * KAPPA$3;
        const kry = ry * KAPPA$3;
        ctx.moveTo(x + rx, y);
        ctx.lineTo(x - rx + width, y);
        ctx.bezierCurveTo(x - rx + width + krx, y, x + width, y + ry - kry, x + width, y + ry);
        ctx.lineTo(x + width, y + height - ry);
        ctx.bezierCurveTo(x + width, y + height - ry + kry, x - rx + width + krx, y + height, x - rx + width, y + height);
        ctx.lineTo(x + rx, y + height);
        ctx.bezierCurveTo(x + rx - krx, y + height, x, y + height - ry + kry, x, y + height - ry);
        ctx.lineTo(x, y + ry);
        ctx.bezierCurveTo(x, y + ry - kry, x + rx - krx, y, x + rx, y);
    } else {
        ctx.moveTo(x, y);
        ctx.lineTo(x + width, y);
        ctx.lineTo(x + width, y + height);
        ctx.lineTo(x, y + height);
    }
    ctx.closePath();
};
const renderLine$1 = (ctx, node)=>{
    const { x1, x2, y1, y2 } = node.props || {};
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
};
const renderGroup = ()=>{
// noop
};
const KAPPA$2 = 4.0 * ((Math.sqrt(2) - 1.0) / 3.0);
const drawEllipse = (ctx, rx, ry, cx = 0, cy = 0)=>{
    const x = cx - rx;
    const y = cy - ry;
    const ox = rx * KAPPA$2;
    const oy = ry * KAPPA$2;
    const xe = x + rx * 2;
    const ye = y + ry * 2;
    const xm = x + rx;
    const ym = y + ry;
    ctx.moveTo(x, ym);
    ctx.bezierCurveTo(x, ym - oy, xm - ox, y, xm, y);
    ctx.bezierCurveTo(xm + ox, y, xe, ym - oy, xe, ym);
    ctx.bezierCurveTo(xe, ym + oy, xm + ox, ye, xm, ye);
    ctx.bezierCurveTo(xm - ox, ye, x, ym + oy, x, ym);
    ctx.closePath();
};
const renderEllipse = (ctx, node)=>{
    const { cx, cy, rx, ry } = node.props || {};
    drawEllipse(ctx, rx, ry, cx, cy);
};
const renderCircle = (ctx, node)=>{
    const cx = node.props?.cx;
    const cy = node.props?.cy;
    const r = node.props?.r;
    drawEllipse(ctx, r, r, cx, cy);
};
/* eslint-disable no-return-assign */ const number = (n)=>{
    if (n > -1e21 && n < 1e21) {
        return Math.round(n * 1e6) / 1e6;
    }
    throw new Error(`unsupported number: ${n}`);
};
const _renderGlyphs = (ctx, encoded, positions, x, y)=>{
    const commands = [];
    const scale = ctx._fontSize / 1000;
    let i;
    let last = 0;
    let hadOffset = false;
    ctx.save();
    // flip coordinate system
    ctx.transform(1, 0, 0, -1, 0, ctx.page.height);
    y = ctx.page.height - y;
    // add current font to page if necessary
    if (ctx.page.fonts[ctx._font.id] == null) {
        ctx.page.fonts[ctx._font.id] = ctx._font.ref();
    }
    // begin the text object
    ctx.addContent('BT');
    // text position
    ctx.addContent(`1 0 0 1 ${number(x)} ${number(y)} Tm`);
    // font and font size
    ctx.addContent(`/${ctx._font.id} ${number(ctx._fontSize)} Tf`);
    // Adds a segment of text to the TJ command buffer
    const addSegment = (cur)=>{
        if (last < cur) {
            const hex = encoded.slice(last, cur).join('');
            const advance = positions[cur - 1].xAdvance - positions[cur - 1].advanceWidth;
            commands.push(`<${hex}> ${number(-advance)}`);
        }
        return last = cur;
    };
    // Flushes the current TJ commands to the output stream
    const flush = (s)=>{
        addSegment(s);
        if (commands.length > 0) {
            ctx.addContent(`[${commands.join(' ')}] TJ`);
            return commands.length = 0;
        }
    };
    for(i = 0; i < positions.length; i += 1){
        // If we have an x or y offset, we have to break out of the current TJ command
        // so we can move the text position.
        const pos = positions[i];
        if (pos.xOffset || pos.yOffset) {
            // Flush the current buffer
            flush(i);
            // Move the text position and flush just the current character
            ctx.addContent(`1 0 0 1 ${number(x + pos.xOffset * scale)} ${number(y + pos.yOffset * scale)} Tm`);
            flush(i + 1);
            hadOffset = true;
        } else {
            // If the last character had an offset, reset the text position
            if (hadOffset) {
                ctx.addContent(`1 0 0 1 ${number(x)} ${number(y)} Tm`);
                hadOffset = false;
            }
            // Group segments that don't have any advance adjustments
            if (pos.xAdvance - pos.advanceWidth !== 0) {
                addSegment(i + 1);
            }
        }
        x += pos.xAdvance * scale;
    }
    // Flush any remaining commands
    flush(i);
    // end the text object
    ctx.addContent('ET');
    // restore flipped coordinate system
    return ctx.restore();
};
const renderGlyphs = (ctx, glyphs, positions, x, y)=>{
    const scale = 1000 / ctx._fontSize;
    const unitsPerEm = ctx._font.font.unitsPerEm || 1000;
    const advanceWidthScale = 1000 / unitsPerEm;
    // Glyph encoding and positioning
    const encodedGlyphs = ctx._font.encodeGlyphs(glyphs);
    const encodedPositions = positions.map((pos, i)=>({
            xAdvance: pos.xAdvance * scale,
            yAdvance: pos.yAdvance * scale,
            xOffset: pos.xOffset,
            yOffset: pos.yOffset,
            advanceWidth: glyphs[i].advanceWidth * advanceWidthScale
        }));
    return _renderGlyphs(ctx, encodedGlyphs, encodedPositions, x, y);
};
const renderRun$1 = (ctx, run)=>{
    if (!run.glyphs) return;
    if (!run.positions) return;
    const runAdvanceWidth = run.xAdvance;
    const font = run.attributes.font?.[0];
    const { fontSize, color, opacity } = run.attributes;
    if (color) ctx.fillColor(color);
    ctx.fillOpacity(opacity);
    if (font) {
        ctx.font(font.type === 'STANDARD' ? font.fullName : font, fontSize);
    }
    try {
        renderGlyphs(ctx, run.glyphs, run.positions, 0, 0);
    } catch (error) {
        console.log(error);
    }
    ctx.translate(runAdvanceWidth, 0);
};
const renderSpan = (ctx, line, textAnchor, dominantBaseline)=>{
    ctx.save();
    const x = line.box?.x || 0;
    const y = line.box?.y || 0;
    const font = line.runs[0]?.attributes.font?.[0];
    const scale = line.runs[0]?.attributes?.scale || 1;
    const width = line.xAdvance;
    if (!font) return;
    const ascent = font.ascent * scale;
    const xHeight = font.xHeight * scale;
    const descent = font.descent * scale;
    const capHeight = font.capHeight * scale;
    let xTranslate = x;
    let yTranslate = y;
    switch(textAnchor){
        case 'middle':
            xTranslate = x - width / 2;
            break;
        case 'end':
            xTranslate = x - width;
            break;
        default:
            xTranslate = x;
            break;
    }
    switch(dominantBaseline){
        case 'middle':
        case 'central':
            yTranslate = y + capHeight / 2;
            break;
        case 'hanging':
            yTranslate = y + capHeight;
            break;
        case 'mathematical':
            yTranslate = y + xHeight;
            break;
        case 'text-after-edge':
            yTranslate = y + descent;
            break;
        case 'text-before-edge':
            yTranslate = y + ascent;
            break;
        default:
            yTranslate = y;
            break;
    }
    ctx.translate(xTranslate, yTranslate);
    line.runs.forEach((run)=>renderRun$1(ctx, run));
    ctx.restore();
};
const renderSvgText = (ctx, node)=>{
    const children = node.children;
    children.forEach((span)=>renderSpan(ctx, span.lines[0], span.props.textAnchor, span.props.dominantBaseline));
};
const pairs = (values)=>{
    const result = [];
    for(let i = 0; i < values.length; i += 2){
        result.push([
            values[i],
            values[i + 1]
        ]);
    }
    return result;
};
/**
 * Parse svg-like points into number arrays
 *
 * @param points string ex. "20,30 50,60"
 * @returns points array ex. [[20, 30], [50, 60]]
 */ const parsePoints = (points)=>{
    let values = (points || '').trim().replace(/,/g, ' ').replace(/(\d)-(\d)/g, '$1 -$2').split(/\s+/);
    if (values.length % 2 !== 0) {
        values = values.slice(0, -1);
    }
    const mappedValues = values.map(parseFloat);
    return pairs(mappedValues);
};
const drawPolyline = (ctx, points)=>{
    if (points.length > 0) {
        ctx.moveTo(points[0][0], points[0][1]);
        points.slice(1).forEach((p)=>ctx.lineTo(p[0], p[1]));
    }
};
const renderPolyline = (ctx, node)=>{
    const points = parsePoints(node.props.points || '');
    drawPolyline(ctx, points);
};
const renderPolygon = (ctx, node)=>{
    const points = parsePoints(node.props.points || '');
    drawPolyline(ctx, points);
    ctx.closePath();
};
const renderImage$1 = (ctx, node)=>{
    if (!node.box) return;
    if (!node.image?.data) return;
    const { x = 0, y = 0 } = node.props;
    const { width, height, opacity } = node.style;
    const paddingTop = node.box.paddingLeft || 0;
    const paddingLeft = node.box.paddingLeft || 0;
    if (width === 0 || height === 0) {
        console.warn(`Image with src '${node.props.href}' skipped due to invalid dimensions`);
        return;
    }
    if (typeof width === 'string' || typeof height === 'string') {
        console.warn(`Image with src '${node.props.href}' skipped due to percentage width or height`);
        return;
    }
    ctx.save();
    ctx.fillOpacity(opacity || 1).image(node.image.data, x + paddingLeft, y + paddingTop, {
        width,
        height
    });
    ctx.restore();
};
// This constant is used to approximate a symmetrical arc using a cubic
// Bezier curve.
const KAPPA$1 = 4.0 * ((Math.sqrt(2) - 1.0) / 3.0);
const clipNode = (ctx, node)=>{
    if (!node.box) return;
    if (!node.style) return;
    const { top, left, width, height } = node.box;
    const { borderTopLeftRadius = 0, borderTopRightRadius = 0, borderBottomRightRadius = 0, borderBottomLeftRadius = 0 } = node.style;
    // Border top
    // @ts-expect-error this is always a number due to resolve border radius step
    const rtr = Math.min(borderTopRightRadius, 0.5 * width, 0.5 * height);
    const ctr = rtr * (1.0 - KAPPA$1);
    ctx.moveTo(left + rtr, top);
    ctx.lineTo(left + width - rtr, top);
    ctx.bezierCurveTo(left + width - ctr, top, left + width, top + ctr, left + width, top + rtr);
    // Border right
    // @ts-expect-error this is always a number due to resolve border radius step
    const rbr = Math.min(borderBottomRightRadius, 0.5 * width, 0.5 * height);
    const cbr = rbr * (1.0 - KAPPA$1);
    ctx.lineTo(left + width, top + height - rbr);
    ctx.bezierCurveTo(left + width, top + height - cbr, left + width - cbr, top + height, left + width - rbr, top + height);
    // Border bottom
    // @ts-expect-error this is always a number due to resolve border radius step
    const rbl = Math.min(borderBottomLeftRadius, 0.5 * width, 0.5 * height);
    const cbl = rbl * (1.0 - KAPPA$1);
    ctx.lineTo(left + rbl, top + height);
    ctx.bezierCurveTo(left + cbl, top + height, left, top + height - cbl, left, top + height - rbl);
    // Border left
    // @ts-expect-error this is always a number due to resolve border radius step
    const rtl = Math.min(borderTopLeftRadius, 0.5 * width, 0.5 * height);
    const ctl = rtl * (1.0 - KAPPA$1);
    ctx.lineTo(left, top + rtl);
    ctx.bezierCurveTo(left, top + ctl, left + ctl, top, left + rtl, top);
    ctx.closePath();
    ctx.clip();
};
const applySingleTransformation = (ctx, transform, origin)=>{
    const { operation, value } = transform;
    switch(operation){
        case 'scale':
            {
                const [scaleX, scaleY] = value;
                ctx.scale(scaleX, scaleY, {
                    origin
                });
                break;
            }
        case 'rotate':
            {
                const [angle] = value;
                ctx.rotate(angle, {
                    origin
                });
                break;
            }
        case 'translate':
            {
                const [x, y = 0] = value;
                ctx.translate(x, y, {
                    origin
                });
                break;
            }
        case 'skew':
            {
                const [xAngle = 0, yAngle = 0] = value;
                const radx = xAngle * Math.PI / 180;
                const rady = yAngle * Math.PI / 180;
                const tanx = Math.tan(radx);
                const tany = Math.tan(rady);
                let x = 0;
                let y = 0;
                if (origin != null) {
                    [x, y] = Array.from(origin);
                    const x1 = x + tanx * y;
                    const y1 = y + tany * x;
                    x -= x1;
                    y -= y1;
                }
                ctx.transform(1, tany, tanx, 1, x, y);
                break;
            }
        case 'matrix':
            {
                ctx.transform(...value);
                break;
            }
        default:
            {
                console.error(`Transform operation: '${operation}' doesn't supported`);
            }
    }
};
const applyTransformations = (ctx, node)=>{
    if (!node.origin) return;
    const { props, style } = node;
    const origin = [
        node.origin.left,
        node.origin.top
    ];
    const propsTransform = 'transform' in props ? props.transform : undefined;
    const operations = style?.transform || propsTransform || [];
    operations.forEach((operation)=>{
        applySingleTransformation(ctx, operation, origin);
    });
};
// From https://github.com/dy/svg-path-bounds/blob/master/index.js
const getPathBoundingBox = (node)=>{
    const path = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$normalize$2d$svg$2d$path$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$abs$2d$svg$2d$path$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$parse$2d$svg$2d$path$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node.props?.d || '')));
    if (!path.length) return [
        0,
        0,
        0,
        0
    ];
    const bounds = [
        Infinity,
        Infinity,
        -Infinity,
        -Infinity
    ];
    for(let i = 0, l = path.length; i < l; i += 1){
        const points = path[i].slice(1);
        for(let j = 0; j < points.length; j += 2){
            if (points[j + 0] < bounds[0]) bounds[0] = points[j + 0];
            if (points[j + 1] < bounds[1]) bounds[1] = points[j + 1];
            if (points[j + 0] > bounds[2]) bounds[2] = points[j + 0];
            if (points[j + 1] > bounds[3]) bounds[3] = points[j + 1];
        }
    }
    return bounds;
};
const getCircleBoundingBox = (node)=>{
    const r = node.props?.r || 0;
    const cx = node.props?.cx || 0;
    const cy = node.props?.cy || 0;
    return [
        cx - r,
        cy - r,
        cx + r,
        cy + r
    ];
};
const getEllipseBoundingBox = (node)=>{
    const cx = node.props?.cx || 0;
    const cy = node.props?.cy || 0;
    const rx = node.props?.rx || 0;
    const ry = node.props?.ry || 0;
    return [
        cx - rx,
        cy - ry,
        cx + rx,
        cy + ry
    ];
};
const getLineBoundingBox = (node)=>{
    const x1 = node.props?.x1 || 0;
    const y1 = node.props?.y1 || 0;
    const x2 = node.props?.x2 || 0;
    const y2 = node.props?.y2 || 0;
    return [
        Math.min(x1, x2),
        Math.min(y1, y2),
        Math.max(x1, x2),
        Math.max(y1, y2)
    ];
};
const getRectBoundingBox = (node)=>{
    const x = node.props?.x || 0;
    const y = node.props?.y || 0;
    const width = node.props?.width || 0;
    const height = node.props?.height || 0;
    return [
        x,
        y,
        x + width,
        y + height
    ];
};
const max = (values)=>Math.max(-Infinity, ...values);
const min = (values)=>Math.min(Infinity, ...values);
const getPolylineBoundingBox = (node)=>{
    const points = parsePoints(node.props?.points);
    const xValues = points.map((p)=>p[0]);
    const yValues = points.map((p)=>p[1]);
    return [
        min(xValues),
        min(yValues),
        max(xValues),
        max(yValues)
    ];
};
const boundingBoxFns = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Rect"]]: getRectBoundingBox,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Line"]]: getLineBoundingBox,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Path"]]: getPathBoundingBox,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Circle"]]: getCircleBoundingBox,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Ellipse"]]: getEllipseBoundingBox,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Polygon"]]: getPolylineBoundingBox,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Polyline"]]: getPolylineBoundingBox
};
const getBoundingBox = (node)=>{
    const boundingBoxFn = boundingBoxFns[node.type];
    return boundingBoxFn ? boundingBoxFn(node) : [
        0,
        0,
        0,
        0
    ];
};
const setStrokeWidth = (ctx, node)=>{
    if (!node.props) return;
    if (!('strokeWidth' in node.props)) return;
    const lineWidth = node.props.strokeWidth;
    if (lineWidth) ctx.lineWidth(lineWidth);
};
const setStrokeColor = (ctx, node)=>{
    if (!node.props) return;
    if (!('stroke' in node.props)) return;
    const strokeColor = node.props.stroke;
    if (strokeColor) ctx.strokeColor(strokeColor);
};
const setOpacity = (ctx, node)=>{
    if (!node.props) return;
    if (!('opacity' in node.props)) return;
    const opacity = node.props.opacity;
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(opacity)) ctx.opacity(opacity);
};
const setFillOpacity = (ctx, node)=>{
    if (!node.props) return;
    if (!('fillOpacity' in node.props)) return;
    const fillOpacity = node.props.fillOpacity || null;
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(fillOpacity)) ctx.fillOpacity(fillOpacity);
};
const setStrokeOpacity = (ctx, node)=>{
    if (!node.props) return;
    if (!('strokeOpacity' in node.props)) return;
    const strokeOpacity = node.props?.strokeOpacity;
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(strokeOpacity)) ctx.strokeOpacity(strokeOpacity);
};
const setLineJoin = (ctx, node)=>{
    if (!node.props) return;
    if (!('strokeLinejoin' in node.props)) return;
    const lineJoin = node.props.strokeLinejoin;
    if (lineJoin) ctx.lineJoin(lineJoin);
};
const setLineCap = (ctx, node)=>{
    if (!node.props) return;
    if (!('strokeLinecap' in node.props)) return;
    const lineCap = node.props?.strokeLinecap;
    if (lineCap) ctx.lineCap(lineCap);
};
const setLineDash = (ctx, node)=>{
    if (!node.props) return;
    if (!('strokeDasharray' in node.props)) return;
    const value = node.props?.strokeDasharray || null;
    // @ts-expect-error check this works as expected
    if (value) ctx.dash(value.split(/[\s,]+/).map(Number));
};
const hasLinearGradientFill = (node)=>{
    if (!node.props) return false;
    if (!('fill' in node.props)) return false;
    if (typeof node.props.fill === 'string') return false;
    return node.props.fill?.type === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LinearGradient"];
};
const hasRadialGradientFill = (node)=>{
    if (!node.props) return false;
    if (!('fill' in node.props)) return false;
    if (typeof node.props.fill === 'string') return false;
    return node.props.fill?.type === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["RadialGradient"];
};
function multiplyMatrices(m1, m2) {
    const a = m1[0] * m2[0] + m1[2] * m2[1];
    const b = m1[1] * m2[0] + m1[3] * m2[1];
    const c = m1[0] * m2[2] + m1[2] * m2[3];
    const d = m1[1] * m2[2] + m1[3] * m2[3];
    const e = m1[0] * m2[4] + m1[2] * m2[5] + m1[4];
    const f = m1[1] * m2[4] + m1[3] * m2[5] + m1[5];
    return [
        a,
        b,
        c,
        d,
        e,
        f
    ];
}
const transformGradient = (grad, transforms, bbox, units)=>{
    const matrices = transforms.map((transform)=>{
        switch(transform.operation){
            case 'scale':
                {
                    const value = transform.value;
                    return [
                        value[0],
                        0,
                        0,
                        value[1],
                        0,
                        0
                    ];
                }
            case 'translate':
                {
                    const value = transform.value;
                    let x = value[0] || 0;
                    let y = value[1] || 0;
                    if (units === 'objectBoundingBox') {
                        x = (bbox[2] - bbox[0]) * x;
                        y = (bbox[3] - bbox[1]) * y;
                    }
                    return [
                        1,
                        0,
                        0,
                        1,
                        x,
                        y
                    ];
                }
            case 'rotate':
                {
                    const value = transform.value;
                    const cos = Math.cos(value[0]);
                    const sin = Math.sin(value[0]);
                    return [
                        cos,
                        sin,
                        -sin,
                        cos,
                        0,
                        0
                    ];
                }
            case 'skew':
                {
                    const value = transform.value;
                    return [
                        1,
                        Math.tan(value[0]),
                        Math.tan(value[1]),
                        1,
                        0,
                        0
                    ];
                }
            case 'matrix':
                {
                    const value = transform.value;
                    let x = value[4] || 0;
                    let y = value[5] || 0;
                    if (units === 'objectBoundingBox') {
                        x = (bbox[2] - bbox[0]) * x;
                        y = (bbox[3] - bbox[1]) * y;
                    }
                    return [
                        value[0],
                        value[1],
                        value[2],
                        value[3],
                        x,
                        y
                    ];
                }
            default:
                return [
                    1,
                    0,
                    0,
                    1,
                    0,
                    0
                ];
        }
    });
    const matrix = matrices.reduce(multiplyMatrices, [
        1,
        0,
        0,
        1,
        0,
        0
    ]);
    grad.setTransform(...matrix);
};
// Math simplified from https://github.com/devongovett/svgkit/blob/master/src/elements/SVGGradient.js#L104
const setLinearGradientFill = (ctx, node)=>{
    if (!node.props) return;
    if (!('fill' in node.props)) return;
    const bbox = getBoundingBox(node);
    const gradient = node.props?.fill;
    if (!gradient) return;
    const units = gradient.props.gradientUnits || 'objectBoundingBox';
    const transforms = gradient.props.gradientTransform || [];
    let x1 = gradient.props.x1 || 0;
    let y1 = gradient.props.y1 || 0;
    let x2 = gradient.props.x2 || 1;
    let y2 = gradient.props.y2 || 0;
    if (units === 'objectBoundingBox') {
        const m0 = bbox[2] - bbox[0];
        const m3 = bbox[3] - bbox[1];
        const m4 = bbox[0];
        const m5 = bbox[1];
        x1 = m0 * x1 + m4;
        y1 = m3 * y1 + m5;
        x2 = m0 * x2 + m4;
        y2 = m3 * y2 + m5;
    }
    const grad = ctx.linearGradient(x1, y1, x2, y2);
    transformGradient(grad, transforms, bbox, units);
    gradient.children?.forEach((stop)=>{
        grad.stop(stop.props.offset, stop.props.stopColor, stop.props.stopOpacity);
    });
    ctx.fill(grad);
};
// Math simplified from https://github.com/devongovett/svgkit/blob/master/src/elements/SVGGradient.js#L155
const setRadialGradientFill = (ctx, node)=>{
    if (!node.props) return;
    if (!('fill' in node.props)) return;
    const bbox = getBoundingBox(node);
    const gradient = node.props?.fill;
    if (!gradient) return;
    const units = gradient.props.gradientUnits || 'objectBoundingBox';
    const transforms = gradient.props.gradientTransform || [];
    let r = gradient.props.r || 0.5;
    let cx = gradient.props.cx || 0.5;
    let cy = gradient.props.cy || 0.5;
    let fx = gradient.props.fx || cx;
    let fy = gradient.props.fy || cy;
    if (units === 'objectBoundingBox') {
        const m0 = bbox[2] - bbox[0];
        const m3 = bbox[3] - bbox[1];
        const m4 = bbox[0];
        const m5 = bbox[1];
        r = r * m0;
        cx = m0 * cx + m4;
        cy = m3 * cy + m5;
        fx = m0 * fx + m4;
        fy = m3 * fy + m5;
    }
    const grad = ctx.radialGradient(cx, cy, 0, fx, fy, r);
    transformGradient(grad, transforms, bbox, units);
    gradient.children?.forEach((stop)=>{
        grad.stop(stop.props.offset, stop.props.stopColor, stop.props.stopOpacity);
    });
    ctx.fill(grad);
};
const setFillColor = (ctx, node)=>{
    if (!node.props) return;
    if (!('fill' in node.props)) return;
    const fillColor = node.props?.fill;
    if (fillColor) ctx.fillColor(fillColor);
};
const setFill = (ctx, node)=>{
    if (hasLinearGradientFill(node)) return setLinearGradientFill(ctx, node);
    if (hasRadialGradientFill(node)) return setRadialGradientFill(ctx, node);
    return setFillColor(ctx, node);
};
const draw = (ctx, node)=>{
    const props = node.props || {};
    if ('fill' in props && 'stroke' in props && props.fill && props.stroke) {
        ctx.fillAndStroke(props.fillRule);
    } else if ('fill' in props && props.fill) {
        ctx.fill(props.fillRule);
    } else if ('stroke' in props && props.stroke) {
        ctx.stroke();
    } else {
        ctx.save();
        ctx.opacity(0);
        ctx.fill(null);
        ctx.restore();
    }
};
const noop = ()=>{};
const renderFns$1 = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Tspan"]]: noop,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextInstance"]]: noop,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Path"]]: renderPath,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Rect"]]: renderRect,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Line"]]: renderLine$1,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["G"]]: renderGroup,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"]]: renderSvgText,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Circle"]]: renderCircle,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Image"]]: renderImage$1,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Ellipse"]]: renderEllipse,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Polygon"]]: renderPolygon,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Polyline"]]: renderPolyline
};
const renderNode$1 = (ctx, node)=>{
    const renderFn = renderFns$1[node.type];
    if (renderFn) {
        renderFn(ctx, node);
    } else {
        console.warn(`SVG node of type ${node.type} is not currently supported`);
    }
};
const drawNode = (ctx, node)=>{
    setLineCap(ctx, node);
    setLineDash(ctx, node);
    setLineJoin(ctx, node);
    setStrokeWidth(ctx, node);
    setStrokeColor(ctx, node);
    setFill(ctx, node);
    setStrokeOpacity(ctx, node);
    setFillOpacity(ctx, node);
    setOpacity(ctx, node);
    applyTransformations(ctx, node);
    renderNode$1(ctx, node);
    draw(ctx, node);
};
const clipPath = (ctx, node)=>{
    if (!node.props) return;
    if (!('clipPath' in node.props)) return;
    const value = node.props.clipPath;
    if (value) {
        const children = value.children || [];
        children.forEach((child)=>renderNode$1(ctx, child));
        ctx.clip();
    }
};
const drawChildren = (ctx, node)=>{
    const children = node.children || [];
    children.forEach((child)=>{
        ctx.save();
        clipPath(ctx, child);
        drawNode(ctx, child);
        drawChildren(ctx, child);
        ctx.restore();
    });
};
const resolveAspectRatio = (ctx, node)=>{
    if (!node.box) return;
    const { width, height } = node.box;
    const { viewBox, preserveAspectRatio } = node.props;
    const { meetOrSlice = 'meet', align = 'xMidYMid' } = preserveAspectRatio || {};
    if (viewBox == null || width == null || height == null) return;
    const x = viewBox?.minX || 0;
    const y = viewBox?.minY || 0;
    const logicalWidth = viewBox?.maxX || width;
    const logicalHeight = viewBox?.maxY || height;
    const logicalRatio = logicalWidth / logicalHeight;
    const physicalRatio = width / height;
    const scaleX = width / logicalWidth;
    const scaleY = height / logicalHeight;
    if (align === 'none') {
        ctx.scale(scaleX, scaleY);
        ctx.translate(-x, -y);
        return;
    }
    if (logicalRatio < physicalRatio && meetOrSlice === 'meet' || logicalRatio >= physicalRatio && meetOrSlice === 'slice') {
        ctx.scale(scaleY, scaleY);
        switch(align){
            case 'xMinYMin':
            case 'xMinYMid':
            case 'xMinYMax':
                ctx.translate(-x, -y);
                break;
            case 'xMidYMin':
            case 'xMidYMid':
            case 'xMidYMax':
                ctx.translate(-x - (logicalWidth - width * logicalHeight / height) / 2, -y);
                break;
            default:
                ctx.translate(-x - (logicalWidth - width * logicalHeight / height), -y);
        }
    } else {
        ctx.scale(scaleX, scaleX);
        switch(align){
            case 'xMinYMin':
            case 'xMidYMin':
            case 'xMaxYMin':
                ctx.translate(-x, -y);
                break;
            case 'xMinYMid':
            case 'xMidYMid':
            case 'xMaxYMid':
                ctx.translate(-x, -y - (logicalHeight - height * logicalWidth / width) / 2);
                break;
            default:
                ctx.translate(-x, -y - (logicalHeight - height * logicalWidth / width));
        }
    }
};
const moveToOrigin = (ctx, node)=>{
    if (!node.box) return;
    const { top, left } = node.box;
    const paddingLeft = node.box.paddingLeft || 0;
    const paddingTop = node.box.paddingTop || 0;
    ctx.translate(left + paddingLeft, top + paddingTop);
};
const renderSvg = (ctx, node)=>{
    ctx.save();
    clipNode(ctx, node);
    moveToOrigin(ctx, node);
    resolveAspectRatio(ctx, node);
    drawChildren(ctx, node);
    ctx.restore();
};
const black = {
    value: '#000',
    opacity: 1
};
// TODO: parse to number[] in layout to avoid this step
const parseColor = (hex)=>{
    if (!hex) return black;
    const parsed = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$color$2d$string$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(hex);
    if (!parsed) return black;
    const value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$color$2d$string$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].to.hex(parsed.value.slice(0, 3));
    const opacity = parsed.value[3];
    return {
        value,
        opacity
    };
};
const DEST_REGEXP = /^#.+/;
const isSrcId$1 = (src)=>src.match(DEST_REGEXP);
const renderAttachment = (ctx, attachment)=>{
    const { xOffset = 0, yOffset = 0, width, height, image } = attachment;
    ctx.translate(-width + xOffset, -height + yOffset);
    ctx.image(image, 0, 0, {
        fit: [
            width,
            height
        ],
        align: 'center',
        valign: 'bottom'
    });
};
const renderAttachments = (ctx, run)=>{
    if (!run.glyphs) return;
    if (!run.positions) return;
    const font = run.attributes.font?.[0];
    if (!font) return;
    ctx.save();
    const space = font.glyphForCodePoint(0x20);
    const objectReplacement = font.glyphForCodePoint(0xfffc);
    let attachmentAdvance = 0;
    for(let i = 0; i < run.glyphs.length; i += 1){
        const position = run.positions[i];
        const glyph = run.glyphs[i];
        attachmentAdvance += position.xAdvance || 0;
        if (glyph.id === objectReplacement.id && run.attributes.attachment) {
            ctx.translate(attachmentAdvance, position.yOffset || 0);
            renderAttachment(ctx, run.attributes.attachment);
            run.glyphs[i] = space;
            attachmentAdvance = 0;
        }
    }
    ctx.restore();
};
const renderRun = (ctx, run)=>{
    if (!run.glyphs) return;
    if (!run.positions) return;
    const font = run.attributes.font?.[0];
    if (!font) return;
    const { fontSize, link } = run.attributes;
    const color = parseColor(run.attributes.color);
    const opacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(run.attributes.opacity) ? color.opacity : run.attributes.opacity;
    const { height = 0, descent = 0, xAdvance = 0 } = run;
    ctx.fillColor(color.value);
    ctx.fillOpacity(opacity);
    if (link) {
        if (isSrcId$1(link)) {
            ctx.goTo(0, -height - descent, xAdvance, height, link.slice(1));
        } else {
            ctx.link(0, -height - descent, xAdvance, height, link);
        }
    }
    renderAttachments(ctx, run);
    ctx.font(font.type === 'STANDARD' ? font.fullName : font, fontSize);
    try {
        renderGlyphs(ctx, run.glyphs, run.positions, 0, 0);
    } catch (error) {
        console.log(error);
    }
    ctx.translate(xAdvance, 0);
};
const renderBackground$1 = (ctx, rect, backgroundColor)=>{
    const color = parseColor(backgroundColor);
    ctx.save();
    ctx.fillOpacity(color.opacity);
    ctx.rect(rect.x, rect.y, rect.width, rect.height);
    ctx.fill(color.value);
    ctx.restore();
};
const renderDecorationLine = (ctx, decorationLine)=>{
    ctx.save();
    ctx.lineWidth(decorationLine.rect.height);
    ctx.strokeOpacity(decorationLine.opacity);
    if (/dashed/.test(decorationLine.style)) {
        ctx.dash(3 * decorationLine.rect.height, {});
    } else if (/dotted/.test(decorationLine.style)) {
        ctx.dash(decorationLine.rect.height, {});
    }
    if (/wavy/.test(decorationLine.style)) {
        const dist = Math.max(2, decorationLine.rect.height);
        let step = 1.1 * dist;
        const stepCount = Math.floor(decorationLine.rect.width / (2 * step));
        // Adjust step to fill entire width
        const remainingWidth = decorationLine.rect.width - stepCount * 2 * step;
        const adjustment = remainingWidth / stepCount / 2;
        step += adjustment;
        const cp1y = decorationLine.rect.y + dist;
        const cp2y = decorationLine.rect.y - dist;
        let { x } = decorationLine.rect;
        ctx.moveTo(decorationLine.rect.x, decorationLine.rect.y);
        for(let i = 0; i < stepCount; i += 1){
            ctx.bezierCurveTo(x + step, cp1y, x + step, cp2y, x + 2 * step, decorationLine.rect.y);
            x += 2 * step;
        }
    } else {
        ctx.moveTo(decorationLine.rect.x, decorationLine.rect.y);
        ctx.lineTo(decorationLine.rect.x + decorationLine.rect.width, decorationLine.rect.y);
        if (/double/.test(decorationLine.style)) {
            ctx.moveTo(decorationLine.rect.x, decorationLine.rect.y + decorationLine.rect.height * 2);
            ctx.lineTo(decorationLine.rect.x + decorationLine.rect.width, decorationLine.rect.y + decorationLine.rect.height * 2);
        }
    }
    ctx.stroke(decorationLine.color);
    ctx.restore();
};
const renderLine = (ctx, line)=>{
    if (!line.box) return;
    const lineAscent = line.ascent || 0;
    ctx.save();
    ctx.translate(line.box.x, line.box.y + lineAscent);
    for(let i = 0; i < line.runs.length; i += 1){
        const run = line.runs[i];
        const isLastRun = i === line.runs.length - 1;
        if (run.attributes.backgroundColor) {
            const xAdvance = run.xAdvance ?? 0;
            const overflowRight = isLastRun ? line.overflowRight ?? 0 : 0;
            const backgroundRect = {
                x: 0,
                y: -lineAscent,
                height: line.box.height,
                width: xAdvance - overflowRight
            };
            renderBackground$1(ctx, backgroundRect, run.attributes.backgroundColor);
        }
        renderRun(ctx, run);
    }
    ctx.restore();
    ctx.save();
    ctx.translate(line.box.x, line.box.y);
    if (line.decorationLines) {
        for(let i = 0; i < line.decorationLines.length; i += 1){
            const decorationLine = line.decorationLines[i];
            renderDecorationLine(ctx, decorationLine);
        }
    }
    ctx.restore();
};
const renderBlock = (ctx, block)=>{
    block.forEach((line)=>{
        renderLine(ctx, line);
    });
};
const renderText = (ctx, node)=>{
    if (!node.box) return;
    if (!node.lines) return;
    const { top, left } = node.box;
    const blocks = [
        node.lines
    ];
    const paddingTop = node.box?.paddingTop || 0;
    const paddingLeft = node.box?.paddingLeft || 0;
    const initialY = node.lines[0] ? node.lines[0].box.y : 0;
    const offsetX = node.alignOffset || 0;
    ctx.save();
    ctx.translate(left + paddingLeft - offsetX, top + paddingTop - initialY);
    blocks.forEach((block)=>{
        renderBlock(ctx, block);
    });
    ctx.restore();
};
const renderPage = (ctx, node)=>{
    if (!node.box) return;
    const { width, height } = node.box;
    const dpi = node.props?.dpi || 72;
    const userUnit = dpi / 72;
    ctx.addPage({
        size: [
            width,
            height
        ],
        margin: 0,
        userUnit
    });
};
const renderNote = (ctx, node)=>{
    if (!node.box) return;
    const { top, left } = node.box;
    const value = node?.children?.[0].value || '';
    const color = node.style?.backgroundColor;
    ctx.note(left, top, 0, 0, value, {
        color
    });
};
const embedImage = (ctx, node)=>{
    const src = node.image.data;
    let image;
    if (typeof src === 'string') {
        image = ctx._imageRegistry[src];
    }
    if (!image) {
        image = ctx.openImage(src);
    }
    if (!image.obj) {
        image.embed(ctx);
    }
    return image;
};
const isNumeric = (n)=>{
    return !Number.isNaN(parseFloat(n)) && Number.isFinite(n);
};
const applyContainObjectFit = (cw, ch, iw, ih, px, py)=>{
    const cr = cw / ch;
    const ir = iw / ih;
    const pxp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPercent"])(px ?? null);
    const pyp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPercent"])(py ?? null);
    const pxv = pxp ? pxp.percent : 0.5;
    const pyv = pyp ? pyp.percent : 0.5;
    if (cr > ir) {
        const height = ch;
        const width = height * ir;
        const yOffset = isNumeric(py) ? py : 0;
        const xOffset = isNumeric(px) ? px : (cw - width) * pxv;
        return {
            width,
            height,
            xOffset,
            yOffset
        };
    }
    const width = cw;
    const height = width / ir;
    const xOffset = isNumeric(px) ? px : 0;
    const yOffset = isNumeric(py) ? py : (ch - height) * pyv;
    return {
        width,
        height,
        yOffset,
        xOffset
    };
};
const applyNoneObjectFit = (cw, ch, iw, ih, px, py)=>{
    const width = iw;
    const height = ih;
    const pxp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPercent"])(px ?? null);
    const pyp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPercent"])(py ?? null);
    const pxv = pxp ? pxp.percent : 0.5;
    const pyv = pyp ? pyp.percent : 0.5;
    const xOffset = isNumeric(px) ? px : (cw - width) * pxv;
    const yOffset = isNumeric(py) ? py : (ch - height) * pyv;
    return {
        width,
        height,
        xOffset,
        yOffset
    };
};
const applyCoverObjectFit = (cw, ch, iw, ih, px, py)=>{
    const ir = iw / ih;
    const cr = cw / ch;
    const pxp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPercent"])(px ?? null);
    const pyp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPercent"])(py ?? null);
    const pxv = pxp ? pxp.percent : 0.5;
    const pyv = pyp ? pyp.percent : 0.5;
    if (cr > ir) {
        const width = cw;
        const height = width / ir;
        const xOffset = isNumeric(px) ? px : 0;
        const yOffset = isNumeric(py) ? py : (ch - height) * pyv;
        return {
            width,
            height,
            yOffset,
            xOffset
        };
    }
    const height = ch;
    const width = height * ir;
    const xOffset = isNumeric(px) ? px : (cw - width) * pxv;
    const yOffset = isNumeric(py) ? py : 0;
    return {
        width,
        height,
        xOffset,
        yOffset
    };
};
const applyScaleDownObjectFit = (cw, ch, iw, ih, px, py)=>{
    const containDimension = applyContainObjectFit(cw, ch, iw, ih, px, py);
    const noneDimension = applyNoneObjectFit(cw, ch, iw, ih, px, py);
    return containDimension.width < noneDimension.width ? containDimension : noneDimension;
};
const applyFillObjectFit = (cw, ch, px, py)=>{
    return {
        width: cw,
        height: ch,
        xOffset: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPercent"])(px ?? null) ? 0 : px || 0,
        yOffset: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPercent"])(py ?? null) ? 0 : py || 0
    };
};
const resolveObjectFit = (type = 'fill', cw, ch, iw, ih, px, py)=>{
    switch(type){
        case 'contain':
            return applyContainObjectFit(cw, ch, iw, ih, px, py);
        case 'cover':
            return applyCoverObjectFit(cw, ch, iw, ih, px, py);
        case 'none':
            return applyNoneObjectFit(cw, ch, iw, ih, px, py);
        case 'scale-down':
            return applyScaleDownObjectFit(cw, ch, iw, ih, px, py);
        default:
            return applyFillObjectFit(cw, ch, px, py);
    }
};
const drawImage = (ctx, node, options)=>{
    if (!node.box) return;
    if (!node.image) return;
    const { left, top } = node.box;
    const opacity = node.style?.opacity;
    const objectFit = node.style?.objectFit;
    const objectPositionX = node.style?.objectPositionX;
    const objectPositionY = node.style?.objectPositionY;
    const paddingTop = node.box.paddingTop || 0;
    const paddingRight = node.box.paddingRight || 0;
    const paddingBottom = node.box.paddingBottom || 0;
    const paddingLeft = node.box.paddingLeft || 0;
    const imageCache = options.imageCache || new Map();
    const { width, height, xOffset, yOffset } = resolveObjectFit(objectFit, node.box.width - paddingLeft - paddingRight, node.box.height - paddingTop - paddingBottom, node.image.width, node.image.height, objectPositionX, objectPositionY);
    if (node.image.data) {
        if (width !== 0 && height !== 0) {
            const cacheKey = node.image.key;
            const image = imageCache.get(cacheKey) || embedImage(ctx, node);
            if (cacheKey) imageCache.set(cacheKey, image);
            const imageOpacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(opacity) ? 1 : opacity;
            ctx.fillOpacity(imageOpacity).image(image, left + paddingLeft + xOffset, top + paddingTop + yOffset, {
                width,
                height
            });
        } else {
            console.warn(`Image with src '${JSON.stringify(node.props.src || node.props.source)}' skipped due to invalid dimensions`);
        }
    }
};
const renderImage = (ctx, node, options)=>{
    ctx.save();
    clipNode(ctx, node);
    drawImage(ctx, node, options);
    ctx.restore();
};
const CONTENT_COLOR = '#a1c6e7';
const PADDING_COLOR = '#c4deb9';
const MARGIN_COLOR = '#f8cca1';
// TODO: Draw debug boxes using clipping to enhance quality
const debugContent = (ctx, node)=>{
    if (!node.box) return;
    const { left, top, width, height, paddingLeft = 0, paddingTop = 0, paddingRight = 0, paddingBottom = 0, borderLeftWidth = 0, borderTopWidth = 0, borderRightWidth = 0, borderBottomWidth = 0 } = node.box;
    ctx.fillColor(CONTENT_COLOR).opacity(0.5).rect(left + paddingLeft + borderLeftWidth, top + paddingTop + borderTopWidth, width - paddingLeft - paddingRight - borderRightWidth - borderLeftWidth, height - paddingTop - paddingBottom - borderTopWidth - borderBottomWidth).fill();
};
const debugPadding = (ctx, node)=>{
    if (!node.box) return;
    const { left, top, width, height, paddingLeft = 0, paddingTop = 0, paddingRight = 0, paddingBottom = 0, borderLeftWidth = 0, borderTopWidth = 0, borderRightWidth = 0, borderBottomWidth = 0 } = node.box;
    ctx.fillColor(PADDING_COLOR).opacity(0.5);
    // Padding top
    ctx.rect(left + paddingLeft + borderLeftWidth, top + borderTopWidth, width - paddingRight - paddingLeft - borderLeftWidth - borderRightWidth, paddingTop).fill();
    // Padding left
    ctx.rect(left + borderLeftWidth, top + borderTopWidth, paddingLeft, height - borderTopWidth - borderBottomWidth).fill();
    // Padding right
    ctx.rect(left + width - paddingRight - borderRightWidth, top + borderTopWidth, paddingRight, height - borderTopWidth - borderBottomWidth).fill();
    // Padding bottom
    ctx.rect(left + paddingLeft + borderLeftWidth, top + height - paddingBottom - borderBottomWidth, width - paddingRight - paddingLeft - borderLeftWidth - borderRightWidth, paddingBottom).fill();
};
const debugMargin = (ctx, node)=>{
    if (!node.box) return;
    const { left, top, width, height } = node.box;
    const { marginLeft = 0, marginTop = 0, marginRight = 0, marginBottom = 0 } = node.box;
    ctx.fillColor(MARGIN_COLOR).opacity(0.5);
    // Margin top
    ctx.rect(left, top - marginTop, width, marginTop).fill();
    // Margin left
    ctx.rect(left - marginLeft, top - marginTop, marginLeft, height + marginTop + marginBottom).fill();
    // Margin right
    ctx.rect(left + width, top - marginTop, marginRight, height + marginTop + marginBottom).fill();
    // Margin bottom
    ctx.rect(left, top + height, width, marginBottom).fill();
};
const debugText = (ctx, node)=>{
    if (!node.box) return;
    const { left, top, width, height } = node.box;
    const { marginLeft = 0, marginTop = 0, marginRight = 0, marginBottom = 0 } = node.box;
    const roundedWidth = Math.round(width + marginLeft + marginRight);
    const roundedHeight = Math.round(height + marginTop + marginBottom);
    ctx.fontSize(6).opacity(1).fillColor('black').text(`${roundedWidth} x ${roundedHeight}`, left - marginLeft, Math.max(top - marginTop - 4, 1), {
        width: Infinity
    });
};
const debugOrigin = (ctx, node)=>{
    if (node.origin) {
        ctx.circle(node.origin.left, node.origin.top, 3).fill('red').circle(node.origin.left, node.origin.top, 5).stroke('red');
    }
};
const renderDebug = (ctx, node)=>{
    if (!node.props) return;
    if (!('debug' in node.props) || !node.props.debug) return;
    ctx.save();
    debugContent(ctx, node);
    debugPadding(ctx, node);
    debugMargin(ctx, node);
    debugText(ctx, node);
    debugOrigin(ctx, node);
    ctx.restore();
};
const availableMethods = [
    'dash',
    'clip',
    'save',
    'path',
    'fill',
    'font',
    'text',
    'rect',
    'scale',
    'moveTo',
    'lineTo',
    'stroke',
    'rotate',
    'circle',
    'lineCap',
    'opacity',
    'ellipse',
    'polygon',
    'restore',
    'lineJoin',
    'fontSize',
    'fillColor',
    'lineWidth',
    'translate',
    'miterLimit',
    'strokeColor',
    'fillOpacity',
    'roundedRect',
    'fillAndStroke',
    'strokeOpacity',
    'bezierCurveTo',
    'quadraticCurveTo',
    'linearGradient',
    'radialGradient'
];
const painter = (ctx)=>{
    const p = availableMethods.reduce((acc, prop)=>({
            ...acc,
            [prop]: (...args)=>{
                // @ts-expect-error ctx[prop] is a function
                ctx[prop](...args);
                return p;
            }
        }), {});
    return p;
};
const renderCanvas = (ctx, node)=>{
    if (!node.box) return;
    const { top, left, width, height } = node.box;
    const paddingTop = node.box.paddingTop || 0;
    const paddingLeft = node.box.paddingLeft || 0;
    const paddingRight = node.box.paddingRight || 0;
    const paddingBottom = node.box.paddingBottom || 0;
    const availableWidth = width - paddingLeft - paddingRight;
    const availableHeight = height - paddingTop - paddingBottom;
    if (!availableWidth || !availableHeight) {
        console.warn('Canvas element has null width or height. Please provide valid values via the `style` prop in order to correctly render it.');
    }
    ctx.save().translate(left + paddingLeft, top + paddingTop);
    if (node.props.paint) {
        node.props.paint(painter(ctx), availableWidth, availableHeight);
    }
    ctx.restore();
};
// Ref: https://www.w3.org/TR/css-backgrounds-3/#borders
// This constant is used to approximate a symmetrical arc using a cubic Bezier curve.
const KAPPA = 4.0 * ((Math.sqrt(2) - 1.0) / 3.0);
const clipBorderTop = (ctx, layout, style, rtr, rtl)=>{
    const { top, left, width, height } = layout;
    const { borderTopWidth, borderRightWidth, borderLeftWidth } = style;
    // Clip outer top border edge
    ctx.moveTo(left + rtl, top);
    ctx.lineTo(left + width - rtr, top);
    // Ellipse coefficients outer top right cap
    const c0 = rtr * (1.0 - KAPPA);
    // Clip outer top right cap
    ctx.bezierCurveTo(left + width - c0, top, left + width, top + c0, left + width, top + rtr);
    // Move down in case the margin exceedes the radius
    const topRightYCoord = top + Math.max(borderTopWidth, rtr);
    ctx.lineTo(left + width, topRightYCoord);
    // Clip inner top right cap
    ctx.lineTo(left + width - borderRightWidth, topRightYCoord);
    // Ellipse coefficients inner top right cap
    const innerTopRightRadiusX = Math.max(rtr - borderRightWidth, 0);
    const innerTopRightRadiusY = Math.max(rtr - borderTopWidth, 0);
    const c1 = innerTopRightRadiusX * (1.0 - KAPPA);
    const c2 = innerTopRightRadiusY * (1.0 - KAPPA);
    // Clip inner top right cap
    ctx.bezierCurveTo(left + width - borderRightWidth, top + borderTopWidth + c2, left + width - borderRightWidth - c1, top + borderTopWidth, left + width - borderRightWidth - innerTopRightRadiusX, top + borderTopWidth);
    // Clip inner top border edge
    ctx.lineTo(left + Math.max(rtl, borderLeftWidth), top + borderTopWidth);
    // Ellipse coefficients inner top left cap
    const innerTopLeftRadiusX = Math.max(rtl - borderLeftWidth, 0);
    const innerTopLeftRadiusY = Math.max(rtl - borderTopWidth, 0);
    const c3 = innerTopLeftRadiusX * (1.0 - KAPPA);
    const c4 = innerTopLeftRadiusY * (1.0 - KAPPA);
    const topLeftYCoord = top + Math.max(borderTopWidth, rtl);
    // Clip inner top left cap
    ctx.bezierCurveTo(left + borderLeftWidth + c3, top + borderTopWidth, left + borderLeftWidth, top + borderTopWidth + c4, left + borderLeftWidth, topLeftYCoord);
    ctx.lineTo(left, topLeftYCoord);
    // Move down in case the margin exceedes the radius
    ctx.lineTo(left, top + rtl);
    // Ellipse coefficients outer top left cap
    const c5 = rtl * (1.0 - KAPPA);
    // Clip outer top left cap
    ctx.bezierCurveTo(left, top + c5, left + c5, top, left + rtl, top);
    ctx.closePath();
    ctx.clip();
    // Clip border top cap joins
    if (borderRightWidth) {
        const trSlope = -borderTopWidth / borderRightWidth;
        ctx.moveTo(left + width / 2, trSlope * (-width / 2) + top);
        ctx.lineTo(left + width, top);
        ctx.lineTo(left, top);
        ctx.lineTo(left, top + height);
        ctx.closePath();
        ctx.clip();
    }
    if (borderLeftWidth) {
        const trSlope = -borderTopWidth / borderLeftWidth;
        ctx.moveTo(left + width / 2, trSlope * (-width / 2) + top);
        ctx.lineTo(left, top);
        ctx.lineTo(left + width, top);
        ctx.lineTo(left + width, top + height);
        ctx.closePath();
        ctx.clip();
    }
};
const fillBorderTop = (ctx, layout, style, rtr, rtl)=>{
    const { top, left, width } = layout;
    const { borderTopColor, borderTopWidth, borderTopStyle, borderRightWidth, borderLeftWidth } = style;
    const c0 = rtl * (1.0 - KAPPA);
    const c1 = rtr * (1.0 - KAPPA);
    ctx.moveTo(left, top + Math.max(rtl, borderTopWidth));
    ctx.bezierCurveTo(left, top + c0, left + c0, top, left + rtl, top);
    ctx.lineTo(left + width - rtr, top);
    ctx.bezierCurveTo(left + width - c1, top, left + width, top + c1, left + width, top + rtr);
    ctx.strokeColor(borderTopColor);
    ctx.lineWidth(Math.max(borderRightWidth, borderTopWidth, borderLeftWidth) * 2);
    if (borderTopStyle === 'dashed') {
        ctx.dash(borderTopWidth * 2, {
            space: borderTopWidth * 1.2
        });
    } else if (borderTopStyle === 'dotted') {
        ctx.dash(borderTopWidth, {
            space: borderTopWidth * 1.2
        });
    }
    ctx.stroke();
    ctx.undash();
};
const clipBorderRight = (ctx, layout, style, rtr, rbr)=>{
    const { top, left, width, height } = layout;
    const { borderTopWidth, borderRightWidth, borderBottomWidth } = style;
    // Clip outer right border edge
    ctx.moveTo(left + width, top + rtr);
    ctx.lineTo(left + width, top + height - rbr);
    // Ellipse coefficients outer bottom right cap
    const c0 = rbr * (1.0 - KAPPA);
    // Clip outer top right cap
    ctx.bezierCurveTo(left + width, top + height - c0, left + width - c0, top + height, left + width - rbr, top + height);
    // Move left in case the margin exceedes the radius
    const topBottomXCoord = left + width - Math.max(borderRightWidth, rbr);
    ctx.lineTo(topBottomXCoord, top + height);
    // Clip inner bottom right cap
    ctx.lineTo(topBottomXCoord, top + height - borderBottomWidth);
    // Ellipse coefficients inner bottom right cap
    const innerBottomRightRadiusX = Math.max(rbr - borderRightWidth, 0);
    const innerBottomRightRadiusY = Math.max(rbr - borderBottomWidth, 0);
    const c1 = innerBottomRightRadiusX * (1.0 - KAPPA);
    const c2 = innerBottomRightRadiusY * (1.0 - KAPPA);
    // Clip inner top right cap
    ctx.bezierCurveTo(left + width - borderRightWidth - c1, top + height - borderBottomWidth, left + width - borderRightWidth, top + height - borderBottomWidth - c2, left + width - borderRightWidth, top + height - Math.max(rbr, borderBottomWidth));
    // Clip inner right border edge
    ctx.lineTo(left + width - borderRightWidth, top + Math.max(rtr, borderTopWidth));
    // Ellipse coefficients inner top right cap
    const innerTopRightRadiusX = Math.max(rtr - borderRightWidth, 0);
    const innerTopRightRadiusY = Math.max(rtr - borderTopWidth, 0);
    const c3 = innerTopRightRadiusX * (1.0 - KAPPA);
    const c4 = innerTopRightRadiusY * (1.0 - KAPPA);
    const topRightXCoord = left + width - Math.max(rtr, borderRightWidth);
    // Clip inner top left cap
    ctx.bezierCurveTo(left + width - borderRightWidth, top + borderTopWidth + c4, left + width - borderRightWidth - c3, top + borderTopWidth, topRightXCoord, top + borderTopWidth);
    ctx.lineTo(topRightXCoord, top);
    // Move right in case the margin exceedes the radius
    ctx.lineTo(left + width - rtr, top);
    // Ellipse coefficients outer top right cap
    const c5 = rtr * (1.0 - KAPPA);
    // Clip outer top right cap
    ctx.bezierCurveTo(left + width - c5, top, left + width, top + c5, left + width, top + rtr);
    ctx.closePath();
    ctx.clip();
    // Clip border right cap joins
    if (borderTopWidth) {
        const trSlope = -borderTopWidth / borderRightWidth;
        ctx.moveTo(left + width / 2, trSlope * (-width / 2) + top);
        ctx.lineTo(left + width, top);
        ctx.lineTo(left + width, top + height);
        ctx.lineTo(left, top + height);
        ctx.closePath();
        ctx.clip();
    }
    if (borderBottomWidth) {
        const brSlope = borderBottomWidth / borderRightWidth;
        ctx.moveTo(left + width / 2, brSlope * (-width / 2) + top + height);
        ctx.lineTo(left + width, top + height);
        ctx.lineTo(left + width, top);
        ctx.lineTo(left, top);
        ctx.closePath();
        ctx.clip();
    }
};
const fillBorderRight = (ctx, layout, style, rtr, rbr)=>{
    const { top, left, width, height } = layout;
    const { borderRightColor, borderRightStyle, borderRightWidth, borderTopWidth, borderBottomWidth } = style;
    const c0 = rbr * (1.0 - KAPPA);
    const c1 = rtr * (1.0 - KAPPA);
    ctx.moveTo(left + width - rtr, top);
    ctx.bezierCurveTo(left + width - c1, top, left + width, top + c1, left + width, top + rtr);
    ctx.lineTo(left + width, top + height - rbr);
    ctx.bezierCurveTo(left + width, top + height - c0, left + width - c0, top + height, left + width - rbr, top + height);
    ctx.strokeColor(borderRightColor);
    ctx.lineWidth(Math.max(borderRightWidth, borderTopWidth, borderBottomWidth) * 2);
    if (borderRightStyle === 'dashed') {
        ctx.dash(borderRightWidth * 2, {
            space: borderRightWidth * 1.2
        });
    } else if (borderRightStyle === 'dotted') {
        ctx.dash(borderRightWidth, {
            space: borderRightWidth * 1.2
        });
    }
    ctx.stroke();
    ctx.undash();
};
const clipBorderBottom = (ctx, layout, style, rbl, rbr)=>{
    const { top, left, width, height } = layout;
    const { borderBottomWidth, borderRightWidth, borderLeftWidth } = style;
    // Clip outer top border edge
    ctx.moveTo(left + width - rbr, top + height);
    ctx.lineTo(left + rbl, top + height);
    // Ellipse coefficients outer top right cap
    const c0 = rbl * (1.0 - KAPPA);
    // Clip outer top right cap
    ctx.bezierCurveTo(left + c0, top + height, left, top + height - c0, left, top + height - rbl);
    // Move up in case the margin exceedes the radius
    const bottomLeftYCoord = top + height - Math.max(borderBottomWidth, rbl);
    ctx.lineTo(left, bottomLeftYCoord);
    // Clip inner bottom left cap
    ctx.lineTo(left + borderLeftWidth, bottomLeftYCoord);
    // Ellipse coefficients inner top right cap
    const innerBottomLeftRadiusX = Math.max(rbl - borderLeftWidth, 0);
    const innerBottomLeftRadiusY = Math.max(rbl - borderBottomWidth, 0);
    const c1 = innerBottomLeftRadiusX * (1.0 - KAPPA);
    const c2 = innerBottomLeftRadiusY * (1.0 - KAPPA);
    // Clip inner bottom left cap
    ctx.bezierCurveTo(left + borderLeftWidth, top + height - borderBottomWidth - c2, left + borderLeftWidth + c1, top + height - borderBottomWidth, left + borderLeftWidth + innerBottomLeftRadiusX, top + height - borderBottomWidth);
    // Clip inner bottom border edge
    ctx.lineTo(left + width - Math.max(rbr, borderRightWidth), top + height - borderBottomWidth);
    // Ellipse coefficients inner top left cap
    const innerBottomRightRadiusX = Math.max(rbr - borderRightWidth, 0);
    const innerBottomRightRadiusY = Math.max(rbr - borderBottomWidth, 0);
    const c3 = innerBottomRightRadiusX * (1.0 - KAPPA);
    const c4 = innerBottomRightRadiusY * (1.0 - KAPPA);
    const bottomRightYCoord = top + height - Math.max(borderBottomWidth, rbr);
    // Clip inner top left cap
    ctx.bezierCurveTo(left + width - borderRightWidth - c3, top + height - borderBottomWidth, left + width - borderRightWidth, top + height - borderBottomWidth - c4, left + width - borderRightWidth, bottomRightYCoord);
    ctx.lineTo(left + width, bottomRightYCoord);
    // Move down in case the margin exceedes the radius
    ctx.lineTo(left + width, top + height - rbr);
    // Ellipse coefficients outer top left cap
    const c5 = rbr * (1.0 - KAPPA);
    // Clip outer top left cap
    ctx.bezierCurveTo(left + width, top + height - c5, left + width - c5, top + height, left + width - rbr, top + height);
    ctx.closePath();
    ctx.clip();
    // Clip border bottom cap joins
    if (borderRightWidth) {
        const brSlope = borderBottomWidth / borderRightWidth;
        ctx.moveTo(left + width / 2, brSlope * (-width / 2) + top + height);
        ctx.lineTo(left + width, top + height);
        ctx.lineTo(left, top + height);
        ctx.lineTo(left, top);
        ctx.closePath();
        ctx.clip();
    }
    if (borderLeftWidth) {
        const trSlope = -borderBottomWidth / borderLeftWidth;
        ctx.moveTo(left + width / 2, trSlope * (width / 2) + top + height);
        ctx.lineTo(left, top + height);
        ctx.lineTo(left + width, top + height);
        ctx.lineTo(left + width, top);
        ctx.closePath();
        ctx.clip();
    }
};
const fillBorderBottom = (ctx, layout, style, rbl, rbr)=>{
    const { top, left, width, height } = layout;
    const { borderBottomColor, borderBottomStyle, borderBottomWidth, borderRightWidth, borderLeftWidth } = style;
    const c0 = rbl * (1.0 - KAPPA);
    const c1 = rbr * (1.0 - KAPPA);
    ctx.moveTo(left + width, top + height - rbr);
    ctx.bezierCurveTo(left + width, top + height - c1, left + width - c1, top + height, left + width - rbr, top + height);
    ctx.lineTo(left + rbl, top + height);
    ctx.bezierCurveTo(left + c0, top + height, left, top + height - c0, left, top + height - rbl);
    ctx.strokeColor(borderBottomColor);
    ctx.lineWidth(Math.max(borderBottomWidth, borderRightWidth, borderLeftWidth) * 2);
    if (borderBottomStyle === 'dashed') {
        ctx.dash(borderBottomWidth * 2, {
            space: borderBottomWidth * 1.2
        });
    } else if (borderBottomStyle === 'dotted') {
        ctx.dash(borderBottomWidth, {
            space: borderBottomWidth * 1.2
        });
    }
    ctx.stroke();
    ctx.undash();
};
const clipBorderLeft = (ctx, layout, style, rbl, rtl)=>{
    const { top, left, width, height } = layout;
    const { borderTopWidth, borderLeftWidth, borderBottomWidth } = style;
    // Clip outer left border edge
    ctx.moveTo(left, top + height - rbl);
    ctx.lineTo(left, top + rtl);
    // Ellipse coefficients outer top left cap
    const c0 = rtl * (1.0 - KAPPA);
    // Clip outer top left cap
    ctx.bezierCurveTo(left, top + c0, left + c0, top, left + rtl, top);
    // Move right in case the margin exceedes the radius
    const topLeftCoordX = left + Math.max(borderLeftWidth, rtl);
    ctx.lineTo(topLeftCoordX, top);
    // Clip inner top left cap
    ctx.lineTo(topLeftCoordX, top + borderTopWidth);
    // Ellipse coefficients inner top left cap
    const innerTopLeftRadiusX = Math.max(rtl - borderLeftWidth, 0);
    const innerTopLeftRadiusY = Math.max(rtl - borderTopWidth, 0);
    const c1 = innerTopLeftRadiusX * (1.0 - KAPPA);
    const c2 = innerTopLeftRadiusY * (1.0 - KAPPA);
    // Clip inner top right cap
    ctx.bezierCurveTo(left + borderLeftWidth + c1, top + borderTopWidth, left + borderLeftWidth, top + borderTopWidth + c2, left + borderLeftWidth, top + Math.max(rtl, borderTopWidth));
    // Clip inner left border edge
    ctx.lineTo(left + borderLeftWidth, top + height - Math.max(rbl, borderBottomWidth));
    // Ellipse coefficients inner bottom left cap
    const innerBottomLeftRadiusX = Math.max(rbl - borderLeftWidth, 0);
    const innerBottomLeftRadiusY = Math.max(rbl - borderBottomWidth, 0);
    const c3 = innerBottomLeftRadiusX * (1.0 - KAPPA);
    const c4 = innerBottomLeftRadiusY * (1.0 - KAPPA);
    const bottomLeftXCoord = left + Math.max(rbl, borderLeftWidth);
    // Clip inner top left cap
    ctx.bezierCurveTo(left + borderLeftWidth, top + height - borderBottomWidth - c4, left + borderLeftWidth + c3, top + height - borderBottomWidth, bottomLeftXCoord, top + height - borderBottomWidth);
    ctx.lineTo(bottomLeftXCoord, top + height);
    // Move left in case the margin exceedes the radius
    ctx.lineTo(left + rbl, top + height);
    // Ellipse coefficients outer top right cap
    const c5 = rbl * (1.0 - KAPPA);
    // Clip outer top right cap
    ctx.bezierCurveTo(left + c5, top + height, left, top + height - c5, left, top + height - rbl);
    ctx.closePath();
    ctx.clip();
    // Clip border right cap joins
    if (borderBottomWidth) {
        const trSlope = -borderBottomWidth / borderLeftWidth;
        ctx.moveTo(left + width / 2, trSlope * (width / 2) + top + height);
        ctx.lineTo(left, top + height);
        ctx.lineTo(left, top);
        ctx.lineTo(left + width, top);
        ctx.closePath();
        ctx.clip();
    }
    if (borderBottomWidth) {
        const trSlope = -borderTopWidth / borderLeftWidth;
        ctx.moveTo(left + width / 2, trSlope * (-width / 2) + top);
        ctx.lineTo(left, top);
        ctx.lineTo(left, top + height);
        ctx.lineTo(left + width, top + height);
        ctx.closePath();
        ctx.clip();
    }
};
const fillBorderLeft = (ctx, layout, style, rbl, rtl)=>{
    const { top, left, height } = layout;
    const { borderLeftColor, borderLeftStyle, borderLeftWidth, borderTopWidth, borderBottomWidth } = style;
    const c0 = rbl * (1.0 - KAPPA);
    const c1 = rtl * (1.0 - KAPPA);
    ctx.moveTo(left + rbl, top + height);
    ctx.bezierCurveTo(left + c0, top + height, left, top + height - c0, left, top + height - rbl);
    ctx.lineTo(left, top + rtl);
    ctx.bezierCurveTo(left, top + c1, left + c1, top, left + rtl, top);
    ctx.strokeColor(borderLeftColor);
    ctx.lineWidth(Math.max(borderLeftWidth, borderTopWidth, borderBottomWidth) * 2);
    if (borderLeftStyle === 'dashed') {
        ctx.dash(borderLeftWidth * 2, {
            space: borderLeftWidth * 1.2
        });
    } else if (borderLeftStyle === 'dotted') {
        ctx.dash(borderLeftWidth, {
            space: borderLeftWidth * 1.2
        });
    }
    ctx.stroke();
    ctx.undash();
};
const shouldRenderBorders = (node)=>node.box && (node.box.borderTopWidth || node.box.borderRightWidth || node.box.borderBottomWidth || node.box.borderLeftWidth);
const renderBorders = (ctx, node)=>{
    if (!node.box) return;
    if (!shouldRenderBorders(node)) return;
    const { width, height, borderTopWidth = 0, borderLeftWidth = 0, borderRightWidth = 0, borderBottomWidth = 0 } = node.box;
    const { opacity = 1, borderTopColor = 'black', borderTopStyle = 'solid', borderLeftColor = 'black', borderLeftStyle = 'solid', borderRightColor = 'black', borderRightStyle = 'solid', borderBottomColor = 'black', borderBottomStyle = 'solid' } = node.style;
    // @ts-expect-error this is always a number due to resolve border radius step
    const borderTopLeftRadius = node.style.borderTopLeftRadius || 0;
    // @ts-expect-error this is always a number due to resolve border radius step
    const borderTopRightRadius = node.style.borderTopRightRadius || 0;
    // @ts-expect-error this is always a number due to resolve border radius step
    const borderBottomLeftRadius = node.style.borderBottomLeftRadius || 0;
    // @ts-expect-error this is always a number due to resolve border radius step
    const borderBottomRightRadius = node.style.borderBottomRightRadius || 0;
    const style = {
        borderTopColor,
        borderTopWidth,
        borderTopStyle,
        borderLeftColor,
        borderLeftWidth,
        borderLeftStyle,
        borderRightColor,
        borderRightWidth,
        borderRightStyle,
        borderBottomColor,
        borderBottomWidth,
        borderBottomStyle
    };
    const rtr = Math.min(borderTopRightRadius, 0.5 * width, 0.5 * height);
    const rtl = Math.min(borderTopLeftRadius, 0.5 * width, 0.5 * height);
    const rbr = Math.min(borderBottomRightRadius, 0.5 * width, 0.5 * height);
    const rbl = Math.min(borderBottomLeftRadius, 0.5 * width, 0.5 * height);
    ctx.save();
    ctx.strokeOpacity(opacity);
    if (borderTopWidth) {
        ctx.save();
        clipBorderTop(ctx, node.box, style, rtr, rtl);
        fillBorderTop(ctx, node.box, style, rtr, rtl);
        ctx.restore();
    }
    if (borderRightWidth) {
        ctx.save();
        clipBorderRight(ctx, node.box, style, rtr, rbr);
        fillBorderRight(ctx, node.box, style, rtr, rbr);
        ctx.restore();
    }
    if (borderBottomWidth) {
        ctx.save();
        clipBorderBottom(ctx, node.box, style, rbl, rbr);
        fillBorderBottom(ctx, node.box, style, rbl, rbr);
        ctx.restore();
    }
    if (borderLeftWidth) {
        ctx.save();
        clipBorderLeft(ctx, node.box, style, rbl, rtl);
        fillBorderLeft(ctx, node.box, style, rbl, rtl);
        ctx.restore();
    }
    ctx.restore();
};
const drawBackground = (ctx, node)=>{
    if (!node.box) return;
    const { top, left, width, height } = node.box;
    const color = parseColor(node.style.backgroundColor);
    const nodeOpacity = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(node.style?.opacity) ? 1 : node.style.opacity;
    const opacity = Math.min(color.opacity, nodeOpacity);
    ctx.fillOpacity(opacity).fillColor(color.value).rect(left, top, width, height).fill();
};
const renderBackground = (ctx, node)=>{
    const hasBackground = !!node.box && !!node.style?.backgroundColor;
    if (hasBackground) {
        ctx.save();
        clipNode(ctx, node);
        drawBackground(ctx, node);
        ctx.restore();
    }
};
const isString = (value)=>typeof value === 'string';
const isSrcId = (value)=>/^#.+/.test(value);
const renderLink = (ctx, node, src)=>{
    if (!src || !node.box) return;
    const isId = isSrcId(src);
    const method = isId ? 'goTo' : 'link';
    const value = isId ? src.slice(1) : src;
    const { top, left, width, height } = node.box;
    ctx[method](left, top, width, height, value);
};
const setLink = (ctx, node)=>{
    const props = node.props || {};
    if ('src' in props && isString(props.src)) return renderLink(ctx, node, props.src);
    if ('href' in props && isString(props.href)) return renderLink(ctx, node, props.href);
};
const setDestination = (ctx, node)=>{
    if (!node.box) return;
    if (!node.props) return;
    if ('id' in node.props) {
        ctx.addNamedDestination(node.props.id, 'XYZ', null, node.box.top, null);
    }
};
const clean = (options)=>{
    const opt = {
        ...options
    };
    // We need to ensure the elements are no present if not true
    Object.entries(opt).forEach((pair)=>{
        if (!pair[1]) {
            delete opt[pair[0]];
        }
    });
    return opt;
};
const parseCommonFormOptions = (node)=>{
    // Common Options
    return {
        required: node.props?.required || false,
        noExport: node.props?.noExport || false,
        readOnly: node.props?.readOnly || false,
        value: node.props?.value || undefined,
        defaultValue: node.props?.defaultValue || undefined
    };
};
const parseTextInputOptions = (node, fieldSet)=>{
    return clean({
        ...parseCommonFormOptions(node),
        parent: fieldSet || undefined,
        align: node.props?.align || 'left',
        multiline: node.props?.multiline || undefined,
        password: node.props?.password || false,
        noSpell: node.props?.noSpell || false,
        format: node.props?.format || undefined,
        fontSize: node.props?.fontSize || undefined,
        MaxLen: node.props?.maxLength || undefined
    });
};
const parseSelectAndListFieldOptions = (node)=>{
    return clean({
        ...parseCommonFormOptions(node),
        sort: node.props?.sort || false,
        edit: node.props?.edit || false,
        multiSelect: node.props?.multiSelect || false,
        noSpell: node.props?.noSpell || false,
        select: node.props?.select || [
            ''
        ]
    });
};
const getAppearance = (ctx, codepoint, width, height)=>{
    const appearance = ctx.ref({
        Type: 'XObject',
        Subtype: 'Form',
        BBox: [
            0,
            0,
            width,
            height
        ],
        Resources: {
            ProcSet: [
                'PDF',
                'Text',
                'ImageB',
                'ImageC',
                'ImageI'
            ],
            Font: {
                ZaDi: ctx._acroform.fonts.ZaDi
            }
        }
    });
    appearance.initDeflate();
    appearance.write(`/Tx BMC\nq\n/ZaDi ${height * 0.8} Tf\nBT\n${width * 0.45} ${height / 4} Td (${codepoint}) Tj\nET\nQ\nEMC`);
    appearance.end(null);
    return appearance;
};
const parseCheckboxOptions = (ctx, node, fieldSet)=>{
    const { width, height } = node.box || {};
    const onOption = node.props?.onState || 'Yes';
    const offOption = node.props?.offState || 'Off';
    const xMark = node.props?.xMark || false;
    if (!Object.prototype.hasOwnProperty.call(ctx._acroform.fonts, 'ZaDi')) {
        const ref = ctx.ref({
            Type: 'Font',
            Subtype: 'Type1',
            BaseFont: 'ZapfDingbats'
        });
        ctx._acroform.fonts.ZaDi = ref;
        ref.end(null);
    }
    const normalAppearance = {
        [onOption]: getAppearance(ctx, xMark ? '8' : '4', width, height),
        [offOption]: getAppearance(ctx, xMark ? ' ' : '8', width, height)
    };
    return clean({
        ...parseCommonFormOptions(node),
        backgroundColor: node.props?.backgroundColor || undefined,
        borderColor: node.props?.borderColor || undefined,
        parent: fieldSet || undefined,
        value: `/${node.props?.checked === true ? onOption : offOption}`,
        defaultValue: `/${node.props?.checked === true ? onOption : offOption}`,
        AS: node.props?.checked === true ? onOption : offOption,
        AP: {
            N: normalAppearance,
            D: normalAppearance
        }
    });
};
const renderTextInput = (ctx, node, options)=>{
    if (!node.box) return;
    const { top, left, width, height } = node.box;
    // Element's name
    const name = node.props?.name || '';
    const fieldSetOptions = options.fieldSets?.at(0);
    if (!ctx._root.data.AcroForm) {
        ctx.initForm();
    }
    ctx.formText(name, left, top, width, height, parseTextInputOptions(node, fieldSetOptions));
};
const renderSelect = (ctx, node)=>{
    if (!node.box) return;
    const { top, left, width, height } = node.box;
    // Element's name
    const name = node.props?.name || '';
    if (!ctx._root.data.AcroForm) {
        ctx.initForm();
    }
    ctx.formCombo(name, left, top, width, height, parseSelectAndListFieldOptions(node));
};
const renderFieldSet = (ctx, node, options)=>{
    const name = node.props?.name || '';
    if (!ctx._root.data.AcroForm) {
        ctx.initForm();
    }
    const formField = ctx.formField(name);
    const option = options;
    if (!option.fieldSets) {
        option.fieldSets = [
            formField
        ];
    } else {
        option.fieldSets.push(formField);
    }
};
const cleanUpFieldSet = (_ctx, _node, options)=>{
    options.fieldSets.pop();
};
const renderList = (ctx, node)=>{
    if (!node.box) return;
    const { top, left, width, height } = node.box || {};
    // Element's name
    const name = 'name' in node.props ? node.props.name || '' : '';
    if (!ctx._root.data.AcroForm) {
        ctx.initForm();
    }
    ctx.formList(name, left, top, width, height, parseSelectAndListFieldOptions(node));
};
const renderCheckbox = (ctx, node, options)=>{
    if (!node.box) return;
    const { top, left, width, height } = node.box;
    // Element's name
    const name = node.props?.name || '';
    const fieldSetOptions = options.fieldSets?.at(0);
    if (!ctx._root.data.AcroForm) {
        ctx.initForm();
    }
    ctx.formCheckbox(name, left, top, width, height, parseCheckboxOptions(ctx, node, fieldSetOptions));
};
const isRecursiveNode = (node)=>node.type !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"] && node.type !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Svg"];
const renderChildren = (ctx, node, options)=>{
    ctx.save();
    if (node.box) {
        ctx.translate(node.box.left, node.box.top);
    }
    const children = node.children || [];
    const renderChild = (child)=>renderNode(ctx, child, options);
    children.forEach(renderChild);
    ctx.restore();
};
const renderFns = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Text"]]: renderText,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Note"]]: renderNote,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Image"]]: renderImage,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldSet"]]: renderFieldSet,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TextInput"]]: renderTextInput,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Select"]]: renderSelect,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Checkbox"]]: renderCheckbox,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["List"]]: renderList,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Canvas"]]: renderCanvas,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Svg"]]: renderSvg,
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Link"]]: setLink
};
const cleanUpFns = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FieldSet"]]: cleanUpFieldSet
};
const renderNode = (ctx, node, options)=>{
    const overflowHidden = node.style?.overflow === 'hidden';
    const shouldRenderChildren = isRecursiveNode(node);
    if (node.type === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Page"]) renderPage(ctx, node);
    ctx.save();
    if (overflowHidden) clipNode(ctx, node);
    applyTransformations(ctx, node);
    renderBackground(ctx, node);
    renderBorders(ctx, node);
    const renderFn = renderFns[node.type];
    if (renderFn) renderFn(ctx, node, options);
    if (shouldRenderChildren) renderChildren(ctx, node, options);
    const cleanUpFn = cleanUpFns[node.type];
    if (cleanUpFn) cleanUpFn(ctx, node, options);
    setDestination(ctx, node);
    renderDebug(ctx, node);
    ctx.restore();
};
const addNodeBookmark = (ctx, node, pageNumber, registry)=>{
    if (!node.box) return;
    if (!node.props) return;
    if ('bookmark' in node.props && node.props.bookmark) {
        const bookmark = node.props.bookmark;
        const { title, parent, expanded, zoom, fit } = bookmark;
        const outline = registry[parent] || ctx.outline;
        const top = bookmark.top || node.box.top;
        const left = bookmark.left || node.box.left;
        const instance = outline.addItem(title, {
            pageNumber,
            expanded,
            top,
            left,
            zoom,
            fit
        });
        registry[bookmark.ref] = instance;
    }
    if (!node.children) return;
    node.children.forEach((child)=>addNodeBookmark(ctx, child, pageNumber, registry));
};
const addBookmarks = (ctx, root)=>{
    const registry = {};
    const pages = root.children || [];
    pages.forEach((page, i)=>{
        addNodeBookmark(ctx, page, i, registry);
    });
};
const render = (ctx, doc)=>{
    const pages = doc.children || [];
    const options = {
        imageCache: new Map(),
        fieldSets: []
    };
    pages.forEach((page)=>renderNode(ctx, page, options));
    addBookmarks(ctx, doc);
    ctx.end();
    return ctx;
};
;
}),
"[project]/node_modules/media-engine/src/queries.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function MaxHeight(value) {
    this.value = value;
    this.match = function(options) {
        return this.value >= options.height;
    };
}
function MinHeight(value) {
    this.value = value;
    this.match = function(options) {
        return this.value < options.height;
    };
}
function MaxWidth(value) {
    this.value = value;
    this.match = function(options) {
        return this.value >= options.width;
    };
}
function MinWidth(value) {
    this.value = value;
    this.match = function(options) {
        return this.value < options.width;
    };
}
function Orientation(value) {
    this.value = value;
    this.match = function(options) {
        return this.value === options.orientation;
    };
}
module.exports = function Query(type, value) {
    switch(type){
        case 'max-height':
            return new MaxHeight(value);
        case 'min-height':
            return new MinHeight(value);
        case 'max-width':
            return new MaxWidth(value);
        case 'min-width':
            return new MinWidth(value);
        case 'orientation':
            return new Orientation(value);
        default:
            throw new Error(value);
    }
};
}),
"[project]/node_modules/media-engine/src/operators.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

function And(left, right) {
    this.left = left;
    this.right = right;
    this.match = function(options) {
        return left.match(options) && right.match(options);
    };
}
function Or(left, right) {
    this.left = left;
    this.right = right;
    this.match = function(options) {
        return left.match(options) || right.match(options);
    };
}
module.exports = function Operator(type, left, right) {
    switch(type){
        case 'and':
            return new And(left, right);
        case ',':
            return new Or(left, right);
        default:
            throw new Error(value);
    }
};
}),
"[project]/node_modules/media-engine/src/parser.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var Query = __turbopack_context__.r("[project]/node_modules/media-engine/src/queries.js [app-client] (ecmascript)");
var Operator = __turbopack_context__.r("[project]/node_modules/media-engine/src/operators.js [app-client] (ecmascript)");
var NUMBERS = /[0-9]/;
var LETTERS = /[a-z|\-]/i;
var WHITESPACE = /\s/;
var COLON = /:/;
var COMMA = /,/;
var AND = /and$/;
var AT = /@/;
function tokenizer(input) {
    var current = 0;
    var tokens = [];
    while(current < input.length){
        var char = input[current];
        if (AT.test(char)) {
            char = input[++current];
            while(LETTERS.test(char) && char !== undefined){
                char = input[++current];
            }
        }
        if (WHITESPACE.test(char) || char === ')' || char === '(') {
            current++;
            continue;
        }
        if (COLON.test(char) || COMMA.test(char)) {
            current++;
            tokens.push({
                type: 'operator',
                value: char
            });
            continue;
        }
        if (NUMBERS.test(char)) {
            var value = '';
            while(NUMBERS.test(char)){
                value += char;
                char = input[++current];
            }
            tokens.push({
                type: 'number',
                value: value
            });
            continue;
        }
        if (LETTERS.test(char)) {
            var value = '';
            while(LETTERS.test(char) && char !== undefined){
                value += char;
                char = input[++current];
            }
            if (AND.test(value)) {
                tokens.push({
                    type: 'operator',
                    value: value
                });
            } else {
                tokens.push({
                    type: 'literal',
                    value: value
                });
            }
            continue;
        }
        throw new TypeError('Tokenizer: I dont know what this character is: ' + char);
    }
    return tokens;
}
function parser(tokens) {
    var output = [];
    var stack = [];
    while(tokens.length > 0){
        var token = tokens.shift();
        if (token.type === 'number' || token.type === 'literal') {
            output.push(token);
            continue;
        }
        if (token.type === 'operator') {
            if (COLON.test(token.value)) {
                token = {
                    type: 'query',
                    key: output.pop(),
                    value: tokens.shift()
                };
                output.push(token);
                continue;
            }
            while(stack.length > 0){
                output.unshift(stack.pop());
            }
            stack.push(token);
        }
    }
    while(stack.length > 0){
        output.unshift(stack.pop());
    }
    function walk() {
        var head = output.shift();
        if (head.type === 'number') {
            return parseInt(head.value);
        }
        if (head.type === 'literal') {
            return head.value;
        }
        if (head.type === 'operator') {
            var l = walk();
            var r = walk();
            return Operator(head.value, l, r);
        }
        if (head.type === 'query') {
            var l = head.key.value;
            var r = head.value.value;
            return Query(l, r);
        }
    }
    return walk();
}
module.exports = {
    parse: function(query) {
        var tokens = tokenizer(query);
        var ast = parser(tokens);
        return ast;
    }
};
}),
"[project]/node_modules/media-engine/src/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var Parser = __turbopack_context__.r("[project]/node_modules/media-engine/src/parser.js [app-client] (ecmascript)");
module.exports = function(queries, options) {
    var result = {};
    Object.keys(queries).forEach(function(query) {
        if (Parser.parse(query).match(options)) {
            Object.assign(result, queries[query]);
        }
    });
    return result;
};
}),
"[project]/node_modules/hsl-to-rgb-for-reals/converter.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// expected hue range: [0, 360)
// expected saturation range: [0, 1]
// expected lightness range: [0, 1]
var hslToRgb = function(hue, saturation, lightness) {
    // based on algorithm from http://en.wikipedia.org/wiki/HSL_and_HSV#Converting_to_RGB
    if (hue == undefined) {
        return [
            0,
            0,
            0
        ];
    }
    var chroma = (1 - Math.abs(2 * lightness - 1)) * saturation;
    var huePrime = hue / 60;
    var secondComponent = chroma * (1 - Math.abs(huePrime % 2 - 1));
    huePrime = Math.floor(huePrime);
    var red;
    var green;
    var blue;
    if (huePrime === 0) {
        red = chroma;
        green = secondComponent;
        blue = 0;
    } else if (huePrime === 1) {
        red = secondComponent;
        green = chroma;
        blue = 0;
    } else if (huePrime === 2) {
        red = 0;
        green = chroma;
        blue = secondComponent;
    } else if (huePrime === 3) {
        red = 0;
        green = secondComponent;
        blue = chroma;
    } else if (huePrime === 4) {
        red = secondComponent;
        green = 0;
        blue = chroma;
    } else if (huePrime === 5) {
        red = chroma;
        green = 0;
        blue = secondComponent;
    }
    var lightnessAdjustment = lightness - chroma / 2;
    red += lightnessAdjustment;
    green += lightnessAdjustment;
    blue += lightnessAdjustment;
    return [
        Math.abs(Math.round(red * 255)),
        Math.abs(Math.round(green * 255)),
        Math.abs(Math.round(blue * 255))
    ];
};
module.exports = hslToRgb;
}),
"[project]/node_modules/hsl-to-hex/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

// In our case, there's only one dependency
var toRgb = __turbopack_context__.r("[project]/node_modules/hsl-to-rgb-for-reals/converter.js [app-client] (ecmascript)");
// Typically all dependencies should be declared at the top of the file.
// Now let's define an API for our module, we're taking hue, saturation and luminosity values and outputting a CSS compatible hex string.
// Hue is in degrees, between 0 and 359. Since degrees a cyclical in nature, we'll support numbers greater than 359 or less than 0 by "spinning" them around until they fall within the 0 to 359 range.
// Saturation and luminosity are both percentages, we'll represent these percentages with whole numbers between 0 and 100. For these numbers we'll need to enforce a maximum and a minimum, anything below 0 will become 0, anything above 100 will become 100.
// Let's write some utility functions to handle this logic:
function max(val, n) {
    return val > n ? n : val;
}
function min(val, n) {
    return val < n ? n : val;
}
function cycle(val) {
    // for safety:
    val = max(val, 1e7);
    val = min(val, -1e7);
    // cycle value:
    while(val < 0){
        val += 360;
    }
    while(val > 359){
        val -= 360;
    }
    return val;
}
// Now for the main piece, the `hsl` function:
function hsl(hue, saturation, luminosity) {
    // resolve degrees to 0 - 359 range
    hue = cycle(hue);
    // enforce constraints
    saturation = min(max(saturation, 100), 0);
    luminosity = min(max(luminosity, 100), 0);
    // convert to 0 to 1 range used by hsl-to-rgb-for-reals
    saturation /= 100;
    luminosity /= 100;
    // let hsl-to-rgb-for-reals do the hard work
    var rgb = toRgb(hue, saturation, luminosity);
    // convert each value in the returned RGB array
    // to a 2 character hex value, join the array into
    // a string, prefixed with a hash
    return '#' + rgb.map(function(n) {
        return (256 + n).toString(16).substr(-2);
    }).join('');
}
// In order to make our code into a bona fide module we have to export it:
module.exports = hsl;
}),
"[project]/node_modules/postcss-value-parser/lib/parse.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var openParentheses = "(".charCodeAt(0);
var closeParentheses = ")".charCodeAt(0);
var singleQuote = "'".charCodeAt(0);
var doubleQuote = '"'.charCodeAt(0);
var backslash = "\\".charCodeAt(0);
var slash = "/".charCodeAt(0);
var comma = ",".charCodeAt(0);
var colon = ":".charCodeAt(0);
var star = "*".charCodeAt(0);
var uLower = "u".charCodeAt(0);
var uUpper = "U".charCodeAt(0);
var plus = "+".charCodeAt(0);
var isUnicodeRange = /^[a-f0-9?-]+$/i;
module.exports = function(input) {
    var tokens = [];
    var value = input;
    var next, quote, prev, token, escape, escapePos, whitespacePos, parenthesesOpenPos;
    var pos = 0;
    var code = value.charCodeAt(pos);
    var max = value.length;
    var stack = [
        {
            nodes: tokens
        }
    ];
    var balanced = 0;
    var parent;
    var name = "";
    var before = "";
    var after = "";
    while(pos < max){
        // Whitespaces
        if (code <= 32) {
            next = pos;
            do {
                next += 1;
                code = value.charCodeAt(next);
            }while (code <= 32)
            token = value.slice(pos, next);
            prev = tokens[tokens.length - 1];
            if (code === closeParentheses && balanced) {
                after = token;
            } else if (prev && prev.type === "div") {
                prev.after = token;
                prev.sourceEndIndex += token.length;
            } else if (code === comma || code === colon || code === slash && value.charCodeAt(next + 1) !== star && (!parent || parent && parent.type === "function" && parent.value !== "calc")) {
                before = token;
            } else {
                tokens.push({
                    type: "space",
                    sourceIndex: pos,
                    sourceEndIndex: next,
                    value: token
                });
            }
            pos = next;
        // Quotes
        } else if (code === singleQuote || code === doubleQuote) {
            next = pos;
            quote = code === singleQuote ? "'" : '"';
            token = {
                type: "string",
                sourceIndex: pos,
                quote: quote
            };
            do {
                escape = false;
                next = value.indexOf(quote, next + 1);
                if (~next) {
                    escapePos = next;
                    while(value.charCodeAt(escapePos - 1) === backslash){
                        escapePos -= 1;
                        escape = !escape;
                    }
                } else {
                    value += quote;
                    next = value.length - 1;
                    token.unclosed = true;
                }
            }while (escape)
            token.value = value.slice(pos + 1, next);
            token.sourceEndIndex = token.unclosed ? next : next + 1;
            tokens.push(token);
            pos = next + 1;
            code = value.charCodeAt(pos);
        // Comments
        } else if (code === slash && value.charCodeAt(pos + 1) === star) {
            next = value.indexOf("*/", pos);
            token = {
                type: "comment",
                sourceIndex: pos,
                sourceEndIndex: next + 2
            };
            if (next === -1) {
                token.unclosed = true;
                next = value.length;
                token.sourceEndIndex = next;
            }
            token.value = value.slice(pos + 2, next);
            tokens.push(token);
            pos = next + 2;
            code = value.charCodeAt(pos);
        // Operation within calc
        } else if ((code === slash || code === star) && parent && parent.type === "function" && parent.value === "calc") {
            token = value[pos];
            tokens.push({
                type: "word",
                sourceIndex: pos - before.length,
                sourceEndIndex: pos + token.length,
                value: token
            });
            pos += 1;
            code = value.charCodeAt(pos);
        // Dividers
        } else if (code === slash || code === comma || code === colon) {
            token = value[pos];
            tokens.push({
                type: "div",
                sourceIndex: pos - before.length,
                sourceEndIndex: pos + token.length,
                value: token,
                before: before,
                after: ""
            });
            before = "";
            pos += 1;
            code = value.charCodeAt(pos);
        // Open parentheses
        } else if (openParentheses === code) {
            // Whitespaces after open parentheses
            next = pos;
            do {
                next += 1;
                code = value.charCodeAt(next);
            }while (code <= 32)
            parenthesesOpenPos = pos;
            token = {
                type: "function",
                sourceIndex: pos - name.length,
                value: name,
                before: value.slice(parenthesesOpenPos + 1, next)
            };
            pos = next;
            if (name === "url" && code !== singleQuote && code !== doubleQuote) {
                next -= 1;
                do {
                    escape = false;
                    next = value.indexOf(")", next + 1);
                    if (~next) {
                        escapePos = next;
                        while(value.charCodeAt(escapePos - 1) === backslash){
                            escapePos -= 1;
                            escape = !escape;
                        }
                    } else {
                        value += ")";
                        next = value.length - 1;
                        token.unclosed = true;
                    }
                }while (escape)
                // Whitespaces before closed
                whitespacePos = next;
                do {
                    whitespacePos -= 1;
                    code = value.charCodeAt(whitespacePos);
                }while (code <= 32)
                if (parenthesesOpenPos < whitespacePos) {
                    if (pos !== whitespacePos + 1) {
                        token.nodes = [
                            {
                                type: "word",
                                sourceIndex: pos,
                                sourceEndIndex: whitespacePos + 1,
                                value: value.slice(pos, whitespacePos + 1)
                            }
                        ];
                    } else {
                        token.nodes = [];
                    }
                    if (token.unclosed && whitespacePos + 1 !== next) {
                        token.after = "";
                        token.nodes.push({
                            type: "space",
                            sourceIndex: whitespacePos + 1,
                            sourceEndIndex: next,
                            value: value.slice(whitespacePos + 1, next)
                        });
                    } else {
                        token.after = value.slice(whitespacePos + 1, next);
                        token.sourceEndIndex = next;
                    }
                } else {
                    token.after = "";
                    token.nodes = [];
                }
                pos = next + 1;
                token.sourceEndIndex = token.unclosed ? next : pos;
                code = value.charCodeAt(pos);
                tokens.push(token);
            } else {
                balanced += 1;
                token.after = "";
                token.sourceEndIndex = pos + 1;
                tokens.push(token);
                stack.push(token);
                tokens = token.nodes = [];
                parent = token;
            }
            name = "";
        // Close parentheses
        } else if (closeParentheses === code && balanced) {
            pos += 1;
            code = value.charCodeAt(pos);
            parent.after = after;
            parent.sourceEndIndex += after.length;
            after = "";
            balanced -= 1;
            stack[stack.length - 1].sourceEndIndex = pos;
            stack.pop();
            parent = stack[balanced];
            tokens = parent.nodes;
        // Words
        } else {
            next = pos;
            do {
                if (code === backslash) {
                    next += 1;
                }
                next += 1;
                code = value.charCodeAt(next);
            }while (next < max && !(code <= 32 || code === singleQuote || code === doubleQuote || code === comma || code === colon || code === slash || code === openParentheses || code === star && parent && parent.type === "function" && parent.value === "calc" || code === slash && parent.type === "function" && parent.value === "calc" || code === closeParentheses && balanced))
            token = value.slice(pos, next);
            if (openParentheses === code) {
                name = token;
            } else if ((uLower === token.charCodeAt(0) || uUpper === token.charCodeAt(0)) && plus === token.charCodeAt(1) && isUnicodeRange.test(token.slice(2))) {
                tokens.push({
                    type: "unicode-range",
                    sourceIndex: pos,
                    sourceEndIndex: next,
                    value: token
                });
            } else {
                tokens.push({
                    type: "word",
                    sourceIndex: pos,
                    sourceEndIndex: next,
                    value: token
                });
            }
            pos = next;
        }
    }
    for(pos = stack.length - 1; pos; pos -= 1){
        stack[pos].unclosed = true;
        stack[pos].sourceEndIndex = value.length;
    }
    return stack[0].nodes;
};
}),
"[project]/node_modules/postcss-value-parser/lib/unit.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

var minus = "-".charCodeAt(0);
var plus = "+".charCodeAt(0);
var dot = ".".charCodeAt(0);
var exp = "e".charCodeAt(0);
var EXP = "E".charCodeAt(0);
// Check if three code points would start a number
// https://www.w3.org/TR/css-syntax-3/#starts-with-a-number
function likeNumber(value) {
    var code = value.charCodeAt(0);
    var nextCode;
    if (code === plus || code === minus) {
        nextCode = value.charCodeAt(1);
        if (nextCode >= 48 && nextCode <= 57) {
            return true;
        }
        var nextNextCode = value.charCodeAt(2);
        if (nextCode === dot && nextNextCode >= 48 && nextNextCode <= 57) {
            return true;
        }
        return false;
    }
    if (code === dot) {
        nextCode = value.charCodeAt(1);
        if (nextCode >= 48 && nextCode <= 57) {
            return true;
        }
        return false;
    }
    if (code >= 48 && code <= 57) {
        return true;
    }
    return false;
}
// Consume a number
// https://www.w3.org/TR/css-syntax-3/#consume-number
module.exports = function(value) {
    var pos = 0;
    var length = value.length;
    var code;
    var nextCode;
    var nextNextCode;
    if (length === 0 || !likeNumber(value)) {
        return false;
    }
    code = value.charCodeAt(pos);
    if (code === plus || code === minus) {
        pos++;
    }
    while(pos < length){
        code = value.charCodeAt(pos);
        if (code < 48 || code > 57) {
            break;
        }
        pos += 1;
    }
    code = value.charCodeAt(pos);
    nextCode = value.charCodeAt(pos + 1);
    if (code === dot && nextCode >= 48 && nextCode <= 57) {
        pos += 2;
        while(pos < length){
            code = value.charCodeAt(pos);
            if (code < 48 || code > 57) {
                break;
            }
            pos += 1;
        }
    }
    code = value.charCodeAt(pos);
    nextCode = value.charCodeAt(pos + 1);
    nextNextCode = value.charCodeAt(pos + 2);
    if ((code === exp || code === EXP) && (nextCode >= 48 && nextCode <= 57 || (nextCode === plus || nextCode === minus) && nextNextCode >= 48 && nextNextCode <= 57)) {
        pos += nextCode === plus || nextCode === minus ? 3 : 2;
        while(pos < length){
            code = value.charCodeAt(pos);
            if (code < 48 || code > 57) {
                break;
            }
            pos += 1;
        }
    }
    return {
        number: value.slice(0, pos),
        unit: value.slice(pos)
    };
};
}),
"[project]/node_modules/@react-pdf/stylesheet/lib/index.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>resolveStyles,
    "flatten",
    ()=>flatten,
    "transformColor",
    ()=>transformColor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/fns/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$media$2d$engine$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/media-engine/src/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hsl$2d$to$2d$hex$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hsl-to-hex/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$color$2d$string$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/color-string/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$postcss$2d$value$2d$parser$2f$lib$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/postcss-value-parser/lib/parse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$postcss$2d$value$2d$parser$2f$lib$2f$unit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/postcss-value-parser/lib/unit.js [app-client] (ecmascript)");
;
;
;
;
;
;
/**
 * Remove nil values from array
 *
 * @param array - Style array
 * @returns Style array without nils
 */ const compact = (array)=>array.filter(Boolean);
/**
 * Merges style objects array
 *
 * @param styles - Style array
 * @returns Merged style object
 */ const mergeStyles = (styles)=>styles.reduce((acc, style)=>{
        const s = Array.isArray(style) ? flatten(style) : style;
        Object.keys(s).forEach((key)=>{
            if (s[key] !== null && s[key] !== undefined) {
                acc[key] = s[key];
            }
        });
        return acc;
    }, {});
/**
 * Flattens an array of style objects, into one aggregated style object.
 *
 * @param styles - Style or style array
 * @returns Flattened style object
 */ const flatten = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compose"])(mergeStyles, compact, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["castArray"]);
/**
 * Resolves media queries in styles object
 *
 * @param container - Container for which styles are resolved
 * @param style - Style description
 * @returns Resolved style object
 */ const resolveMediaQueries = (container, style)=>{
    return Object.keys(style).reduce((acc, key)=>{
        if (/@media/.test(key)) {
            return {
                ...acc,
                ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$media$2d$engine$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                    [key]: style[key]
                }, container)
            };
        }
        return {
            ...acc,
            [key]: style[key]
        };
    }, {});
};
const isRgb = (value)=>/rgba?/g.test(value);
const isHsl = (value)=>/hsla?/g.test(value);
/**
 * Transform rgb color to hexa
 *
 * @param value - Styles value
 * @returns Transformed value
 */ const parseRgb = (value)=>{
    const rgb = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$color$2d$string$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get.rgb(value);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$color$2d$string$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].to.hex(rgb);
};
/**
 * Transform Hsl color to hexa
 *
 * @param value - Styles value
 * @returns Transformed value
 */ const parseHsl = (value)=>{
    const hsl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$color$2d$string$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get.hsl(value).map(Math.round);
    const hex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hsl$2d$to$2d$hex$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(...hsl);
    return hex.toUpperCase();
};
/**
 * Transform given color to hexa
 *
 * @param value - Styles value
 * @returns Transformed value
 */ const transformColor = (value)=>{
    if (isRgb(value)) return parseRgb(value);
    if (isHsl(value)) return parseHsl(value);
    return value;
};
/**
 * Parses scalar value in value and unit pairs
 *
 * @param value - Scalar value
 * @returns Parsed value
 */ const parseValue = (value)=>{
    if (typeof value === 'number') return {
        value,
        unit: undefined
    };
    const match = /^(-?\d*\.?\d+)(in|mm|cm|pt|vh|vw|px|rem)?$/g.exec(value);
    return match ? {
        value: parseFloat(match[1]),
        unit: match[2] || 'pt'
    } : {
        value,
        unit: undefined
    };
};
/**
 * Transform given scalar value
 *
 * @param container
 * @param value - Styles value
 * @returns Transformed value
 */ const transformUnit = (container, value)=>{
    const scalar = parseValue(value);
    const outputDpi = 72;
    const inputDpi = container.dpi || 72;
    const mmFactor = 1 / 25.4 * outputDpi;
    const cmFactor = 1 / 2.54 * outputDpi;
    if (typeof scalar.value !== 'number') return scalar.value;
    switch(scalar.unit){
        case 'rem':
            return scalar.value * (container.remBase || 18);
        case 'in':
            return scalar.value * outputDpi;
        case 'mm':
            return scalar.value * mmFactor;
        case 'cm':
            return scalar.value * cmFactor;
        case 'vh':
            return scalar.value * (container.height / 100);
        case 'vw':
            return scalar.value * (container.width / 100);
        case 'px':
            return Math.round(scalar.value * (outputDpi / inputDpi));
        default:
            return scalar.value;
    }
};
const processNumberValue = (key, value)=>({
        [key]: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseFloat"])(value)
    });
const processUnitValue = (key, value, container)=>({
        [key]: transformUnit(container, value)
    });
const processColorValue = (key, value)=>{
    const result = {
        [key]: transformColor(value)
    };
    return result;
};
const processNoopValue = (key, value)=>({
        [key]: value
    });
const BORDER_SHORTHAND_REGEX = /(-?\d+(\.\d+)?(in|mm|cm|pt|vw|vh|px|rem)?)\s(\S+)\s(.+)/;
const matchBorderShorthand = (value)=>value.match(BORDER_SHORTHAND_REGEX) || [];
const resolveBorderShorthand = (key, value, container)=>{
    const match = matchBorderShorthand(`${value}`);
    if ("TURBOPACK compile-time truthy", 1) {
        const widthMatch = match[1] || value;
        const styleMatch = match[4] || value;
        const colorMatch = match[5] || value;
        const style = styleMatch;
        const color = colorMatch ? transformColor(colorMatch) : undefined;
        const width = widthMatch ? transformUnit(container, widthMatch) : undefined;
        if (key.match(/(Top|Right|Bottom|Left)$/)) {
            return {
                [`${key}Color`]: color,
                [`${key}Style`]: style,
                [`${key}Width`]: width
            };
        }
        if (key.match(/Color$/)) {
            return {
                borderTopColor: color,
                borderRightColor: color,
                borderBottomColor: color,
                borderLeftColor: color
            };
        }
        if (key.match(/Style$/)) {
            if (typeof style === 'number') throw new Error(`Invalid border style: ${style}`);
            return {
                borderTopStyle: style,
                borderRightStyle: style,
                borderBottomStyle: style,
                borderLeftStyle: style
            };
        }
        if (key.match(/Width$/)) {
            if (typeof width !== 'number') throw new Error(`Invalid border width: ${width}`);
            return {
                borderTopWidth: width,
                borderRightWidth: width,
                borderBottomWidth: width,
                borderLeftWidth: width
            };
        }
        if (key.match(/Radius$/)) {
            const radius = value ? transformUnit(container, value) : undefined;
            if (typeof radius !== 'number') throw new Error(`Invalid border radius: ${radius}`);
            return {
                borderTopLeftRadius: radius,
                borderTopRightRadius: radius,
                borderBottomRightRadius: radius,
                borderBottomLeftRadius: radius
            };
        }
        if (typeof width !== 'number') throw new Error(`Invalid border width: ${width}`);
        if (typeof style === 'number') throw new Error(`Invalid border style: ${style}`);
        return {
            borderTopColor: color,
            borderTopStyle: style,
            borderTopWidth: width,
            borderRightColor: color,
            borderRightStyle: style,
            borderRightWidth: width,
            borderBottomColor: color,
            borderBottomStyle: style,
            borderBottomWidth: width,
            borderLeftColor: color,
            borderLeftStyle: style,
            borderLeftWidth: width
        };
    }
    //TURBOPACK unreachable
    ;
};
const handlers$b = {
    border: resolveBorderShorthand,
    borderBottom: resolveBorderShorthand,
    borderBottomColor: processColorValue,
    borderBottomLeftRadius: processUnitValue,
    borderBottomRightRadius: processUnitValue,
    borderBottomStyle: processNoopValue,
    borderBottomWidth: processUnitValue,
    borderColor: resolveBorderShorthand,
    borderLeft: resolveBorderShorthand,
    borderLeftColor: processColorValue,
    borderLeftStyle: processNoopValue,
    borderLeftWidth: processUnitValue,
    borderRadius: resolveBorderShorthand,
    borderRight: resolveBorderShorthand,
    borderRightColor: processColorValue,
    borderRightStyle: processNoopValue,
    borderRightWidth: processUnitValue,
    borderStyle: resolveBorderShorthand,
    borderTop: resolveBorderShorthand,
    borderTopColor: processColorValue,
    borderTopLeftRadius: processUnitValue,
    borderTopRightRadius: processUnitValue,
    borderTopStyle: processNoopValue,
    borderTopWidth: processUnitValue,
    borderWidth: resolveBorderShorthand
};
const handlers$a = {
    backgroundColor: processColorValue,
    color: processColorValue,
    opacity: processNumberValue
};
const handlers$9 = {
    height: processUnitValue,
    maxHeight: processUnitValue,
    maxWidth: processUnitValue,
    minHeight: processUnitValue,
    minWidth: processUnitValue,
    width: processUnitValue
};
// https://developer.mozilla.org/en-US/docs/Web/CSS/flex#values
// TODO: change flex defaults to [0, 1, 'auto'] as in spec in next major release
const flexDefaults = [
    1,
    1,
    0
];
const flexAuto = [
    1,
    1,
    'auto'
];
const processFlexShorthand = (key, value, container)=>{
    let defaults = flexDefaults;
    let matches = [];
    if (value === 'auto') {
        defaults = flexAuto;
    } else {
        matches = `${value}`.split(' ');
    }
    const flexGrow = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseFloat"])(matches[0] || defaults[0]);
    const flexShrink = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseFloat"])(matches[1] || defaults[1]);
    const flexBasis = transformUnit(container, matches[2] || defaults[2]);
    return {
        flexGrow,
        flexShrink,
        flexBasis
    };
};
const handlers$8 = {
    alignContent: processNoopValue,
    alignItems: processNoopValue,
    alignSelf: processNoopValue,
    flex: processFlexShorthand,
    flexBasis: processUnitValue,
    flexDirection: processNoopValue,
    flexFlow: processNoopValue,
    flexGrow: processNumberValue,
    flexShrink: processNumberValue,
    flexWrap: processNoopValue,
    justifyContent: processNoopValue,
    justifySelf: processNoopValue
};
const processGapShorthand = (key, value, container)=>{
    const match = `${value}`.split(' ');
    const rowGap = transformUnit(container, match?.[0] || value);
    const columnGap = transformUnit(container, match?.[1] || value);
    return {
        rowGap,
        columnGap
    };
};
const handlers$7 = {
    gap: processGapShorthand,
    columnGap: processUnitValue,
    rowGap: processUnitValue
};
const handlers$6 = {
    aspectRatio: processNumberValue,
    bottom: processUnitValue,
    display: processNoopValue,
    left: processUnitValue,
    position: processNoopValue,
    right: processUnitValue,
    top: processUnitValue,
    overflow: processNoopValue,
    zIndex: processNumberValue
};
const BOX_MODEL_UNITS = 'px,in,mm,cm,pt,%,vw,vh';
const logError = (style, value)=>{
    const name = style.toString();
    // eslint-disable-next-line no-console
    console.error(`
    @react-pdf/stylesheet parsing error:
    ${name}: ${value},
    ${' '.repeat(name.length + 2)}^
    Unsupported ${name} value format
  `);
};
/**
 * @param options
 * @param [options.expandsTo]
 * @param [options.maxValues]
 * @param [options.autoSupported]
 */ const expandBoxModel = ({ expandsTo, maxValues = 1, autoSupported = false } = {})=>(model, value, container)=>{
        const nodes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$postcss$2d$value$2d$parser$2f$lib$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`${value}`);
        const parts = [];
        for(let i = 0; i < nodes.length; i++){
            const node = nodes[i];
            // value contains `calc`, `url` or other css function
            // `,`, `/` or strings that unsupported by margin and padding
            if (node.type === 'function' || node.type === 'string' || node.type === 'div') {
                logError(model, value);
                return {};
            }
            if (node.type === 'word') {
                if (node.value === 'auto' && autoSupported) {
                    parts.push(node.value);
                } else {
                    const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$postcss$2d$value$2d$parser$2f$lib$2f$unit$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(node.value);
                    // when unit isn't specified this condition is true
                    if (result && BOX_MODEL_UNITS.includes(result.unit)) {
                        parts.push(node.value);
                    } else {
                        logError(model, value);
                        return {};
                    }
                }
            }
        }
        // checks that we have enough parsed values
        if (parts.length > maxValues) {
            logError(model, value);
            return {};
        }
        const first = transformUnit(container, parts[0]);
        if (expandsTo) {
            const second = transformUnit(container, parts[1] || parts[0]);
            const third = transformUnit(container, parts[2] || parts[0]);
            const fourth = transformUnit(container, parts[3] || parts[1] || parts[0]);
            return expandsTo({
                first,
                second,
                third,
                fourth
            });
        }
        return {
            [model]: first
        };
    };
const processMargin = expandBoxModel({
    expandsTo: ({ first, second, third, fourth })=>({
            marginTop: first,
            marginRight: second,
            marginBottom: third,
            marginLeft: fourth
        }),
    maxValues: 4,
    autoSupported: true
});
const processMarginVertical = expandBoxModel({
    expandsTo: ({ first, second })=>({
            marginTop: first,
            marginBottom: second
        }),
    maxValues: 2,
    autoSupported: true
});
const processMarginHorizontal = expandBoxModel({
    expandsTo: ({ first, second })=>({
            marginRight: first,
            marginLeft: second
        }),
    maxValues: 2,
    autoSupported: true
});
const processMarginSingle = expandBoxModel({
    autoSupported: true
});
const handlers$5 = {
    margin: processMargin,
    marginBottom: processMarginSingle,
    marginHorizontal: processMarginHorizontal,
    marginLeft: processMarginSingle,
    marginRight: processMarginSingle,
    marginTop: processMarginSingle,
    marginVertical: processMarginVertical
};
const processPadding = expandBoxModel({
    expandsTo: ({ first, second, third, fourth })=>({
            paddingTop: first,
            paddingRight: second,
            paddingBottom: third,
            paddingLeft: fourth
        }),
    maxValues: 4
});
const processPaddingVertical = expandBoxModel({
    expandsTo: ({ first, second })=>({
            paddingTop: first,
            paddingBottom: second
        }),
    maxValues: 2
});
const processPaddingHorizontal = expandBoxModel({
    expandsTo: ({ first, second })=>({
            paddingRight: first,
            paddingLeft: second
        }),
    maxValues: 2
});
const processPaddingSingle = expandBoxModel();
const handlers$4 = {
    padding: processPadding,
    paddingBottom: processPaddingSingle,
    paddingHorizontal: processPaddingHorizontal,
    paddingLeft: processPaddingSingle,
    paddingRight: processPaddingSingle,
    paddingTop: processPaddingSingle,
    paddingVertical: processPaddingVertical
};
const offsetKeyword = (value)=>{
    switch(value){
        case 'top':
        case 'left':
            return '0%';
        case 'right':
        case 'bottom':
            return '100%';
        case 'center':
            return '50%';
        default:
            return value;
    }
};
const processObjectPosition = (key, value, container)=>{
    const match = `${value}`.split(' ');
    const objectPositionX = offsetKeyword(transformUnit(container, match?.[0] || value));
    const objectPositionY = offsetKeyword(transformUnit(container, match?.[1] || value));
    return {
        objectPositionX,
        objectPositionY
    };
};
const processObjectPositionValue = (key, value, container)=>({
        [key]: offsetKeyword(transformUnit(container, value))
    });
const handlers$3 = {
    objectPosition: processObjectPosition,
    objectPositionX: processObjectPositionValue,
    objectPositionY: processObjectPositionValue,
    objectFit: processNoopValue
};
const castInt = (value)=>{
    if (typeof value === 'number') return value;
    return parseInt(value, 10);
};
const FONT_WEIGHTS = {
    thin: 100,
    hairline: 100,
    ultralight: 200,
    extralight: 200,
    light: 300,
    normal: 400,
    medium: 500,
    semibold: 600,
    demibold: 600,
    bold: 700,
    ultrabold: 800,
    extrabold: 800,
    heavy: 900,
    black: 900
};
const transformFontWeight = (value)=>{
    if (!value) return FONT_WEIGHTS.normal;
    if (typeof value === 'number') return value;
    const lv = value.toLowerCase();
    if (FONT_WEIGHTS[lv]) return FONT_WEIGHTS[lv];
    return castInt(value);
};
const processFontWeight = (key, value)=>{
    return {
        [key]: transformFontWeight(value)
    };
};
const transformLineHeight = (value, styles, container)=>{
    if (value === '') return value;
    const fontSize = transformUnit(container, styles.fontSize || 18);
    const lineHeight = transformUnit(container, value);
    // Percent values: use this number multiplied by the element's font size
    const { percent } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["matchPercent"])(lineHeight) || {};
    if (percent) return percent * fontSize;
    // Unitless values: use this number multiplied by the element's font size
    return isNaN(value) ? lineHeight : lineHeight * fontSize;
};
const processLineHeight = (key, value, container, styles)=>{
    return {
        [key]: transformLineHeight(value, styles, container)
    };
};
const handlers$2 = {
    direction: processNoopValue,
    fontFamily: processNoopValue,
    fontSize: processUnitValue,
    fontStyle: processNoopValue,
    fontWeight: processFontWeight,
    letterSpacing: processUnitValue,
    lineHeight: processLineHeight,
    maxLines: processNumberValue,
    textAlign: processNoopValue,
    textDecoration: processNoopValue,
    textDecorationColor: processColorValue,
    textDecorationStyle: processNoopValue,
    textIndent: processNoopValue,
    textOverflow: processNoopValue,
    textTransform: processNoopValue,
    verticalAlign: processNoopValue
};
const matchNumber = (value)=>typeof value === 'string' && /^-?\d*\.?\d*$/.test(value);
const castFloat = (value)=>{
    if (typeof value !== 'string') return value;
    if (matchNumber(value)) return parseFloat(value);
    return value;
};
const parse = (transformString)=>{
    const transforms = transformString.trim().split(/\)[ ,]|\)/);
    // Handle "initial", "inherit", "unset".
    if (transforms.length === 1) {
        return [
            [
                transforms[0],
                true
            ]
        ];
    }
    const parsed = [];
    for(let i = 0; i < transforms.length; i += 1){
        const transform = transforms[i];
        if (transform) {
            const [name, rawValue] = transform.split('(');
            const splitChar = rawValue.indexOf(',') >= 0 ? ',' : ' ';
            const value = rawValue.split(splitChar).map((val)=>val.trim());
            parsed.push({
                operation: name.trim(),
                value
            });
        }
    }
    return parsed;
};
const parseAngle = (value)=>{
    const unitsRegexp = /(-?\d*\.?\d*)(\w*)?/i;
    const [, angle, unit] = unitsRegexp.exec(value);
    const number = Number.parseFloat(angle);
    return unit === 'rad' ? number * 180 / Math.PI : number;
};
const normalizeTransformOperation = ({ operation, value })=>{
    switch(operation){
        case 'scale':
            {
                const [scaleX, scaleY = scaleX] = value.map((num)=>Number.parseFloat(num));
                return {
                    operation: 'scale',
                    value: [
                        scaleX,
                        scaleY
                    ]
                };
            }
        case 'scaleX':
            {
                return {
                    operation: 'scale',
                    value: [
                        Number.parseFloat(value),
                        1
                    ]
                };
            }
        case 'scaleY':
            {
                return {
                    operation: 'scale',
                    value: [
                        1,
                        Number.parseFloat(value)
                    ]
                };
            }
        case 'rotate':
            {
                return {
                    operation: 'rotate',
                    value: [
                        parseAngle(value)
                    ]
                };
            }
        case 'translate':
            {
                return {
                    operation: 'translate',
                    value: value.map((num)=>Number.parseFloat(num))
                };
            }
        case 'translateX':
            {
                return {
                    operation: 'translate',
                    value: [
                        Number.parseFloat(value),
                        0
                    ]
                };
            }
        case 'translateY':
            {
                return {
                    operation: 'translate',
                    value: [
                        0,
                        Number.parseFloat(value)
                    ]
                };
            }
        case 'skew':
            {
                return {
                    operation: 'skew',
                    value: value.map(parseAngle)
                };
            }
        case 'skewX':
            {
                return {
                    operation: 'skew',
                    value: [
                        parseAngle(value),
                        0
                    ]
                };
            }
        case 'skewY':
            {
                return {
                    operation: 'skew',
                    value: [
                        0,
                        parseAngle(value)
                    ]
                };
            }
        default:
            {
                return {
                    operation,
                    value: value.map((num)=>Number.parseFloat(num))
                };
            }
    }
};
const normalize = (operations)=>{
    return operations.map((operation)=>normalizeTransformOperation(operation));
};
const processTransform = (key, value)=>{
    if (typeof value !== 'string') return {
        [key]: value
    };
    return {
        [key]: normalize(parse(value))
    };
};
const Y_AXIS_SHORTHANDS = {
    top: true,
    bottom: true
};
const sortTransformOriginPair = (a, b)=>{
    if (Y_AXIS_SHORTHANDS[a]) return 1;
    if (Y_AXIS_SHORTHANDS[b]) return -1;
    return 0;
};
const getTransformOriginPair = (values)=>{
    if (!values || values.length === 0) return [
        'center',
        'center'
    ];
    const pair = values.length === 1 ? [
        values[0],
        'center'
    ] : values;
    return pair.sort(sortTransformOriginPair);
};
// Transforms shorthand transformOrigin values
const processTransformOriginShorthand = (key, value, container)=>{
    const match = `${value}`.split(' ');
    const pair = getTransformOriginPair(match);
    const transformOriginX = transformUnit(container, pair[0]);
    const transformOriginY = transformUnit(container, pair[1]);
    return {
        transformOriginX: offsetKeyword(transformOriginX) || castFloat(transformOriginX),
        transformOriginY: offsetKeyword(transformOriginY) || castFloat(transformOriginY)
    };
};
const processTransformOriginValue = (key, value, container)=>{
    const v = transformUnit(container, value);
    return {
        [key]: offsetKeyword(v) || castFloat(v)
    };
};
const handlers$1 = {
    transform: processTransform,
    gradientTransform: processTransform,
    transformOrigin: processTransformOriginShorthand,
    transformOriginX: processTransformOriginValue,
    transformOriginY: processTransformOriginValue
};
const handlers = {
    fill: processColorValue,
    stroke: processColorValue,
    strokeDasharray: processNoopValue,
    strokeWidth: processUnitValue,
    fillOpacity: processNumberValue,
    strokeOpacity: processNumberValue,
    fillRule: processNoopValue,
    textAnchor: processNoopValue,
    strokeLinecap: processNoopValue,
    strokeLinejoin: processNoopValue,
    visibility: processNoopValue,
    clipPath: processNoopValue,
    dominantBaseline: processNoopValue
};
const shorthands = {
    ...handlers$b,
    ...handlers$a,
    ...handlers$9,
    ...handlers$8,
    ...handlers$7,
    ...handlers$6,
    ...handlers$5,
    ...handlers$4,
    ...handlers$3,
    ...handlers$2,
    ...handlers$1,
    ...handlers
};
/**
 * Expand the shorthand properties.
 *
 * @param style - Style object
 * @returns Expanded style object
 */ const resolve = (container)=>(style)=>{
        const propsArray = Object.keys(style);
        const resolvedStyle = {};
        for(let i = 0; i < propsArray.length; i += 1){
            const key = propsArray[i];
            const value = style[key];
            if (!shorthands[key]) {
                resolvedStyle[key] = value;
                continue;
            }
            const resolved = shorthands[key](key, value, container, style);
            const keys = Object.keys(resolved);
            for(let j = 0; j < keys.length; j += 1){
                const propName = keys[j];
                const propValue = resolved[propName];
                resolvedStyle[propName] = propValue;
            }
        }
        return resolvedStyle;
    };
/**
 * Resolves styles
 *
 * @param container
 * @param style - Style
 * @returns Resolved style
 */ const resolveStyles = (container, style)=>{
    const computeMediaQueries = (value)=>resolveMediaQueries(container, value);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compose"])(resolve(container), computeMediaQueries, flatten)(style);
};
;
}),
"[project]/node_modules/bidi-js/dist/bidi.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
function bidiFactory() {
    var bidi = function(exports) {
        // Bidi character types data, auto generated
        var DATA = {
            "R": "13k,1a,2,3,3,2+1j,ch+16,a+1,5+2,2+n,5,a,4,6+16,4+3,h+1b,4mo,179q,2+9,2+11,2i9+7y,2+68,4,3+4,5+13,4+3,2+4k,3+29,8+cf,1t+7z,w+17,3+3m,1t+3z,16o1+5r,8+30,8+mc,29+1r,29+4v,75+73",
            "EN": "1c+9,3d+1,6,187+9,513,4+5,7+9,sf+j,175h+9,qw+q,161f+1d,4xt+a,25i+9",
            "ES": "17,2,6dp+1,f+1,av,16vr,mx+1,4o,2",
            "ET": "z+2,3h+3,b+1,ym,3e+1,2o,p4+1,8,6u,7c,g6,1wc,1n9+4,30+1b,2n,6d,qhx+1,h0m,a+1,49+2,63+1,4+1,6bb+3,12jj",
            "AN": "16o+5,2j+9,2+1,35,ed,1ff2+9,87+u",
            "CS": "18,2+1,b,2u,12k,55v,l,17v0,2,3,53,2+1,b",
            "B": "a,3,f+2,2v,690",
            "S": "9,2,k",
            "WS": "c,k,4f4,1vk+a,u,1j,335",
            "ON": "x+1,4+4,h+5,r+5,r+3,z,5+3,2+1,2+1,5,2+2,3+4,o,w,ci+1,8+d,3+d,6+8,2+g,39+1,9,6+1,2,33,b8,3+1,3c+1,7+1,5r,b,7h+3,sa+5,2,3i+6,jg+3,ur+9,2v,ij+1,9g+9,7+a,8m,4+1,49+x,14u,2+2,c+2,e+2,e+2,e+1,i+n,e+e,2+p,u+2,e+2,36+1,2+3,2+1,b,2+2,6+5,2,2,2,h+1,5+4,6+3,3+f,16+2,5+3l,3+81,1y+p,2+40,q+a,m+13,2r+ch,2+9e,75+hf,3+v,2+2w,6e+5,f+6,75+2a,1a+p,2+2g,d+5x,r+b,6+3,4+o,g,6+1,6+2,2k+1,4,2j,5h+z,1m+1,1e+f,t+2,1f+e,d+3,4o+3,2s+1,w,535+1r,h3l+1i,93+2,2s,b+1,3l+x,2v,4g+3,21+3,kz+1,g5v+1,5a,j+9,n+v,2,3,2+8,2+1,3+2,2,3,46+1,4+4,h+5,r+5,r+a,3h+2,4+6,b+4,78,1r+24,4+c,4,1hb,ey+6,103+j,16j+c,1ux+7,5+g,fsh,jdq+1t,4,57+2e,p1,1m,1m,1m,1m,4kt+1,7j+17,5+2r,d+e,3+e,2+e,2+10,m+4,w,1n+5,1q,4z+5,4b+rb,9+c,4+c,4+37,d+2g,8+b,l+b,5+1j,9+9,7+13,9+t,3+1,27+3c,2+29,2+3q,d+d,3+4,4+2,6+6,a+o,8+6,a+2,e+6,16+42,2+1i",
            "BN": "0+8,6+d,2s+5,2+p,e,4m9,1kt+2,2b+5,5+5,17q9+v,7k,6p+8,6+1,119d+3,440+7,96s+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+1,1ekf+75,6p+2rz,1ben+1,1ekf+1,1ekf+1",
            "NSM": "lc+33,7o+6,7c+18,2,2+1,2+1,2,21+a,1d+k,h,2u+6,3+5,3+1,2+3,10,v+q,2k+a,1n+8,a,p+3,2+8,2+2,2+4,18+2,3c+e,2+v,1k,2,5+7,5,4+6,b+1,u,1n,5+3,9,l+1,r,3+1,1m,5+1,5+1,3+2,4,v+1,4,c+1,1m,5+4,2+1,5,l+1,n+5,2,1n,3,2+3,9,8+1,c+1,v,1q,d,1f,4,1m+2,6+2,2+3,8+1,c+1,u,1n,g+1,l+1,t+1,1m+1,5+3,9,l+1,u,21,8+2,2,2j,3+6,d+7,2r,3+8,c+5,23+1,s,2,2,1k+d,2+4,2+1,6+a,2+z,a,2v+3,2+5,2+1,3+1,q+1,5+2,h+3,e,3+1,7,g,jk+2,qb+2,u+2,u+1,v+1,1t+1,2+6,9,3+a,a,1a+2,3c+1,z,3b+2,5+1,a,7+2,64+1,3,1n,2+6,2,2,3+7,7+9,3,1d+g,1s+3,1d,2+4,2,6,15+8,d+1,x+3,3+1,2+2,1l,2+1,4,2+2,1n+7,3+1,49+2,2+c,2+6,5,7,4+1,5j+1l,2+4,k1+w,2db+2,3y,2p+v,ff+3,30+1,n9x+3,2+9,x+1,29+1,7l,4,5,q+1,6,48+1,r+h,e,13+7,q+a,1b+2,1d,3+3,3+1,14,1w+5,3+1,3+1,d,9,1c,1g,2+2,3+1,6+1,2,17+1,9,6n,3,5,fn5,ki+f,h+f,r2,6b,46+4,1af+2,2+1,6+3,15+2,5,4m+1,fy+3,as+1,4a+a,4x,1j+e,1l+2,1e+3,3+1,1y+2,11+4,2+7,1r,d+1,1h+8,b+3,3,2o+2,3,2+1,7,4h,4+7,m+1,1m+1,4,12+6,4+4,5g+7,3+2,2,o,2d+5,2,5+1,2+1,6n+3,7+1,2+1,s+1,2e+7,3,2+1,2z,2,3+5,2,2u+2,3+3,2+4,78+8,2+1,75+1,2,5,41+3,3+1,5,x+5,3+1,15+5,3+3,9,a+5,3+2,1b+c,2+1,bb+6,2+5,2d+l,3+6,2+1,2+1,3f+5,4,2+1,2+6,2,21+1,4,2,9o+1,f0c+4,1o+6,t5,1s+3,2a,f5l+1,43t+2,i+7,3+6,v+3,45+2,1j0+1i,5+1d,9,f,n+4,2+e,11t+6,2+g,3+6,2+1,2+4,7a+6,c6+3,15t+6,32+6,gzhy+6n",
            "AL": "16w,3,2,e+1b,z+2,2+2s,g+1,8+1,b+m,2+t,s+2i,c+e,4h+f,1d+1e,1bwe+dp,3+3z,x+c,2+1,35+3y,2rm+z,5+7,b+5,dt+l,c+u,17nl+27,1t+27,4x+6n,3+d",
            "LRO": "6ct",
            "RLO": "6cu",
            "LRE": "6cq",
            "RLE": "6cr",
            "PDF": "6cs",
            "LRI": "6ee",
            "RLI": "6ef",
            "FSI": "6eg",
            "PDI": "6eh"
        };
        var TYPES = {};
        var TYPES_TO_NAMES = {};
        TYPES.L = 1; //L is the default
        TYPES_TO_NAMES[1] = 'L';
        Object.keys(DATA).forEach(function(type, i) {
            TYPES[type] = 1 << i + 1;
            TYPES_TO_NAMES[TYPES[type]] = type;
        });
        Object.freeze(TYPES);
        var ISOLATE_INIT_TYPES = TYPES.LRI | TYPES.RLI | TYPES.FSI;
        var STRONG_TYPES = TYPES.L | TYPES.R | TYPES.AL;
        var NEUTRAL_ISOLATE_TYPES = TYPES.B | TYPES.S | TYPES.WS | TYPES.ON | TYPES.FSI | TYPES.LRI | TYPES.RLI | TYPES.PDI;
        var BN_LIKE_TYPES = TYPES.BN | TYPES.RLE | TYPES.LRE | TYPES.RLO | TYPES.LRO | TYPES.PDF;
        var TRAILING_TYPES = TYPES.S | TYPES.WS | TYPES.B | ISOLATE_INIT_TYPES | TYPES.PDI | BN_LIKE_TYPES;
        var map = null;
        function parseData() {
            if (!map) {
                //const start = performance.now()
                map = new Map();
                var loop = function(type) {
                    if (DATA.hasOwnProperty(type)) {
                        var lastCode = 0;
                        DATA[type].split(',').forEach(function(range) {
                            var ref = range.split('+');
                            var skip = ref[0];
                            var step = ref[1];
                            skip = parseInt(skip, 36);
                            step = step ? parseInt(step, 36) : 0;
                            map.set(lastCode += skip, TYPES[type]);
                            for(var i = 0; i < step; i++){
                                map.set(++lastCode, TYPES[type]);
                            }
                        });
                    }
                };
                for(var type in DATA)loop(type);
            //console.log(`char types parsed in ${performance.now() - start}ms`)
            }
        }
        /**
   * @param {string} char
   * @return {number}
   */ function getBidiCharType(char) {
            parseData();
            return map.get(char.codePointAt(0)) || TYPES.L;
        }
        function getBidiCharTypeName(char) {
            return TYPES_TO_NAMES[getBidiCharType(char)];
        }
        // Bidi bracket pairs data, auto generated
        var data$1 = {
            "pairs": "14>1,1e>2,u>2,2wt>1,1>1,1ge>1,1wp>1,1j>1,f>1,hm>1,1>1,u>1,u6>1,1>1,+5,28>1,w>1,1>1,+3,b8>1,1>1,+3,1>3,-1>-1,3>1,1>1,+2,1s>1,1>1,x>1,th>1,1>1,+2,db>1,1>1,+3,3>1,1>1,+2,14qm>1,1>1,+1,4q>1,1e>2,u>2,2>1,+1",
            "canonical": "6f1>-6dx,6dy>-6dx,6ec>-6ed,6ee>-6ed,6ww>2jj,-2ji>2jj,14r4>-1e7l,1e7m>-1e7l,1e7m>-1e5c,1e5d>-1e5b,1e5c>-14qx,14qy>-14qx,14vn>-1ecg,1ech>-1ecg,1edu>-1ecg,1eci>-1ecg,1eda>-1ecg,1eci>-1ecg,1eci>-168q,168r>-168q,168s>-14ye,14yf>-14ye"
        };
        /**
   * Parses an string that holds encoded codepoint mappings, e.g. for bracket pairs or
   * mirroring characters, as encoded by scripts/generateBidiData.js. Returns an object
   * holding the `map`, and optionally a `reverseMap` if `includeReverse:true`.
   * @param {string} encodedString
   * @param {boolean} includeReverse - true if you want reverseMap in the output
   * @return {{map: Map<number, number>, reverseMap?: Map<number, number>}}
   */ function parseCharacterMap(encodedString, includeReverse) {
            var radix = 36;
            var lastCode = 0;
            var map = new Map();
            var reverseMap = includeReverse && new Map();
            var prevPair;
            encodedString.split(',').forEach(function visit(entry) {
                if (entry.indexOf('+') !== -1) {
                    for(var i = +entry; i--;){
                        visit(prevPair);
                    }
                } else {
                    prevPair = entry;
                    var ref = entry.split('>');
                    var a = ref[0];
                    var b = ref[1];
                    a = String.fromCodePoint(lastCode += parseInt(a, radix));
                    b = String.fromCodePoint(lastCode += parseInt(b, radix));
                    map.set(a, b);
                    includeReverse && reverseMap.set(b, a);
                }
            });
            return {
                map: map,
                reverseMap: reverseMap
            };
        }
        var openToClose, closeToOpen, canonical;
        function parse$1() {
            if (!openToClose) {
                //const start = performance.now()
                var ref = parseCharacterMap(data$1.pairs, true);
                var map = ref.map;
                var reverseMap = ref.reverseMap;
                openToClose = map;
                closeToOpen = reverseMap;
                canonical = parseCharacterMap(data$1.canonical, false).map;
            //console.log(`brackets parsed in ${performance.now() - start}ms`)
            }
        }
        function openingToClosingBracket(char) {
            parse$1();
            return openToClose.get(char) || null;
        }
        function closingToOpeningBracket(char) {
            parse$1();
            return closeToOpen.get(char) || null;
        }
        function getCanonicalBracket(char) {
            parse$1();
            return canonical.get(char) || null;
        }
        // Local type aliases
        var TYPE_L = TYPES.L;
        var TYPE_R = TYPES.R;
        var TYPE_EN = TYPES.EN;
        var TYPE_ES = TYPES.ES;
        var TYPE_ET = TYPES.ET;
        var TYPE_AN = TYPES.AN;
        var TYPE_CS = TYPES.CS;
        var TYPE_B = TYPES.B;
        var TYPE_S = TYPES.S;
        var TYPE_ON = TYPES.ON;
        var TYPE_BN = TYPES.BN;
        var TYPE_NSM = TYPES.NSM;
        var TYPE_AL = TYPES.AL;
        var TYPE_LRO = TYPES.LRO;
        var TYPE_RLO = TYPES.RLO;
        var TYPE_LRE = TYPES.LRE;
        var TYPE_RLE = TYPES.RLE;
        var TYPE_PDF = TYPES.PDF;
        var TYPE_LRI = TYPES.LRI;
        var TYPE_RLI = TYPES.RLI;
        var TYPE_FSI = TYPES.FSI;
        var TYPE_PDI = TYPES.PDI;
        /**
   * @typedef {object} GetEmbeddingLevelsResult
   * @property {{start, end, level}[]} paragraphs
   * @property {Uint8Array} levels
   */ /**
   * This function applies the Bidirectional Algorithm to a string, returning the resolved embedding levels
   * in a single Uint8Array plus a list of objects holding each paragraph's start and end indices and resolved
   * base embedding level.
   *
   * @param {string} string - The input string
   * @param {"ltr"|"rtl"|"auto"} [baseDirection] - Use "ltr" or "rtl" to force a base paragraph direction,
   *        otherwise a direction will be chosen automatically from each paragraph's contents.
   * @return {GetEmbeddingLevelsResult}
   */ function getEmbeddingLevels(string, baseDirection) {
            var MAX_DEPTH = 125;
            // Start by mapping all characters to their unicode type, as a bitmask integer
            var charTypes = new Uint32Array(string.length);
            for(var i = 0; i < string.length; i++){
                charTypes[i] = getBidiCharType(string[i]);
            }
            var charTypeCounts = new Map(); //will be cleared at start of each paragraph
            function changeCharType(i, type) {
                var oldType = charTypes[i];
                charTypes[i] = type;
                charTypeCounts.set(oldType, charTypeCounts.get(oldType) - 1);
                if (oldType & NEUTRAL_ISOLATE_TYPES) {
                    charTypeCounts.set(NEUTRAL_ISOLATE_TYPES, charTypeCounts.get(NEUTRAL_ISOLATE_TYPES) - 1);
                }
                charTypeCounts.set(type, (charTypeCounts.get(type) || 0) + 1);
                if (type & NEUTRAL_ISOLATE_TYPES) {
                    charTypeCounts.set(NEUTRAL_ISOLATE_TYPES, (charTypeCounts.get(NEUTRAL_ISOLATE_TYPES) || 0) + 1);
                }
            }
            var embedLevels = new Uint8Array(string.length);
            var isolationPairs = new Map(); //init->pdi and pdi->init
            // === 3.3.1 The Paragraph Level ===
            // 3.3.1 P1: Split the text into paragraphs
            var paragraphs = []; // [{start, end, level}, ...]
            var paragraph = null;
            for(var i$1 = 0; i$1 < string.length; i$1++){
                if (!paragraph) {
                    paragraphs.push(paragraph = {
                        start: i$1,
                        end: string.length - 1,
                        // 3.3.1 P2-P3: Determine the paragraph level
                        level: baseDirection === 'rtl' ? 1 : baseDirection === 'ltr' ? 0 : determineAutoEmbedLevel(i$1, false)
                    });
                }
                if (charTypes[i$1] & TYPE_B) {
                    paragraph.end = i$1;
                    paragraph = null;
                }
            }
            var FORMATTING_TYPES = TYPE_RLE | TYPE_LRE | TYPE_RLO | TYPE_LRO | ISOLATE_INIT_TYPES | TYPE_PDI | TYPE_PDF | TYPE_B;
            var nextEven = function(n) {
                return n + (n & 1 ? 1 : 2);
            };
            var nextOdd = function(n) {
                return n + (n & 1 ? 2 : 1);
            };
            // Everything from here on will operate per paragraph.
            for(var paraIdx = 0; paraIdx < paragraphs.length; paraIdx++){
                paragraph = paragraphs[paraIdx];
                var statusStack = [
                    {
                        _level: paragraph.level,
                        _override: 0,
                        _isolate: 0 //bool
                    }
                ];
                var stackTop = void 0;
                var overflowIsolateCount = 0;
                var overflowEmbeddingCount = 0;
                var validIsolateCount = 0;
                charTypeCounts.clear();
                // === 3.3.2 Explicit Levels and Directions ===
                for(var i$2 = paragraph.start; i$2 <= paragraph.end; i$2++){
                    var charType = charTypes[i$2];
                    stackTop = statusStack[statusStack.length - 1];
                    // Set initial counts
                    charTypeCounts.set(charType, (charTypeCounts.get(charType) || 0) + 1);
                    if (charType & NEUTRAL_ISOLATE_TYPES) {
                        charTypeCounts.set(NEUTRAL_ISOLATE_TYPES, (charTypeCounts.get(NEUTRAL_ISOLATE_TYPES) || 0) + 1);
                    }
                    // Explicit Embeddings: 3.3.2 X2 - X3
                    if (charType & FORMATTING_TYPES) {
                        if (charType & (TYPE_RLE | TYPE_LRE)) {
                            embedLevels[i$2] = stackTop._level; // 5.2
                            var level = (charType === TYPE_RLE ? nextOdd : nextEven)(stackTop._level);
                            if (level <= MAX_DEPTH && !overflowIsolateCount && !overflowEmbeddingCount) {
                                statusStack.push({
                                    _level: level,
                                    _override: 0,
                                    _isolate: 0
                                });
                            } else if (!overflowIsolateCount) {
                                overflowEmbeddingCount++;
                            }
                        } else if (charType & (TYPE_RLO | TYPE_LRO)) {
                            embedLevels[i$2] = stackTop._level; // 5.2
                            var level$1 = (charType === TYPE_RLO ? nextOdd : nextEven)(stackTop._level);
                            if (level$1 <= MAX_DEPTH && !overflowIsolateCount && !overflowEmbeddingCount) {
                                statusStack.push({
                                    _level: level$1,
                                    _override: charType & TYPE_RLO ? TYPE_R : TYPE_L,
                                    _isolate: 0
                                });
                            } else if (!overflowIsolateCount) {
                                overflowEmbeddingCount++;
                            }
                        } else if (charType & ISOLATE_INIT_TYPES) {
                            // X5c - FSI becomes either RLI or LRI
                            if (charType & TYPE_FSI) {
                                charType = determineAutoEmbedLevel(i$2 + 1, true) === 1 ? TYPE_RLI : TYPE_LRI;
                            }
                            embedLevels[i$2] = stackTop._level;
                            if (stackTop._override) {
                                changeCharType(i$2, stackTop._override);
                            }
                            var level$2 = (charType === TYPE_RLI ? nextOdd : nextEven)(stackTop._level);
                            if (level$2 <= MAX_DEPTH && overflowIsolateCount === 0 && overflowEmbeddingCount === 0) {
                                validIsolateCount++;
                                statusStack.push({
                                    _level: level$2,
                                    _override: 0,
                                    _isolate: 1,
                                    _isolInitIndex: i$2
                                });
                            } else {
                                overflowIsolateCount++;
                            }
                        } else if (charType & TYPE_PDI) {
                            if (overflowIsolateCount > 0) {
                                overflowIsolateCount--;
                            } else if (validIsolateCount > 0) {
                                overflowEmbeddingCount = 0;
                                while(!statusStack[statusStack.length - 1]._isolate){
                                    statusStack.pop();
                                }
                                // Add to isolation pairs bidirectional mapping:
                                var isolInitIndex = statusStack[statusStack.length - 1]._isolInitIndex;
                                if (isolInitIndex != null) {
                                    isolationPairs.set(isolInitIndex, i$2);
                                    isolationPairs.set(i$2, isolInitIndex);
                                }
                                statusStack.pop();
                                validIsolateCount--;
                            }
                            stackTop = statusStack[statusStack.length - 1];
                            embedLevels[i$2] = stackTop._level;
                            if (stackTop._override) {
                                changeCharType(i$2, stackTop._override);
                            }
                        } else if (charType & TYPE_PDF) {
                            if (overflowIsolateCount === 0) {
                                if (overflowEmbeddingCount > 0) {
                                    overflowEmbeddingCount--;
                                } else if (!stackTop._isolate && statusStack.length > 1) {
                                    statusStack.pop();
                                    stackTop = statusStack[statusStack.length - 1];
                                }
                            }
                            embedLevels[i$2] = stackTop._level; // 5.2
                        } else if (charType & TYPE_B) {
                            embedLevels[i$2] = paragraph.level;
                        }
                    } else {
                        embedLevels[i$2] = stackTop._level;
                        // NOTE: This exclusion of BN seems to go against what section 5.2 says, but is required for test passage
                        if (stackTop._override && charType !== TYPE_BN) {
                            changeCharType(i$2, stackTop._override);
                        }
                    }
                }
                // === 3.3.3 Preparations for Implicit Processing ===
                // Remove all RLE, LRE, RLO, LRO, PDF, and BN characters: 3.3.3 X9
                // Note: Due to section 5.2, we won't remove them, but we'll use the BN_LIKE_TYPES bitset to
                // easily ignore them all from here on out.
                // 3.3.3 X10
                // Compute the set of isolating run sequences as specified by BD13
                var levelRuns = [];
                var currentRun = null;
                for(var i$3 = paragraph.start; i$3 <= paragraph.end; i$3++){
                    var charType$1 = charTypes[i$3];
                    if (!(charType$1 & BN_LIKE_TYPES)) {
                        var lvl = embedLevels[i$3];
                        var isIsolInit = charType$1 & ISOLATE_INIT_TYPES;
                        var isPDI = charType$1 === TYPE_PDI;
                        if (currentRun && lvl === currentRun._level) {
                            currentRun._end = i$3;
                            currentRun._endsWithIsolInit = isIsolInit;
                        } else {
                            levelRuns.push(currentRun = {
                                _start: i$3,
                                _end: i$3,
                                _level: lvl,
                                _startsWithPDI: isPDI,
                                _endsWithIsolInit: isIsolInit
                            });
                        }
                    }
                }
                var isolatingRunSeqs = []; // [{seqIndices: [], sosType: L|R, eosType: L|R}]
                for(var runIdx = 0; runIdx < levelRuns.length; runIdx++){
                    var run = levelRuns[runIdx];
                    if (!run._startsWithPDI || run._startsWithPDI && !isolationPairs.has(run._start)) {
                        var seqRuns = [
                            currentRun = run
                        ];
                        for(var pdiIndex = void 0; currentRun && currentRun._endsWithIsolInit && (pdiIndex = isolationPairs.get(currentRun._end)) != null;){
                            for(var i$4 = runIdx + 1; i$4 < levelRuns.length; i$4++){
                                if (levelRuns[i$4]._start === pdiIndex) {
                                    seqRuns.push(currentRun = levelRuns[i$4]);
                                    break;
                                }
                            }
                        }
                        // build flat list of indices across all runs:
                        var seqIndices = [];
                        for(var i$5 = 0; i$5 < seqRuns.length; i$5++){
                            var run$1 = seqRuns[i$5];
                            for(var j = run$1._start; j <= run$1._end; j++){
                                seqIndices.push(j);
                            }
                        }
                        // determine the sos/eos types:
                        var firstLevel = embedLevels[seqIndices[0]];
                        var prevLevel = paragraph.level;
                        for(var i$6 = seqIndices[0] - 1; i$6 >= 0; i$6--){
                            if (!(charTypes[i$6] & BN_LIKE_TYPES)) {
                                prevLevel = embedLevels[i$6];
                                break;
                            }
                        }
                        var lastIndex = seqIndices[seqIndices.length - 1];
                        var lastLevel = embedLevels[lastIndex];
                        var nextLevel = paragraph.level;
                        if (!(charTypes[lastIndex] & ISOLATE_INIT_TYPES)) {
                            for(var i$7 = lastIndex + 1; i$7 <= paragraph.end; i$7++){
                                if (!(charTypes[i$7] & BN_LIKE_TYPES)) {
                                    nextLevel = embedLevels[i$7];
                                    break;
                                }
                            }
                        }
                        isolatingRunSeqs.push({
                            _seqIndices: seqIndices,
                            _sosType: Math.max(prevLevel, firstLevel) % 2 ? TYPE_R : TYPE_L,
                            _eosType: Math.max(nextLevel, lastLevel) % 2 ? TYPE_R : TYPE_L
                        });
                    }
                }
                // The next steps are done per isolating run sequence
                for(var seqIdx = 0; seqIdx < isolatingRunSeqs.length; seqIdx++){
                    var ref = isolatingRunSeqs[seqIdx];
                    var seqIndices$1 = ref._seqIndices;
                    var sosType = ref._sosType;
                    var eosType = ref._eosType;
                    /**
         * All the level runs in an isolating run sequence have the same embedding level.
         * 
         * DO NOT change any `embedLevels[i]` within the current scope.
         */ var embedDirection = embedLevels[seqIndices$1[0]] & 1 ? TYPE_R : TYPE_L;
                    // === 3.3.4 Resolving Weak Types ===
                    // W1 + 5.2. Search backward from each NSM to the first character in the isolating run sequence whose
                    // bidirectional type is not BN, and set the NSM to ON if it is an isolate initiator or PDI, and to its
                    // type otherwise. If the NSM is the first non-BN character, change the NSM to the type of sos.
                    if (charTypeCounts.get(TYPE_NSM)) {
                        for(var si = 0; si < seqIndices$1.length; si++){
                            var i$8 = seqIndices$1[si];
                            if (charTypes[i$8] & TYPE_NSM) {
                                var prevType = sosType;
                                for(var sj = si - 1; sj >= 0; sj--){
                                    if (!(charTypes[seqIndices$1[sj]] & BN_LIKE_TYPES)) {
                                        prevType = charTypes[seqIndices$1[sj]];
                                        break;
                                    }
                                }
                                changeCharType(i$8, prevType & (ISOLATE_INIT_TYPES | TYPE_PDI) ? TYPE_ON : prevType);
                            }
                        }
                    }
                    // W2. Search backward from each instance of a European number until the first strong type (R, L, AL, or sos)
                    // is found. If an AL is found, change the type of the European number to Arabic number.
                    if (charTypeCounts.get(TYPE_EN)) {
                        for(var si$1 = 0; si$1 < seqIndices$1.length; si$1++){
                            var i$9 = seqIndices$1[si$1];
                            if (charTypes[i$9] & TYPE_EN) {
                                for(var sj$1 = si$1 - 1; sj$1 >= -1; sj$1--){
                                    var prevCharType = sj$1 === -1 ? sosType : charTypes[seqIndices$1[sj$1]];
                                    if (prevCharType & STRONG_TYPES) {
                                        if (prevCharType === TYPE_AL) {
                                            changeCharType(i$9, TYPE_AN);
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    // W3. Change all ALs to R
                    if (charTypeCounts.get(TYPE_AL)) {
                        for(var si$2 = 0; si$2 < seqIndices$1.length; si$2++){
                            var i$10 = seqIndices$1[si$2];
                            if (charTypes[i$10] & TYPE_AL) {
                                changeCharType(i$10, TYPE_R);
                            }
                        }
                    }
                    // W4. A single European separator between two European numbers changes to a European number. A single common
                    // separator between two numbers of the same type changes to that type.
                    if (charTypeCounts.get(TYPE_ES) || charTypeCounts.get(TYPE_CS)) {
                        for(var si$3 = 1; si$3 < seqIndices$1.length - 1; si$3++){
                            var i$11 = seqIndices$1[si$3];
                            if (charTypes[i$11] & (TYPE_ES | TYPE_CS)) {
                                var prevType$1 = 0, nextType = 0;
                                for(var sj$2 = si$3 - 1; sj$2 >= 0; sj$2--){
                                    prevType$1 = charTypes[seqIndices$1[sj$2]];
                                    if (!(prevType$1 & BN_LIKE_TYPES)) {
                                        break;
                                    }
                                }
                                for(var sj$3 = si$3 + 1; sj$3 < seqIndices$1.length; sj$3++){
                                    nextType = charTypes[seqIndices$1[sj$3]];
                                    if (!(nextType & BN_LIKE_TYPES)) {
                                        break;
                                    }
                                }
                                if (prevType$1 === nextType && (charTypes[i$11] === TYPE_ES ? prevType$1 === TYPE_EN : prevType$1 & (TYPE_EN | TYPE_AN))) {
                                    changeCharType(i$11, prevType$1);
                                }
                            }
                        }
                    }
                    // W5. A sequence of European terminators adjacent to European numbers changes to all European numbers.
                    if (charTypeCounts.get(TYPE_EN)) {
                        for(var si$4 = 0; si$4 < seqIndices$1.length; si$4++){
                            var i$12 = seqIndices$1[si$4];
                            if (charTypes[i$12] & TYPE_EN) {
                                for(var sj$4 = si$4 - 1; sj$4 >= 0 && charTypes[seqIndices$1[sj$4]] & (TYPE_ET | BN_LIKE_TYPES); sj$4--){
                                    changeCharType(seqIndices$1[sj$4], TYPE_EN);
                                }
                                for(si$4++; si$4 < seqIndices$1.length && charTypes[seqIndices$1[si$4]] & (TYPE_ET | BN_LIKE_TYPES | TYPE_EN); si$4++){
                                    if (charTypes[seqIndices$1[si$4]] !== TYPE_EN) {
                                        changeCharType(seqIndices$1[si$4], TYPE_EN);
                                    }
                                }
                            }
                        }
                    }
                    // W6. Otherwise, separators and terminators change to Other Neutral.
                    if (charTypeCounts.get(TYPE_ET) || charTypeCounts.get(TYPE_ES) || charTypeCounts.get(TYPE_CS)) {
                        for(var si$5 = 0; si$5 < seqIndices$1.length; si$5++){
                            var i$13 = seqIndices$1[si$5];
                            if (charTypes[i$13] & (TYPE_ET | TYPE_ES | TYPE_CS)) {
                                changeCharType(i$13, TYPE_ON);
                                // 5.2 transform adjacent BNs too:
                                for(var sj$5 = si$5 - 1; sj$5 >= 0 && charTypes[seqIndices$1[sj$5]] & BN_LIKE_TYPES; sj$5--){
                                    changeCharType(seqIndices$1[sj$5], TYPE_ON);
                                }
                                for(var sj$6 = si$5 + 1; sj$6 < seqIndices$1.length && charTypes[seqIndices$1[sj$6]] & BN_LIKE_TYPES; sj$6++){
                                    changeCharType(seqIndices$1[sj$6], TYPE_ON);
                                }
                            }
                        }
                    }
                    // W7. Search backward from each instance of a European number until the first strong type (R, L, or sos)
                    // is found. If an L is found, then change the type of the European number to L.
                    // NOTE: implemented in single forward pass for efficiency
                    if (charTypeCounts.get(TYPE_EN)) {
                        for(var si$6 = 0, prevStrongType = sosType; si$6 < seqIndices$1.length; si$6++){
                            var i$14 = seqIndices$1[si$6];
                            var type = charTypes[i$14];
                            if (type & TYPE_EN) {
                                if (prevStrongType === TYPE_L) {
                                    changeCharType(i$14, TYPE_L);
                                }
                            } else if (type & STRONG_TYPES) {
                                prevStrongType = type;
                            }
                        }
                    }
                    // === 3.3.5 Resolving Neutral and Isolate Formatting Types ===
                    if (charTypeCounts.get(NEUTRAL_ISOLATE_TYPES)) {
                        // N0. Process bracket pairs in an isolating run sequence sequentially in the logical order of the text
                        // positions of the opening paired brackets using the logic given below. Within this scope, bidirectional
                        // types EN and AN are treated as R.
                        var R_TYPES_FOR_N_STEPS = TYPE_R | TYPE_EN | TYPE_AN;
                        var STRONG_TYPES_FOR_N_STEPS = R_TYPES_FOR_N_STEPS | TYPE_L;
                        // * Identify the bracket pairs in the current isolating run sequence according to BD16.
                        var bracketPairs = [];
                        {
                            var openerStack = [];
                            for(var si$7 = 0; si$7 < seqIndices$1.length; si$7++){
                                // NOTE: for any potential bracket character we also test that it still carries a NI
                                // type, as that may have been changed earlier. This doesn't seem to be explicitly
                                // called out in the spec, but is required for passage of certain tests.
                                if (charTypes[seqIndices$1[si$7]] & NEUTRAL_ISOLATE_TYPES) {
                                    var char = string[seqIndices$1[si$7]];
                                    var oppositeBracket = void 0;
                                    // Opening bracket
                                    if (openingToClosingBracket(char) !== null) {
                                        if (openerStack.length < 63) {
                                            openerStack.push({
                                                char: char,
                                                seqIndex: si$7
                                            });
                                        } else {
                                            break;
                                        }
                                    } else if ((oppositeBracket = closingToOpeningBracket(char)) !== null) {
                                        for(var stackIdx = openerStack.length - 1; stackIdx >= 0; stackIdx--){
                                            var stackChar = openerStack[stackIdx].char;
                                            if (stackChar === oppositeBracket || stackChar === closingToOpeningBracket(getCanonicalBracket(char)) || openingToClosingBracket(getCanonicalBracket(stackChar)) === char) {
                                                bracketPairs.push([
                                                    openerStack[stackIdx].seqIndex,
                                                    si$7
                                                ]);
                                                openerStack.length = stackIdx; //pop the matching bracket and all following
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            bracketPairs.sort(function(a, b) {
                                return a[0] - b[0];
                            });
                        }
                        // * For each bracket-pair element in the list of pairs of text positions
                        for(var pairIdx = 0; pairIdx < bracketPairs.length; pairIdx++){
                            var ref$1 = bracketPairs[pairIdx];
                            var openSeqIdx = ref$1[0];
                            var closeSeqIdx = ref$1[1];
                            // a. Inspect the bidirectional types of the characters enclosed within the bracket pair.
                            // b. If any strong type (either L or R) matching the embedding direction is found, set the type for both
                            // brackets in the pair to match the embedding direction.
                            var foundStrongType = false;
                            var useStrongType = 0;
                            for(var si$8 = openSeqIdx + 1; si$8 < closeSeqIdx; si$8++){
                                var i$15 = seqIndices$1[si$8];
                                if (charTypes[i$15] & STRONG_TYPES_FOR_N_STEPS) {
                                    foundStrongType = true;
                                    var lr = charTypes[i$15] & R_TYPES_FOR_N_STEPS ? TYPE_R : TYPE_L;
                                    if (lr === embedDirection) {
                                        useStrongType = lr;
                                        break;
                                    }
                                }
                            }
                            // c. Otherwise, if there is a strong type it must be opposite the embedding direction. Therefore, test
                            // for an established context with a preceding strong type by checking backwards before the opening paired
                            // bracket until the first strong type (L, R, or sos) is found.
                            //    1. If the preceding strong type is also opposite the embedding direction, context is established, so
                            //    set the type for both brackets in the pair to that direction.
                            //    2. Otherwise set the type for both brackets in the pair to the embedding direction.
                            if (foundStrongType && !useStrongType) {
                                useStrongType = sosType;
                                for(var si$9 = openSeqIdx - 1; si$9 >= 0; si$9--){
                                    var i$16 = seqIndices$1[si$9];
                                    if (charTypes[i$16] & STRONG_TYPES_FOR_N_STEPS) {
                                        var lr$1 = charTypes[i$16] & R_TYPES_FOR_N_STEPS ? TYPE_R : TYPE_L;
                                        if (lr$1 !== embedDirection) {
                                            useStrongType = lr$1;
                                        } else {
                                            useStrongType = embedDirection;
                                        }
                                        break;
                                    }
                                }
                            }
                            if (useStrongType) {
                                charTypes[seqIndices$1[openSeqIdx]] = charTypes[seqIndices$1[closeSeqIdx]] = useStrongType;
                                // * Any number of characters that had original bidirectional character type NSM prior to the application
                                // of W1 that immediately follow a paired bracket which changed to L or R under N0 should change to match
                                // the type of their preceding bracket.
                                if (useStrongType !== embedDirection) {
                                    for(var si$10 = openSeqIdx + 1; si$10 < seqIndices$1.length; si$10++){
                                        if (!(charTypes[seqIndices$1[si$10]] & BN_LIKE_TYPES)) {
                                            if (getBidiCharType(string[seqIndices$1[si$10]]) & TYPE_NSM) {
                                                charTypes[seqIndices$1[si$10]] = useStrongType;
                                            }
                                            break;
                                        }
                                    }
                                }
                                if (useStrongType !== embedDirection) {
                                    for(var si$11 = closeSeqIdx + 1; si$11 < seqIndices$1.length; si$11++){
                                        if (!(charTypes[seqIndices$1[si$11]] & BN_LIKE_TYPES)) {
                                            if (getBidiCharType(string[seqIndices$1[si$11]]) & TYPE_NSM) {
                                                charTypes[seqIndices$1[si$11]] = useStrongType;
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        // N1. A sequence of NIs takes the direction of the surrounding strong text if the text on both sides has the
                        // same direction.
                        // N2. Any remaining NIs take the embedding direction.
                        for(var si$12 = 0; si$12 < seqIndices$1.length; si$12++){
                            if (charTypes[seqIndices$1[si$12]] & NEUTRAL_ISOLATE_TYPES) {
                                var niRunStart = si$12, niRunEnd = si$12;
                                var prevType$2 = sosType; //si === 0 ? sosType : (charTypes[seqIndices[si - 1]] & R_TYPES_FOR_N_STEPS) ? TYPE_R : TYPE_L
                                for(var si2 = si$12 - 1; si2 >= 0; si2--){
                                    if (charTypes[seqIndices$1[si2]] & BN_LIKE_TYPES) {
                                        niRunStart = si2; //5.2 treat BNs adjacent to NIs as NIs
                                    } else {
                                        prevType$2 = charTypes[seqIndices$1[si2]] & R_TYPES_FOR_N_STEPS ? TYPE_R : TYPE_L;
                                        break;
                                    }
                                }
                                var nextType$1 = eosType;
                                for(var si2$1 = si$12 + 1; si2$1 < seqIndices$1.length; si2$1++){
                                    if (charTypes[seqIndices$1[si2$1]] & (NEUTRAL_ISOLATE_TYPES | BN_LIKE_TYPES)) {
                                        niRunEnd = si2$1;
                                    } else {
                                        nextType$1 = charTypes[seqIndices$1[si2$1]] & R_TYPES_FOR_N_STEPS ? TYPE_R : TYPE_L;
                                        break;
                                    }
                                }
                                for(var sj$7 = niRunStart; sj$7 <= niRunEnd; sj$7++){
                                    charTypes[seqIndices$1[sj$7]] = prevType$2 === nextType$1 ? prevType$2 : embedDirection;
                                }
                                si$12 = niRunEnd;
                            }
                        }
                    }
                }
                // === 3.3.6 Resolving Implicit Levels ===
                for(var i$17 = paragraph.start; i$17 <= paragraph.end; i$17++){
                    var level$3 = embedLevels[i$17];
                    var type$1 = charTypes[i$17];
                    // I2. For all characters with an odd (right-to-left) embedding level, those of type L, EN or AN go up one level.
                    if (level$3 & 1) {
                        if (type$1 & (TYPE_L | TYPE_EN | TYPE_AN)) {
                            embedLevels[i$17]++;
                        }
                    } else {
                        if (type$1 & TYPE_R) {
                            embedLevels[i$17]++;
                        } else if (type$1 & (TYPE_AN | TYPE_EN)) {
                            embedLevels[i$17] += 2;
                        }
                    }
                    // 5.2: Resolve any LRE, RLE, LRO, RLO, PDF, or BN to the level of the preceding character if there is one,
                    // and otherwise to the base level.
                    if (type$1 & BN_LIKE_TYPES) {
                        embedLevels[i$17] = i$17 === 0 ? paragraph.level : embedLevels[i$17 - 1];
                    }
                    // 3.4 L1.1-4: Reset the embedding level of segment/paragraph separators, and any sequence of whitespace or
                    // isolate formatting characters preceding them or the end of the paragraph, to the paragraph level.
                    // NOTE: this will also need to be applied to each individual line ending after line wrapping occurs.
                    if (i$17 === paragraph.end || getBidiCharType(string[i$17]) & (TYPE_S | TYPE_B)) {
                        for(var j$1 = i$17; j$1 >= 0 && getBidiCharType(string[j$1]) & TRAILING_TYPES; j$1--){
                            embedLevels[j$1] = paragraph.level;
                        }
                    }
                }
            }
            // DONE! The resolved levels can then be used, after line wrapping, to flip runs of characters
            // according to section 3.4 Reordering Resolved Levels
            return {
                levels: embedLevels,
                paragraphs: paragraphs
            };
            //TURBOPACK unreachable
            ;
            function determineAutoEmbedLevel(start, isFSI) {
                // 3.3.1 P2 - P3
                for(var i = start; i < string.length; i++){
                    var charType = charTypes[i];
                    if (charType & (TYPE_R | TYPE_AL)) {
                        return 1;
                    }
                    if (charType & (TYPE_B | TYPE_L) || isFSI && charType === TYPE_PDI) {
                        return 0;
                    }
                    if (charType & ISOLATE_INIT_TYPES) {
                        var pdi = indexOfMatchingPDI(i);
                        i = pdi === -1 ? string.length : pdi;
                    }
                }
                return 0;
            }
            function indexOfMatchingPDI(isolateStart) {
                // 3.1.2 BD9
                var isolationLevel = 1;
                for(var i = isolateStart + 1; i < string.length; i++){
                    var charType = charTypes[i];
                    if (charType & TYPE_B) {
                        break;
                    }
                    if (charType & TYPE_PDI) {
                        if (--isolationLevel === 0) {
                            return i;
                        }
                    } else if (charType & ISOLATE_INIT_TYPES) {
                        isolationLevel++;
                    }
                }
                return -1;
            }
        }
        // Bidi mirrored chars data, auto generated
        var data = "14>1,j>2,t>2,u>2,1a>g,2v3>1,1>1,1ge>1,1wd>1,b>1,1j>1,f>1,ai>3,-2>3,+1,8>1k0,-1jq>1y7,-1y6>1hf,-1he>1h6,-1h5>1ha,-1h8>1qi,-1pu>1,6>3u,-3s>7,6>1,1>1,f>1,1>1,+2,3>1,1>1,+13,4>1,1>1,6>1eo,-1ee>1,3>1mg,-1me>1mk,-1mj>1mi,-1mg>1mi,-1md>1,1>1,+2,1>10k,-103>1,1>1,4>1,5>1,1>1,+10,3>1,1>8,-7>8,+1,-6>7,+1,a>1,1>1,u>1,u6>1,1>1,+5,26>1,1>1,2>1,2>2,8>1,7>1,4>1,1>1,+5,b8>1,1>1,+3,1>3,-2>1,2>1,1>1,+2,c>1,3>1,1>1,+2,h>1,3>1,a>1,1>1,2>1,3>1,1>1,d>1,f>1,3>1,1a>1,1>1,6>1,7>1,13>1,k>1,1>1,+19,4>1,1>1,+2,2>1,1>1,+18,m>1,a>1,1>1,lk>1,1>1,4>1,2>1,f>1,3>1,1>1,+3,db>1,1>1,+3,3>1,1>1,+2,14qm>1,1>1,+1,6>1,4j>1,j>2,t>2,u>2,2>1,+1";
        var mirrorMap;
        function parse() {
            if (!mirrorMap) {
                //const start = performance.now()
                var ref = parseCharacterMap(data, true);
                var map = ref.map;
                var reverseMap = ref.reverseMap;
                // Combine both maps into one
                reverseMap.forEach(function(value, key) {
                    map.set(key, value);
                });
                mirrorMap = map;
            //console.log(`mirrored chars parsed in ${performance.now() - start}ms`)
            }
        }
        function getMirroredCharacter(char) {
            parse();
            return mirrorMap.get(char) || null;
        }
        /**
   * Given a string and its resolved embedding levels, build a map of indices to replacement chars
   * for any characters in right-to-left segments that have defined mirrored characters.
   * @param string
   * @param embeddingLevels
   * @param [start]
   * @param [end]
   * @return {Map<number, string>}
   */ function getMirroredCharactersMap(string, embeddingLevels, start, end) {
            var strLen = string.length;
            start = Math.max(0, start == null ? 0 : +start);
            end = Math.min(strLen - 1, end == null ? strLen - 1 : +end);
            var map = new Map();
            for(var i = start; i <= end; i++){
                if (embeddingLevels[i] & 1) {
                    var mirror = getMirroredCharacter(string[i]);
                    if (mirror !== null) {
                        map.set(i, mirror);
                    }
                }
            }
            return map;
        }
        /**
   * Given a start and end denoting a single line within a string, and a set of precalculated
   * bidi embedding levels, produce a list of segments whose ordering should be flipped, in sequence.
   * @param {string} string - the full input string
   * @param {GetEmbeddingLevelsResult} embeddingLevelsResult - the result object from getEmbeddingLevels
   * @param {number} [start] - first character in a subset of the full string
   * @param {number} [end] - last character in a subset of the full string
   * @return {number[][]} - the list of start/end segments that should be flipped, in order.
   */ function getReorderSegments(string, embeddingLevelsResult, start, end) {
            var strLen = string.length;
            start = Math.max(0, start == null ? 0 : +start);
            end = Math.min(strLen - 1, end == null ? strLen - 1 : +end);
            var segments = [];
            embeddingLevelsResult.paragraphs.forEach(function(paragraph) {
                var lineStart = Math.max(start, paragraph.start);
                var lineEnd = Math.min(end, paragraph.end);
                if (lineStart < lineEnd) {
                    // Local slice for mutation
                    var lineLevels = embeddingLevelsResult.levels.slice(lineStart, lineEnd + 1);
                    // 3.4 L1.4: Reset any sequence of whitespace characters and/or isolate formatting characters at the
                    // end of the line to the paragraph level.
                    for(var i = lineEnd; i >= lineStart && getBidiCharType(string[i]) & TRAILING_TYPES; i--){
                        lineLevels[i] = paragraph.level;
                    }
                    // L2. From the highest level found in the text to the lowest odd level on each line, including intermediate levels
                    // not actually present in the text, reverse any contiguous sequence of characters that are at that level or higher.
                    var maxLevel = paragraph.level;
                    var minOddLevel = Infinity;
                    for(var i$1 = 0; i$1 < lineLevels.length; i$1++){
                        var level = lineLevels[i$1];
                        if (level > maxLevel) {
                            maxLevel = level;
                        }
                        if (level < minOddLevel) {
                            minOddLevel = level | 1;
                        }
                    }
                    for(var lvl = maxLevel; lvl >= minOddLevel; lvl--){
                        for(var i$2 = 0; i$2 < lineLevels.length; i$2++){
                            if (lineLevels[i$2] >= lvl) {
                                var segStart = i$2;
                                while(i$2 + 1 < lineLevels.length && lineLevels[i$2 + 1] >= lvl){
                                    i$2++;
                                }
                                if (i$2 > segStart) {
                                    segments.push([
                                        segStart + lineStart,
                                        i$2 + lineStart
                                    ]);
                                }
                            }
                        }
                    }
                }
            });
            return segments;
        }
        /**
   * @param {string} string
   * @param {GetEmbeddingLevelsResult} embedLevelsResult
   * @param {number} [start]
   * @param {number} [end]
   * @return {string} the new string with bidi segments reordered
   */ function getReorderedString(string, embedLevelsResult, start, end) {
            var indices = getReorderedIndices(string, embedLevelsResult, start, end);
            var chars = [].concat(string);
            indices.forEach(function(charIndex, i) {
                chars[i] = (embedLevelsResult.levels[charIndex] & 1 ? getMirroredCharacter(string[charIndex]) : null) || string[charIndex];
            });
            return chars.join('');
        }
        /**
   * @param {string} string
   * @param {GetEmbeddingLevelsResult} embedLevelsResult
   * @param {number} [start]
   * @param {number} [end]
   * @return {number[]} an array with character indices in their new bidi order
   */ function getReorderedIndices(string, embedLevelsResult, start, end) {
            var segments = getReorderSegments(string, embedLevelsResult, start, end);
            // Fill an array with indices
            var indices = [];
            for(var i = 0; i < string.length; i++){
                indices[i] = i;
            }
            // Reverse each segment in order
            segments.forEach(function(ref) {
                var start = ref[0];
                var end = ref[1];
                var slice = indices.slice(start, end + 1);
                for(var i = slice.length; i--;){
                    indices[end - i] = slice[i];
                }
            });
            return indices;
        }
        exports.closingToOpeningBracket = closingToOpeningBracket;
        exports.getBidiCharType = getBidiCharType;
        exports.getBidiCharTypeName = getBidiCharTypeName;
        exports.getCanonicalBracket = getCanonicalBracket;
        exports.getEmbeddingLevels = getEmbeddingLevels;
        exports.getMirroredCharacter = getMirroredCharacter;
        exports.getMirroredCharactersMap = getMirroredCharactersMap;
        exports.getReorderSegments = getReorderSegments;
        exports.getReorderedIndices = getReorderedIndices;
        exports.getReorderedString = getReorderedString;
        exports.openingToClosingBracket = openingToClosingBracket;
        Object.defineProperty(exports, '__esModule', {
            value: true
        });
        return exports;
    }({});
    return bidi;
}
const __TURBOPACK__default__export__ = bidiFactory;
}),
"[project]/node_modules/hyphen/hyphen.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

/** Text hyphenation in Javascript.
 *  Copyright (C) 2024 Yevhen Tiurin (yevhentiurin@gmail.com)
 *  https://github.com/ytiurin/hyphen
 *
 *  Released under the ISC license
 *  https://github.com/ytiurin/hyphen/blob/master/LICENSE
 */ (function(root, factory) {
    if (typeof define === "function" && define.amd) {
        // AMD. Register as an anonymous module.
        ((r)=>r !== undefined && __turbopack_context__.v(r))(factory());
    } else if (("TURBOPACK compile-time value", "object") === "object" && module.exports) {
        // Node. Does not work with strict CommonJS, but
        // only CommonJS-like environments that support module.exports,
        // like Node.
        module.exports = factory();
    } else {
        // Browser globals (root is window)
        root.createHyphenator = factory();
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, function() {
    function createTextReader(setup) {
        var char1 = "";
        var char2 = "";
        var i = 0;
        var verifier = setup();
        return function(text) {
            while(i < text.length){
                char1 = text.charAt(i++);
                char2 = text.charAt(i);
                var verified = verifier(char1, char2);
                if (verified !== void 0) {
                    return verified;
                }
            }
        };
    }
    var isNotLetter = RegExp.prototype.test.bind(/\s|(?![\'])[\!-\@\[-\`\{-\~\u2013-\u203C]/);
    function createHTMLVerifier() {
        var skip = false;
        return function(accumulate, chars) {
            if (skip) {
                if (chars[0] === ">") {
                    accumulate();
                    skip = false;
                }
            } else if (chars[0] === "<" && (!isNotLetter(chars[1]) || chars[1] === "/")) {
                skip = true;
            }
            return skip;
        };
    }
    function createHyphenCharVerifier(hyphenChar) {
        var skip = false;
        return function(accumulate, chars) {
            if (skip) {
                if (!isNotLetter(chars[0]) && isNotLetter(chars[1])) {
                    accumulate();
                    skip = false;
                }
            } else if (!isNotLetter(chars[0]) && chars[1] === hyphenChar) {
                skip = true;
            }
            return skip;
        };
    }
    function createHyphenationVerifier(verifiers, minWordLength) {
        return function() {
            var accum0 = "";
            var accum = "";
            function accumulate() {
                accum0 += accum;
                accum = "";
            }
            function resolveWith(value) {
                accum0 = "";
                accum = "";
                return value;
            }
            return function(char1, char2) {
                accum += char1;
                var skip = verifiers.reduce(function(skip2, verify) {
                    return skip2 || verify(accumulate, [
                        char1,
                        char2
                    ]);
                }, false);
                if (!skip) {
                    if (isNotLetter(char1) && !isNotLetter(char2)) {
                        accumulate();
                    }
                    if (!isNotLetter(char1) && isNotLetter(char2)) {
                        if (accum.length >= minWordLength) {
                            return resolveWith([
                                accum0,
                                accum
                            ]);
                        } else {
                            accumulate();
                        }
                    }
                }
                if (char2 === "") {
                    if (accum.length < minWordLength || skip) {
                        accumulate();
                    }
                    return resolveWith([
                        accum0,
                        accum
                    ]);
                }
            };
        };
    }
    function createCharIterator(str) {
        var i = 0;
        function nextChar() {
            return str[i++];
        }
        return nextChar;
    }
    function createStringSlicer(str) {
        var i = 0, slice = str;
        function next() {
            slice = str.slice(i++);
            if (slice.length < 3) {
                return;
            }
            return slice;
        }
        function isFirstCharacter() {
            return i === 2;
        }
        return [
            next,
            isFirstCharacter
        ];
    }
    function hyphenateWord(text, levelsTable, patternTrie, debug, hyphenChar) {
        var levels = new Array(text.length + 1), loweredText = ("." + text.toLocaleLowerCase() + ".").split(""), wordSlice, letter, triePtr, trieNode, patternLevelsIndex, patternLevels, patternEntityIndex = -1, slicer, nextSlice, isFirstCharacter, nextLetter;
        for(var i = levels.length; i--;)levels[i] = 0;
        slicer = createStringSlicer(loweredText);
        nextSlice = slicer[0];
        isFirstCharacter = slicer[1];
        while(wordSlice = nextSlice()){
            patternEntityIndex++;
            if (isFirstCharacter()) {
                patternEntityIndex--;
            }
            triePtr = patternTrie;
            nextLetter = createCharIterator(wordSlice);
            while(letter = nextLetter()){
                if ((trieNode = triePtr[letter]) === void 0) {
                    break;
                }
                triePtr = {};
                patternLevelsIndex = -1;
                switch(Object.prototype.toString.call(trieNode)){
                    case "[object Array]":
                        triePtr = trieNode[0];
                        patternLevelsIndex = trieNode[1];
                        break;
                    case "[object Object]":
                        triePtr = trieNode;
                        break;
                    case "[object Number]":
                        patternLevelsIndex = trieNode;
                        break;
                }
                if (patternLevelsIndex < 0) {
                    continue;
                }
                if (!levelsTable[patternLevelsIndex].splice) {
                    levelsTable[patternLevelsIndex] = levelsTable[patternLevelsIndex].slice("");
                }
                patternLevels = levelsTable[patternLevelsIndex];
                for(var k = 0; k < patternLevels.length; k++)levels[patternEntityIndex + k] = Math.max(patternLevels[k], levels[patternEntityIndex + k]);
            }
        }
        levels[0] = levels[1] = levels[levels.length - 1] = levels[levels.length - 2] = 0;
        var hyphenatedText = "";
        for(var i = 0; i < levels.length; i++){
            hyphenatedText += (levels[i] % 2 === 1 ? hyphenChar : "") + text.charAt(i);
        }
        return hyphenatedText;
    }
    function start(text, levelsTable, patterns, cache, debug, hyphenChar, skipHTML, minWordLength, isAsync) {
        function done() {
            resolveNewText(newText);
        }
        var newText = "", fragments, readText = createTextReader(createHyphenationVerifier((skipHTML ? [
            createHTMLVerifier()
        ] : []).concat(createHyphenCharVerifier(hyphenChar)), minWordLength)), resolveNewText = function() {};
        function nextTick() {
            var loopStart = /* @__PURE__ */ new Date();
            while((!isAsync || /* @__PURE__ */ new Date() - loopStart < 10) && (fragments = readText(text))){
                if (fragments[1]) {
                    var cacheKey = fragments[1].length ? "~" + fragments[1] : "";
                    if (cache[cacheKey] === void 0) {
                        cache[cacheKey] = hyphenateWord(fragments[1], levelsTable, patterns, debug, hyphenChar);
                    }
                    fragments[1] = cache[cacheKey];
                }
                newText += fragments[0] + fragments[1];
            }
            if (!fragments) {
                done();
            } else {
                setTimeout(nextTick);
            }
        }
        if (isAsync) {
            setTimeout(nextTick);
            return new Promise(function(resolve) {
                resolveNewText = resolve;
            });
        } else {
            nextTick();
            return newText;
        }
    }
    var SETTING_DEFAULT_ASYNC = false;
    var SETTING_DEFAULT_DEBUG = false;
    var SETTING_DEFAULT_EXCEPTIONS = [];
    var SETTING_DEFAULT_HTML = true;
    var SETTING_DEFAULT_HYPH_CHAR = "\xAD";
    var SETTING_DEFAULT_MIN_WORD_LENGTH = 5;
    var SETTING_NAME_ASYNC = "async";
    var SETTING_NAME_DEBUG = "debug";
    var SETTING_NAME_EXCEPTIONS = "exceptions";
    var SETTING_NAME_HTML = "html";
    var SETTING_NAME_HYPH_CHAR = "hyphenChar";
    var SETTING_NAME_MIN_WORD_LENGTH = "minWordLength";
    var _global = ("TURBOPACK compile-time truthy", 1) ? /*TURBOPACK member replacement*/ __turbopack_context__.g : "TURBOPACK unreachable";
    function extend(target, source) {
        target = target || {};
        for(var key in source){
            target[key] = source[key];
        }
        return target;
    }
    function validateArray(value) {
        return value instanceof Array;
    }
    function keyOrDefault(object, key, defaultValue, test) {
        if (key in object && (test ? test(object[key]) : true)) {
            return object[key];
        }
        return defaultValue;
    }
    function exceptionsFromDefinition(excetionsList, hyphenChar) {
        return excetionsList.reduce(function(exceptions, exception) {
            exceptions["~" + exception.replace(/\-/g, "")] = exception.replace(/\-/g, hyphenChar);
            return exceptions;
        }, {});
    }
    function createHyphenator(patternsDefinition, options) {
        options = options || {};
        var asyncMode = keyOrDefault(options, SETTING_NAME_ASYNC, SETTING_DEFAULT_ASYNC), caches = {}, debug = keyOrDefault(options, SETTING_NAME_DEBUG, SETTING_DEFAULT_DEBUG), exceptions = {}, hyphenChar = keyOrDefault(options, SETTING_NAME_HYPH_CHAR, SETTING_DEFAULT_HYPH_CHAR), levelsTable = patternsDefinition[0].split(","), patterns = JSON.parse(patternsDefinition[1]), minWordLength = keyOrDefault(options, SETTING_NAME_MIN_WORD_LENGTH, SETTING_DEFAULT_MIN_WORD_LENGTH) >> 0, skipHTML = keyOrDefault(options, SETTING_NAME_HTML, SETTING_DEFAULT_HTML), userExceptions = keyOrDefault(options, SETTING_NAME_EXCEPTIONS, SETTING_DEFAULT_EXCEPTIONS, validateArray);
        var cacheKey = hyphenChar + minWordLength;
        exceptions[cacheKey] = {};
        if (patternsDefinition[2]) {
            exceptions[cacheKey] = exceptionsFromDefinition(patternsDefinition[2], hyphenChar);
        }
        if (userExceptions && userExceptions.length) {
            exceptions[cacheKey] = extend(exceptions[cacheKey], exceptionsFromDefinition(userExceptions, hyphenChar));
        }
        caches[cacheKey] = extend({}, exceptions[cacheKey]);
        if (asyncMode && !("Promise" in _global)) {
            throw new Error("Failed to create hyphenator: Could not find global Promise object, needed for hyphenator to work in async mode");
        }
        return function(text, options2) {
            options2 = options2 || {};
            var localDebug = keyOrDefault(options2, SETTING_NAME_DEBUG, debug), localHyphenChar = keyOrDefault(options2, SETTING_NAME_HYPH_CHAR, hyphenChar), localMinWordLength = keyOrDefault(options2, SETTING_NAME_MIN_WORD_LENGTH, minWordLength) >> 0, localUserExceptions = keyOrDefault(options2, SETTING_NAME_EXCEPTIONS, SETTING_DEFAULT_EXCEPTIONS, validateArray), cacheKey2 = localHyphenChar + localMinWordLength;
            if (!exceptions[cacheKey2] && patternsDefinition[2]) {
                exceptions[cacheKey2] = exceptionsFromDefinition(patternsDefinition[2], localHyphenChar);
                caches[cacheKey2] = extend(caches[cacheKey2], exceptions[cacheKey2]);
            }
            if (localUserExceptions && localUserExceptions.length) {
                exceptions[cacheKey2] = extend(exceptions[cacheKey2], exceptionsFromDefinition(localUserExceptions, localHyphenChar));
                caches[cacheKey2] = extend(caches[cacheKey2], exceptions[cacheKey2]);
            }
            return start(text, levelsTable, patterns, caches[cacheKey2], localDebug, localHyphenChar, skipHTML, localMinWordLength, asyncMode);
        };
    }
    return createHyphenator;
});
}),
"[project]/node_modules/hyphen/patterns/en-us.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {

(function(root, factory) {
    if (typeof define === "function" && define.amd) {
        // AMD. Register as an anonymous module.
        ((r)=>r !== undefined && __turbopack_context__.v(r))(factory());
    } else if (("TURBOPACK compile-time value", "object") === "object" && module.exports) {
        // Node. Does not work with strict CommonJS, but
        // only CommonJS-like environments that support module.exports,
        // like Node.
        module.exports = factory();
    } else {
        // Browser globals (root is window)
        root.hyphenationPatternsEnUs = factory();
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, function() {
    return [
        "0004,004,001,003,005,0005,00005,000005,0002,002,0000005,0003,00003,00505,00034,0001,00055,00004,4,05,0055,04,42,03,02,2,404,3,044,01,0505,55,5,045,041,0033,000004,22,00504,5504,0042,1,21,41,402,405,4004,43,23,000054,303,3005,022,5004,000003,252,45,25,2004,000505,054,403,401,3002,0025,144,432,00054,34,12,234,0022,014,0304,012,143,503,0403,101,052,414,212,011,043,00002,0041,0024,05005,03003,00102,0404,04303,01004,0034,025,0044,00404,00025,0103,042,0205,412,104,54,344,433,5005,253,055,0402,3004,0043,204,505,454,0000004,00303,04004,552,201,4005,0255,52,444,14,44,02004,033,05004,00045,00013,0021,0405,00044,0054,50055,000303,00001,304,0204,11,301,232,122,00305,504,000043,0104,00052,000045,50004,0023,00033,00032,00202,5003,202,0401,0000505,214,102,032,000161,004101,00501,00301,0036,0052,00023,006101,006,00401,000521,0014,0063,00012,000501,000006,000604,000601,005001,005005,0010305,00006,003012,003005,0003011,0061,013,000021,000022,000105,00211,00062,00051,000112,006013,000011,0200306,1021,0050001,003003,2102,305,000015,01030005,000035,001011,00021,16330001,0234,030006,5020001,000001,00016,0031,021,21431,002305,0350014,0000012,000063,00101,106,105,00435,00063,0300061,00041,100306,003602,023,0503,0010011,10003,1005,30011,00031,0001001,0000061,0030003,30305,001201,0301,5000101,500101,00015,000401,000065,000016,0000402,0500002,000205,030201,500301,00014,5001,000002,00030011,01034,0300006,030213,00400304,050001,05003,000311,0634,00061,0006,00000604,00050013,00213,0030001,100003,000033,30002,00003632,0003004,050003,0000021,006303,0000006,00005005,30451,03001,00231,00056,00011,6,001001,00500001,03005,503005,0000010001,1002,003001,001065,300001,32011,32,0000003,0213001,0500053,021005,10001,0000011,0001041,0020016,100032,50011,0606,5002,3001,03002,0015001,0102,00003001,000000033,0000001,300101,300015,0101003,00000101,0100501,0101,0010033,00000362,000014,0005001,031",
        '{".":{"a":{"c":{"h":0},"d":{"d":{"e":{"r":1}}},"f":{"t":2},"l":{"t":3},"m":{"a":{"t":4}},"n":{"c":4,"g":0,"i":{"m":5},"t":[{"e":3,"i":{"s":6}},0]},"r":{"s":4,"t":{"i":{"e":1},"y":1}},"s":{"c":3,"p":2,"s":2,"t":{"e":{"r":7}}},"t":{"o":{"m":6}},"u":{"d":2},"v":{"i":1},"w":{"n":0}},"b":{"a":{"g":1,"n":{"a":4},"s":{"e":0}},"e":{"r":[{"a":4},0],"s":{"m":3,"t":{"o":4}}},"r":{"i":8},"u":{"t":{"t":{"i":0}}}},"c":{"a":{"m":{"p":{"e":0}},"n":{"c":5},"p":{"a":{"b":6}},"r":{"o":{"l":5}},"t":1},"e":{"l":{"a":1}},"h":[{"i":{"l":{"l":{"i":7}}}},1],"i":[{"t":{"r":5}},9],"o":{"e":3,"r":[{"n":{"e":{"r":5}}},1],"n":{"g":{"r":5}}}},"d":{"e":{"m":{"o":{"i":1}},"o":3,"r":{"a":3,"i":[{"v":{"a":4}},3]},"s":{"c":0}},"i":{"c":{"t":{"i":{"o":10}}}},"o":{"t":1},"u":{"c":1,"m":{"b":6}},"r":{"i":{"v":67}}},"e":{"a":{"r":{"t":{"h":7}},"s":{"i":11}},"b":1,"e":{"r":0},"g":9,"l":{"d":4,"e":{"m":3}},"n":{"a":{"m":12},"g":3,"s":3},"q":{"u":{"i":{"t":13}}},"r":{"r":{"i":1}},"s":3,"u":[{"l":{"e":{"r":1}}},3],"y":{"e":5},"t":{"h":{"y":{"l":162}}},"v":[{"e":{"r":{"s":{"i":{"b":158}}}}},9]},"f":{"e":{"s":11},"o":{"r":{"m":{"e":{"r":5}}}}},"g":{"a":[{"s":{"o":{"m":163}}},9],"e":[{"n":{"t":14},"o":{"g":4,"m":{"e":1},"t":164}},9],"i":{"a":4,"b":1},"o":{"r":1}},"h":{"a":{"n":{"d":{"i":6},"k":5}},"e":[{"r":{"o":{"i":6,"e":3}},"s":11,"t":11,"m":{"o":165},"p":{"a":166}},9],"i":{"b":3,"e":{"r":3}},"o":{"n":{"e":{"y":5},"o":11},"v":5}},"i":{"d":{"l":1,"o":{"l":12}},"m":{"m":3,"p":{"i":{"n":4}}},"n":[{"c":{"i":3},"e":8,"k":9,"s":3,"u":{"t":167}},2],"r":{"r":4},"s":{"i":1}},"j":{"u":{"r":3}},"l":{"a":{"c":{"y":1},"m":1,"t":{"e":{"r":5},"h":6}},"e":[{"g":{"e":5},"n":0,"p":5,"v":15,"i":{"c":{"e":{"s":170}}}},9],"i":{"g":[{"a":5},1],"n":9,"o":3,"t":1}},"m":{"a":{"g":{"a":16},"l":{"o":5},"n":{"a":5},"r":{"t":{"i":5}}},"e":[{"r":{"c":11},"t":{"e":{"r":4},"a":{"l":{"a":0}}},"g":{"a":{"l":171}}},9],"i":{"s":[{"t":{"i":6},"e":{"r":{"s":173}}},15],"m":{"i":{"c":172}}},"o":{"n":{"e":11},"r":{"o":3}},"u":{"t":{"a":[{"b":6},4]}}},"n":{"i":{"c":1},"e":{"o":{"f":174}},"o":{"e":{"t":{"h":15}},"n":{"e":{"m":175}}}},"o":{"d":[{"d":5},9],"f":{"t":{"e":4}},"r":{"a":{"t":{"o":4}},"c":3,"d":2,"t":3},"s":[{"t":{"l":1}},3],"t":{"h":11},"u":{"t":11}},"p":{"e":{"d":{"a":{"l":5}},"t":{"e":4,"i":{"t":4}}},"i":{"e":1,"o":{"n":5},"t":9},"r":{"e":{"m":11,"a":{"m":15}}},"o":{"l":{"y":{"s":137}},"s":{"t":{"a":{"m":137}}}}},"r":{"a":{"c":1,"n":{"t":0},"t":{"i":{"o":{"n":{"a":7}}}},"v":{"e":{"n":{"o":176}}}},"e":{"e":[{"c":173},8],"m":{"i":{"t":4}},"s":[{"t":{"a":{"t":4}}},8]},"i":{"g":1,"t":{"u":5}},"o":{"q":1,"s":{"t":5},"w":{"d":5}},"u":{"d":1}},"s":{"c":{"i":{"e":11}},"e":{"l":{"f":6,"l":6},"n":9,"r":{"i":{"e":4}},"m":{"i":[{"c":0,"d":177,"p":36,"r":36,"s":178,"v":36},6]}},"h":9,"i":[{"n":{"g":17}},9],"t":[{"a":{"b":{"l":5}}},1],"y":9,"p":{"h":{"i":{"n":179}},"i":{"n":{"o":137}}}},"t":{"a":[{"p":{"e":{"s":{"t":{"r":180}}}}},1],"e":[{"n":{"a":{"n":5}},"l":{"e":{"g":{"r":3}}}},1],"h":9,"i":[{"l":0,"m":{"o":16},"n":{"g":17,"k":5}},9],"o":{"n":{"a":0},"p":[{"i":5,"o":{"g":170}},1],"u":{"s":5},"q":9},"r":{"i":{"b":{"u":{"t":6}}}}},"u":{"n":{"a":[{"t":{"t":144}},2],"c":{"e":3},"d":{"e":{"r":7}},"e":[{"r":{"r":181}},2],"k":4,"o":4,"u":3},"p":3,"r":{"e":11},"s":{"a":4}},"v":{"e":{"n":{"d":{"e":0}},"r":{"a":4}},"i":{"c":{"a":{"r":151}}}},"w":{"i":{"l":{"i":5}},"e":{"b":{"l":131}}},"y":{"e":1},"k":{"i":{"l":{"n":{"i":168}}},"o":{"r":{"t":{"e":169}}}}},"a":{"b":{".":18,"a":{"l":19,"n":19},"e":[{"r":{"d":4}},8],"i":{"a":5,"t":{"a":{"b":13}}},"l":{"a":{"t":4}},"o":{"l":{"i":{"z":20,"c":19}}},"r":[{"o":{"g":4}},18],"u":{"l":3}},"c":{"a":{"r":[{"d":4,"o":4},21],"b":{"l":24}},"e":{"o":{"u":19},"r":2},"h":{"e":{"t":19}},"i":[{"e":23,"n":2,"o":23},22],"r":{"o":{"b":4}},"t":{"i":{"f":5}},"u":{"l":3,"m":1}},"d":[{"d":{"i":{"n":1}},"e":{"r":{".":4}},"i":[{"a":23,"c":{"a":3},"e":{"r":0},"o":23,"t":23,"u":19},25],"l":{"e":1},"o":{"w":3},"r":{"a":{"n":4}},"s":{"u":1},"u":[{"c":23,"m":4},18]},24],"e":{"r":[{"i":{"e":17}},1]},"f":[{"f":[{"i":{"s":{"h":170}}},0]},24],"g":{"a":{"b":21,"n":0},"e":{"l":{"l":4},"o":0,"u":18},"i":2,"l":26,"n":2,"o":[{"g":27,"n":{"i":3}},24],"u":{"e":{"r":19},"l":4},"y":21},"h":{"a":23,"e":23,"l":1,"o":23},"i":[{"a":19,"c":{".":23},"l":{"y":4},"n":[{"i":{"n":5},"o":5},28],"t":{"e":{"n":5}}},9],"j":29,"k":{"e":{"n":2}},"l":{"a":{"b":4,"d":3,"r":21},"d":{"i":18},"e":[{"n":{"d":3,"t":{"i":21}},"o":30},25],"i":[{"a":{".":1},"e":0},2],"l":{"e":{"v":4},"i":{"c":18}},"m":18,"o":{"g":{".":19}},"y":{".":21,"s":[{"t":31},18],"t":32,"z":27}},"m":{"a":[{"b":4,"g":3,"r":{"a":5},"s":{"c":4},"t":{"i":{"s":21},"o":33}},18],"e":{"r":{"a":4},"n":{"t":{"a":{"b":182}}}},"i":{"c":3,"f":4,"l":{"y":4},"n":[{"o":0},2]},"o":[{"n":19,"r":{"i":6}},24],"p":{"e":{"n":5}}},"n":[{"a":{"g":{"e":3},"l":{"y":[{"s":183},27]},"r":[{"c":3,"i":17},23],"t":{"i":23}},"d":[{"e":{"s":17},"i":{"s":3},"l":2,"o":{"w":1}},18],"e":{"e":19,"n":23,"s":{"t":{".":4}},"u":23},"g":[{"i":{"e":5},"l":2},25],"i":{"c":34,"e":{"s":23},"f":35,"m":{"e":1,"i":19},"n":{"e":19},"o":3,"p":23,"s":{"h":3},"t":3,"u":23},"k":{"l":{"i":1}},"n":{"i":{"z":32}},"o":[{"t":[{"h":7},4],"a":{"c":148}},0],"s":{"a":9,"c":{"o":1},"n":1,"p":[{"o":11},9],"t":1,"u":{"r":1},"g":{"r":5},"v":11},"t":{"a":{"l":36},"i":{"e":1,"d":137,"n":184,"r":{"e":137}},"o":18,"r":9,"w":1},"u":{"a":3,"l":3,"r":19}},24],"o":18,"p":{"a":{"r":17,"t":4},"e":{"r":{"o":4},"a":{"b":{"l":{"e":132}}}},"h":{"e":{"r":23},"i":18},"i":{"l":{"l":{"a":[{"r":4},21]}},"n":3,"t":{"a":3,"u":23}},"l":24,"o":{"c":6,"l":{"a":4},"r":{"i":6},"s":{"t":12}},"s":{"e":{"s":5}},"u":23},"q":{"u":{"e":6}},"r":[{"a":{"c":{"t":3},"d":{"e":19,"i":{"s":4}},"l":3,"m":{"e":{"t":{"e":19}}},"n":{"g":17},"p":11,"t":[{"i":{"o":19,"v":4}},1],"u":19,"v":38,"w":17},"b":{"a":{"l":36}},"c":{"h":{"a":{"n":1},"e":{"t":185}}},"d":{"i":{"n":{"e":4}},"r":1},"e":{"a":{"s":4},"e":23,"n":{"t":3},"s":{"s":19}},"f":{"i":1,"l":1},"i":[{"a":{"l":4,"n":3},"e":{"t":23},"m":1,"n":{"a":{"t":4}},"o":3,"z":9},2],"m":{"i":9},"o":{"d":20,"n":{"i":19},"o":23},"p":9,"q":3,"r":{"e":17,"a":{"n":{"g":{"e":9}}}},"s":{"a":1,"h":9}},37],"s":{".":18,"a":{"b":1,"n":{"t":3}},"h":{"i":17},"i":{"a":{".":19},"b":23,"c":23,"t":39},"k":{"i":11},"l":1,"o":{"c":21},"p":{"h":4},"s":{"h":1},"t":{"e":{"n":3},"r":2},"u":{"r":{"a":6}},"y":{"m":{"p":{"t":{"o":{"t":4}}}}}},"t":{"a":[{"b":{"l":3},"c":4,"l":{"o":3},"p":4},24],"e":{"c":[{"h":4},5],"g":{"o":3},"n":{".":3},"r":{"a":3,"n":[{"a":19},6]},"s":{"t":3},"v":4},"h":[{"e":{"m":5,"n":19,"r":{"o":{"s":186}}},"o":[{"m":5},1]},18],"i":{".":18,"a":19,"b":20,"c":2,"f":3,"o":{"n":{"a":{"r":7}}},"t":{"u":3}},"o":{"g":21,"m":[{"i":{"z":4}},24],"p":21,"s":21},"r":[{"o":{"p":4}},29],"s":{"k":1},"t":{"a":{"g":1},"e":[{"s":{".":170}},4],"h":1},"u":[{"a":4,"e":4,"l":3,"r":{"a":3}},24],"y":24},"u":{"b":1,"g":{"h":[{"t":{"l":17}},12],"u":3},"l":[{"i":{"f":13}},40],"n":{"d":5},"r":3,"s":{"i":{"b":4}},"t":{"e":{"n":5},"h":2}},"v":{"a":[{"g":3,"n":19},24],"e":{"n":{"o":0},"r":{"a":3,"n":4,"y":4}},"i":[{"e":{"r":0},"g":3,"o":{"u":3}},2],"o":{"c":4,"r":29}},"w":{"a":{"y":27},"i":3,"l":{"y":1},"s":0},"x":{"i":{"c":1,"d":1}},"y":{"a":{"l":4},"e":0,"s":0},"z":{"i":{"e":{"r":0}},"z":{"i":5}}},"b":{"a":{".":32,"d":{"g":{"e":{"r":5}}},"g":{"e":1},"l":{"a":15},"n":{"d":{"a":{"g":5}},"e":0,"i":11},"r":{"b":{"i":7},"i":{"a":17},"o":{"n":{"i":{"e":187}}}},"s":{"s":{"i":0}},"t":[{"h":{"y":2}},41],"z":1,"c":{"k":{"e":{"r":{".":84}}}}},"b":[{"e":[{"r":23},24],"i":{"n":{"a":0},"t":0}},42],"d":43,"e":{".":18,"a":{"k":17,"t":12},"d":[{"a":3,"e":3,"i":3},44],"g":{"i":3,"u":4},"l":[{"i":2,"o":3},41],"m":45,"n":{"i":{"g":4},"u":4},"s":[{"p":3,"t":{"r":4}},46],"t":[{"i":{"z":5},"r":4,"w":3},27],"w":3,"y":{"o":4},"v":{"i":{"e":9}}},"f":25,"h":47,"i":{"b":9,"d":[{"i":{"f":167}},1],"e":[{"n":4,"r":1},27],"f":48,"l":[{"i":{"z":3},"l":{"a":{"b":8}}},41],"n":{"a":{"r":49},"d":0,"e":{"t":4}},"o":{"g":{"r":3},"u":4,"m":5,"r":{"b":2,"h":15}},"t":[{"i":{"o":50,"v":{"e":188}},"r":3,"u":{"a":51},"z":19},9]},"j":29,"k":1,"l":[{"a":{"t":{"h":7},"n":{"d":189}},"e":{".":21,"n":17,"s":{"p":32}},"i":{"s":23,"n":{"d":189}},"o":[{"n":{"d":190}},21],"u":{"n":{"t":17}}},52],"m":43,"n":[{"e":{"g":5}},47],"o":{"d":[{"i":11},27],"e":1,"l":{"i":{"c":11}},"m":{"b":{"i":0}},"n":{"a":[{"t":5},0]},"o":27,"r":{".":32,"a":43,"d":5,"e":32,"i":32,"n":{"o":191}},"s":53,"t":{"a":19,"h":6,"o":1,"u":{"l":192}},"u":{"n":{"d":54}}},"p":18,"r":{"i":{"t":18},"o":{"t":{"h":54}},"u":{"s":{"q":17}}},"s":[{"o":{"r":17}},55],"t":[{"l":1,"o":21,"r":23},25],"u":{"f":{"f":{"e":{"r":0}}},"g":{"a":1},"l":{"i":3},"m":{"i":17},"n":[{"t":{"i":17}},1],"r":{"e":3},"s":{"i":{"e":[{"r":193,"s":193},5]},"s":{"e":17,"i":{"n":{"g":17}}},"t":32},"t":{"a":18,"i":{"o":27},"o":19,"e":{"d":{".":8}},"t":{"e":{"d":0}}}},"v":29,"w":56,"y":{".":32,"s":0}},"c":{"a":[{"b":{"i":{"n":11},"l":2},"c":{"h":17},"d":{"e":{"n":4,"m":194}},"g":46,"h":57,"l":{"a":{"t":3},"l":{"a":0,"i":{"n":6}},"o":18},"n":{"d":5,"e":0,"i":{"c":0,"s":5,"z":11},"t":{"y":0},"y":17},"p":{"e":{"r":4}},"r":{"o":{"m":5}},"s":{"t":{"e":{"r":6},"i":{"g":5}},"y":18},"t":{"h":1,"i":{"v":18},"a":{"s":195}},"v":{"a":{"l":5}}},41],"c":[{"h":{"a":6},"i":{"a":0},"o":{"m":{"p":{"a":10}},"n":17,"u":{"t":12}}},23],"e":{".":25,"d":{".":18,"e":{"n":18}},"i":27,"l":{".":32,"l":27},"n":[{"c":27,"e":58,"i":18,"t":27},41],"p":27,"r":{"a":{"m":4}},"s":{"a":18,"s":{"i":[{"b":59},27]},"t":5},"t":[{"a":60},0],"w":0},"h":[{".":18,"a":{"b":61,"n":{"i":{"c":32,"s":20}}},"e":[{"a":{"p":54},"d":18,"l":{"o":5},"m":{"i":27},"n":{"e":4},"r":{".":3,"s":3}},8],"i":{"n":[{"e":{".":32,"s":{"s":4}},"i":32},62],"o":32,"t":27,"z":8,"e":{"v":{"o":6}}},"o":63,"t":{"i":1},"s":{".":18,"h":{"u":11}}},25],"i":[{"a":[{"b":64,"r":5},27],"c":4,"e":{"r":18},"f":{"i":{"c":{".":32}}},"i":18,"l":{"a":1,"i":27},"m":25,"n":[{"a":[{"t":27},21],"e":{"m":11},"g":[{".":19},29],"o":32,"q":8},25],"o":{"n":17},"p":{"e":18,"h":3,"i":{"c":18}},"s":{"t":{"a":18,"i":18}},"t":[{"i":{"z":11}},42],"z":32,"g":{"a":{"r":152}}},41],"k":[{"i":3},2],"l":[{"a":{"r":[{"a":{"t":{"i":{"o":19}}},"e":32},18]},"e":{"m":0,"a":{"r":0}},"i":{"c":18,"m":17},"y":0},65],"n":19,"o":[{"a":{"g":4},"e":8,"g":[{"r":1},25],"i":[{"n":{"c":3}},0],"l":{"i":5,"o":[{"r":11},32]},"m":{"e":{"r":5}},"n":{"a":0,"e":21,"g":11,"t":5},"p":{"a":3,"i":{"c":11},"l":1,"h":{"o":{"n":196}}},"r":{"b":18,"o":{"n":12}},"s":{"e":0},"v":[{"e":17},15],"w":{"a":5},"z":{"e":5,"i":4},"u":{"s":{"t":{"i":84}}}},41],"q":29,"r":{"a":{"s":{"t":6},"t":{".":32,"i":{"c":32}}},"e":{"a":{"t":11},"d":32,"t":{"a":47},"v":0},"i":[{"f":5,"n":21,"s":17,"t":{"i":[{"e":11},32]}},8],"o":{"p":{"l":0,"o":6},"s":{"e":17},"c":{"o":{"d":197}},"e":{"c":{"o":148}}},"u":{"d":0}},"s":66,"t":[{"a":{"b":0,"n":{"g":4,"t":19}},"e":[{"r":23},24],"i":{"c":{"u":21},"m":{"i":12}},"u":{"r":0},"w":21,"r":{"o":{"m":{"e":{"c":198}}}}},42],"u":{"d":5,"f":21,"i":[{"t":{"y":4}},21],"l":{"i":32,"t":{"i":{"s":0},"u":27}},"m":{"a":9,"e":23,"i":1},"n":27,"p":{"i":3,"y":4},"r":{"a":{"b":67,"n":{"c":{"e":199}}},"i":{"a":4}},"s":[{"s":{"i":17}},41],"t":[{"i":{"e":1,"v":56},"r":18},68]},"y":41,"z":{"e":0}},"d":{"a":[{".":32,"b":70,"c":{"h":17},"f":18,"g":25,"m":71,"n":{"g":11},"r":{"d":6,"k":6,"y":18},"t":[{"i":{"v":18},"o":18,"a":{"b":137}},27],"v":[{"e":5},53],"y":32,"l":{"o":{"n":{"e":48}}}},69],"b":29,"c":19,"d":[{"a":{"b":20},"i":{"b":94}},72],"e":{".":25,"a":{"f":6,"l":{"s":{".":1}}},"b":{"i":{"t":5},"o":{"n":1}},"c":{"a":{"n":36},"i":{"l":1},"o":{"m":4},"l":{"a":{"r":200},"i":{"n":{"a":64}}}},"d":42,"e":{".":18},"i":{"f":4},"l":{"i":{"e":17,"q":16},"o":4},"m":[{".":32,"i":{"c":[{".":5},27],"l":4},"o":{"n":{"s":1},"r":7,"s":9}},21],"n":[{"a":{"r":1},"o":3,"t":{"i":{"f":7}},"u":3},41],"p":[{"a":3,"i":17,"u":9},2],"q":23,"r":{"h":21,"m":32,"n":{"i":{"z":6}},"s":5},"s":[{".":24,"c":2,"o":64,"t":{"i":11,"r":3},"u":1,"i":{"c":11}},8],"t":[{"o":9,"i":{"c":9}},2],"v":[{"i":{"l":11}},2],"y":18,"f":{"i":{"n":{"i":{"t":{"i":201}}}}}},"f":43,"g":{"a":21,"e":{"t":73},"i":2,"y":24},"h":74,"i":{".":32,"a":[{"b":5},75],"c":{"a":{"m":1,"i":{"d":15}},"e":21,"t":27},"d":27,"e":{"n":76},"f":[{"f":{"r":{"a":5}}},29],"g":{"e":3},"l":{"a":{"t":{"o":1}}},"n":[{"a":41,"e":{".":27},"i":[{"z":4},32]},29],"o":[{"g":5},41],"p":{"l":1},"r":[{"e":[{"n":9,"r":9},2],"t":{"i":6}},8],"s":[{"i":32,"t":77},15],"t":{"i":24},"v":78,"m":{"e":{"t":{"h":{"y":141}}}}},"j":29,"k":79,"l":{"a":56,"e":{".":27,"d":27,"s":{".":27,"s":18},"a":{"d":42}},"o":48,"u":56,"y":25,"i":{"e":202}},"m":29,"n":80,"o":[{".":27,"d":{"e":4},"e":32,"f":57,"g":21,"l":{"a":1,"i":17,"o":{"r":4}},"m":{"i":{"z":5}},"n":{"a":{"t":3},"i":17},"o":{"d":11},"p":{"p":0},"r":21,"s":27,"u":{"t":56},"v":1,"x":27,"w":{"o":{"r":{"d":203}}}},41],"p":29,"r":[{"a":{"g":{"o":{"n":6}},"i":18},"e":[{"a":{"r":6},"n":[{"a":{"l":204}},32]},0],"i":{"b":0,"l":17,"f":{"t":{"a":189}},"p":{"l":{"e":{"g":205}}}},"o":{"p":0,"w":18,"m":{"e":{"d":206}}},"u":{"p":{"l":{"i":32}}},"y":18},41],"s":[{"p":1,"w":21,"y":21},81],"t":{"h":24,"a":{"b":23}},"u":[{"a":[{"l":{".":9}},82],"c":[{"a":29,"e":{"r":5},"t":{".":18,"s":18}},9],"e":{"l":4},"g":1,"l":{"e":23},"m":{"b":{"e":0}},"n":1,"p":[{"e":1},18],"o":{"p":{"o":{"l":207}}}},41],"v":29,"w":29,"y":[{"n":32,"s":{"e":1,"p":5}},24]},"e":{"a":{"b":72,"c":{"t":23},"d":[{"i":{"e":5}},15],"g":{"e":[{"r":4},1]},"l":[{"e":{"r":5},"o":{"u":11}},1],"m":{"e":{"r":11}},"n":{"d":19,"i":{"e":{"s":111}}},"r":{"a":11,"c":0,"e":{"s":5},"i":{"c":0,"l":0},"k":5,"t":[{"e":12},8]},"s":{"p":4,"s":23,"t":12},"t":[{"e":{"n":5},"h":{"i":12},"i":{"f":19},"u":83},9],"v":[{"e":{"n":11},"i":5,"o":5},9]},"b":[{"e":{"l":{".":21,"s":21},"n":21},"i":{"t":21},"r":23},42],"c":{"a":{"d":21,"n":{"c":6}},"c":{"a":6},"e":[{"s":{"s":{"a":4}}},29],"i":[{"b":21,"f":{"i":{"c":{"a":{"t":4}},"e":4},"y":4},"m":3,"t":[{"e":19},0]},9],"l":{"a":{"m":21},"u":{"s":21}},"o":{"l":24,"m":{"m":21,"p":{"e":21}},"n":{"c":21},"r":[{"a":3,"o":5},24]},"r":[{"e":{"m":21}},29],"t":{"a":{"n":1},"e":1},"u":[{"l":[{"a":3},21]},29],"h":{"a":{"s":23}}},"d":{"a":37,"d":61,"e":{"r":34,"s":0},"i":[{"a":23,"b":3,"c":{"a":3},"m":3,"t":2,"z":5},18],"o":[{"l":21,"n":84},18],"r":{"i":21},"u":{"l":[{"o":4,"i":{"n":{"g":2}}},21]},"g":{"l":15}},"e":{"c":9,"d":{"i":11},"f":9,"l":{"i":11,"y":1},"m":9,"n":{"a":1},"p":85,"s":[{"t":17},86],"t":{"y":1},"x":19},"f":[{"e":{"r":{"e":83}},"f":41,"i":{"c":[{"i":32},21],"l":17,"n":{"e":23,"i":{"t":{"e":20}}},"t":27},"o":{"r":{"e":{"s":6}}},"u":{"s":{"e":{".":21}}}},29],"g":{"a":{"l":18},"e":{"r":17},"i":{"b":4,"c":1,"n":{"g":4},"t":87},"n":4,"o":{".":21,"s":21},"u":{"l":2,"r":19},"y":32},"h":[{"e":{"r":17}},72],"i":[{"c":19,"d":4,"g":[{"l":4},8],"m":{"b":23},"n":{"f":23,"g":29,"s":{"t":19}},"r":{"d":0},"t":{"e":11,"h":3,"y":19}},9],"j":[{"u":{"d":[{"i":4},21]}},29],"k":{"i":{"n":0},"l":{"a":1}},"l":{"a":[{".":21,"c":21,"n":{"d":17},"t":{"i":{"v":4}},"w":21,"x":{"a":36}},29],"e":{"a":23,"b":{"r":{"a":4}},"c":32,"d":21,"g":{"a":3},"n":19,"r":34,"s":29},"f":9,"i":[{"b":{"e":23},"c":{".":33,"a":3},"e":{"r":23},"g":{"i":{"b":4}},"m":19,"n":{"g":83},"o":23,"s":[{"h":4},24],"v":88,"t":{"i":{"s":208}}},9],"l":{"a":[{"b":1},18],"o":17},"o":{"c":19,"g":4,"p":{".":3},"a":29},"s":{"h":9},"t":{"a":1},"u":{"d":19,"g":4}},"m":{"a":{"c":21,"g":21,"n":[{"a":4},19]},"b":4,"e":[{"l":24,"t":21},29],"i":{"c":{"a":3},"e":0,"g":{"r":{"a":4}},"n":[{"e":4,"i":35},89],"s":[{"h":4,"s":19},21],"z":3},"n":{"i":{"z":32}},"o":{"g":0,"n":{"i":{"o":7}}},"p":{"i":3},"u":{"l":[{"a":4},21],"n":11},"y":23},"n":{"a":{"m":{"o":4},"n":{"t":21}},"c":{"h":{"e":{"r":17}}},"d":{"i":{"c":3,"x":2}},"e":{"a":19,"e":19,"m":3,"r":{"o":4},"s":{"i":4,"t":4},"t":{"r":3},"w":23},"i":{"c":{"s":4},"e":19,"l":19,"o":23,"s":{"h":3},"t":3,"u":19,"z":32},"n":18,"o":[{"g":0,"s":21,"v":3},18],"s":{"w":1},"t":{"a":{"g":{"e":5}},"h":{"e":{"s":18}}},"u":{"a":3,"f":4},"y":{".":23},"z":61},"o":{"f":19,"g":[{"r":{"a":{"p":3}}},9],"i":90,"l":23,"p":{"a":{"r":11}},"r":[{"e":3,"o":{"l":4}},29],"s":0,"t":[{"o":1},21],"u":{"t":19},"w":19},"p":{"a":[{"i":23,"n":{"c":4}},24],"e":{"l":19,"n":{"t":23},"t":{"i":{"t":{"i":{"o":4}}}}},"h":{"e":17},"l":{"i":21},"o":29,"r":{"e":{"c":[{"a":4},21],"d":21,"h":3},"o":[{"b":21},23]},"s":{"h":1},"t":{"i":{"b":13}},"u":{"t":[{"a":4},21]},"i":{"n":{"e":{"p":{"h":209}}}}},"q":[{"u":{"i":{"l":12,"s":91}}},29],"r":{"a":[{"b":0,"n":{"d":18},"r":3,"t":{"i":{".":18}}},2],"b":[{"l":1},25],"c":{"h":[{"e":1},3]},"e":{".":25,"a":{"l":23},"c":{"o":5},"i":{"n":11},"l":{".":4},"m":{"o":3},"n":{"a":4,"c":{"e":4},"e":18,"t":3},"q":0,"s":{"s":4,"t":3},"t":17},"h":2,"i":[{"a":[{"n":{".":210}},92],"c":{"k":32},"e":{"n":23,"r":0},"n":{"e":3},"o":29,"t":18,"u":1,"v":[{"a":21},0]},2],"m":93,"n":{"i":{"s":1,"t":18,"z":32},"o":3},"o":[{"b":4,"c":19,"r":0,"u":2},25],"s":[{"e":{"t":3}},2],"t":{"e":{"r":11},"l":18,"w":3},"u":[{"t":0},18],"w":{"a":{"u":32}}},"s":{"a":[{"g":{"e":{".":21,"s":21}}},72],"c":[{"a":[{"n":4},24],"r":23,"u":4},9],"e":[{"c":[{"r":4},24],"n":{"c":4},"r":{"t":{".":21,"s":21},"v":{"a":21}}},74],"h":[{"a":23,"e":{"n":5}},18],"i":[{"c":24,"d":[{"e":{"n":4}},24],"g":{"n":{"a":4}},"m":94,"n":95,"s":{"t":{"e":17}},"u":0},29],"k":{"i":{"n":19}},"m":{"i":1},"o":{"l":[{"u":3},24],"n":[{"a":4},24]},"p":[{"e":{"r":3},"i":{"r":{"a":4}},"r":{"e":1},"a":{"c":{"i":211}}},29],"s":[{"i":{"b":96}},25],"t":{"a":{"n":36},"i":{"g":3,"m":4},"o":[{"n":23},44],"r":[{"o":19,"u":{"c":10}},25]},"u":{"r":[{"r":4},24]},"w":1},"t":{"a":{"b":0},"e":{"n":{"d":17},"o":23},"h":{"o":{"d":54},"y":{"l":{"e":{"n":{"e":162}}}}},"i":{"c":2,"d":{"e":19},"n":[{"o":0},17],"r":19,"t":{"i":{"o":19,"v":4}}},"n":18,"o":{"n":{"a":4}},"r":{"a":23,"e":23,"i":{"c":3,"f":4},"o":{"g":3,"s":4}},"u":{"a":3},"y":{"m":4},"z":4},"u":[{"n":19,"p":23,"r":{"o":3},"s":0,"t":{"e":17,"i":{"l":6},"r":4},"c":{"l":{"i":{"d":212}}}},18],"v":{"a":{"p":97,"s":[{"t":4},24]},"e":{"a":19,"l":{"l":3,"o":12},"n":{"g":19,"i":17},"r":[{"b":19},2]},"i":[{"d":3,"l":0,"n":21,"v":0},29],"o":{"c":19},"u":19},"w":{"a":[{"g":21},29],"e":{"e":19},"h":23,"i":{"l":6,"n":{"g":3},"t":23}},"x":{"p":41},"y":{"c":32,"e":{".":32},"s":0}},"f":{"a":[{"b":{"l":3,"r":11},"c":{"e":1},"g":18,"i":{"n":17},"l":{"l":{"e":6}},"m":{"a":26,"i":{"s":5}},"r":[{"t":{"h":5}},32],"t":{"a":3,"h":{"e":3},"o":18},"u":{"l":{"t":7}}},41],"b":56,"d":18,"e":{".":18,"a":{"s":17,"t":{"h":54}},"b":[{"r":{"u":{"a":15}}},1],"c":{"a":18,"t":32},"d":25,"l":{"i":3},"m":{"o":1},"n":{"d":[{"e":6},8]},"r":[{"r":32,"m":{"i":{"o":213}}},15],"v":0},"f":[{"e":{"s":21},"i":{"e":21,"n":{".":19},"s":94},"l":{"y":21},"y":24},43],"h":18,"i":[{"a":3,"c":{".":48,"a":{"l":47,"n":23,"t":{"e":18}},"e":{"n":23,"r":3},"i":[{"a":32,"e":32},0],"s":18,"u":3,"h":27},"d":{"e":{"l":4}},"g":{"h":{"t":7}},"l":{"i":5,"l":{"i":{"n":6}},"y":18},"n":[{"a":32,"d":97,"e":9,"g":98,"n":0},25],"s":{"t":{"i":0}},"t":{"t":{"e":{"d":{".":5}}}}},41],"l":[{"e":{"s":{"s":19}},"i":{"n":17},"o":{"r":{"e":11},"w":{"e":{"r":{".":84}}}},"y":100,"a":{"g":{"e":{"l":214}}},"u":{"o":{"r":27}}},99],"m":18,"n":18,"o":[{"n":[{"d":{"e":0},"t":0},32],"r":[{"a":{"t":4,"y":5},"e":{"t":6},"i":0,"t":{"a":6}},9],"s":5},41],"p":56,"r":{"a":{"t":0},"e":{"a":19,"s":{"c":6}},"i":[{"l":17},8],"o":{"l":6}},"s":48,"t":[{"o":21,"y":24},25],"u":[{"e":{"l":4},"g":18,"m":{"i":{"n":1}},"n":{"e":4},"r":{"i":3},"s":{"i":17,"s":0},"t":{"a":18}},27],"y":41},"g":{"a":[{"f":0,"l":{".":32,"i":27,"o":3},"m":[{"e":{"t":4},"o":19},25],"n":{"i":{"s":5,"z":[{"a":6},3]},"o":18},"r":{"n":67},"s":{"s":17},"t":{"h":12,"i":{"v":18}},"z":18},41],"b":23,"d":1,"e":{".":25,"d":25,"e":{"z":17},"l":{"i":{"n":0,"s":4,"z":4},"y":18},"n":[{"a":{"t":1},"i":{"z":4},"o":18,"y":18,"c":{"y":{".":8}}},41],"o":[{"m":3,"d":215},41],"r":{"y":21},"s":{"i":32},"t":{"h":6,"o":18,"y":1,"i":{"c":{".":8}}},"v":1},"g":[{"e":[{"r":23},24],"l":{"u":6},"o":0},101],"h":{"i":{"n":3},"o":{"u":{"t":4}},"t":{"o":1,"w":{"e":15}}},"i":{".":32,"a":[{"r":5},102],"c":[{"i":{"a":32},"o":21},29],"e":{"n":6,"s":{".":32}},"l":0,"m":{"e":{"n":23}},"n":{".":68,"g":{"e":5},"s":103},"o":32,"r":[{"l":0},27],"s":{"l":23},"u":1,"v":32,"z":27},"l":[{"a":[{"d":{"i":6},"s":32},0],"e":[{"a":{"d":29}},41],"i":{"b":0,"g":23,"s":{"h":43}},"o":[{"r":11,"b":{"i":{"n":106}}},27]},9],"m":[{"y":21},29],"n":{"a":[{".":21,"c":69},1],"e":{"t":{"t":17,"i":{"s":{"m":137}}}},"i":[{"n":24,"o":21},29],"o":[{"n":21,"m":{"o":5},"r":{".":216,"e":{"s":{"p":24}}}},29]},"o":[{".":27,"b":5,"e":32,"g":104,"i":{"s":3},"n":[{"a":105,"d":{"o":7},"i":[{"z":{"a":217}},3]},8],"o":32,"r":{"i":{"z":4},"o":{"u":5}},"s":{".":32},"v":15},41],"p":23,"r":[{"a":{"d":{"a":18},"i":21,"n":84,"p":{"h":{".":32,"e":{"r":[{".":7},19]},"i":{"c":32},"y":18}},"y":18},"e":{"n":0,"s":{"s":{".":18}}},"i":{"t":18,"e":{"v":213}},"o":21,"u":{"f":17}},41],"s":[{"t":{"e":19}},9],"t":{"h":11},"u":{"a":[{"r":{"d":27}},1],"e":25,"i":{"t":106},"n":27,"s":27,"t":[{"a":{"n":29}},26]},"w":23,"y":[{"n":107,"r":{"a":4}},41]},"h":{"a":{"b":{"l":73},"c":{"h":17},"e":{"m":0,"t":0},"g":{"u":19},"l":{"a":[{"m":12},3]},"m":1,"n":{"c":{"i":0,"y":0},"d":{".":32},"g":[{"e":{"r":6},"o":6},0],"i":{"z":108},"k":0,"t":{"e":0}},"p":{"l":11,"t":5,"a":{"r":{"r":218}}},"r":{"a":{"n":3,"s":4},"d":[{"e":12},8],"l":{"e":0},"p":{"e":{"n":6}},"t":{"e":{"r":5}}},"s":{"s":5},"u":{"n":17},"z":[{"a":11},32],"i":{"r":{"s":137}},"t":{"c":{"h":213}}},"b":29,"e":{"a":{"d":41,"r":27},"c":{"a":{"n":1,"t":19}},"d":[{"o":13},21],"l":{"i":93,"l":{"i":{"s":0},"y":0},"o":19},"m":{"p":0},"n":[{"a":[{"t":5},17]},9],"o":{"r":5},"p":5,"r":{"a":[{"p":12},21],"b":{"a":0},"e":{"a":6},"n":23,"o":{"u":19},"y":23},"s":[{"p":64},29],"t":[{"e":{"d":0}},1],"u":0,"x":{"a":168}},"f":29,"h":29,"i":{"a":{"n":4},"c":{"o":1},"g":{"h":6},"l":109,"m":{"e":{"r":36}},"n":{"a":21},"o":{"n":{"e":17}},"p":[{"e":{"l":{"a":219}}},1],"r":{"l":0,"o":3,"p":0,"r":0},"s":{"e":{"l":11},"s":0},"t":{"h":{"e":{"r":6}},"e":{"s":{"i":{"d":12}}}},"v":9},"k":18,"l":[{"a":{"n":17},"o":[{"r":{"i":11}},24]},80],"m":[{"e":{"t":17}},43],"n":[{"a":{"u":{"z":12}}},42],"o":{"d":{"i":{"z":19},"s":19},"g":[{"e":17},1],"l":{"a":{"r":5},"e":110},"m":{"a":1,"e":12},"n":{"a":0,"y":4},"o":{"d":27,"n":17},"r":{"a":{"t":5},"i":{"s":4,"c":{".":187}},"t":{"e":12},"u":4},"s":{"e":[{"n":4},0],"p":15},"u":{"s":[{"e":54},41]},"v":{"e":{"l":5}}},"p":56,"r":[{"e":{"e":6},"o":{"n":{"i":{"z":5}},"p":{"o":11}}},26],"s":[{"h":21},101],"t":{"a":{"r":21},"e":{"n":2,"s":4,"o":{"u":216}},"y":21},"u":{"g":1,"m":{"i":{"n":1}},"n":{"k":{"e":5},"t":0},"s":{"t":14},"t":1},"w":[{"a":{"r":{"t":21}}},29],"y":{"p":{"e":3,"h":3,"o":{"t":{"h":{"a":137}}}},"s":9}},"i":{"a":[{"l":24,"m":[{"e":{"t":{"e":5}}},0],"n":[{"c":18,"i":11,"t":46},24],"p":{"e":4},"s":{"s":17},"t":{"i":{"v":21},"r":{"i":{"c":1}},"u":21}},42],"b":{"e":[{"r":{"a":3,"t":4}},0],"i":{"a":4,"n":3,"t":{".":4,"e":4}},"l":[{"i":3},29],"o":19,"r":[{"i":94},29],"u":{"n":19}},"c":{"a":{"m":18,"p":32,"r":[{".":21,"a":21},18],"s":6,"y":21},"c":{"u":17},"e":{"o":18},"h":18,"i":[{"d":19,"n":{"a":4},"p":[{"a":3},24]},25],"l":{"y":21},"o":{"c":94},"r":[{"a":32,"y":21},43],"t":{"e":1,"u":[{"a":111},84]},"u":{"l":{"a":3},"m":1,"o":4,"r":23}},"d":[{"a":{"i":21,"n":{"c":4}},"d":4,"e":{"a":{"l":11},"s":0},"i":[{"a":{"n":4,"r":0},"e":19,"o":[{"u":5,"s":1},3],"t":2,"u":4},24],"l":{"e":23},"o":{"m":21,"w":3},"r":21,"u":[{"o":4},24]},25],"e":[{"d":{"e":0},"g":{"a":113},"l":{"d":12},"n":{"a":67,"e":0,"n":19,"t":{"i":23}},"r":{".":29},"s":{"c":23,"t":29},"t":23},112],"f":{".":18,"e":{"r":{"o":4}},"f":{"e":{"n":5},"r":1},"i":{"c":{".":18},"e":23},"l":23,"t":18,"a":{"c":{"e":{"t":137}}}},"g":[{"a":{"b":5},"e":{"r":{"a":3}},"h":{"t":{"i":12}},"i":[{"b":23,"l":3,"n":3,"t":3},18],"l":28,"o":[{"r":3,"t":4},24],"r":{"e":19},"u":{"i":5,"r":2},"n":{"i":{"t":[{"e":{"r":213}},0]}}},25],"h":23,"i":114,"j":[{"k":21},23],"k":18,"l":{"a":[{"b":93,"d":{"e":21},"m":94,"r":{"a":5}},29],"e":{"g":23,"r":2,"v":17},"f":4,"i":[{"a":3,"b":9,"o":3,"s":{"t":1},"t":25,"z":9},2],"l":{"a":{"b":5}},"n":18,"o":{"q":3},"t":{"y":1},"u":{"r":4},"v":3},"m":{"a":{"g":[{"e":3},21],"r":{"y":5}},"e":{"n":{"t":{"a":{"r":10}}},"t":18},"i":[{"d":{"a":4},"l":{"e":5},"n":{"i":19},"t":18},2],"n":{"i":1},"o":{"n":23},"u":[{"l":{"a":3}},24],"p":{"e":{"d":{"a":201}}}},"n":{".":25,"a":{"u":83,"v":18},"c":{"e":{"l":36,"r":3}},"d":[{"l":{"i":{"n":{"g":4}}}},18],"e":[{"e":23,"r":{"a":{"r":17}},"s":{"s":19}},25],"g":{"a":18,"e":[{"n":4},18],"i":18,"l":{"i":{"n":{"g":4}}},"o":18,"u":18},"i":[{".":19,"a":21,"o":3,"s":2,"t":{"e":{".":19,"l":{"y":{".":19}}},"i":{"o":32},"y":3}},25],"k":18,"l":18,"n":25,"o":[{"c":90,"s":0,"t":21},42],"s":[{"e":3,"u":{"r":{"a":7}}},25],"t":{".":25,"h":112},"u":[{"s":19},2],"y":18,"f":{"r":{"a":{"s":220}}}},"o":[{".":18,"g":{"e":17,"r":9},"l":29,"m":1,"n":{"a":{"t":11},"e":{"r":{"y":0}},"i":11},"p":{"h":4},"r":{"i":11},"s":21,"t":{"h":4,"i":19,"o":1},"u":{"r":21}},25],"p":[{"e":0,"h":{"r":{"a":{"s":115}}},"i":[{"c":1},3],"r":{"e":96},"u":{"l":3}},25],"q":{"u":{"a":23,"e":{"f":4},"i":{"d":3,"t":116}}},"r":[{"a":[{"b":0,"c":21},29],"d":{"e":5},"e":{"d":{"e":0},"f":21,"l":117,"s":21},"g":{"i":4},"i":[{"d":{"e":5},"s":1,"t":{"u":11},"z":118},2],"m":{"i":{"n":1}},"o":{"g":0,"n":{".":32}},"u":{"l":4},"r":{"e":{"v":{"o":{"c":221}}}}},18],"s":{".":25,"a":{"g":4,"r":3,"s":6},"c":[{"h":3},119],"e":[{"r":3},18],"f":27,"h":{"a":{"n":4},"o":{"n":3,"p":5}},"i":{"b":3,"d":0,"s":19,"t":{"i":{"v":4}}},"k":26,"l":{"a":{"n":36}},"m":{"s":18},"o":[{"m":{"e":{"r":5}}},24],"p":[{"i":9,"y":1},2],"s":[{"a":{"l":1},"e":{"n":36,"s":1}},62],"t":{"a":{".":1},"e":2,"i":2,"l":{"y":0},"r":{"a":{"l":18}}},"u":[{"s":4},24]},"t":{"a":{".":18,"b":{"i":0},"g":21,"m":120,"n":23,"t":23},"e":[{"r":{"a":3,"i":19},"s":[{"i":{"m":{"a":29}}},1]},25],"h":[{"i":{"l":148}},25],"i":[{"a":18,"c":[{"a":3,"k":31},22],"g":3,"l":{"l":4},"m":24,"o":25,"s":[{"m":21},18],"n":{"e":{"r":{"a":{"r":158}}}}},29],"o":{"m":121,"n":18},"r":{"a":{"m":21},"y":4},"t":18,"u":{"a":{"t":3},"d":19,"l":3},"z":{".":18}},"u":29,"v":[{"e":{"l":{"l":3},"n":{".":3},"r":{".":83,"s":{".":21}}},"i":{"l":{".":4},"o":4,"t":2},"o":{"r":{"e":19,"o":35},"t":83}},25],"w":56,"x":{"o":1},"y":18,"z":{"a":{"r":18},"i":0,"o":{"n":{"t":32}}}},"j":{"a":[{"c":{"q":0},"p":[{"a":{"n":{"e":{"s":220}}}},1],"n":{"u":{"a":12}}},32],"e":[{"r":{"s":5,"e":{"m":222}},"s":{"t":{"i":{"e":18},"y":18}},"w":11},41],"o":{"p":1},"u":{"d":{"g":32}}},"k":{"a":{".":27,"b":23,"g":19,"i":{"s":17},"l":0},"b":29,"e":{"d":24,"e":41,"g":1,"l":{"i":[{"n":{"g":223}},4]},"n":{"d":73},"r":29,"s":[{"t":{".":23}},0],"t":{"y":1}},"f":23,"h":1,"i":[{".":32,"c":122,"l":{"l":21,"o":6},"m":21,"n":{".":21,"d":{"e":0},"e":{"s":{"s":19},"t":{"i":{"c":224}}},"g":0},"p":1,"s":[{"h":19},0]},29],"k":1,"l":[{"e":{"y":18},"y":18},29],"m":29,"n":{"e":{"s":19},"o":69},"o":{"r":4,"s":{"h":17},"u":23,"v":{"i":{"a":{"n":41}}}},"r":{"o":{"n":5}},"s":[{"c":21,"l":1,"y":21,"h":{"a":23}},101],"t":19,"w":29},"l":{"a":{"b":{"i":{"c":11},"o":21},"c":{"i":[{"e":225},17]},"d":{"e":21,"y":3},"g":{"n":0},"m":{"o":11},"n":{"d":[{"l":0},27],"e":{"t":5},"t":{"e":0}},"r":{"g":0,"i":11,"c":{"e":{"n":176}}},"s":{"e":0},"t":{"a":{"n":4},"e":{"l":{"i":18}},"i":{"v":18}},"v":[{"a":95},18],"i":{"n":{"e":{"s":{"s":226}}}}},"b":[{"i":{"n":17}},42],"c":[{"e":0,"i":23,"h":{"a":{"i":23},"i":{"l":{"d":227}}}},101],"d":[{"e":[{"r":{"e":1,"i":1}},24],"i":[{"s":4},0],"r":[{"i":21},23]},25],"e":{"a":[{"d":{"e":{"r":{".":183}}},"s":{"a":228}},9],"b":{"i":1},"f":{"t":6},"g":{".":32,"g":32,"e":{"n":{"d":{"r":{"e":230}}}}},"m":{"a":{"t":[{"i":{"c":5}},1]}},"n":{".":18,"c":27,"e":{".":32},"t":41,"o":{"i":{"d":78}}},"p":{"h":3,"r":1},"r":{"a":{"b":6},"e":0,"g":27,"i":68,"o":21},"s":[{"c":{"o":4},"q":32,"s":[{".":32},27]},8],"v":{"a":23,"e":{"r":{".":0,"a":0,"s":0}}},"y":[{"e":18},27],"c":{"t":{"a":{"b":229}}}},"f":[{"r":19},25],"g":[{"a":[{"r":12},19],"e":{"s":21},"o":11},80],"h":48,"i":{"a":{"g":1,"m":9,"r":{"i":{"z":6}},"s":1,"t":{"o":1}},"b":{"i":4},"c":{"i":{"o":32},"o":{"r":1},"s":18,"t":{".":18},"u":21,"y":23},"d":{"a":23,"e":{"r":5},"i":27},"f":{"e":{"r":11},"f":21,"l":1},"g":{"a":{"t":{"e":32}},"h":27,"r":{"a":1}},"k":27,"l":123,"m":{"b":{"l":0},"i":11,"o":1,"p":90},"n":{"a":21,"e":[{"a":11},124],"i":11,"k":{"e":{"r":6}}},"o":{"g":4},"q":125,"s":{"p":0},"t":[{".":24,"i":{"c":{"a":32,"s":108}},"h":{"o":{"g":204}}},29],"v":{"e":{"r":11}},"z":29},"j":18,"k":{"a":[{"l":23,"t":0},11]},"l":[{"a":{"w":21},"e":[{"a":19,"c":23,"g":23,"l":23,"n":73,"t":73},24],"i":[{"n":[{"a":19},126],"s":{"h":231}},9],"o":[{"q":{"u":{"i":10}},"u":{"t":4},"w":19},1],"f":{"l":2}},29],"m":[{"e":{"t":19},"i":{"n":{"g":3}},"o":{"d":21,"n":[{"e":{"l":{"l":232}}},17]}},25],"n":81,"o":{".":27,"b":{"a":{"l":5},"o":{"t":{"o":233}}},"c":{"i":1},"f":18,"g":{"i":{"c":27},"o":19,"u":27,"e":{"s":{".":9}}},"m":{"e":{"r":11}},"n":{"g":32,"i":[{"z":127},0]},"o":{"d":6},"p":{"e":{".":32},"i":11,"m":23},"r":{"a":[{"t":{"o":1}},17],"i":{"e":4},"o":{"u":5}},"s":{".":32,"e":{"t":5},"o":{"p":{"h":{"i":{"z":32},"y":32}}},"t":0},"t":{"a":1},"u":{"n":{"d":6},"t":25},"v":18,"a":{"d":{"e":{"d":{".":17},"r":{".":183}}}}},"p":[{"a":{"b":5},"h":{"a":23,"i":19},"i":{"n":{"g":4},"t":23},"l":21,"r":19},25],"r":43,"s":[{"c":21,"e":24,"i":{"e":21}},81],"t":[{"a":{"g":4,"n":{"e":7}},"e":[{"n":17,"r":{"a":36},"a":23},29],"h":{"i":[{"l":{"y":148}},11]},"i":{"e":{"s":{".":19}},"s":17},"r":29,"u":[{"r":{"a":12}},8]},18],"u":{"a":4,"b":{"r":3},"c":{"h":17,"i":3},"e":{"n":3,"p":15},"f":0,"i":{"d":4},"m":{"a":1,"i":32,"n":{".":19,"i":{"a":32}},"b":{"i":{"a":{".":235}}}},"o":[{"r":11},3],"p":18,"s":{"s":17,"t":{"e":11}},"t":41,"n":{"k":{"e":{"r":234}}}},"v":{"e":{"n":19,"t":128}},"w":42,"y":[{"a":18,"b":18,"m":{"e":4},"n":{"o":3},"s":[{"e":19,"t":{"y":{"r":4}}},58],"g":{"a":{"m":{"i":236}}}},41]},"m":{"a":[{"b":25,"c":{"a":9,"h":{"i":{"n":{"e":4}}},"l":1},"g":{"i":{"n":5},"n":32},"h":25,"i":{"d":6},"l":{"d":18,"i":{"g":3,"n":4},"l":{"i":0},"t":{"y":0},"a":{"p":222}},"n":{"i":{"a":32,"s":5,"z":11},".":24,"u":{"s":{"c":237}}},"p":[{"h":{"r":{"o":244}}},18],"r":{"i":{"n":{"e":{".":4}},"z":4},"l":{"y":0},"v":11,"g":{"i":{"n":238}}},"s":{"c":{"e":4},"e":0,"t":15},"t":{"e":32,"h":12,"i":{"s":3,"z":{"a":18}}}},41],"b":[{"a":{"t":129},"i":{"l":19,"n":{"g":83},"v":0}},43],"c":56,"e":{".":18,"d":[{".":18,"i":{"a":32,"e":3,"c":[{"i":{"n":152}},84],"o":{"c":239}},"y":108},25],"g":[{"r":{"a":{"n":240}}},9],"l":{"o":{"n":5},"t":0},"m":[{"o":130},9],"n":[{"a":[{"c":5},0],"d":{"e":0},"e":18,"i":0,"s":[{"u":7},17],"t":[{"e":0},27],".":24},41],"o":{"n":4},"r":{"s":{"a":19}},"s":[{"t":{"i":27}},25],"t":{"a":[{"l":11},1],"e":2,"h":{"i":4},"r":[{"i":{"c":32,"e":4},"y":3},21]},"v":1},"f":43,"h":25,"i":{".":32,"a":3,"d":{"a":[{"b":241},0],"g":0},"g":0,"l":{"i":{"a":27,"e":108,"t":{"a":27}},"l":[{"a":{"g":208},"i":{"l":{"i":59}}},21]},"n":{"a":0,"d":27,"e":{"e":19},"g":{"l":[{"i":5,"y":19},21]},"t":0,"u":[{"t":{"e":{"r":242,"s":{"t":242}}}},21],"i":{"s":{".":174}}},"o":{"t":17},"s":[{"e":{"r":{".":0}},"l":5,"t":{"i":0,"r":{"y":19}}},24],"t":{"h":18},"z":24},"k":18,"l":43,"m":[{"a":{"r":{"y":5},"b":243}},29],"n":[{"a":1,"i":{"n":21},"o":1},43],"o":[{"c":{"r":[{"a":{"t":[{"i":{"z":32}},245]}},18]},"d":131,"g":{"o":1},"i":{"s":[{"e":5},84]},"k":18,"l":{"e":{"s":{"t":4},"c":246}},"m":{"e":3},"n":{"e":{"t":5,"y":{"l":247}},"g":{"e":5},"i":{"a":12,"s":{"m":0,"t":0},"z":3},"o":{"l":36,"c":{"h":12},"e":{"n":171},"s":249},"y":{".":3}},"r":[{"a":{".":18},"o":{"n":{"i":{"s":248}}}},9],"s":[{"e":{"y":4},"p":3},8],"t":{"h":[{"e":{"t":250}},12]},"u":{"f":19,"s":[{"i":{"n":98}},27]},"v":9,"e":{"l":{"a":{"s":167}}}},41],"p":[{"a":{"r":{"a":[{"b":5},7],"i":6}},"e":{"t":23},"h":{"a":{"s":36}},"i":[{"a":0,"e":{"s":4},"n":34,"r":19,"s":4},24],"o":{"r":{"i":11},"s":{"i":{"t":{"e":6}}},"u":{"s":21},"v":6},"t":{"r":1},"y":24},43],"r":47,"s":[{"h":[{"a":{"c":{"k":251}}},21],"i":19},101],"t":18,"u":[{"l":{"a":{"r":49},"t":[{"i":[{"u":252},54]},32]},"m":27,"n":8,"p":18,"u":1,"d":{"r":{"o":9}}},41],"w":18},"n":{"a":[{"b":[{"u":21},81],"c":{".":18,"a":1,"t":19},"g":{"e":{"r":{".":5}}},"k":0,"l":{"i":[{"a":4},1],"t":18},"m":{"i":{"t":4}},"n":[{"c":{"i":36},"i":{"t":0},"k":17},24],"r":{"c":[{"h":{"s":{".":73}}},11],"e":18,"i":11,"l":0,"m":19},"s":[{"c":0,"t":{"i":5}},21],"t":[{"a":{"l":3},"o":{"m":{"i":{"z":6}}}},24],"u":[{"s":{"e":11},"t":27},24],"v":{"e":0}},41],"b":80,"c":{"a":{"r":6},"e":{"s":{".":21}},"h":{"a":23,"e":{"o":19,"s":{"t":253}},"i":{"l":19,"s":23}},"i":{"n":2,"t":1},"o":{"u":{"r":{"a":7}}},"r":29,"u":29},"d":{"a":{"i":21,"n":19},"e":[{"s":{"t":{".":4}}},29],"i":{"b":0,"f":79,"t":29,"z":23,"e":{"c":{"k":29}}},"u":{"c":19,"r":0},"w":{"e":9},"t":{"h":{"r":3}}},"e":{".":25,"a":{"r":23},"b":[{"u":11,"a":{"c":{"k":3}}},9],"c":[{"k":32},9],"d":25,"g":{"a":{"t":[{"i":{"v":5}},1]},"e":32},"l":{"a":1,"i":{"z":5}},"m":{"i":4,"o":1},"n":[{"e":18},41],"o":27,"p":{"o":1},"q":9,"r":[{"a":{"b":6,"r":21},"e":24,"i":132,"r":0},29],"s":[{".":25,"p":18,"t":25,"w":18,"k":{"i":119}},41],"t":{"i":{"c":27}},"v":[{"e":19},1],"w":1},"f":[{"i":{"n":{"i":{"t":{"e":{"s":226}}}}}},23],"g":{"a":{"b":21},"e":{"l":23,"n":{"e":[{"s":5},133]},"r":{"e":19,"i":23}},"h":{"a":4,"o":2},"i":{"b":23,"n":2,"t":19},"l":{"a":21},"o":{"v":17},"s":{"h":4,"p":{"r":2}},"u":[{"m":21},29],"y":24},"h":[{"a":[{"b":12},0],"e":0},80],"i":{"a":[{"n":[{".":114},3],"p":1},68],"b":{"a":3,"l":1},"d":[{"i":4},1],"e":{"r":1},"f":{"i":[{"c":{"a":{"t":4}}},9]},"g":{"r":19},"k":0,"m":[{"i":{"z":3}},29],"n":[{"e":{".":32},"g":0},29],"o":1,"s":{".":32,"t":{"a":0}},"t":[{"h":21,"i":{"o":27},"o":{"r":23},"r":3},24]},"j":29,"k":[{"e":{"r":{"o":19},"t":23},"i":{"n":3},"l":29,"r":{"u":{"p":3}}},44],"l":[{"e":{"s":{"s":19}}},43],"m":[{"e":[{"t":17},0]},19],"n":[{"e":0,"i":{"a":{"l":11},"v":0}},101],"o":{"b":{"l":[{"e":3},0]},"c":{"l":19,"e":{"r":{"o":{"s":254}}}},"d":66,"e":27,"g":[{"e":17},18],"i":{"s":{"i":6}},"l":{"i":134,"o":{"g":{"i":{"s":32}}}},"m":{"i":{"c":27,"z":108,"s":{"t":82}},"o":1,"y":3,"a":{"l":214},"e":{"n":{"o":194}}},"n":[{"a":{"g":0},"i":[{"z":19,"s":{"o":255}},5],"e":{"q":15}},1],"p":[{"o":{"l":{"i":135,"y":{".":256}}}},18],"r":{"a":{"b":5,"r":{"y":1}}},"s":{"c":18,"e":0,"t":5},"t":{"a":4},"u":[{"n":27},41],"v":{"e":{"l":136,"m":{"b":2}}},"w":{"l":12}},"p":[{"i":0,"r":{"e":{"c":17}}},72],"q":29,"r":[{"u":0},29],"s":[{"a":{"b":4,"t":{"i":36}},"c":[{"e":{"i":{"v":4}}},1],"e":[{"s":83},24],"i":{"d":137,"g":17},"l":24,"m":[{"o":{"o":1}},3],"o":{"c":21},"p":{"e":1,"i":19},"t":{"a":{"b":{"l":6}}}},81],"t":[{"a":{"b":0},"e":{"r":{"s":12}},"i":[{"b":19,"e":{"r":0},"f":8,"n":{"e":23,"g":83},"p":0},9],"r":{"o":{"l":{"l":{"i":7}}},"e":{"p":137}},"s":1,"u":{"m":{"e":11}}},29],"u":{"a":2,"d":1,"e":{"n":4},"f":{"f":{"e":0}},"i":{"n":23,"t":50},"m":[{"e":2,"i":19},21],"n":138,"o":23,"t":{"r":3}},"v":74,"w":72,"y":{"m":0,"p":0},"z":[{"a":23},18]},"o":{"a":[{"d":11,"l":{"e":{"s":108}},"r":{"d":12},"s":{"e":0,"t":{"e":6}},"t":{"i":5}},18],"b":{"a":{"b":35,"r":19},"e":{"l":0},"i":[{"n":[{"g":4},24]},29],"r":23,"u":{"l":3},"l":{"i":{"g":189}}},"c":{"e":29,"h":[{"e":{"t":23},"a":{"s":23}},0],"i":{"f":12,"l":21},"l":{"a":{"m":21}},"o":{"d":21},"r":{"a":{"c":3,"t":{"i":{"z":4}}},"e":12,"i":{"t":32}},"t":{"o":{"r":{"a":7}}},"u":{"l":{"a":3},"r":{"e":19}}},"d":{"d":{"e":{"d":4}},"i":{"c":3,"o":11,"t":{"i":{"c":137}}},"o":[{"r":12},139],"u":{"c":{"t":{".":4,"s":4}}},"e":{"l":{"l":{"i":12}}}},"e":{"l":21,"n":{"g":19},"r":[{"s":{"t":257}},23],"t":{"a":1},"v":23},"f":{"i":[{"t":{"e":4,"t":17}},24]},"g":{"a":{"r":121,"t":{"i":{"v":4},"o":21}},"e":[{"n":{"e":19},"o":19,"r":21},29],"i":{"e":23,"s":140,"t":3},"l":[{"y":79},21],"n":{"i":{"z":27}},"r":{"o":21},"u":{"i":5},"y":[{"n":25},41]},"h":[{"a":{"b":6}},74],"i":[{"c":{"e":{"s":11}},"d":{"e":{"r":3}},"f":{"f":17},"g":0,"l":{"e":{"t":4}},"n":{"g":23,"t":{"e":{"r":6}}},"s":{"m":19,"o":{"n":4},"t":{"e":{"n":6}}},"t":{"e":{"r":3}}},9],"j":19,"k":[{"e":{"n":23,"s":{"t":15}},"i":{"e":4}},25],"l":{"a":[{"n":21,"s":{"s":36}},29],"d":[{"e":15},9],"e":{"r":3,"s":{"c":23,"t":{"e":{"r":88}}},"t":23},"f":{"i":1},"i":[{"a":23,"c":{"e":23},"d":{".":4},"f":73,"l":19,"n":{"g":3},"o":19,"s":{".":19,"h":3},"t":{"e":19,"i":{"o":19}},"v":19,"g":{"o":{"p":{"o":258}}}},9],"l":{"i":{"e":17}},"o":{"g":{"i":{"z":4}},"r":0,"n":{"o":{"m":259}}},"p":{"l":4},"t":9,"u":{"b":3,"m":{"e":3},"n":3,"s":19},"v":9,"y":24},"m":{"a":{"h":4,"l":5,"t":{"i":{"z":4}}},"b":{"e":9,"l":1},"e":[{"n":{"a":3},"r":{"s":{"e":4}},"t":[{"r":{"y":4}},21],"c":{"h":{"a":260}}},24],"i":{"a":23,"c":{".":3,"a":3},"d":19,"n":[{"i":19},2]},"m":{"e":{"n":{"d":32}}},"o":{"g":{"e":0},"n":21},"p":{"i":3,"r":{"o":7}}},"n":[{"a":[{"c":1,"n":23},2],"c":[{"i":{"l":27}},2],"d":[{"o":4},25],"e":{"n":23,"s":{"t":4}},"g":{"u":1},"i":{"c":2,"o":23,"s":2,"u":19},"k":{"e":{"y":3}},"o":{"d":{"i":1},"m":{"y":3,"i":{"c":137}},"r":{"m":{"a":23}},"t":{"o":{"n":261}},"u":23},"s":[{"p":{"i":[{"r":{"a":10}},36]},"u":17},3],"t":{"e":{"n":36},"i":[{"f":7},93]},"u":{"m":4},"v":{"a":6}},24],"o":[{"d":{"e":5,"i":5},"k":1,"p":{"i":11},"r":{"d":23},"s":{"t":6}},9],"p":{"a":24,"e":{"d":5,"r":[{"a":[{"g":18},27]},2]},"h":[{"a":{"n":19},"e":{"r":19}},25],"i":{"n":{"g":3},"t":23,"s":{"m":{".":2}}},"o":{"n":19,"s":{"i":21}},"r":29,"u":2,"y":5},"q":29,"r":{"a":[{".":19,"g":83,"l":{"i":{"z":4}},"n":{"g":{"e":4}}},29],"e":{"a":[{"l":19},5],"i":3,"s":{"h":5,"t":{".":4}},"w":17},"g":{"u":1},"i":{"a":56,"c":{"a":3},"l":19,"n":2,"o":29,"t":{"y":3},"u":23},"m":{"i":9},"n":{"e":8},"o":{"f":19,"u":{"g":3}},"p":{"e":4},"r":{"h":27},"s":{"e":[{"n":5},1],"t":17},"t":{"h":{"i":3,"y":3,"o":{"n":{"i":{"t":262}}},"r":{"i":137}},"y":1,"i":{"v":{"e":{"l":{"y":4}}}}},"u":{"m":19},"y":29},"s":{"a":{"l":3},"c":[{"e":1,"o":{"p":[{"i":18},23]},"r":19},9],"i":{"e":95,"t":{"i":{"v":4},"o":3,"y":3},"u":0},"l":1,"o":24,"p":{"a":1,"o":1,"h":{"e":{"r":83}}},"t":{"a":[{"t":{"i":19}},9],"i":{"l":4,"t":4}}},"t":{"a":{"n":21},"e":{"l":{"e":{"g":36}},"r":{".":3,"s":4},"s":[{"t":{"e":{"r":263},"o":{"r":264}}},21]},"h":[{"e":{"s":{"i":5},"o":{"s":265}},"i":14},18],"i":{"c":{".":3,"a":4,"e":23},"f":23,"s":23},"o":{"s":5}},"u":[{"b":{"l":3,"a":{"d":{"o":116}}},"c":{"h":{"i":6}},"e":{"t":4},"l":1,"n":{"c":{"e":{"r":6}},"d":8},"v":4},9],"v":{"e":{"n":1,"r":{"n":{"e":17},"s":12,"t":1}},"i":{"s":23,"t":{"i":36},"a":{"n":{".":266}}},"o":{"l":60}},"w":{"d":{"e":{"r":3}},"e":{"l":3,"s":{"t":4}},"i":2,"n":{"i":5},"o":21},"y":{"a":2},"x":{"i":{"d":{"i":{"c":267}}}}},"p":{"a":[{"c":{"a":1,"e":1,"t":0},"d":21,"g":{"a":{"n":32,"t":23}},"i":[{"n":17},21],"l":[{"m":{"a":{"t":268}}},21],"n":{"a":0,"e":{"l":11},"t":{"y":0},"y":3},"p":[{"u":1},2],"r":{"a":{"b":{"l":6},"g":{"e":5,"r":{"a":269}},"l":{"e":228},"m":[{"e":12},36]},"d":{"i":5},"e":[{"l":5},27],"i":[{"s":0},28]},"t":{"e":[{"r":4},9],"h":{"i":{"c":32},"y":4},"r":{"i":{"c":1}}},"v":0,"y":27},41],"b":43,"d":1,"e":{".":18,"a":[{"r":{"l":17}},138],"c":9,"d":[{"e":27,"i":[{"a":36,"c":0},27]},37],"e":[{"d":0,"v":208},21],"k":0,"l":{"a":1,"i":{"e":17}},"n":{"a":{"n":1},"c":21,"t":{"h":0}},"o":{"n":4},"r":{"a":{".":21,"b":{"l":6},"g":21},"i":[{"s":{"t":6}},21],"m":{"a":{"l":0},"e":7},"n":21,"o":11,"t":{"i":11},"u":4,"v":15},"t":[{"e":{"n":4},"i":{"z":4}},9]},"f":18,"g":18,"h":{".":18,"a":{"r":{"i":6}},"e":{"n":{"o":11},"r":1,"s":{".":1}},"i":{"c":2,"e":32,"n":{"g":4},"s":{"t":{"i":32}},"z":27,"l":{"a":{"n":{"t":168},"t":{"e":{"l":270}}}}},"l":9,"o":{"b":27,"n":{"e":27,"i":32},"r":0},"s":18,"t":3,"u":32,"y":41},"i":{"a":[{"n":17},3],"c":{"i":{"e":1},"y":1,"a":{"d":271}},"d":[{"a":19,"e":3,"i":32},21],"e":{"c":27,"n":3},"g":{"r":{"a":{"p":1}}},"l":{"o":3},"n":[{".":21,"d":17,"o":21},9],"o":[{"n":17},141],"t":{"h":[{"a":4},23],"u":9}},"k":142,"l":[{"a":{"n":27,"s":{"t":6}},"i":{"a":11,"e":{"r":5},"g":18,"n":[{"a":{"r":5}},0],"c":{"a":{"b":208}}},"o":{"i":17},"u":{"m":[{"b":17},0]}},143],"m":43,"n":48,"o":{"c":1,"d":{".":32},"e":{"m":4,"t":144},"g":145,"i":{"n":[{"t":32,"c":{"a":12}},84]},"l":{"y":{"t":6,"e":137,"p":{"h":{"o":{"n":{"o":272}}}}},"e":{".":41}},"n":{"i":1},"p":1,"r":[{"y":1},124],"s":[{"s":15},41],"t":[{"a":1},21],"u":{"n":32}},"p":[{"a":{"r":{"a":5}},"e":[{"d":21,"l":19,"n":23,"r":23,"t":23},24],"o":{"s":{"i":{"t":{"e":5}}}}},43],"r":[{"a":{"y":{"e":17}},"e":{"c":{"i":32,"o":5},"e":{"m":11},"f":{"a":{"c":6}},"l":{"a":0},"r":11,"s":{"e":23,"s":27,"p":{"l":{"i":84}}},"t":{"e":{"n":5}},"v":11,"m":{"a":{"c":273}},"n":{"e":{"u":15}}},"i":{"e":53,"n":{"t":146},"s":[{"o":12},0]},"o":{"c":{"a":23,"e":{"s":{"s":8}},"i":{"t":{"y":{".":274}}}},"f":{"i":{"t":6}},"l":11,"s":{"e":12},"t":15,"g":{"e":208}}},9],"s":[{"e":[{"u":{"d":[{"o":{"d":276,"f":276}},275]}},24],"h":1,"i":{"b":21}},81],"t":[{"a":{"b":134},"e":24,"h":24,"i":{"m":11},"u":{"r":0},"w":21,"o":{"m":{"a":{"t":277}}},"r":{"o":{"l":278}}},42],"u":{"b":[{"e":{"s":{"c":181}}},11],"e":0,"f":0,"l":{"c":11},"m":1,"n":9,"r":{"r":0},"s":32,"t":[{"e":[{"r":11},32],"r":3,"t":{"e":{"d":0},"i":{"n":0}}},9]},"w":23},"q":{"u":[{"a":{"v":5,"i":{"n":{"t":{"e":279}}},"s":{"i":[{"r":281,"s":281},280]}},"e":{".":25,"r":27,"t":27},"i":{"n":{"t":{"e":{"s":{"s":282}}}},"v":{"a":{"r":14}}}},9]},"r":{"a":{"b":[{"i":3,"o":{"l":{"i":{"c":29},"o":{"i":236}}}},25],"c":{"h":{"e":17,"u":3},"l":19},"f":{"f":{"i":5},"t":0},"i":24,"l":{"o":1},"m":{"e":{"t":[{"r":{"i":{"z":283}}},11],"n":24},"i":24,"o":{"u":3}},"n":{"e":{"o":6},"g":{"e":0},"i":21,"o":4,"h":{"a":{"s":167}}},"p":{"e":{"r":11},"h":{"y":27}},"r":{"c":5,"e":[{"f":5},17],"i":{"l":18}},"s":24,"t":{"i":{"o":{"n":115}}},"u":{"t":0},"v":{"a":{"i":4},"e":{"l":11}},"z":{"i":{"e":4}},"d":{"i":{"g":127,"o":{"g":249}}},"o":{"r":2}},"b":[{"a":{"b":21,"g":21},"i":[{"f":0,"n":[{"e":19,"g":{".":4,"e":284}},24]},8],"o":1},29],"c":[{"e":[{"n":17},24],"h":{"a":23,"e":{"r":0}},"i":{"b":90,"t":1},"u":{"m":12}},29],"d":{"a":{"l":21},"i":[{"a":0,"e":{"r":0},"n":[{"g":3},17]},9]},"e":{".":25,"a":{"l":2,"n":3,"r":{"r":4},"v":32,"w":1},"b":{"r":{"a":{"t":19}}},"c":{"o":{"l":{"l":5},"m":{"p":{"e":5}}},"r":{"e":1},"i":{"p":{"r":285}},"t":{"a":{"n":{"g":286}}}},"d":[{"e":2,"i":{"s":3,"t":5}},37],"f":{"a":{"c":1},"e":[{"r":{".":4}},9],"i":3,"y":1},"g":{"i":{"s":11}},"i":{"t":4},"l":{"i":2,"u":4},"n":{"t":{"a":90,"e":0}},"o":2,"p":{"i":{"n":4},"o":{"s":{"i":1}},"u":2},"r":[{"i":21,"o":17,"u":4},147],"s":{".":21,"p":{"i":1},"s":{"i":{"b":6}},"t":[{"a":{"l":4},"r":3},8]},"t":{"e":{"r":1},"i":{"z":96},"r":{"i":[{"b":{"u":85}},3]}},"u":[{"t":{"i":4}},8],"v":[{"a":{"l":1},"e":{"l":11,"r":{".":30,"s":4,"t":4}},"i":{"l":4},"o":{"l":{"u":5}}},8],"w":{"h":1}},"f":[{"u":0,"y":21},29],"g":[{"e":{"r":3,"t":23},"i":{"c":23,"n":[{"g":3},0],"s":19,"t":19},"l":29,"o":{"n":0},"u":23},9],"h":[{".":18,"a":{"l":18}},1],"i":{"a":[{"b":0,"g":1,"l":{".":23}},3],"b":[{"a":11},21],"c":{"a":{"s":5},"e":21,"i":[{"d":32,"e":1},18],"o":21},"d":{"e":{"r":5}},"e":{"n":{"c":3,"t":3},"r":2,"t":4},"g":{"a":{"n":5},"i":32},"l":{"i":{"z":11}},"m":{"a":{"n":32},"i":5,"o":27,"p":{"e":0}},"n":{"a":[{".":32},24],"d":0,"e":0,"g":0},"o":2,"p":{"h":[{"e":6},32],"l":[{"i":{"c":5}},9]},"q":21,"s":[{".":21,"c":0,"h":23,"p":0},24],"t":{"a":{"b":116},"e":{"d":{".":19},"r":{".":5,"s":5}},"i":{"c":11},"u":[{"r":5},9]},"v":{"e":{"l":5,"t":11},"i":11,"o":{"l":287}}},"j":23,"k":{"e":{"t":23},"l":{"e":1,"i":{"n":1}},".":288,"h":{"o":2},"r":{"a":{"u":29}},"s":{".":288}},"l":[{"e":[{"d":24,"q":{"u":30}},0],"i":{"g":21,"s":[{"h":4},21]},"o":73},29],"m":[{"a":{"c":5},"e":[{"n":23,"r":{"s":4}},24],"i":{"n":{"g":[{".":21},3]},"o":21,"t":23},"y":21},29],"n":{"a":{"r":21},"e":{"l":23,"r":21,"t":19,"y":23},"i":{"c":19,"s":92,"t":23,"v":23},"o":[{"u":21},0],"u":23},"o":{"b":{"l":11,"o":{"t":289}},"c":[{"r":3},24],"e":[{"l":{"a":{"s":167}},"p":{"i":{"d":{"e":290}}}},1],"f":{"e":2,"i":{"l":4}},"k":[{"e":{"r":4}},8],"l":{"e":{".":32}},"m":{"e":{"t":{"e":5},"s":{"h":3}},"i":0,"p":0},"n":{"a":{"l":0},"e":0,"i":{"s":134},"t":{"a":0}},"o":{"m":41,"t":32},"p":{"e":{"l":3},"i":{"c":11}},"r":{"i":11,"o":4},"s":{"p":{"e":{"r":5}},"s":0},"t":{"h":{"e":1},"y":1,"r":{"o":{"n":2}}},"v":{"a":1,"e":{"l":5}},"x":5},"p":[{"e":{"a":21,"n":{"t":19},"r":{".":4},"t":23},"h":95,"i":{"n":{"g":3}},"o":23,"a":{"u":{"l":{"i":291}}}},29],"r":[{"e":{"c":0,"f":0,"o":21,"s":{"t":0}},"i":{"o":0,"v":0},"o":{"n":17,"s":17},"y":{"s":17}},72],"s":[{"a":[{"t":{"i":5}},29],"c":1,"e":[{"c":[{"r":0},23],"r":{".":4,"a":{"d":{"i":238}}},"s":3,"v":148},24],"h":[{"a":19},29],"i":[{"b":90},29],"o":{"n":12},"p":29,"w":19},44],"t":{"a":{"c":{"h":36},"g":21},"e":{"b":23,"n":{"d":17},"o":5},"i":[{"b":4,"d":0,"e":{"r":21},"g":23,"l":{"i":12,"l":17,"y":21},"s":{"t":21},"v":21},29],"r":{"i":23,"o":{"p":{"h":115}},"e":{"u":29}},"s":{"h":1},"h":{"o":{"u":29}}},"u":{"a":3,"e":{"l":93,"n":3},"g":{"l":1},"i":{"n":3},"m":{"p":{"l":11}},"n":[{"k":6,"t":{"y":0}},9],"s":{"c":19},"t":{"i":{"n":6}}},"v":{"e":[{"l":{"i":17},"n":23,"r":{".":4},"s":{"t":19},"y":23,"i":{"l":29}},1],"i":{"c":23,"v":0},"o":23},"w":29,"y":{"c":1,"n":{"g":{"e":32}},"t":3},"z":{"s":{"c":2}}},"s":{"a":[{"b":42,"c":{"k":32,"r":{"i":11},"t":23},"i":32,"l":{"a":{"r":36},"m":0,"o":4,"t":0,"e":{"s":{"c":54,"w":7}}},"n":{"c":27,"d":{"e":0}},"p":[{"a":{"r":{"i":{"l":292}}}},29],"t":{"a":4,"i":{"o":76},"u":11},"u":0,"v":{"o":{"r":4}},"w":32},9],"b":56,"c":{"a":{"n":{"t":149},"p":[{"e":{"r":267}},0],"v":6,"t":{"o":{"l":208}}},"e":{"d":21,"i":18,"s":21},"h":[{"o":21,"i":{"t":{"z":21}},"r":{"o":{"d":{"i":{"n":{"g":293}}}}}},8],"i":{"e":68,"n":{"d":150},"u":{"t":{"t":294}}},"l":{"e":6,"i":21},"o":{"f":17,"p":{"y":18},"u":{"r":{"a":7}}},"u":29,"r":{"a":{"p":{"e":{"r":{".":36}}}}},"y":{"t":{"h":247}}},"d":56,"e":{".":18,"a":[{"s":17,"w":5},1],"c":{"o":151,"t":27},"d":[{"e":95,"l":19},125],"g":[{"r":11},9],"i":32,"l":{"e":2,"f":32,"v":32},"m":{"e":[{"s":{"t":295}},18],"o":{"l":1},"a":{"p":{"h":287}},"i":{"t":{"i":{"c":296}}}},"n":{"a":{"t":5},"c":18,"d":0,"e":{"d":19},"g":5,"i":{"n":19},"t":{"d":18,"l":18}},"p":{"a":152,"t":{"e":{"m":{"b":11}}}},"r":{".":43,"l":21,"o":0,"v":{"o":18}},"s":[{"h":4,"t":5},72],"u":{"m":113},"v":[{"e":{"n":11}},32],"w":{"i":0},"x":32},"f":47,"g":48,"h":[{".":25,"e":{"r":2,"v":32},"i":{"n":2,"o":3,"p":27,"v":6},"o":[{"l":{"d":4},"n":12,"r":[{"t":7},17],"e":{"s":{"t":137}}},0],"w":18},24],"i":{"b":2,"c":{"c":19},"d":{"e":{".":27,"s":[{"t":6,"w":6},32],"d":{".":8}},"i":[{"z":4},32]},"g":{"n":{"a":18}},"l":{"e":0,"y":18},"n":[{"a":24,"e":{".":32},"g":23},42],"o":[{"n":[{"a":6},32]},41],"r":[{"a":5,"e":{"s":{"i":{"d":4}}}},9],"s":41,"t":{"i":{"o":27}},"u":32,"v":41,"z":32},"k":[{"e":[{"t":23},18],"i":{"n":{"e":4,"g":4}},"y":{"s":{"c":15}}},9],"l":[{"a":{"t":23},"e":24,"i":{"t":{"h":7}},"o":{"v":{"a":{"k":{"i":{"a":297}}}}}},74],"m":[{"a":[{"l":{"l":54},"n":12},23],"e":{"l":17,"n":19},"i":{"t":{"h":32}},"o":{"l":{"d":49}}},42],"n":72,"o":[{"c":{"e":1},"f":{"t":12},"l":{"a":{"b":1},"d":153,"i":{"c":3},"v":32,"u":{"t":{"e":9}}},"m":27,"n":{".":68,"a":17,"g":0},"p":[{"h":{"i":{"c":32,"z":19},"y":19}},21],"r":{"c":5,"d":5},"v":[{"i":4},18],"g":{"a":{"m":{"y":298}}}},41],"p":{"a":[{"i":32,"n":0,"c":{"e":299,"i":{"n":69}}},25],"e":{"n":{"d":17},"o":57,"r":25,"c":{"i":{"o":11}}},"h":{"e":[{"r":[{"o":213},27]},24],"o":6},"i":{"l":17,"n":{"g":4},"o":18,"c":{"i":{"l":208}}},"l":{"y":21},"o":{"n":21,"r":[{"t":{"s":{"c":300,"w":300}}},17],"t":18,"k":{"e":{"s":{"w":10}}}}},"q":{"u":{"a":{"l":{"l":36}},"i":{"t":{"o":88}}}},"r":29,"s":[{"a":[{"s":12,"c":{"h":{"u":301}}},29],"c":94,"e":{"l":23,"n":{"g":19},"s":{".":21},"t":19},"i":[{"e":[{"r":0},21],"l":{"y":4},"a":{"n":{".":210}},"g":{"n":{"a":{"b":302}}}},29],"l":[{"i":1},21],"n":21,"p":{"e":{"n":{"d":115}}},"t":9,"u":{"r":{"a":6}},"w":4,"h":{"a":{"t":3}}},25],"t":{".":25,"a":{"g":24,"l":24,"m":{"i":17,"p":69},"n":{"d":32,"t":{"s":{"h":{"i":303}}}},"p":90,"t":{".":32,"i":15},"r":{"t":{"l":{"i":12}}}},"e":{"d":21,"r":{"n":{"i":7},"o":19},"w":[{"a":6},8]},"h":{"e":23},"i":[{".":21,"a":19,"c":[{"k":32},29],"e":21,"f":23,"n":{"g":3},"r":32},9],"l":{"e":29},"o":{"c":{"k":32},"m":{"a":12},"n":{"e":32},"p":21,"r":{"e":27,"a":{"b":304}}},"r":[{"a":{"d":21,"t":{"u":32,"a":{"g":305}},"y":21},"i":{"d":21,"b":{"u":{"t":7}}},"y":18},1],"w":61,"y":[{"l":{"i":{"s":137}}},24],"b":4,"s":{"c":{"r":4}},"u":{"p":{"i":{"d":306}}}},"u":[{"a":{"l":2},"b":111,"g":151,"i":{"s":4,"t":12},"l":21,"m":[{"i":11},9],"n":9,"r":9,"p":{"e":{"r":{"e":307}}}},41],"v":18,"w":[{"o":18,"i":{"m":{"m":177}}},9],"y":[{"c":18,"l":27,"n":{"o":5,"c":41},"r":{"i":{"n":4}},"t":{"h":{"i":308}}},21]},"t":{"a":[{".":27,"b":[{"l":{"e":{"s":4}},"o":{"l":{"i":{"z":32,"s":{"m":309}}}}},25],"c":{"i":18},"d":{"o":4},"f":46,"i":{"l":{"o":5}},"l":[{"a":4,"e":{"n":5},"i":11,"k":[{"a":204},18],"l":{"i":{"s":0}},"o":{"g":4}},9],"m":{"o":4,"i":{"n":82}},"n":{"d":{"e":0},"t":{"a":54}},"p":{"e":{"r":4},"l":4,"a":{"t":{"h":310}}},"r":{"a":0,"c":18,"e":18,"i":{"z":3},"r":{"h":311}},"s":{"e":0,"y":4},"t":{"i":{"c":18},"u":{"r":1}},"u":{"n":17},"v":0,"w":25,"x":{"i":{"s":0}},"g":{"o":{"n":{".":3}}}},41],"b":42,"c":[{"h":[{"e":{"t":5},"c":15,"i":{"e":{"r":237}}},21],"r":29},18],"d":43,"e":{".":18,"a":{"d":{"i":17},"t":18,"c":{"h":{"e":{"r":{".":36}}}}},"c":{"e":17,"t":32},"d":[{"i":4},42],"e":41,"g":[{"e":{"r":4},"i":4},0],"l":{".":27,"i":17,"s":32,"e":{"g":84,"r":{"o":249}}},"m":{"a":[{"t":11},154]},"n":{"a":{"n":27},"c":27,"d":27,"e":{"s":18},"t":[{"a":{"g":0}},41]},"o":41,"p":[{"e":4},1],"r":{"c":11,"d":155,"i":[{"e":{"s":5},"s":11,"z":{"a":6},"c":{".":8}},41],"n":{"i":{"t":32}},"v":5,"g":{"e":{"i":312}}},"s":{".":18,"s":[{".":23,"e":{"s":313}},18]},"t":{"h":{"e":6}},"u":27,"x":27,"y":18},"f":42,"g":43,"h":{".":25,"a":{"n":17,"l":{"a":{"m":228}}},"e":[{"a":[{"s":3,"t":5},18],"i":{"s":11},"t":27},9],"i":{"c":{".":4,"a":4},"l":18,"n":{"k":32}},"l":18,"o":{"d":{"e":4,"i":{"c":32},"o":{"n":11}},"o":18,"r":{"i":{"t":6,"z":5}},"g":{"e":{"n":{"i":314}}},"k":{"e":{"r":175}}},"s":25,"y":{"l":{"a":{"n":228}},"s":{"c":11}}},"i":{"a":[{"b":1,"t":{"o":1},"n":{".":70}},41],"b":156,"c":{"k":18,"o":21,"u":157},"d":{"i":32},"e":{"n":27},"f":[{"y":4},8],"g":[{"u":32},25],"l":{"l":{"i":{"n":6}}},"m":[{"p":18,"u":{"l":5}},41],"n":[{"a":24,"e":{".":27},"i":27,"o":{"m":285}},42],"o":[{"c":4,"n":{"e":{"e":6}}},41],"q":32,"s":{"a":3,"e":27,"m":0,"o":4,"p":0,"t":{"i":{"c":{"a":32}}}},"t":{"l":3},"u":1,"v":[{"a":0},41],"z":[{"a":3,"e":{"n":3}},41]},"l":[{"a":[{"n":17},19],"e":{".":27,"d":27,"s":{".":27},"t":{".":19}},"o":19,"i":{"e":{"r":315}}},25],"m":[{"e":0},43],"n":81,"o":[{"b":3,"c":{"r":{"a":{"t":4}}},"d":{"o":18},"f":25,"g":{"r":9},"i":{"c":4},"m":{"a":9,"b":0,"y":3},"n":{"a":{"l":{"i":0},"t":3},"o":18,"y":18},"r":{"a":9,"i":{"e":3,"z":5}},"s":8,"u":{"r":32,"t":18},"w":{"a":{"r":3}},"l":{"o":{"g":{"y":84}}},"t":{"i":{"c":11}}},41],"p":43,"r":{"a":[{"b":11,"c":{"h":5,"i":[{"t":17},36],"t":{"e":17}},"s":17,"v":{"e":{"n":5,"s":158,"r":{"s":[{"a":{"b":317}},15]}}},"i":{"t":{"o":{"r":316}}}},41],"e":{"f":5,"m":[{"i":6},0],"a":{"c":{"h":{"e":318}}}},"i":{"a":[{"l":{".":1}},32],"c":{"e":{"s":5},"i":{"a":32},"s":18},"m":25,"v":0},"o":{"m":{"i":5},"n":{"i":6,"y":18},"p":{"h":{"e":5},"i":{"s":175},"o":{"l":{"e":{"s":320},"i":{"s":320,"t":321}}}},"s":{"p":11},"v":11,"l":{"e":{"u":{"m":319}}},"f":{"i":{"c":{".":17},"t":11}}},"u":{"i":5,"s":17}},"s":[{"c":[{"h":{"i":{"e":12}}},21],"h":0,"w":21},101],"t":[{"e":{"s":21},"o":19,"u":0,"r":{"i":{"b":{"u":{"t":322}}}}},66],"u":[{"a":[{"r":3},2],"b":{"i":1},"d":8,"e":18,"f":46,"i":76,"m":27,"n":{"i":{"s":1}},"p":{".":48},"r":{"e":27,"i":[{"s":11},32],"o":5,"y":4,"n":{"a":{"r":12}}},"s":27},41],"v":18,"w":[{"a":43,"i":{"s":17},"o":18,"h":29},1],"y":[{"a":18,"l":25,"p":{"e":12,"h":4,"a":{"l":64}}},41],"z":[{"e":1},18]},"u":{"a":{"b":18,"c":0,"n":{"a":4,"i":0},"r":{"a":{"n":{"t":5}},"d":8,"i":11,"t":11},"t":29,"v":0,"d":{"r":{"a":{"t":{"i":3,"u":15}}}}},"b":{"e":[{"l":21,"r":[{"o":21},23]},1],"i":[{"n":{"g":33}},72],"l":{"e":{".":23}}},"c":{"a":23,"i":{"b":0,"t":1},"l":{"e":12},"r":23,"u":23,"y":21},"d":{"d":4,"e":{"r":3,"s":{"t":4},"v":17},"i":{"c":29,"e":{"d":3,"s":3},"s":4,"t":19},"o":{"n":[{"y":232},21]},"s":{"i":1},"u":21},"e":{"n":{"e":21,"s":17,"t":{"e":0}},"r":{"i":{"l":0}},"a":{"m":15}},"f":{"a":27,"l":23},"g":{"h":{"e":{"n":11}},"i":{"n":4}},"i":[{"l":{"i":{"z":5}},"n":[{"g":29},1],"r":{"m":0},"t":{"a":17},"v":[{"e":{"r":{".":0}}},11]},156],"j":19,"k":18,"l":{"a":[{"b":5,"t":{"i":19}},29],"c":{"h":[{"e":32},17]},"d":{"e":{"r":3}},"e":[{"n":29},1],"g":{"i":1},"i":[{"a":19,"n":{"g":3},"s":{"h":4}},9],"l":{"a":{"r":1},"i":{"b":96,"s":1}},"m":61,"o":72,"s":[{"e":{"s":5}},18],"t":{"i":2,"r":{"a":54},"u":18},"u":[{"l":4},23],"v":4},"m":{"a":{"b":4},"b":{"i":1,"l":{"y":1}},"i":[{"n":{"g":83}},29],"o":{"r":{"o":6}},"p":9},"n":{"a":{"t":17},"e":[{"r":1},24],"i":[{"m":1,"n":24,"s":{"h":4},"v":11},29],"s":[{"w":1},93],"t":{"a":{"b":11},"e":{"r":{".":1},"s":1}},"u":0,"y":4,"z":4},"o":{"r":{"s":21},"s":19,"u":29},"p":{"e":[{"r":{"s":6}},29],"i":{"a":19,"n":{"g":3}},"l":23,"p":[{"o":{"r":{"t":10}}},3],"t":{"i":{"b":5},"u":17}},"r":{"a":[{".":18,"g":21,"s":21,"l":{".":216}},29],"b":{"e":1},"c":0,"d":2,"e":{"a":{"t":5}},"f":{"e":{"r":1},"r":1},"i":{"f":[{"i":{"c":0}},23],"n":2,"o":23,"t":29,"z":3,"a":{"l":{".":0}}},"l":[{"i":{"n":{"g":{".":5}}}},9],"n":{"o":1},"o":{"s":17},"p":{"e":1,"i":1},"s":{"e":{"r":5}},"t":{"e":{"s":4},"h":{"e":3},"i":[{"e":1},17]},"u":23},"s":[{"a":{"d":19,"n":19,"p":1},"c":[{"i":3},8],"e":{"a":5,"r":{".":9}},"i":{"a":19,"c":23},"l":{"i":{"n":1}},"p":2,"s":{"l":4},"t":{"e":{"r":{"e":4}},"r":2},"u":[{"r":17},24]},25],"t":{"a":{"b":0,"t":23},"e":{".":18,"l":18,"n":[{"i":17},18]},"i":[{"l":{"i":{"z":5}},"n":{"e":23,"g":3},"o":{"n":{"a":7}},"s":21,"z":31},101],"l":34,"o":{"f":4,"g":5,"m":{"a":{"t":{"i":{"c":5}}}},"n":19,"u":21},"s":0},"u":[{"m":1},23],"v":74,"x":{"u":11},"z":{"e":1}},"v":{"a":[{".":32,"b":159,"c":{"i":{"l":5},"u":11},"g":[{"e":1,"u":{"e":{"r":170}}},0],"l":{"i":{"e":4},"o":5,"u":15},"m":{"o":4},"n":{"i":{"z":4}},"p":{"i":4},"r":{"i":{"e":{"d":5}}},"t":[{"i":{"v":29}},27],"u":{"d":{"e":{"v":54}}}},41],"e":{".":18,"d":18,"g":11,"l":{".":23,"l":{"i":11},"o":1,"y":21},"n":{"o":{"m":11},"u":{"e":19}},"r":{"d":21,"e":{".":32,"l":[{"y":{".":41}},21],"n":[{"c":5},23],"s":21,"i":{"g":324}},"i":{"e":11},"m":{"i":{"n":36}},"s":{"e":27},"t":{"h":11}},"s":[{".":18,"t":{"e":0,"i":{"t":{"e":15}}}},99],"t":{"e":[{"r":11},1],"y":1}},"i":{"a":{"l":{"i":4},"n":32},"d":{"e":{".":32,"d":32,"n":47,"s":32},"i":32},"f":23,"g":{"n":4},"k":0,"l":[{"i":{"t":32,"z":127}},25],"n":[{"a":26,"c":24,"d":5,"g":18},29],"o":{"l":11,"r":73,"u":2},"p":1,"r":{"o":4},"s":{"i":{"t":11},"o":3,"u":3},"t":{"i":18,"r":11,"y":18},"v":[{"i":{"p":{"a":{"r":325}}}},27]},"o":{".":32,"i":[{"r":{"d":{"u":323}},"c":{"e":{"p":213}}},0],"k":27,"l":{"a":1,"e":19,"t":32,"v":27},"m":{"i":5},"r":{"a":{"b":5},"i":17,"y":1},"t":{"a":1,"e":{"e":18}}},"v":26,"y":21},"w":{"a":{"b":{"l":19},"c":25,"g":{"e":{"r":4},"o":5},"i":{"t":6},"l":{".":19},"m":0,"r":{"t":0},"s":{"t":[{"e":{"w":{"a":326}}},0]},"t":{"e":2},"v":{"e":{"r":4,"g":327}}},"b":29,"e":{"a":{"r":{"i":{"e":5}},"t":{"h":54}},"d":{"n":0},"e":{"t":12,"v":5,"k":{"n":137}},"l":{"l":0},"r":29,"s":{"t":12},"v":23},"h":{"i":0},"i":[{"l":[{"l":{"i":{"n":6}}},8],"n":{"d":{"e":0},"g":0},"r":0,"s":{"e":27},"t":{"h":12},"z":5,"d":{"e":{"s":{"p":6}}}},9],"k":21,"l":{"e":{"s":1},"i":{"n":3}},"n":{"o":21},"o":[{"m":15,"v":{"e":{"n":4}},"k":{"e":{"n":85}}},160],"p":19,"r":{"a":[{"p":{"a":{"r":{"o":12}}}},0],"i":[{"t":{"a":36,"e":{"r":{".":183}}}},0]},"s":{"h":23,"l":1,"p":{"e":1},"t":60},"t":18,"y":1,"c":23},"x":{"a":[{"c":{"e":5},"g":{"o":21},"m":11,"p":21,"s":5},29],"c":161,"e":[{"c":{"u":{"t":{"o":1}}},"d":24,"r":{"i":0,"o":4}},29],"h":[{"i":[{"l":6},8],"u":0},29],"i":[{"a":4,"c":4,"d":{"i":4},"m":{"e":21,"i":{"z":4}}},23],"o":[{"b":21},23],"p":[{"a":{"n":{"d":17}},"e":{"c":{"t":{"o":10}},"d":11}},23],"t":[{"i":23},74],"u":[{"a":3},29],"x":1,"q":[{"u":{"i":{"s":54}}},29]},"y":{"a":{"c":19,"r":110,"t":19},"b":29,"c":[{"e":[{"r":4},24],"h":[{"e":[{"d":264},0]},23],"o":{"m":17,"t":17}},29],"d":29,"e":{"e":19,"r":[{"f":21},29],"s":[{"t":{"e":{"r":{"y":328}}}},0],"t":1},"g":{"i":19},"h":47,"i":29,"l":{"a":23,"l":{"a":{"b":{"l":6}}},"o":23,"u":19},"m":{"b":{"o":{"l":7}},"e":[{"t":{"r":{"y":20}}},0],"p":{"a":12}},"n":{"c":{"h":{"r":3}},"d":4,"g":4,"i":{"c":4},"x":32},"o":[{"d":4,"g":33,"m":0,"n":{"e":{"t":4},"s":21},"s":21},72],"p":{"e":{"d":21,"r":6},"i":3,"o":[{"c":21},23],"t":{"a":9},"u":19},"r":{"a":{"m":5},"i":{"a":4},"o":23,"r":1},"s":{"c":1,"e":161,"i":{"c":{"a":3},"o":3,"s":27},"o":21,"s":0,"t":[{"a":3,"r":{"o":29}},2],"u":{"r":17}},"t":{"h":{"i":{"n":23}},"i":{"c":3}},"w":29},"z":{"a":[{"b":79,"r":8},2],"b":18,"e":[{"n":1,"p":1,"r":[{"o":3},29],"t":0},25],"i":[{"l":21,"s":21,"a":{"n":{".":23}}},42],"l":32,"m":18,"o":[{"m":1,"o":{"l":4},"p":{"h":{"r":329}}},41],"t":{"e":0},"z":[{"y":21,"w":231},101]}}',
        [
            "as-so-ciate",
            "as-so-ciates",
            "dec-li-na-tion",
            "oblig-a-tory",
            "phil-an-thropic",
            "present",
            "presents",
            "project",
            "projects",
            "reci-procity",
            "re-cog-ni-zance",
            "ref-or-ma-tion",
            "ret-ri-bu-tion",
            "ta-ble"
        ]
    ];
});
}),
"[project]/node_modules/@react-pdf/textkit/lib/textkit.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "bidi",
    ()=>bidiEngine,
    "default",
    ()=>layoutEngine,
    "fontSubstitution",
    ()=>fontSubstitution,
    "fromFragments",
    ()=>fromFragments,
    "justification",
    ()=>justification,
    "linebreaker",
    ()=>linebreaker,
    "scriptItemizer",
    ()=>scriptItemizer,
    "textDecoration",
    ()=>textDecoration,
    "wordHyphenation",
    ()=>wordHyphenation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/fns/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bidi$2d$js$2f$dist$2f$bidi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bidi-js/dist/bidi.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$unicode$2d$properties$2f$dist$2f$module$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/unicode-properties/dist/module.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hyphen$2f$hyphen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hyphen/hyphen.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hyphen$2f$patterns$2f$en$2d$us$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/hyphen/patterns/en-us.js [app-client] (ecmascript)");
;
;
;
;
;
/**
 * Create attributed string from text fragments
 *
 * @param fragments - Fragments
 * @returns Attributed string
 */ const fromFragments = (fragments)=>{
    let offset = 0;
    let string = '';
    const runs = [];
    fragments.forEach((fragment)=>{
        string += fragment.string;
        runs.push({
            ...fragment,
            start: offset,
            end: offset + fragment.string.length,
            attributes: fragment.attributes || {}
        });
        offset += fragment.string.length;
    });
    return {
        string,
        runs
    };
};
/**
 * Default word hyphenation engine used when no one provided.
 * Does not perform word hyphenation at all
 *
 * @param word
 * @returns Same word
 */ const defaultHyphenationEngine = (word)=>[
        word
    ];
/**
 * Wrap words of attribute string
 *
 * @param engines layout engines
 * @param options layout options
 */ const wrapWords = (engines = {}, options = {})=>{
    /**
     * @param attributedString - Attributed string
     * @returns Attributed string including syllables
     */ return (attributedString)=>{
        const syllables = [];
        const fragments = [];
        const hyphenateWord = options.hyphenationCallback || engines.wordHyphenation?.() || defaultHyphenationEngine;
        for(let i = 0; i < attributedString.runs.length; i += 1){
            let string = '';
            const run = attributedString.runs[i];
            const words = attributedString.string.slice(run.start, run.end).split(/([ ]+)/g).filter(Boolean);
            for(let j = 0; j < words.length; j += 1){
                const word = words[j];
                const parts = hyphenateWord(word);
                syllables.push(...parts);
                string += parts.join('');
            }
            fragments.push({
                ...run,
                string
            });
        }
        const result = {
            ...fromFragments(fragments),
            syllables
        };
        return result;
    };
};
/**
 * Clone rect
 *
 * @param rect - Rect
 * @returns Cloned rect
 */ const copy = (rect)=>{
    return Object.assign({}, rect);
};
/**
 * Partition rect in two in the vertical direction
 *
 * @param rect - Rect
 * @param height - Height
 * @returns Partitioned rects
 */ const partition = (rect, height)=>{
    const a = Object.assign({}, rect, {
        height
    });
    const b = Object.assign({}, rect, {
        y: rect.y + height,
        height: rect.height - height
    });
    return [
        a,
        b
    ];
};
/**
 * Crop upper section of rect
 *
 * @param height - Height
 * @param rect - Rect
 * @returns Cropped rect
 */ const crop = (height, rect)=>{
    const [, result] = partition(rect, height);
    return result;
};
/**
 * Get paragraph block height
 *
 * @param paragraph - Paragraph
 * @returns Paragraph block height
 */ const height$2 = (paragraph)=>{
    return paragraph.reduce((acc, block)=>acc + block.box.height, 0);
};
/**
 * Calculate run scale
 *
 * @param run - Run
 * @returns Scale
 */ const calculateScale = (run)=>{
    const attributes = run.attributes || {};
    const fontSize = attributes.fontSize || 12;
    const font = attributes.font;
    const unitsPerEm = typeof font === 'string' ? null : font?.[0]?.unitsPerEm;
    return unitsPerEm ? fontSize / unitsPerEm : 0;
};
/**
 * Get run scale
 *
 * @param  run
 * @returns Scale
 */ const scale = (run)=>{
    return run.attributes?.scale || calculateScale(run);
};
/**
 * Get ligature offset by index
 *
 * Ex. ffi ligature
 *
 *   glyphs:         l  o  f  f  i  m
 *   glyphIndices:   0  1  2  2  2  3
 *   offset:         0  0  0  1  2  0
 *
 * @param index
 * @param run - Run
 * @returns Ligature offset
 */ const offset = (index, run)=>{
    if (!run) return 0;
    const glyphIndices = run.glyphIndices || [];
    const value = glyphIndices[index];
    return glyphIndices.slice(0, index).filter((i)=>i === value).length;
};
/**
 * Get run font
 *
 * @param run - Run
 * @returns Font
 */ const getFont = (run)=>{
    return run.attributes?.font?.[0] || null;
};
/**
 * Slice glyph between codePoints range
 * Util for breaking ligatures
 *
 * @param start - Start code point index
 * @param end - End code point index
 * @param font - Font to generate new glyph
 * @param glyph - Glyph to be sliced
 * @returns Sliced glyph parts
 */ const slice$2 = (start, end, font, glyph)=>{
    if (!glyph) return [];
    if (start === end) return [];
    if (start === 0 && end === glyph.codePoints.length) return [
        glyph
    ];
    const codePoints = glyph.codePoints.slice(start, end);
    const string = String.fromCodePoint(...codePoints);
    // passing LTR To force fontkit to not reverse the string
    return font ? font.layout(string, undefined, undefined, undefined, 'ltr').glyphs : [
        glyph
    ];
};
/**
 * Return glyph index at string index, if glyph indices present.
 * Otherwise return string index
 *
 * @param index - Index
 * @param run - Run
 * @returns Glyph index
 */ const glyphIndexAt = (index, run)=>{
    const result = run?.glyphIndices?.[index];
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(result) ? index : result;
};
/**
 * Returns new array starting with zero, and keeping same relation between consecutive values
 *
 * @param array - List
 * @returns Normalized array
 */ const normalize = (array)=>{
    const head = array[0];
    return array.map((value)=>value - head);
};
/**
 * Slice run between glyph indices range
 *
 * @param start - Glyph index
 * @param end - Glyph index
 * @param run - Run
 * @returns Sliced run
 */ const slice$1 = (start, end, run)=>{
    const runScale = scale(run);
    const font = getFont(run);
    // Get glyph start and end indices
    const startIndex = glyphIndexAt(start, run);
    const endIndex = glyphIndexAt(end, run);
    // Get start and end glyph
    const startGlyph = run.glyphs?.[startIndex];
    const endGlyph = run.glyphs?.[endIndex];
    // Get start ligature chunks (if any)
    const startOffset = offset(start, run);
    const startGlyphs = startOffset > 0 ? slice$2(startOffset, Infinity, font, startGlyph) : [];
    // Get end ligature chunks (if any)
    const endOffset = offset(end, run);
    const endGlyphs = slice$2(0, endOffset, font, endGlyph);
    // Compute new glyphs
    const sliceStart = startIndex + Math.min(1, startOffset);
    const glyphs = (run.glyphs || []).slice(sliceStart, endIndex);
    // Compute new positions
    const glyphPosition = (g)=>({
            xAdvance: g.advanceWidth * runScale,
            yAdvance: 0,
            xOffset: 0,
            yOffset: 0
        });
    const startPositions = startGlyphs.map(glyphPosition);
    const positions = (run.positions || []).slice(sliceStart, endIndex);
    const endPositions = endGlyphs.map(glyphPosition);
    return Object.assign({}, run, {
        start: run.start + start,
        end: Math.min(run.end, run.start + end),
        glyphIndices: normalize((run.glyphIndices || []).slice(start, end)),
        glyphs: [
            startGlyphs,
            glyphs,
            endGlyphs
        ].flat(),
        positions: [
            startPositions,
            positions,
            endPositions
        ].flat()
    });
};
/**
 * Get run index that contains passed index
 *
 * @param index - Index
 * @param runs - Runs
 * @returns Run index
 */ const runIndexAt$1 = (index, runs)=>{
    if (!runs) return -1;
    return runs.findIndex((run)=>run.start <= index && index < run.end);
};
/**
 * Filter runs contained between start and end
 *
 * @param start
 * @param end
 * @param runs
 * @returns Filtered runs
 */ const filter = (start, end, runs)=>{
    const startIndex = runIndexAt$1(start, runs);
    const endIndex = Math.max(runIndexAt$1(end - 1, runs), startIndex);
    return runs.slice(startIndex, endIndex + 1);
};
/**
 * Subtract scalar to run
 *
 * @param index - Scalar
 * @param run - Run
 * @returns Subtracted run
 */ const subtract = (index, run)=>{
    const start = run.start - index;
    const end = run.end - index;
    return Object.assign({}, run, {
        start,
        end
    });
};
/**
 * Slice array of runs
 *
 * @param start - Offset
 * @param end - Offset
 * @param runs
 * @returns Sliced runs
 */ const sliceRuns = (start, end, runs)=>{
    const sliceFirstRun = (a)=>slice$1(start - a.start, end - a.start, a);
    const sliceLastRun = (a)=>slice$1(0, end - a.start, a);
    return runs.map((run, i)=>{
        let result = run;
        const isFirst = i === 0;
        const isLast = !isFirst && i === runs.length - 1;
        if (isFirst) result = sliceFirstRun(run);
        if (isLast) result = sliceLastRun(run);
        return subtract(start, result);
    });
};
/**
 * Slice attributed string between two indices
 *
 * @param start - Offset
 * @param end - Offset
 * @param attributedString - Attributed string
 * @returns Attributed string
 */ const slice = (start, end, attributedString)=>{
    if (attributedString.string.length === 0) return attributedString;
    const string = attributedString.string.slice(start, end);
    const filteredRuns = filter(start, end, attributedString.runs);
    const slicedRuns = sliceRuns(start, end, filteredRuns);
    return Object.assign({}, attributedString, {
        string,
        runs: slicedRuns
    });
};
const findCharIndex = (string)=>{
    return string.search(/\S/g);
};
const findLastCharIndex = (string)=>{
    const match = string.match(/\S/g);
    return match ? string.lastIndexOf(match[match.length - 1]) : -1;
};
/**
 * Removes (strips) whitespace from both ends of the attributted string.
 *
 * @param attributedString - Attributed string
 * @returns Attributed string
 */ const trim = (attributedString)=>{
    const start = findCharIndex(attributedString.string);
    const end = findLastCharIndex(attributedString.string);
    return slice(start, end + 1, attributedString);
};
/**
 * Returns empty run
 *
 * @returns Empty run
 */ const empty$1 = ()=>{
    return {
        start: 0,
        end: 0,
        glyphIndices: [],
        glyphs: [],
        positions: [],
        attributes: {}
    };
};
/**
 * Check if value is a number
 *
 * @param value - Value to check
 * @returns Whether value is a number
 */ const isNumber = (value)=>{
    return typeof value === 'number';
};
/**
 * Append glyph indices with given length
 *
 * Ex. appendIndices(3, [0, 1, 2, 2]) => [0, 1, 2, 2, 3, 3, 3]
 *
 * @param length - Length
 * @param indices - Glyph indices
 * @returns Extended glyph indices
 */ const appendIndices = (length, indices)=>{
    const lastIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(indices);
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(lastIndex) ? 0 : lastIndex + 1;
    const newIndices = Array(length).fill(value);
    return indices.concat(newIndices);
};
/**
 * Get glyph for a given code point
 *
 * @param value - CodePoint
 * @param font - Font
 * @returns Glyph
 * */ const fromCodePoint = (value, font)=>{
    if (typeof font === 'string') return null;
    return font && value ? font.glyphForCodePoint(value) : null;
};
/**
 * Append glyph to run
 *
 * @param glyph - Glyph
 * @param run - Run
 * @returns Run with glyph
 */ const appendGlyph = (glyph, run)=>{
    const glyphLength = glyph.codePoints?.length || 0;
    const end = run.end + glyphLength;
    const glyphs = run.glyphs.concat(glyph);
    const glyphIndices = appendIndices(glyphLength, run.glyphIndices);
    if (!run.positions) return Object.assign({}, run, {
        end,
        glyphs,
        glyphIndices
    });
    const positions = run.positions.concat({
        xAdvance: glyph.advanceWidth * scale(run),
        yAdvance: 0,
        xOffset: 0,
        yOffset: 0
    });
    return Object.assign({}, run, {
        end,
        glyphs,
        glyphIndices,
        positions
    });
};
/**
 * Append glyph or code point to run
 *
 * @param value - Glyph or codePoint
 * @param run - Run
 * @returns Run with glyph
 */ const append$1 = (value, run)=>{
    if (!value) return run;
    const font = getFont(run);
    const glyph = isNumber(value) ? fromCodePoint(value, font) : value;
    return appendGlyph(glyph, run);
};
/**
 * Get string from array of code points
 *
 * @param codePoints - Points
 * @returns String
 */ const stringFromCodePoints = (codePoints)=>{
    return String.fromCodePoint(...codePoints || []);
};
/**
 * Append glyph into last run of attributed string
 *
 * @param glyph - Glyph or code point
 * @param attributedString - Attributed string
 * @returns Attributed string with new glyph
 */ const append = (glyph, attributedString)=>{
    const codePoints = typeof glyph === 'number' ? [
        glyph
    ] : glyph?.codePoints;
    const codePointsString = stringFromCodePoints(codePoints || []);
    const string = attributedString.string + codePointsString;
    const firstRuns = attributedString.runs.slice(0, -1);
    const lastRun = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(attributedString.runs) || empty$1();
    const runs = firstRuns.concat(append$1(glyph, lastRun));
    return Object.assign({}, attributedString, {
        string,
        runs
    });
};
const ELLIPSIS_UNICODE = 8230;
const ELLIPSIS_STRING = String.fromCharCode(ELLIPSIS_UNICODE);
/**
 * Get ellipsis codepoint. This may be different in standard and embedded fonts
 *
 * @param font
 * @returns Ellipsis codepoint
 */ const getEllipsisCodePoint = (font)=>{
    if (!font.encode) return ELLIPSIS_UNICODE;
    const [codePoints] = font.encode(ELLIPSIS_STRING);
    return parseInt(codePoints[0], 16);
};
/**
 * Trucante block with ellipsis
 *
 * @param paragraph - Paragraph
 * @returns Sliced paragraph
 */ const truncate = (paragraph)=>{
    const runs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(paragraph)?.runs || [];
    const font = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(runs)?.attributes?.font[0];
    if (font) {
        const index = paragraph.length - 1;
        const codePoint = getEllipsisCodePoint(font);
        const glyph = font.glyphForCodePoint(codePoint);
        const lastBlock = append(glyph, trim(paragraph[index]));
        return Object.assign([], paragraph, {
            [index]: lastBlock
        });
    }
    return paragraph;
};
/**
 * Omit attribute from run
 *
 * @param value - Attribute key
 * @param run - Run
 * @returns Run without ommited attribute
 */ const omit = (value, run)=>{
    const attributes = Object.assign({}, run.attributes);
    delete attributes[value];
    return Object.assign({}, run, {
        attributes
    });
};
/**
 * Get run ascent
 *
 * @param run - Run
 * @returns Ascent
 */ const ascent$1 = (run)=>{
    const { font, attachment } = run.attributes;
    const attachmentHeight = attachment?.height || 0;
    const fontAscent = typeof font === 'string' ? 0 : font?.[0]?.ascent || 0;
    return Math.max(attachmentHeight, fontAscent * scale(run));
};
/**
 * Get run descent
 *
 * @param run - Run
 * @returns Descent
 */ const descent = (run)=>{
    const font = run.attributes?.font;
    const fontDescent = typeof font === 'string' ? 0 : font?.[0]?.descent || 0;
    return scale(run) * fontDescent;
};
/**
 * Get run lineGap
 *
 * @param run - Run
 * @returns LineGap
 */ const lineGap = (run)=>{
    const font = run.attributes?.font;
    const lineGap = typeof font === 'string' ? 0 : font?.[0]?.lineGap || 0;
    return lineGap * scale(run);
};
/**
 * Get run height
 *
 * @param run - Run
 * @returns Height
 */ const height$1 = (run)=>{
    const lineHeight = run.attributes?.lineHeight;
    return lineHeight || lineGap(run) + ascent$1(run) - descent(run);
};
/**
 * Returns attributed string height
 *
 * @param attributedString - Attributed string
 * @returns Height
 */ const height = (attributedString)=>{
    const reducer = (acc, run)=>Math.max(acc, height$1(run));
    return attributedString.runs.reduce(reducer, 0);
};
/**
 * Checks if two rects intersect each other
 *
 * @param a - Rect A
 * @param b - Rect B
 * @returns Whether rects intersect
 */ const intersects = (a, b)=>{
    const x = Math.max(a.x, b.x);
    const num1 = Math.min(a.x + a.width, b.x + b.width);
    const y = Math.max(a.y, b.y);
    const num2 = Math.min(a.y + a.height, b.y + b.height);
    return num1 >= x && num2 >= y;
};
const getLineFragment = (lineRect, excludeRect)=>{
    if (!intersects(excludeRect, lineRect)) return [
        lineRect
    ];
    const eStart = excludeRect.x;
    const eEnd = excludeRect.x + excludeRect.width;
    const lStart = lineRect.x;
    const lEnd = lineRect.x + lineRect.width;
    const a = Object.assign({}, lineRect, {
        width: eStart - lStart
    });
    const b = Object.assign({}, lineRect, {
        x: eEnd,
        width: lEnd - eEnd
    });
    return [
        a,
        b
    ].filter((r)=>r.width > 0);
};
const getLineFragments = (rect, excludeRects)=>{
    let fragments = [
        rect
    ];
    for(let i = 0; i < excludeRects.length; i += 1){
        const excludeRect = excludeRects[i];
        fragments = fragments.reduce((acc, fragment)=>{
            const pieces = getLineFragment(fragment, excludeRect);
            return acc.concat(pieces);
        }, []);
    }
    return fragments;
};
const generateLineRects = (container, height)=>{
    const { excludeRects, ...rect } = container;
    if (!excludeRects) return [
        rect
    ];
    const lineRects = [];
    const maxY = Math.max(...excludeRects.map((r)=>r.y + r.height));
    let currentRect = rect;
    while(currentRect.y < maxY){
        const [lineRect, rest] = partition(currentRect, height);
        const lineRectFragments = getLineFragments(lineRect, excludeRects);
        currentRect = rest;
        lineRects.push(...lineRectFragments);
    }
    return [
        ...lineRects,
        currentRect
    ];
};
const ATTACHMENT_CODE$1 = '\ufffc'; // 65532
/**
 * Remove attachment attribute if no char present
 *
 * @param line - Line
 * @returns Line
 */ const purgeAttachments = (line)=>{
    const shouldPurge = !line.string.includes(ATTACHMENT_CODE$1);
    if (!shouldPurge) return line;
    const runs = line.runs.map((run)=>omit('attachment', run));
    return Object.assign({}, line, {
        runs
    });
};
/**
 * Layout paragraphs inside rectangle
 *
 * @param rects - Rects
 * @param lines - Attributed strings
 * @param indent
 * @returns layout blocks
 */ const layoutLines = (rects, lines, indent)=>{
    let rect = rects.shift();
    let currentY = rect.y;
    return lines.map((line, i)=>{
        const lineIndent = i === 0 ? indent : 0;
        const style = line.runs?.[0]?.attributes || {};
        const height$1 = Math.max(height(line), style.lineHeight);
        if (currentY + height$1 > rect.y + rect.height && rects.length > 0) {
            rect = rects.shift();
            currentY = rect.y;
        }
        const newLine = {
            string: line.string,
            runs: line.runs,
            box: {
                x: rect.x + lineIndent,
                y: currentY,
                width: rect.width - lineIndent,
                height: height$1
            }
        };
        currentY += height$1;
        return purgeAttachments(newLine);
    });
};
/**
 * Performs line breaking and layout
 *
 * @param engines - Engines
 * @param options - Layout options
 */ const layoutParagraph = (engines, options = {})=>{
    /**
     * @param container - Container
     * @param paragraph - Attributed string
     * @returns Layout block
     */ return (container, paragraph)=>{
        const height$1 = height(paragraph);
        const indent = paragraph.runs?.[0]?.attributes?.indent || 0;
        const rects = generateLineRects(container, height$1);
        const availableWidths = rects.map((r)=>r.width);
        availableWidths.unshift(availableWidths[0] - indent);
        const lines = engines.linebreaker(options)(paragraph, availableWidths);
        return layoutLines(rects, lines, indent);
    };
};
/**
 * Slice block at given height
 *
 * @param height - Height
 * @param paragraph - Paragraph
 * @returns Sliced paragraph
 */ const sliceAtHeight = (height, paragraph)=>{
    const newBlock = [];
    let counter = 0;
    for(let i = 0; i < paragraph.length; i += 1){
        const line = paragraph[i];
        counter += line.box.height;
        if (counter < height) {
            newBlock.push(line);
        } else {
            break;
        }
    }
    return newBlock;
};
/**
 * Layout paragraphs inside container until it does not
 * fit anymore, performing line wrapping in the process.
 *
 * @param  engines - Engines
 * @param  options - Layout options
 * @param container - Container
 */ const typesetter = (engines, options, container)=>{
    /**
     * @param attributedStrings - Attributed strings (paragraphs)
     * @returns Paragraph blocks
     */ return (attributedStrings)=>{
        const result = [];
        const paragraphs = [
            ...attributedStrings
        ];
        const layout = layoutParagraph(engines, options);
        const maxLines = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(container.maxLines) ? Infinity : container.maxLines;
        const truncateEllipsis = container.truncateMode === 'ellipsis';
        let linesCount = maxLines;
        let paragraphRect = copy(container);
        let nextParagraph = paragraphs.shift();
        while(linesCount > 0 && nextParagraph){
            const paragraph = layout(paragraphRect, nextParagraph);
            const slicedBlock = paragraph.slice(0, linesCount);
            const linesHeight = height$2(slicedBlock);
            const shouldTruncate = truncateEllipsis && paragraph.length !== slicedBlock.length;
            linesCount -= slicedBlock.length;
            if (paragraphRect.height >= linesHeight) {
                result.push(shouldTruncate ? truncate(slicedBlock) : slicedBlock);
                paragraphRect = crop(linesHeight, paragraphRect);
                nextParagraph = paragraphs.shift();
            } else {
                result.push(truncate(sliceAtHeight(paragraphRect.height, slicedBlock)));
                break;
            }
        }
        return result;
    };
};
/**
 * Get attributed string start value
 *
 * @param attributedString - Attributed string
 * @returns Start
 */ const start = (attributedString)=>{
    const { runs } = attributedString;
    return runs.length === 0 ? 0 : runs[0].start;
};
/**
 * Get attributed string end value
 *
 * @param attributedString - Attributed string
 * @returns End
 */ const end = (attributedString)=>{
    const { runs } = attributedString;
    return runs.length === 0 ? 0 : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(runs).end;
};
/**
 * Get attributed string length
 *
 * @param attributedString - Attributed string
 * @returns End
 */ const length$1 = (attributedString)=>{
    return end(attributedString) - start(attributedString);
};
const bidi$2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bidi$2d$js$2f$dist$2f$bidi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
const getBidiLevels$1 = (runs)=>{
    return runs.reduce((acc, run)=>{
        const length = run.end - run.start;
        const levels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["repeat"])(run.attributes.bidiLevel, length);
        return acc.concat(levels);
    }, []);
};
const getReorderedIndices = (string, segments)=>{
    // Fill an array with indices
    const indices = [];
    for(let i = 0; i < string.length; i += 1){
        indices[i] = i;
    }
    // Reverse each segment in order
    segments.forEach(([start, end])=>{
        const slice = indices.slice(start, end + 1);
        for(let i = slice.length - 1; i >= 0; i -= 1){
            indices[end - i] = slice[i];
        }
    });
    return indices;
};
const getItemAtIndex = (runs, objectName, index)=>{
    for(let i = 0; i < runs.length; i += 1){
        const run = runs[i];
        const updatedIndex = run.glyphIndices[index - run.start];
        if (index >= run.start && index < run.end) {
            return run[objectName][updatedIndex];
        }
    }
    throw new Error(`index ${index} out of range`);
};
const reorderLine = (line)=>{
    const levels = getBidiLevels$1(line.runs);
    const direction = line.runs[0]?.attributes.direction;
    const level = direction === 'rtl' ? 1 : 0;
    const end = length$1(line) - 1;
    const paragraphs = [
        {
            start: 0,
            end,
            level
        }
    ];
    const embeddingLevels = {
        paragraphs,
        levels
    };
    const segments = bidi$2.getReorderSegments(line.string, embeddingLevels);
    // No need for bidi reordering
    if (segments.length === 0) return line;
    const indices = getReorderedIndices(line.string, segments);
    const updatedString = bidi$2.getReorderedString(line.string, embeddingLevels);
    const updatedRuns = line.runs.map((run)=>{
        const selectedIndices = indices.slice(run.start, run.end);
        const updatedGlyphs = [];
        const updatedPositions = [];
        const addedGlyphs = new Set();
        for(let i = 0; i < selectedIndices.length; i += 1){
            const index = selectedIndices[i];
            const glyph = getItemAtIndex(line.runs, 'glyphs', index);
            if (addedGlyphs.has(glyph.id)) continue;
            updatedGlyphs.push(glyph);
            updatedPositions.push(getItemAtIndex(line.runs, 'positions', index));
            if (glyph.isLigature) {
                addedGlyphs.add(glyph.id);
            }
        }
        return {
            ...run,
            glyphs: updatedGlyphs,
            positions: updatedPositions
        };
    });
    return {
        box: line.box,
        runs: updatedRuns,
        string: updatedString
    };
};
const reorderParagraph = (paragraph)=>paragraph.map(reorderLine);
/**
 * Perform bidi reordering
 *
 * @returns Reordered paragraphs
 */ const bidiReordering = ()=>{
    /**
     * @param paragraphs - Paragraphs
     * @returns Reordered paragraphs
     */ return (paragraphs)=>paragraphs.map(reorderParagraph);
};
const DUMMY_CODEPOINT = 123;
/**
 * Resolve string indices based on glyphs code points
 *
 * @param glyphs
 * @returns Glyph indices
 */ const resolve = (glyphs = [])=>{
    return glyphs.reduce((acc, glyph)=>{
        const codePoints = glyph?.codePoints || [
            DUMMY_CODEPOINT
        ];
        if (acc.length === 0) return codePoints.map(()=>0);
        const last = acc[acc.length - 1];
        const next = codePoints.map(()=>last + 1);
        return [
            ...acc,
            ...next
        ];
    }, []);
};
const getCharacterSpacing = (run)=>{
    return run.attributes?.characterSpacing || 0;
};
/**
 * Scale run positions
 *
 * @param  run
 * @param  positions
 * @returns Scaled positions
 */ const scalePositions = (run, positions)=>{
    const runScale = scale(run);
    const characterSpacing = getCharacterSpacing(run);
    return positions.map((position, i)=>{
        const isLast = i === positions.length;
        const xSpacing = isLast ? 0 : characterSpacing;
        return Object.assign({}, position, {
            xAdvance: position.xAdvance * runScale + xSpacing,
            yAdvance: position.yAdvance * runScale,
            xOffset: position.xOffset * runScale,
            yOffset: position.yOffset * runScale
        });
    });
};
/**
 * Create glyph run
 *
 * @param string string
 */ const layoutRun = (string)=>{
    /**
     * @param run - Run
     * @returns Glyph run
     */ return (run)=>{
        const { start, end, attributes = {} } = run;
        const { font } = attributes;
        if (!font) return {
            ...run,
            glyphs: [],
            glyphIndices: [],
            positions: []
        };
        const runString = string.slice(start, end);
        if (typeof font === 'string') throw new Error('Invalid font');
        // passing LTR To force fontkit to not reverse the string
        const glyphRun = font[0].layout(runString, undefined, undefined, undefined, 'ltr');
        const positions = scalePositions(run, glyphRun.positions);
        const glyphIndices = resolve(glyphRun.glyphs);
        const result = {
            ...run,
            positions,
            glyphIndices,
            glyphs: glyphRun.glyphs
        };
        return result;
    };
};
/**
 * Generate glyphs for single attributed string
 */ const generateGlyphs = ()=>{
    /**
     * @param attributedString - Attributed string
     * @returns Attributed string with glyphs
     */ return (attributedString)=>{
        const runs = attributedString.runs.map(layoutRun(attributedString.string));
        const res = Object.assign({}, attributedString, {
            runs
        });
        return res;
    };
};
/**
 * Resolves yOffset for run
 *
 * @param run - Run
 * @returns Run
 */ const resolveRunYOffset = (run)=>{
    if (!run.positions) return run;
    const unitsPerEm = run.attributes?.font?.[0]?.unitsPerEm || 0;
    const yOffset = (run.attributes?.yOffset || 0) * unitsPerEm;
    const positions = run.positions.map((p)=>Object.assign({}, p, {
            yOffset
        }));
    return Object.assign({}, run, {
        positions
    });
};
/**
 * Resolves yOffset for multiple paragraphs
 */ const resolveYOffset = ()=>{
    /**
     * @param attributedString - Attributed string
     * @returns Attributed string
     */ return (attributedString)=>{
        const runs = attributedString.runs.map(resolveRunYOffset);
        const res = Object.assign({}, attributedString, {
            runs
        });
        return res;
    };
};
/**
 * Sort runs in ascending order
 *
 * @param runs
 * @returns Sorted runs
 */ const sort = (runs)=>{
    return runs.sort((a, b)=>a.start - b.start || a.end - b.end);
};
/**
 * Is run empty (start === end)
 *
 * @param run - Run
 * @returns Is run empty
 */ const isEmpty = (run)=>{
    return run.start === run.end;
};
/**
 * Sort points in ascending order
 * @param a - First point
 * @param b - Second point
 * @returns Sort order
 */ const sortPoints = (a, b)=>{
    return a[1] - b[1] || a[3] - b[3];
};
/**
 * @param runs
 * @returns Points
 */ const generatePoints = (runs)=>{
    const result = runs.reduce((acc, run, i)=>{
        return acc.concat([
            [
                'start',
                run.start,
                run.attributes,
                i
            ],
            [
                'end',
                run.end,
                run.attributes,
                i
            ]
        ]);
    }, []);
    return result.sort(sortPoints);
};
/**
 * @param runs
 * @returns Merged runs
 */ const mergeRuns = (runs)=>{
    return runs.reduce((acc, run)=>{
        const attributes = Object.assign({}, acc.attributes, run.attributes);
        return Object.assign({}, run, {
            attributes
        });
    }, {});
};
/**
 * @param runs
 * @returns Grouped runs
 */ const groupEmptyRuns = (runs)=>{
    const groups = runs.reduce((acc, run)=>{
        if (!acc[run.start]) acc[run.start] = [];
        acc[run.start].push(run);
        return acc;
    }, []);
    return Object.values(groups);
};
/**
 * @param runs
 * @returns Flattened runs
 */ const flattenEmptyRuns = (runs)=>{
    return groupEmptyRuns(runs).map(mergeRuns);
};
/**
 * @param runs
 * @returns Flattened runs
 */ const flattenRegularRuns = (runs)=>{
    const res = [];
    const points = generatePoints(runs);
    let start = -1;
    let attrs = {};
    const stack = [];
    for(let i = 0; i < points.length; i += 1){
        const [type, offset, attributes] = points[i];
        if (start !== -1 && start < offset) {
            res.push({
                start,
                end: offset,
                attributes: attrs,
                glyphIndices: [],
                glyphs: [],
                positions: []
            });
        }
        if (type === 'start') {
            stack.push(attributes);
            attrs = Object.assign({}, attrs, attributes);
        } else {
            attrs = {};
            for(let j = 0; j < stack.length; j += 1){
                if (stack[j] === attributes) {
                    stack.splice(j--, 1);
                } else {
                    attrs = Object.assign({}, attrs, stack[j]);
                }
            }
        }
        start = offset;
    }
    return res;
};
/**
 * Flatten many runs
 *
 * @param runs
 * @returns Flattened runs
 */ const flatten = (runs = [])=>{
    const emptyRuns = flattenEmptyRuns(runs.filter((run)=>isEmpty(run)));
    const regularRuns = flattenRegularRuns(runs.filter((run)=>!isEmpty(run)));
    return sort(emptyRuns.concat(regularRuns));
};
/**
 * Returns empty attributed string
 *
 * @returns Empty attributed string
 */ const empty = ()=>({
        string: '',
        runs: []
    });
/**
 *
 * @param attributedString
 * @returns Attributed string without font
 */ const omitFont = (attributedString)=>{
    const runs = attributedString.runs.map((run)=>omit('font', run));
    return Object.assign({}, attributedString, {
        runs
    });
};
/**
 * Performs font substitution and script itemization on attributed string
 *
 * @param engines - engines
 */ const preprocessRuns = (engines)=>{
    /**
     * @param attributedString - Attributed string
     * @returns Processed attributed string
     */ return (attributedString)=>{
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(attributedString)) return empty();
        const { string } = attributedString;
        const { fontSubstitution, scriptItemizer, bidi } = engines;
        const { runs: omittedFontRuns } = omitFont(attributedString);
        const { runs: itemizationRuns } = scriptItemizer()(attributedString);
        const { runs: substitutedRuns } = fontSubstitution()(attributedString);
        const { runs: bidiRuns } = bidi()(attributedString);
        const runs = bidiRuns.concat(substitutedRuns).concat(itemizationRuns).concat(omittedFontRuns);
        return {
            string,
            runs: flatten(runs)
        };
    };
};
/**
 * Breaks attributed string into paragraphs
 */ const splitParagraphs = ()=>{
    /**
     * @param attributedString - Attributed string
     * @returns Paragraphs attributed strings
     */ return (attributedString)=>{
        const paragraphs = [];
        let start = 0;
        let breakPoint = attributedString.string.indexOf('\n') + 1;
        while(breakPoint > 0){
            paragraphs.push(slice(start, breakPoint, attributedString));
            start = breakPoint;
            breakPoint = attributedString.string.indexOf('\n', breakPoint) + 1;
        }
        if (start === 0) {
            paragraphs.push(attributedString);
        } else if (start < attributedString.string.length) {
            paragraphs.push(slice(start, length$1(attributedString), attributedString));
        }
        return paragraphs;
    };
};
/**
 * Return positions advance width
 *
 * @param positions - Positions
 * @returns {number} advance width
 */ const advanceWidth$2 = (positions)=>{
    return positions.reduce((acc, pos)=>acc + (pos.xAdvance || 0), 0);
};
/**
 * Return run advance width
 *
 * @param run - Run
 * @returns Advance width
 */ const advanceWidth$1 = (run)=>{
    return advanceWidth$2(run.positions || []);
};
/**
 * Returns attributed string advancewidth
 *
 * @param attributedString - Attributed string
 * @returns Advance width
 */ const advanceWidth = (attributedString)=>{
    const reducer = (acc, run)=>acc + advanceWidth$1(run);
    return attributedString.runs.reduce(reducer, 0);
};
const WHITE_SPACES_CODE = 32;
/**
 * Check if glyph is white space
 *
 * @param glyph - Glyph
 * @returns Whether glyph is white space
 * */ const isWhiteSpace = (glyph)=>{
    const codePoints = glyph?.codePoints || [];
    return codePoints.includes(WHITE_SPACES_CODE);
};
/**
 * Get white space leading positions
 *
 * @param run - Run
 * @returns White space leading positions
 */ const leadingPositions = (run)=>{
    const glyphs = run.glyphs || [];
    const positions = run.positions || [];
    const leadingWhitespaces = glyphs.findIndex((g)=>!isWhiteSpace(g));
    return positions.slice(0, leadingWhitespaces);
};
/**
 * Get run leading white space offset
 *
 * @param run - Run
 * @returns Leading white space offset
 */ const leadingOffset$1 = (run)=>{
    const positions = leadingPositions(run);
    return positions.reduce((acc, pos)=>acc + (pos.xAdvance || 0), 0);
};
/**
 * Get attributed string leading white space offset
 *
 * @param attributedString - Attributed string
 * @returns Leading white space offset
 */ const leadingOffset = (attributedString)=>{
    const runs = attributedString.runs || [];
    return leadingOffset$1(runs[0]);
};
/**
 * Get white space trailing positions
 *
 * @param run run
 * @returns White space trailing positions
 */ const trailingPositions = (run)=>{
    const glyphs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverse"])(run.glyphs || []);
    const positions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reverse"])(run.positions || []);
    const leadingWhitespaces = glyphs.findIndex((g)=>!isWhiteSpace(g));
    return positions.slice(0, leadingWhitespaces);
};
/**
 * Get run trailing white space offset
 *
 * @param run - Run
 * @returns Trailing white space offset
 */ const trailingOffset$1 = (run)=>{
    const positions = trailingPositions(run);
    return positions.reduce((acc, pos)=>acc + (pos.xAdvance || 0), 0);
};
/**
 * Get attributed string trailing white space offset
 *
 * @param attributedString - Attributed string
 * @returns Trailing white space offset
 */ const trailingOffset = (attributedString)=>{
    const runs = attributedString.runs || [];
    return trailingOffset$1((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(runs));
};
/**
 * Drop last char of run
 *
 * @param run - Run
 * @returns Run without last char
 */ const dropLast$1 = (run)=>{
    return slice$1(0, run.end - run.start - 1, run);
};
/**
 * Drop last glyph
 *
 * @param attributedString - Attributed string
 * @returns Attributed string with new glyph
 */ const dropLast = (attributedString)=>{
    const string = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dropLast"])(attributedString.string);
    const runs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["adjust"])(-1, dropLast$1, attributedString.runs);
    return Object.assign({}, attributedString, {
        string,
        runs
    });
};
const ALIGNMENT_FACTORS = {
    center: 0.5,
    right: 1
};
/**
 * Remove new line char at the end of line if present
 *
 * @param line
 * @returns Line
 */ const removeNewLine = (line)=>{
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(line.string) === '\n' ? dropLast(line) : line;
};
const getOverflowLeft = (line)=>{
    return leadingOffset(line) + (line.overflowLeft || 0);
};
const getOverflowRight = (line)=>{
    return trailingOffset(line) + (line.overflowRight || 0);
};
/**
 * Ignore whitespace at the start and end of a line for alignment
 *
 * @param line
 * @returns Line
 */ const adjustOverflow = (line)=>{
    const overflowLeft = getOverflowLeft(line);
    const overflowRight = getOverflowRight(line);
    const x = line.box.x - overflowLeft;
    const width = line.box.width + overflowLeft + overflowRight;
    const box = Object.assign({}, line.box, {
        x,
        width
    });
    return Object.assign({}, line, {
        box,
        overflowLeft,
        overflowRight
    });
};
/**
 * Performs line justification by calling appropiate engine
 *
 * @param engines - Engines
 * @param options - Layout options
 * @param align - Text align
 */ const justifyLine$1 = (engines, options, align)=>{
    /**
     * @param line - Line
     * @returns Line
     */ return (line)=>{
        const lineWidth = advanceWidth(line);
        const alignFactor = ALIGNMENT_FACTORS[align] || 0;
        const remainingWidth = Math.max(0, line.box.width - lineWidth);
        const shouldJustify = align === 'justify' || lineWidth > line.box.width;
        const x = line.box.x + remainingWidth * alignFactor;
        const box = Object.assign({}, line.box, {
            x
        });
        const newLine = Object.assign({}, line, {
            box
        });
        return shouldJustify ? engines.justification(options)(newLine) : newLine;
    };
};
const finalizeLine = (line)=>{
    let lineAscent = 0;
    let lineDescent = 0;
    let lineHeight = 0;
    let lineXAdvance = 0;
    const runs = line.runs.map((run)=>{
        const height = height$1(run);
        const ascent = ascent$1(run);
        const descent$1 = descent(run);
        const xAdvance = advanceWidth$1(run);
        lineHeight = Math.max(lineHeight, height);
        lineAscent = Math.max(lineAscent, ascent);
        lineDescent = Math.max(lineDescent, descent$1);
        lineXAdvance += xAdvance;
        return Object.assign({}, run, {
            height,
            ascent,
            descent: descent$1,
            xAdvance
        });
    });
    return Object.assign({}, line, {
        runs,
        height: lineHeight,
        ascent: lineAscent,
        descent: lineDescent,
        xAdvance: lineXAdvance
    });
};
/**
 * Finalize line by performing line justification
 * and text decoration (using appropiate engines)
 *
 * @param engines - Engines
 * @param options - Layout options
 */ const finalizeBlock = (engines, options)=>{
    /**
     * @param line - Line
     * @param i - Line index
     * @param lines - Total lines
     * @returns Line
     */ return (line, index, lines)=>{
        const isLastFragment = index === lines.length - 1;
        const style = line.runs?.[0]?.attributes || {};
        const align = isLastFragment ? style.alignLastLine : style.align;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compose"])(finalizeLine, engines.textDecoration(), justifyLine$1(engines, options, align), adjustOverflow, removeNewLine)(line);
    };
};
/**
 * Finalize line block by performing line justification
 * and text decoration (using appropiate engines)
 *
 * @param engines - Engines
 * @param options - Layout options
 */ const finalizeFragments = (engines, options)=>{
    /**
     * @param paragraphs - Paragraphs
     * @returns Paragraphs
     */ return (paragraphs)=>{
        const blockFinalizer = finalizeBlock(engines, options);
        return paragraphs.map((paragraph)=>paragraph.map(blockFinalizer));
    };
};
const ATTACHMENT_CODE = 0xfffc; // 65532
const isReplaceGlyph = (glyph)=>glyph.codePoints.includes(ATTACHMENT_CODE);
/**
 * Resolve attachments of run
 *
 * @param run
 * @returns Run
 */ const resolveRunAttachments = (run)=>{
    if (!run.positions) return run;
    const glyphs = run.glyphs || [];
    const attachment = run.attributes?.attachment;
    if (!attachment) return run;
    const positions = run.positions.map((position, i)=>{
        const glyph = glyphs[i];
        if (attachment.width && isReplaceGlyph(glyph)) {
            return Object.assign({}, position, {
                xAdvance: attachment.width
            });
        }
        return Object.assign({}, position);
    });
    return Object.assign({}, run, {
        positions
    });
};
/**
 * Resolve attachments for multiple paragraphs
 */ const resolveAttachments = ()=>{
    /**
     * @param attributedString - Attributed string
     * @returns Attributed string
     */ return (attributedString)=>{
        const runs = attributedString.runs.map(resolveRunAttachments);
        const res = Object.assign({}, attributedString, {
            runs
        });
        return res;
    };
};
/**
 * @param attributes - Attributes
 * @returns Attributes with defaults
 */ const applyAttributes = (a)=>{
    return {
        align: a.align || (a.direction === 'rtl' ? 'right' : 'left'),
        alignLastLine: a.alignLastLine || (a.align === 'justify' ? 'left' : a.align || 'left'),
        attachment: a.attachment || null,
        backgroundColor: a.backgroundColor || null,
        bullet: a.bullet || null,
        characterSpacing: a.characterSpacing || 0,
        color: a.color || 'black',
        direction: a.direction || 'ltr',
        features: a.features || [],
        fill: a.fill !== false,
        font: a.font || [],
        fontSize: a.fontSize || 12,
        hangingPunctuation: a.hangingPunctuation || false,
        hyphenationFactor: a.hyphenationFactor || 0,
        indent: a.indent || 0,
        justificationFactor: a.justificationFactor || 1,
        lineHeight: a.lineHeight || null,
        lineSpacing: a.lineSpacing || 0,
        link: a.link || null,
        marginLeft: a.marginLeft || a.margin || 0,
        marginRight: a.marginRight || a.margin || 0,
        opacity: a.opacity,
        paddingTop: a.paddingTop || a.padding || 0,
        paragraphSpacing: a.paragraphSpacing || 0,
        script: a.script || null,
        shrinkFactor: a.shrinkFactor || 0,
        strike: a.strike || false,
        strikeColor: a.strikeColor || a.color || 'black',
        strikeStyle: a.strikeStyle || 'solid',
        stroke: a.stroke || false,
        underline: a.underline || false,
        underlineColor: a.underlineColor || a.color || 'black',
        underlineStyle: a.underlineStyle || 'solid',
        verticalAlign: a.verticalAlign || null,
        wordSpacing: a.wordSpacing || 0,
        yOffset: a.yOffset || 0
    };
};
/**
 * Apply default style to run
 *
 * @param run - Run
 * @returns Run with default styles
 */ const applyRunStyles = (run)=>{
    const attributes = applyAttributes(run.attributes);
    return Object.assign({}, run, {
        attributes
    });
};
/**
 * Apply default attributes for an attributed string
 */ const applyDefaultStyles = ()=>{
    return (attributedString)=>{
        const string = attributedString.string || '';
        const runs = (attributedString.runs || []).map(applyRunStyles);
        return {
            string,
            runs
        };
    };
};
/**
 * Apply scaling and yOffset for verticalAlign 'sub' and 'super'.
 */ const verticalAlignment = ()=>{
    /**
     * @param attributedString - Attributed string
     * @returns Attributed string
     */ return (attributedString)=>{
        attributedString.runs.forEach((run)=>{
            const { attributes } = run;
            const { verticalAlign } = attributes;
            if (verticalAlign === 'sub') {
                attributes.yOffset = -0.2;
            } else if (verticalAlign === 'super') {
                attributes.yOffset = 0.4;
            }
        });
        return attributedString;
    };
};
const bidi$1 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bidi$2d$js$2f$dist$2f$bidi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
/**
 * @param runs
 * @returns Bidi levels
 */ const getBidiLevels = (runs)=>{
    return runs.reduce((acc, run)=>{
        const length = run.end - run.start;
        const levels = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["repeat"])(run.attributes.bidiLevel, length);
        return acc.concat(levels);
    }, []);
};
/**
 * Perform bidi mirroring
 */ const mirrorString = ()=>{
    /**
     * @param attributedString - Attributed string
     * @returns Attributed string
     */ return (attributedString)=>{
        const levels = getBidiLevels(attributedString.runs);
        let updatedString = '';
        attributedString.string.split('').forEach((char, index)=>{
            const isRTL = levels[index] % 2 === 1;
            const mirroredChar = isRTL ? bidi$1.getMirroredCharacter(attributedString.string.charAt(index)) : null;
            updatedString += mirroredChar || char;
        });
        const result = {
            ...attributedString,
            string: updatedString
        };
        return result;
    };
};
/**
 * A LayoutEngine is the main object that performs text layout.
 * It accepts an AttributedString and a Container object
 * to layout text into, and uses several helper objects to perform
 * various layout tasks. These objects can be overridden to customize
 * layout behavior.
 */ const layoutEngine = (engines)=>{
    return (attributedString, container, options = {})=>{
        const processParagraph = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compose"])(resolveYOffset(), resolveAttachments(), verticalAlignment(), wrapWords(engines, options), generateGlyphs(), mirrorString(), preprocessRuns(engines));
        const processParagraphs = (paragraphs)=>paragraphs.map(processParagraph);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["compose"])(finalizeFragments(engines, options), bidiReordering(), typesetter(engines, options, container), processParagraphs, splitParagraphs(), applyDefaultStyles())(attributedString);
    };
};
const bidi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bidi$2d$js$2f$dist$2f$bidi$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
const bidiEngine = ()=>{
    /**
     * @param attributedString - Attributed string
     * @returns Attributed string
     */ return (attributedString)=>{
        const { string } = attributedString;
        const direction = attributedString.runs[0]?.attributes.direction;
        const { levels } = bidi.getEmbeddingLevels(string, direction);
        let lastLevel = null;
        let lastIndex = 0;
        let index = 0;
        const runs = [];
        for(let i = 0; i < levels.length; i += 1){
            const level = levels[i];
            if (level !== lastLevel) {
                if (lastLevel !== null) {
                    runs.push({
                        start: lastIndex,
                        end: index,
                        attributes: {
                            bidiLevel: lastLevel
                        }
                    });
                }
                lastIndex = index;
                lastLevel = level;
            }
            index += 1;
        }
        if (lastIndex < string.length) {
            runs.push({
                start: lastIndex,
                end: string.length,
                attributes: {
                    bidiLevel: lastLevel
                }
            });
        }
        const result = {
            string,
            runs
        };
        return result;
    };
};
const INFINITY = 10000;
const getNextBreakpoint = (subnodes, widths, lineNumber)=>{
    let position = null;
    let minimumBadness = Infinity;
    const sum = {
        width: 0,
        stretch: 0,
        shrink: 0
    };
    const lineLength = widths[Math.min(lineNumber, widths.length - 1)];
    const calculateRatio = (node)=>{
        const stretch = 'stretch' in node ? node.stretch : null;
        if (sum.width < lineLength) {
            if (!stretch) return INFINITY;
            return sum.stretch - stretch > 0 ? (lineLength - sum.width) / sum.stretch : INFINITY;
        }
        const shrink = 'shrink' in node ? node.shrink : null;
        if (sum.width > lineLength) {
            if (!shrink) return INFINITY;
            return sum.shrink - shrink > 0 ? (lineLength - sum.width) / sum.shrink : INFINITY;
        }
        return 0;
    };
    for(let i = 0; i < subnodes.length; i += 1){
        const node = subnodes[i];
        if (node.type === 'box') {
            sum.width += node.width;
        }
        if (node.type === 'glue') {
            sum.width += node.width;
            sum.stretch += node.stretch;
            sum.shrink += node.shrink;
        }
        if (sum.width - sum.shrink > lineLength) {
            if (position === null) {
                let j = i === 0 ? i + 1 : i;
                while(j < subnodes.length && (subnodes[j].type === 'glue' || subnodes[j].type === 'penalty')){
                    j++;
                }
                position = j - 1;
            }
            break;
        }
        if (node.type === 'penalty' || node.type === 'glue') {
            const ratio = calculateRatio(node);
            const penalty = node.type === 'penalty' ? node.penalty : 0;
            const badness = 100 * Math.abs(ratio) ** 3 + penalty;
            if (minimumBadness >= badness) {
                position = i;
                minimumBadness = badness;
            }
        }
    }
    return sum.width - sum.shrink > lineLength ? position : null;
};
const applyBestFit = (nodes, widths)=>{
    let count = 0;
    let lineNumber = 0;
    let subnodes = nodes;
    const breakpoints = [
        0
    ];
    while(subnodes.length > 0){
        const breakpoint = getNextBreakpoint(subnodes, widths, lineNumber);
        if (breakpoint !== null) {
            count += breakpoint;
            breakpoints.push(count);
            subnodes = subnodes.slice(breakpoint + 1, subnodes.length);
            count++;
            lineNumber++;
        } else {
            subnodes = [];
        }
    }
    return breakpoints;
};
/* eslint-disable max-classes-per-file */ class LinkedListNode {
    data;
    prev;
    next;
    constructor(data){
        this.data = data;
        this.prev = null;
        this.next = null;
    }
}
class LinkedList {
    static Node = LinkedListNode;
    head;
    tail;
    listSize;
    listLength;
    constructor(){
        this.head = null;
        this.tail = null;
        this.listSize = 0;
        this.listLength = 0;
    }
    isLinked(node) {
        return !(node && node.prev === null && node.next === null && this.tail !== node && this.head !== node || this.isEmpty());
    }
    size() {
        return this.listSize;
    }
    isEmpty() {
        return this.listSize === 0;
    }
    first() {
        return this.head;
    }
    last() {
        return this.last;
    }
    forEach(callback) {
        let node = this.head;
        while(node !== null){
            callback(node);
            node = node.next;
        }
    }
    at(i) {
        let node = this.head;
        let index = 0;
        if (i >= this.listLength || i < 0) {
            return null;
        }
        while(node !== null){
            if (i === index) {
                return node;
            }
            node = node.next;
            index += 1;
        }
        return null;
    }
    insertAfter(node, newNode) {
        if (!this.isLinked(node)) return this;
        newNode.prev = node;
        newNode.next = node.next;
        if (node.next === null) {
            this.tail = newNode;
        } else {
            node.next.prev = newNode;
        }
        node.next = newNode;
        this.listSize += 1;
        return this;
    }
    insertBefore(node, newNode) {
        if (!this.isLinked(node)) return this;
        newNode.prev = node.prev;
        newNode.next = node;
        if (node.prev === null) {
            this.head = newNode;
        } else {
            node.prev.next = newNode;
        }
        node.prev = newNode;
        this.listSize += 1;
        return this;
    }
    push(node) {
        if (this.head === null) {
            this.unshift(node);
        } else {
            this.insertAfter(this.tail, node);
        }
        return this;
    }
    unshift(node) {
        if (this.head === null) {
            this.head = node;
            this.tail = node;
            node.prev = null;
            node.next = null;
            this.listSize += 1;
        } else {
            this.insertBefore(this.head, node);
        }
        return this;
    }
    remove(node) {
        if (!this.isLinked(node)) return this;
        if (node.prev === null) {
            this.head = node.next;
        } else {
            node.prev.next = node.next;
        }
        if (node.next === null) {
            this.tail = node.prev;
        } else {
            node.next.prev = node.prev;
        }
        this.listSize -= 1;
        return this;
    }
}
/**
 * Licensed under the new BSD License.
 * Copyright 2009-2010, Bram Stein
 * All rights reserved.
 */ function breakpoint(position, demerits, line, fitnessClass, totals, previous) {
    return {
        position,
        demerits,
        line,
        fitnessClass,
        totals: totals || {
            width: 0,
            stretch: 0,
            shrink: 0
        },
        previous
    };
}
function computeCost(nodes, lineLengths, sum, end, active, currentLine) {
    let width = sum.width - active.totals.width;
    let stretch = 0;
    let shrink = 0;
    // If the current line index is within the list of linelengths, use it, otherwise use
    // the last line length of the list.
    const lineLength = currentLine < lineLengths.length ? lineLengths[currentLine - 1] : lineLengths[lineLengths.length - 1];
    if (nodes[end].type === 'penalty') {
        width += nodes[end].width;
    }
    // Calculate the stretch ratio
    if (width < lineLength) {
        stretch = sum.stretch - active.totals.stretch;
        if (stretch > 0) {
            return (lineLength - width) / stretch;
        }
        return linebreak.infinity;
    }
    // Calculate the shrink ratio
    if (width > lineLength) {
        shrink = sum.shrink - active.totals.shrink;
        if (shrink > 0) {
            return (lineLength - width) / shrink;
        }
        return linebreak.infinity;
    }
    // perfect match
    return 0;
}
// Add width, stretch and shrink values from the current
// break point up to the next box or forced penalty.
function computeSum(nodes, sum, breakPointIndex) {
    const result = {
        width: sum.width,
        stretch: sum.stretch,
        shrink: sum.shrink
    };
    for(let i = breakPointIndex; i < nodes.length; i += 1){
        const node = nodes[i];
        if (node.type === 'glue') {
            result.width += node.width;
            result.stretch += node.stretch;
            result.shrink += node.shrink;
        } else if (node.type === 'box' || node.type === 'penalty' && node.penalty === -linebreak.infinity && i > breakPointIndex) {
            break;
        }
    }
    return result;
}
function findBestBreakpoints(activeNodes) {
    const breakpoints = [];
    if (activeNodes.size() === 0) return [];
    let tmp = {
        data: {
            demerits: Infinity
        }
    };
    // Find the best active node (the one with the least total demerits.)
    activeNodes.forEach((node)=>{
        if (node.data.demerits < tmp.data.demerits) {
            tmp = node;
        }
    });
    while(tmp !== null){
        breakpoints.push(tmp.data.position);
        tmp = tmp.data.previous;
    }
    return breakpoints.reverse();
}
/**
 * @param nodes
 * @param availableWidths
 * @param tolerance
 * @preserve Knuth and Plass line breaking algorithm in JavaScript
 */ const linebreak = (nodes, availableWidths, tolerance)=>{
    // Demerits are used as a way to penalize bad line breaks
    //  - line: applied to each line, depending on how much spaces need to stretch or shrink
    //  - flagged: applied when consecutive lines end in hyphenation
    //  - fitness: algorithm groups lines into fitness classes based on how loose or tight the spacing is.
    //             if a paragraph has consecutive lines from different fitness classes,
    //             a fitness demerit is applied to maintain visual consistency.
    const options = {
        demerits: {
            line: 10,
            flagged: 100,
            fitness: 3000
        },
        tolerance: tolerance || 3
    };
    const activeNodes = new LinkedList();
    const sum = {
        width: 0,
        stretch: 0,
        shrink: 0
    };
    const lineLengths = availableWidths;
    // Add an active node for the start of the paragraph.
    activeNodes.push(new LinkedList.Node(breakpoint(0, 0, 0, 0, undefined, null)));
    // The main loop of the algorithm
    function mainLoop(node, index, nodes) {
        let active = activeNodes.first();
        // The inner loop iterates through all the active nodes with line < currentLine and then
        // breaks out to insert the new active node candidates before looking at the next active
        // nodes for the next lines. The result of this is that the active node list is always
        // sorted by line number.
        while(active !== null){
            let currentLine = 0;
            // Candidates fo each fitness class
            const candidates = [
                {
                    active: undefined,
                    demerits: Infinity
                },
                {
                    active: undefined,
                    demerits: Infinity
                },
                {
                    active: undefined,
                    demerits: Infinity
                },
                {
                    active: undefined,
                    demerits: Infinity
                }
            ];
            // Iterate through the linked list of active nodes to find new potential active nodes and deactivate current active nodes.
            while(active !== null){
                currentLine = active.data.line + 1;
                const ratio = computeCost(nodes, lineLengths, sum, index, active.data, currentLine);
                // Deactive nodes when the distance between the current active node and the
                // current node becomes too large (i.e. it exceeds the stretch limit and the stretch
                // ratio becomes negative) or when the current node is a forced break (i.e. the end
                // of the paragraph when we want to remove all active nodes, but possibly have a final
                // candidate active node---if the paragraph can be set using the given tolerance value.)
                if (ratio < -1 || node.type === 'penalty' && node.penalty === -linebreak.infinity) {
                    activeNodes.remove(active);
                }
                // If the ratio is within the valid range of -1 <= ratio <= tolerance calculate the
                // total demerits and record a candidate active node.
                if (ratio >= -1 && ratio <= options.tolerance) {
                    const badness = 100 * Math.pow(Math.abs(ratio), 3);
                    let demerits = 0;
                    // Positive penalty
                    if (node.type === 'penalty' && node.penalty >= 0) {
                        demerits = Math.pow(options.demerits.line + badness, 2) + Math.pow(node.penalty, 2);
                    // Negative penalty but not a forced break
                    } else if (node.type === 'penalty' && node.penalty !== -linebreak.infinity) {
                        demerits = Math.pow(options.demerits.line + badness, 2) - Math.pow(node.penalty, 2);
                    // All other cases
                    } else {
                        demerits = Math.pow(options.demerits.line + badness, 2);
                    }
                    if (node.type === 'penalty' && nodes[active.data.position].type === 'penalty') {
                        demerits += options.demerits.flagged * node.flagged * // @ts-expect-error node is penalty here
                        nodes[active.data.position].flagged;
                    }
                    // Calculate the fitness class for this candidate active node.
                    let currentClass;
                    if (ratio < -0.5) {
                        currentClass = 0;
                    } else if (ratio <= 0.5) {
                        currentClass = 1;
                    } else if (ratio <= 1) {
                        currentClass = 2;
                    } else {
                        currentClass = 3;
                    }
                    // Add a fitness penalty to the demerits if the fitness classes of two adjacent lines differ too much.
                    if (Math.abs(currentClass - active.data.fitnessClass) > 1) {
                        demerits += options.demerits.fitness;
                    }
                    // Add the total demerits of the active node to get the total demerits of this candidate node.
                    demerits += active.data.demerits;
                    // Only store the best candidate for each fitness class
                    if (demerits < candidates[currentClass].demerits) {
                        candidates[currentClass] = {
                            active,
                            demerits
                        };
                    }
                }
                active = active.next;
                // Stop iterating through active nodes to insert new candidate active nodes in the active list
                // before moving on to the active nodes for the next line.
                // TODO: The Knuth and Plass paper suggests a conditional for currentLine < j0. This means paragraphs
                // with identical line lengths will not be sorted by line number. Find out if that is a desirable outcome.
                // For now I left this out, as it only adds minimal overhead to the algorithm and keeping the active node
                // list sorted has a higher priority.
                if (active !== null && active.data.line >= currentLine) {
                    break;
                }
            }
            const tmpSum = computeSum(nodes, sum, index);
            for(let fitnessClass = 0; fitnessClass < candidates.length; fitnessClass += 1){
                const candidate = candidates[fitnessClass];
                if (candidate.demerits === Infinity) continue;
                const newNode = new LinkedList.Node(breakpoint(index, candidate.demerits, candidate.active.data.line + 1, fitnessClass, tmpSum, candidate.active));
                if (active !== null) {
                    activeNodes.insertBefore(active, newNode);
                } else {
                    activeNodes.push(newNode);
                }
            }
        }
    }
    nodes.forEach((node, index, nodes)=>{
        if (node.type === 'box') {
            sum.width += node.width;
            return;
        }
        if (node.type === 'glue') {
            const precedesBox = index > 0 && nodes[index - 1].type === 'box';
            if (precedesBox) mainLoop(node, index, nodes);
            sum.width += node.width;
            sum.stretch += node.stretch;
            sum.shrink += node.shrink;
            return;
        }
        if (node.type === 'penalty' && node.penalty !== linebreak.infinity) {
            mainLoop(node, index, nodes);
        }
    });
    return findBestBreakpoints(activeNodes);
};
linebreak.infinity = 10000;
linebreak.glue = (width, start, end, stretch, shrink)=>({
        type: 'glue',
        start,
        end,
        width,
        stretch,
        shrink
    });
linebreak.box = (width, start, end, hyphenated = false)=>({
        type: 'box',
        width,
        start,
        end,
        hyphenated
    });
linebreak.penalty = (width, penalty, flagged)=>({
        type: 'penalty',
        width,
        penalty,
        flagged
    });
/**
 * Add scalar to run
 *
 * @param index - Scalar
 * @param run - Run
 * @returns Added run
 */ const add = (index, run)=>{
    const start = run.start + index;
    const end = run.end + index;
    return Object.assign({}, run, {
        start,
        end
    });
};
/**
 * Get run length
 *
 * @param run - Run
 * @returns Length
 */ const length = (run)=>{
    return run.end - run.start;
};
/**
 * Concats two runs into one
 *
 * @param runA - First run
 * @param runB - Second run
 * @returns Concatenated run
 */ const concat = (runA, runB)=>{
    const end = runA.end + length(runB);
    const glyphs = (runA.glyphs || []).concat(runB.glyphs || []);
    const positions = (runA.positions || []).concat(runB.positions || []);
    const attributes = Object.assign({}, runA.attributes, runB.attributes);
    const runAIndices = runA.glyphIndices || [];
    const runALastIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(runAIndices) || 0;
    const runBIndices = (runB.glyphIndices || []).map((i)=>i + runALastIndex + 1);
    const glyphIndices = normalize(runAIndices.concat(runBIndices));
    return Object.assign({}, runA, {
        end,
        glyphs,
        positions,
        attributes,
        glyphIndices
    });
};
/**
 * Insert glyph to run in the given index
 *
 * @param index - Index
 * @param glyph - Glyph
 * @param run - Run
 * @returns Run with glyph
 */ const insertGlyph$1 = (index, glyph, run)=>{
    if (!glyph) return run;
    // Split resolves ligature splitting in case new glyph breaks some
    const leadingRun = slice$1(0, index, run);
    const trailingRun = slice$1(index, Infinity, run);
    return concat(append$1(glyph, leadingRun), trailingRun);
};
/**
 * Insert either glyph or code point to run in the given index
 *
 * @param index - Index
 * @param value - Glyph or codePoint
 * @param run - Run
 * @returns Run with glyph
 */ const insert = (index, value, run)=>{
    const font = getFont(run);
    const glyph = isNumber(value) ? fromCodePoint(value, font) : value;
    return insertGlyph$1(index, glyph, run);
};
/**
 * Get run index at char index
 *
 * @param index - Char index
 * @param attributedString - Attributed string
 * @returns Run index
 */ const runIndexAt = (index, attributedString)=>{
    return runIndexAt$1(index, attributedString.runs);
};
/**
 * Insert glyph into attributed string
 *
 * @param index - Index
 * @param glyph - Glyph or code point
 * @param attributedString - Attributed string
 * @returns Attributed string with new glyph
 */ const insertGlyph = (index, glyph, attributedString)=>{
    const runIndex = runIndexAt(index, attributedString);
    // Add glyph to the end if run index invalid
    if (runIndex === -1) return append(glyph, attributedString);
    const codePoints = [
        glyph
    ];
    const string = attributedString.string.slice(0, index) + stringFromCodePoints(codePoints) + attributedString.string.slice(index);
    const runs = attributedString.runs.map((run, i)=>{
        if (i === runIndex) return insert(index - run.start, glyph, run);
        if (i > runIndex) return add(codePoints.length, run);
        return run;
    });
    return Object.assign({}, attributedString, {
        string,
        runs
    });
};
/**
 * Advance width between two string indices
 *
 * @param start - Glyph index
 * @param end - Glyph index
 * @param run - Run
 * @returns Advanced width run
 */ const advanceWidthBetween$1 = (start, end, run)=>{
    const runStart = run.start || 0;
    const glyphStartIndex = Math.max(0, glyphIndexAt(start - runStart, run));
    const glyphEndIndex = Math.max(0, glyphIndexAt(end - runStart, run));
    const positions = (run.positions || []).slice(glyphStartIndex, glyphEndIndex);
    return advanceWidth$2(positions);
};
/**
 * Advance width between start and end
 * Does not consider ligature splitting for the moment.
 * Check performance impact on supporting this
 *
 * @param start - Start offset
 * @param end - End offset
 * @param attributedString
 * @returns Advance width
 */ const advanceWidthBetween = (start, end, attributedString)=>{
    const runs = filter(start, end, attributedString.runs);
    return runs.reduce((acc, run)=>acc + advanceWidthBetween$1(start, end, run), 0);
};
const HYPHEN = 0x002d;
const TOLERANCE_STEPS = 5;
const TOLERANCE_LIMIT = 50;
const opts = {
    width: 3,
    stretch: 6,
    shrink: 9
};
/**
 * Slice attributed string to many lines
 *
 * @param attributedString - Attributed string
 * @param nodes
 * @param breaks
 * @returns Attributed strings
 */ const breakLines = (attributedString, nodes, breaks)=>{
    let start = 0;
    let end = null;
    const lines = breaks.reduce((acc, breakPoint)=>{
        const node = nodes[breakPoint];
        const prevNode = nodes[breakPoint - 1];
        // Last breakpoint corresponds to K&P mandatory final glue
        if (breakPoint === nodes.length - 1) return acc;
        let line;
        if (node.type === 'penalty') {
            // @ts-expect-error penalty node will always preceed box or glue node
            end = prevNode.end;
            line = slice(start, end, attributedString);
            line = insertGlyph(line.string.length, HYPHEN, line);
        } else {
            end = node.end;
            line = slice(start, end, attributedString);
        }
        start = end;
        return [
            ...acc,
            line
        ];
    }, []);
    // Last line
    lines.push(slice(start, attributedString.string.length, attributedString));
    return lines;
};
/**
 * Return Knuth & Plass nodes based on line and previously calculated syllables
 *
 * @param attributedString - Attributed string
 * @param attributes - Attributes
 * @param options - Layout options
 * @returns ?
 */ const getNodes = (attributedString, { align }, options)=>{
    let start = 0;
    const hyphenWidth = 5;
    const { syllables } = attributedString;
    const hyphenPenalty = options.hyphenationPenalty || (align === 'justify' ? 100 : 600);
    const result = syllables.reduce((acc, s, index)=>{
        const width = advanceWidthBetween(start, start + s.length, attributedString);
        if (s.trim() === '') {
            const stretch = width * opts.width / opts.stretch;
            const shrink = width * opts.width / opts.shrink;
            const end = start + s.length;
            // Add glue node. Glue nodes are used to fill the space between words.
            acc.push(linebreak.glue(width, start, end, stretch, shrink));
        } else {
            const hyphenated = syllables[index + 1] !== ' ';
            const end = start + s.length;
            // Add box node. Box nodes are used to represent words.
            acc.push(linebreak.box(width, start, end, hyphenated));
            if (syllables[index + 1] && hyphenated) {
                // Add penalty node. Penalty nodes are used to represent hyphenation points.
                acc.push(linebreak.penalty(hyphenWidth, hyphenPenalty, 1));
            }
        }
        start += s.length;
        return acc;
    }, []);
    // Add mandatory final glue
    result.push(linebreak.glue(0, start, start, linebreak.infinity, 0));
    result.push(linebreak.penalty(0, -linebreak.infinity, 1));
    return result;
};
/**
 * @param attributedString - Attributed string
 * @returns Attributes
 */ const getAttributes = (attributedString)=>{
    return attributedString.runs?.[0]?.attributes || {};
};
/**
 * Performs Knuth & Plass line breaking algorithm
 * Fallbacks to best fit algorithm if latter not successful
 *
 * @param options - Layout options
 */ const linebreaker = (options)=>{
    /**
     * @param attributedString - Attributed string
     * @param availableWidths - Available widths
     * @returns Attributed string
     */ return (attributedString, availableWidths)=>{
        let tolerance = options.tolerance || 4;
        const attributes = getAttributes(attributedString);
        const nodes = getNodes(attributedString, attributes, options);
        let breaks = linebreak(nodes, availableWidths, tolerance);
        // Try again with a higher tolerance if the line breaking failed.
        while(breaks.length === 0 && tolerance < TOLERANCE_LIMIT){
            tolerance += TOLERANCE_STEPS;
            breaks = linebreak(nodes, availableWidths, tolerance);
        }
        if (breaks.length === 0 || breaks.length === 1 && breaks[0] === 0) {
            breaks = applyBestFit(nodes, availableWidths);
        }
        return breakLines(attributedString, nodes, breaks.slice(1));
    };
};
var Direction;
(function(Direction) {
    Direction[Direction["GROW"] = 0] = "GROW";
    Direction[Direction["SHRINK"] = 1] = "SHRINK";
})(Direction || (Direction = {}));
const WHITESPACE_PRIORITY = 1;
const LETTER_PRIORITY = 2;
const EXPAND_WHITESPACE_FACTOR = {
    before: 0.5,
    after: 0.5,
    priority: WHITESPACE_PRIORITY,
    unconstrained: false
};
const EXPAND_CHAR_FACTOR = {
    before: 0.14453125,
    after: 0.14453125,
    priority: LETTER_PRIORITY,
    unconstrained: false
};
const SHRINK_WHITESPACE_FACTOR = {
    before: -0.04296875,
    after: -0.04296875,
    priority: WHITESPACE_PRIORITY,
    unconstrained: false
};
const SHRINK_CHAR_FACTOR = {
    before: -0.04296875,
    after: -0.04296875,
    priority: LETTER_PRIORITY,
    unconstrained: false
};
const getCharFactor = (direction, options)=>{
    const expandCharFactor = options.expandCharFactor || {};
    const shrinkCharFactor = options.shrinkCharFactor || {};
    return direction === Direction.GROW ? Object.assign({}, EXPAND_CHAR_FACTOR, expandCharFactor) : Object.assign({}, SHRINK_CHAR_FACTOR, shrinkCharFactor);
};
const getWhitespaceFactor = (direction, options)=>{
    const expandWhitespaceFactor = options.expandWhitespaceFactor || {};
    const shrinkWhitespaceFactor = options.shrinkWhitespaceFactor || {};
    return direction === Direction.GROW ? Object.assign({}, EXPAND_WHITESPACE_FACTOR, expandWhitespaceFactor) : Object.assign({}, SHRINK_WHITESPACE_FACTOR, shrinkWhitespaceFactor);
};
const factor = (direction, options)=>(glyphs)=>{
        const charFactor = getCharFactor(direction, options);
        const whitespaceFactor = getWhitespaceFactor(direction, options);
        const factors = [];
        for(let index = 0; index < glyphs.length; index += 1){
            let f;
            const glyph = glyphs[index];
            if (isWhiteSpace(glyph)) {
                f = Object.assign({}, whitespaceFactor);
                if (index === glyphs.length - 1) {
                    f.before = 0;
                    if (index > 0) {
                        factors[index - 1].after = 0;
                    }
                }
            } else if (glyph.isMark && index > 0) {
                f = Object.assign({}, factors[index - 1]);
                f.before = 0;
                factors[index - 1].after = 0;
            } else {
                f = Object.assign({}, charFactor);
            }
            factors.push(f);
        }
        return factors;
    };
const getFactors = (gap, line, options)=>{
    const direction = gap > 0 ? Direction.GROW : Direction.SHRINK;
    const getFactor = factor(direction, options);
    const factors = line.runs.reduce((acc, run)=>{
        return acc.concat(getFactor(run.glyphs));
    }, []);
    factors[0].before = 0;
    factors[factors.length - 1].after = 0;
    return factors;
};
const KASHIDA_PRIORITY = 0;
const NULL_PRIORITY = 3;
const getDistances = (gap, factors)=>{
    let total = 0;
    const priorities = [];
    const unconstrained = [];
    for(let priority = KASHIDA_PRIORITY; priority <= NULL_PRIORITY; priority += 1){
        priorities[priority] = unconstrained[priority] = 0;
    }
    // sum the factors at each priority
    for(let j = 0; j < factors.length; j += 1){
        const f = factors[j];
        const sum = f.before + f.after;
        total += sum;
        priorities[f.priority] += sum;
        if (f.unconstrained) {
            unconstrained[f.priority] += sum;
        }
    }
    // choose the priorities that need to be applied
    let highestPriority = -1;
    let highestPrioritySum = 0;
    let remainingGap = gap;
    let priority;
    for(priority = KASHIDA_PRIORITY; priority <= NULL_PRIORITY; priority += 1){
        const prioritySum = priorities[priority];
        if (prioritySum !== 0) {
            if (highestPriority === -1) {
                highestPriority = priority;
                highestPrioritySum = prioritySum;
            }
            // if this priority covers the remaining gap, we're done
            if (Math.abs(remainingGap) <= Math.abs(prioritySum)) {
                priorities[priority] = remainingGap / prioritySum;
                unconstrained[priority] = 0;
                remainingGap = 0;
                break;
            }
            // mark that we need to use 100% of the adjustment from
            // this priority, and subtract the space that it consumes
            priorities[priority] = 1;
            remainingGap -= prioritySum;
            // if this priority has unconstrained glyphs, let them consume the remaining space
            if (unconstrained[priority] !== 0) {
                unconstrained[priority] = remainingGap / unconstrained[priority];
                remainingGap = 0;
                break;
            }
        }
    }
    // zero out remaining priorities (if any)
    for(let p = priority + 1; p <= NULL_PRIORITY; p += 1){
        priorities[p] = 0;
        unconstrained[p] = 0;
    }
    // if there is still space left over, assign it to the highest priority that we saw.
    // this violates their factors, but it only happens in extreme cases
    if (remainingGap > 0 && highestPriority > -1) {
        priorities[highestPriority] = (highestPrioritySum + (gap - total)) / highestPrioritySum;
    }
    // create and return an array of distances to add to each glyph's advance
    const distances = [];
    for(let index = 0; index < factors.length; index += 1){
        // the distance to add to this glyph is the sum of the space to add
        // after this glyph, and the space to add before the next glyph
        const f = factors[index];
        const next = factors[index + 1];
        let dist = f.after * priorities[f.priority];
        if (next) {
            dist += next.before * priorities[next.priority];
        }
        // if this glyph is unconstrained, add the unconstrained distance as well
        if (f.unconstrained) {
            dist += f.after * unconstrained[f.priority];
            if (next) {
                dist += next.before * unconstrained[next.priority];
            }
        }
        distances.push(dist);
    }
    return distances;
};
/**
 * Adjust run positions by given distances
 *
 * @param distances
 * @param line
 * @returns Line
 */ const justifyLine = (distances, line)=>{
    let index = 0;
    for (const run of line.runs){
        for (const position of run.positions){
            position.xAdvance += distances[index++];
        }
    }
    return line;
};
/**
 * A JustificationEngine is used by a Typesetter to perform line fragment
 * justification. This implementation is based on a description of Apple's
 * justification algorithm from a PDF in the Apple Font Tools package.
 *
 * @param options - Layout options
 */ const justification = (options)=>{
    /**
     * @param line
     * @returns Line
     */ return (line)=>{
        const gap = line.box.width - advanceWidth(line);
        if (gap === 0) return line; // Exact fit
        const factors = getFactors(gap, line, options);
        const distances = getDistances(gap, factors);
        return justifyLine(distances, line);
    };
};
/**
 * Returns attributed string ascent
 *
 * @param attributedString - Attributed string
 * @returns Ascent
 */ const ascent = (attributedString)=>{
    const reducer = (acc, run)=>Math.max(acc, ascent$1(run));
    return attributedString.runs.reduce(reducer, 0);
};
// The base font size used for calculating underline thickness.
const BASE_FONT_SIZE = 12;
/**
 * A TextDecorationEngine is used by a Typesetter to generate
 * DecorationLines for a line fragment, including underlines
 * and strikes.
 */ const textDecoration = ()=>(line)=>{
        let x = line.overflowLeft || 0;
        const overflowRight = line.overflowRight || 0;
        const maxX = advanceWidth(line) - overflowRight;
        line.decorationLines = [];
        for(let i = 0; i < line.runs.length; i += 1){
            const run = line.runs[i];
            const width = Math.min(maxX - x, advanceWidth$1(run));
            const thickness = Math.max(0.5, Math.floor(run.attributes.fontSize / BASE_FONT_SIZE));
            if (run.attributes.underline) {
                const rect = {
                    x,
                    y: ascent(line) + thickness * 2,
                    width,
                    height: thickness
                };
                const decorationLine = {
                    rect,
                    opacity: run.attributes.opacity,
                    color: run.attributes.underlineColor || 'black',
                    style: run.attributes.underlineStyle || 'solid'
                };
                line.decorationLines.push(decorationLine);
            }
            if (run.attributes.strike) {
                const y = ascent(line) - ascent$1(run) / 3;
                const rect = {
                    x,
                    y,
                    width,
                    height: thickness
                };
                const decorationLine = {
                    rect,
                    opacity: run.attributes.opacity,
                    color: run.attributes.strikeColor || 'black',
                    style: run.attributes.strikeStyle || 'solid'
                };
                line.decorationLines.push(decorationLine);
            }
            x += width;
        }
        return line;
    };
const ignoredScripts = [
    'Common',
    'Inherited',
    'Unknown'
];
/**
 * Resolves unicode script in runs, grouping equal runs together
 */ const scriptItemizer = ()=>{
    /**
     * @param attributedString - Attributed string
     * @returns Attributed string
     */ return (attributedString)=>{
        const { string } = attributedString;
        let lastScript = 'Unknown';
        let lastIndex = 0;
        let index = 0;
        const runs = [];
        if (!string) return empty();
        for(let i = 0; i < string.length; i += 1){
            const char = string[i];
            const codePoint = char.codePointAt(0);
            const script = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$unicode$2d$properties$2f$dist$2f$module$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].getScript(codePoint);
            if (script !== lastScript && !ignoredScripts.includes(script)) {
                if (lastScript !== 'Unknown') {
                    runs.push({
                        start: lastIndex,
                        end: index,
                        attributes: {
                            script: lastScript
                        }
                    });
                }
                lastIndex = index;
                lastScript = script;
            }
            index += char.length;
        }
        if (lastIndex < string.length) {
            runs.push({
                start: lastIndex,
                end: string.length,
                attributes: {
                    script: lastScript
                }
            });
        }
        const result = {
            string,
            runs: runs
        };
        return result;
    };
};
const SOFT_HYPHEN = '\u00ad';
const hyphenator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hyphen$2f$hyphen$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$hyphen$2f$patterns$2f$en$2d$us$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]);
/**
 * @param word
 * @returns Word parts
 */ const splitHyphen = (word)=>{
    return word.split(SOFT_HYPHEN);
};
const cache = {};
/**
 * @param word
 * @returns Word parts
 */ const getParts = (word)=>{
    const base = word.includes(SOFT_HYPHEN) ? word : hyphenator(word);
    return splitHyphen(base);
};
const wordHyphenation = ()=>{
    /**
     * @param word - Word
     * @returns Word parts
     */ return (word)=>{
        const cacheKey = `_${word}`;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isNil"])(word)) return [];
        if (cache[cacheKey]) return cache[cacheKey];
        cache[cacheKey] = getParts(word);
        return cache[cacheKey];
    };
};
const IGNORED_CODE_POINTS = [
    173
];
const getFontSize = (run)=>run.attributes.fontSize || 12;
const pickFontFromFontStack = (codePoint, fontStack, lastFont)=>{
    const fontStackWithFallback = [
        ...fontStack,
        lastFont
    ];
    for(let i = 0; i < fontStackWithFallback.length; i += 1){
        const font = fontStackWithFallback[i];
        if (!IGNORED_CODE_POINTS.includes(codePoint) && font && font.hasGlyphForCodePoint && font.hasGlyphForCodePoint(codePoint)) {
            return font;
        }
    }
    return fontStack.at(-1);
};
const fontSubstitution = ()=>({ string, runs })=>{
        let lastFont = null;
        let lastFontSize = null;
        let lastIndex = 0;
        let index = 0;
        const res = [];
        for(let i = 0; i < runs.length; i += 1){
            const run = runs[i];
            if (string.length === 0) {
                res.push({
                    start: 0,
                    end: 0,
                    attributes: {
                        font: run.attributes.font
                    }
                });
                break;
            }
            const chars = string.slice(run.start, run.end);
            for(let j = 0; j < chars.length; j += 1){
                const char = chars[j];
                const codePoint = char.codePointAt(0);
                // If the default font does not have a glyph and the fallback font does, we use it
                const font = pickFontFromFontStack(codePoint, run.attributes.font, lastFont);
                const fontSize = getFontSize(run);
                // If anything that would impact res has changed, update it
                if (font !== lastFont || fontSize !== lastFontSize || font.unitsPerEm !== lastFont.unitsPerEm) {
                    if (lastFont) {
                        res.push({
                            start: lastIndex,
                            end: index,
                            attributes: {
                                font: [
                                    lastFont
                                ],
                                scale: lastFontSize / lastFont.unitsPerEm
                            }
                        });
                    }
                    lastFont = font;
                    lastFontSize = fontSize;
                    lastIndex = index;
                }
                index += char.length;
            }
        }
        if (lastIndex < string.length) {
            const fontSize = getFontSize((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["last"])(runs));
            res.push({
                start: lastIndex,
                end: string.length,
                attributes: {
                    font: [
                        lastFont
                    ],
                    scale: fontSize / lastFont.unitsPerEm
                }
            });
        }
        return {
            string,
            runs: res
        };
    };
;
}),
"[project]/node_modules/emoji-regex/index.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
const __TURBOPACK__default__export__ = ()=>{
    // https://mths.be/emoji
    return /[#*0-9]\uFE0F?\u20E3|[\xA9\xAE\u203C\u2049\u2122\u2139\u2194-\u2199\u21A9\u21AA\u231A\u231B\u2328\u23CF\u23ED-\u23EF\u23F1\u23F2\u23F8-\u23FA\u24C2\u25AA\u25AB\u25B6\u25C0\u25FB\u25FC\u25FE\u2600-\u2604\u260E\u2611\u2614\u2615\u2618\u2620\u2622\u2623\u2626\u262A\u262E\u262F\u2638-\u263A\u2640\u2642\u2648-\u2653\u265F\u2660\u2663\u2665\u2666\u2668\u267B\u267E\u267F\u2692\u2694-\u2697\u2699\u269B\u269C\u26A0\u26A7\u26AA\u26B0\u26B1\u26BD\u26BE\u26C4\u26C8\u26CF\u26D1\u26E9\u26F0-\u26F5\u26F7\u26F8\u26FA\u2702\u2708\u2709\u270F\u2712\u2714\u2716\u271D\u2721\u2733\u2734\u2744\u2747\u2757\u2763\u27A1\u2934\u2935\u2B05-\u2B07\u2B1B\u2B1C\u2B55\u3030\u303D\u3297\u3299]\uFE0F?|[\u261D\u270C\u270D](?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?|[\u270A\u270B](?:\uD83C[\uDFFB-\uDFFF])?|[\u23E9-\u23EC\u23F0\u23F3\u25FD\u2693\u26A1\u26AB\u26C5\u26CE\u26D4\u26EA\u26FD\u2705\u2728\u274C\u274E\u2753-\u2755\u2795-\u2797\u27B0\u27BF\u2B50]|\u26D3\uFE0F?(?:\u200D\uD83D\uDCA5)?|\u26F9(?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?(?:\u200D[\u2640\u2642]\uFE0F?)?|\u2764\uFE0F?(?:\u200D(?:\uD83D\uDD25|\uD83E\uDE79))?|\uD83C(?:[\uDC04\uDD70\uDD71\uDD7E\uDD7F\uDE02\uDE37\uDF21\uDF24-\uDF2C\uDF36\uDF7D\uDF96\uDF97\uDF99-\uDF9B\uDF9E\uDF9F\uDFCD\uDFCE\uDFD4-\uDFDF\uDFF5\uDFF7]\uFE0F?|[\uDF85\uDFC2\uDFC7](?:\uD83C[\uDFFB-\uDFFF])?|[\uDFC4\uDFCA](?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDFCB\uDFCC](?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDCCF\uDD8E\uDD91-\uDD9A\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF43\uDF45-\uDF4A\uDF4C-\uDF7C\uDF7E-\uDF84\uDF86-\uDF93\uDFA0-\uDFC1\uDFC5\uDFC6\uDFC8\uDFC9\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF8-\uDFFF]|\uDDE6\uD83C[\uDDE8-\uDDEC\uDDEE\uDDF1\uDDF2\uDDF4\uDDF6-\uDDFA\uDDFC\uDDFD\uDDFF]|\uDDE7\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEF\uDDF1-\uDDF4\uDDF6-\uDDF9\uDDFB\uDDFC\uDDFE\uDDFF]|\uDDE8\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDEE\uDDF0-\uDDF7\uDDFA-\uDDFF]|\uDDE9\uD83C[\uDDEA\uDDEC\uDDEF\uDDF0\uDDF2\uDDF4\uDDFF]|\uDDEA\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDED\uDDF7-\uDDFA]|\uDDEB\uD83C[\uDDEE-\uDDF0\uDDF2\uDDF4\uDDF7]|\uDDEC\uD83C[\uDDE6\uDDE7\uDDE9-\uDDEE\uDDF1-\uDDF3\uDDF5-\uDDFA\uDDFC\uDDFE]|\uDDED\uD83C[\uDDF0\uDDF2\uDDF3\uDDF7\uDDF9\uDDFA]|\uDDEE\uD83C[\uDDE8-\uDDEA\uDDF1-\uDDF4\uDDF6-\uDDF9]|\uDDEF\uD83C[\uDDEA\uDDF2\uDDF4\uDDF5]|\uDDF0\uD83C[\uDDEA\uDDEC-\uDDEE\uDDF2\uDDF3\uDDF5\uDDF7\uDDFC\uDDFE\uDDFF]|\uDDF1\uD83C[\uDDE6-\uDDE8\uDDEE\uDDF0\uDDF7-\uDDFB\uDDFE]|\uDDF2\uD83C[\uDDE6\uDDE8-\uDDED\uDDF0-\uDDFF]|\uDDF3\uD83C[\uDDE6\uDDE8\uDDEA-\uDDEC\uDDEE\uDDF1\uDDF4\uDDF5\uDDF7\uDDFA\uDDFF]|\uDDF4\uD83C\uDDF2|\uDDF5\uD83C[\uDDE6\uDDEA-\uDDED\uDDF0-\uDDF3\uDDF7-\uDDF9\uDDFC\uDDFE]|\uDDF6\uD83C\uDDE6|\uDDF7\uD83C[\uDDEA\uDDF4\uDDF8\uDDFA\uDDFC]|\uDDF8\uD83C[\uDDE6-\uDDEA\uDDEC-\uDDF4\uDDF7-\uDDF9\uDDFB\uDDFD-\uDDFF]|\uDDF9\uD83C[\uDDE6\uDDE8\uDDE9\uDDEB-\uDDED\uDDEF-\uDDF4\uDDF7\uDDF9\uDDFB\uDDFC\uDDFF]|\uDDFA\uD83C[\uDDE6\uDDEC\uDDF2\uDDF3\uDDF8\uDDFE\uDDFF]|\uDDFB\uD83C[\uDDE6\uDDE8\uDDEA\uDDEC\uDDEE\uDDF3\uDDFA]|\uDDFC\uD83C[\uDDEB\uDDF8]|\uDDFD\uD83C\uDDF0|\uDDFE\uD83C[\uDDEA\uDDF9]|\uDDFF\uD83C[\uDDE6\uDDF2\uDDFC]|\uDF44(?:\u200D\uD83D\uDFEB)?|\uDF4B(?:\u200D\uD83D\uDFE9)?|\uDFC3(?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D(?:[\u2640\u2642]\uFE0F?(?:\u200D\u27A1\uFE0F?)?|\u27A1\uFE0F?))?|\uDFF3\uFE0F?(?:\u200D(?:\u26A7\uFE0F?|\uD83C\uDF08))?|\uDFF4(?:\u200D\u2620\uFE0F?|\uDB40\uDC67\uDB40\uDC62\uDB40(?:\uDC65\uDB40\uDC6E\uDB40\uDC67|\uDC73\uDB40\uDC63\uDB40\uDC74|\uDC77\uDB40\uDC6C\uDB40\uDC73)\uDB40\uDC7F)?)|\uD83D(?:[\uDC3F\uDCFD\uDD49\uDD4A\uDD6F\uDD70\uDD73\uDD76-\uDD79\uDD87\uDD8A-\uDD8D\uDDA5\uDDA8\uDDB1\uDDB2\uDDBC\uDDC2-\uDDC4\uDDD1-\uDDD3\uDDDC-\uDDDE\uDDE1\uDDE3\uDDE8\uDDEF\uDDF3\uDDFA\uDECB\uDECD-\uDECF\uDEE0-\uDEE5\uDEE9\uDEF0\uDEF3]\uFE0F?|[\uDC42\uDC43\uDC46-\uDC50\uDC66\uDC67\uDC6B-\uDC6D\uDC72\uDC74-\uDC76\uDC78\uDC7C\uDC83\uDC85\uDC8F\uDC91\uDCAA\uDD7A\uDD95\uDD96\uDE4C\uDE4F\uDEC0\uDECC](?:\uD83C[\uDFFB-\uDFFF])?|[\uDC6E\uDC70\uDC71\uDC73\uDC77\uDC81\uDC82\uDC86\uDC87\uDE45-\uDE47\uDE4B\uDE4D\uDE4E\uDEA3\uDEB4\uDEB5](?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDD74\uDD90](?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?|[\uDC00-\uDC07\uDC09-\uDC14\uDC16-\uDC25\uDC27-\uDC3A\uDC3C-\uDC3E\uDC40\uDC44\uDC45\uDC51-\uDC65\uDC6A\uDC79-\uDC7B\uDC7D-\uDC80\uDC84\uDC88-\uDC8E\uDC90\uDC92-\uDCA9\uDCAB-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDDA4\uDDFB-\uDE2D\uDE2F-\uDE34\uDE37-\uDE41\uDE43\uDE44\uDE48-\uDE4A\uDE80-\uDEA2\uDEA4-\uDEB3\uDEB7-\uDEBF\uDEC1-\uDEC5\uDED0-\uDED2\uDED5-\uDED7\uDEDC-\uDEDF\uDEEB\uDEEC\uDEF4-\uDEFC\uDFE0-\uDFEB\uDFF0]|\uDC08(?:\u200D\u2B1B)?|\uDC15(?:\u200D\uD83E\uDDBA)?|\uDC26(?:\u200D(?:\u2B1B|\uD83D\uDD25))?|\uDC3B(?:\u200D\u2744\uFE0F?)?|\uDC41\uFE0F?(?:\u200D\uD83D\uDDE8\uFE0F?)?|\uDC68(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDC68\uDC69]\u200D\uD83D(?:\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?)|[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?)|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]))|\uD83C(?:\uDFFB(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFC-\uDFFF])))?|\uDFFC(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFB\uDFFD-\uDFFF])))?|\uDFFD(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])))?|\uDFFE(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFB-\uDFFD\uDFFF])))?|\uDFFF(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?\uDC68\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D\uDC68\uD83C[\uDFFB-\uDFFE])))?))?|\uDC69(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:\uDC8B\u200D\uD83D)?[\uDC68\uDC69]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D(?:[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?|\uDC69\u200D\uD83D(?:\uDC66(?:\u200D\uD83D\uDC66)?|\uDC67(?:\u200D\uD83D[\uDC66\uDC67])?))|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]))|\uD83C(?:\uDFFB(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFC-\uDFFF])))?|\uDFFC(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB\uDFFD-\uDFFF])))?|\uDFFD(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])))?|\uDFFE(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB-\uDFFD\uDFFF])))?|\uDFFF(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D\uD83D(?:[\uDC68\uDC69]|\uDC8B\u200D\uD83D[\uDC68\uDC69])\uD83C[\uDFFB-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83D[\uDC68\uDC69]\uD83C[\uDFFB-\uDFFE])))?))?|\uDC6F(?:\u200D[\u2640\u2642]\uFE0F?)?|\uDD75(?:\uD83C[\uDFFB-\uDFFF]|\uFE0F)?(?:\u200D[\u2640\u2642]\uFE0F?)?|\uDE2E(?:\u200D\uD83D\uDCA8)?|\uDE35(?:\u200D\uD83D\uDCAB)?|\uDE36(?:\u200D\uD83C\uDF2B\uFE0F?)?|\uDE42(?:\u200D[\u2194\u2195]\uFE0F?)?|\uDEB6(?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D(?:[\u2640\u2642]\uFE0F?(?:\u200D\u27A1\uFE0F?)?|\u27A1\uFE0F?))?)|\uD83E(?:[\uDD0C\uDD0F\uDD18-\uDD1F\uDD30-\uDD34\uDD36\uDD77\uDDB5\uDDB6\uDDBB\uDDD2\uDDD3\uDDD5\uDEC3-\uDEC5\uDEF0\uDEF2-\uDEF8](?:\uD83C[\uDFFB-\uDFFF])?|[\uDD26\uDD35\uDD37-\uDD39\uDD3D\uDD3E\uDDB8\uDDB9\uDDCD\uDDCF\uDDD4\uDDD6-\uDDDD](?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDDDE\uDDDF](?:\u200D[\u2640\u2642]\uFE0F?)?|[\uDD0D\uDD0E\uDD10-\uDD17\uDD20-\uDD25\uDD27-\uDD2F\uDD3A\uDD3F-\uDD45\uDD47-\uDD76\uDD78-\uDDB4\uDDB7\uDDBA\uDDBC-\uDDCC\uDDD0\uDDE0-\uDDFF\uDE70-\uDE7C\uDE80-\uDE89\uDE8F-\uDEC2\uDEC6\uDECE-\uDEDC\uDEDF-\uDEE9]|\uDD3C(?:\u200D[\u2640\u2642]\uFE0F?|\uD83C[\uDFFB-\uDFFF])?|\uDDCE(?:\uD83C[\uDFFB-\uDFFF])?(?:\u200D(?:[\u2640\u2642]\uFE0F?(?:\u200D\u27A1\uFE0F?)?|\u27A1\uFE0F?))?|\uDDD1(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83E\uDDD1|\uDDD1\u200D\uD83E\uDDD2(?:\u200D\uD83E\uDDD2)?|\uDDD2(?:\u200D\uD83E\uDDD2)?))|\uD83C(?:\uDFFB(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFC-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?|\uDFFC(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB\uDFFD-\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?|\uDFFD(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?|\uDFFE(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB-\uDFFD\uDFFF]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?|\uDFFF(?:\u200D(?:[\u2695\u2696\u2708]\uFE0F?|\u2764\uFE0F?\u200D(?:\uD83D\uDC8B\u200D)?\uD83E\uDDD1\uD83C[\uDFFB-\uDFFE]|\uD83C[\uDF3E\uDF73\uDF7C\uDF84\uDF93\uDFA4\uDFA8\uDFEB\uDFED]|\uD83D[\uDCBB\uDCBC\uDD27\uDD2C\uDE80\uDE92]|\uD83E(?:[\uDDAF\uDDBC\uDDBD](?:\u200D\u27A1\uFE0F?)?|[\uDDB0-\uDDB3]|\uDD1D\u200D\uD83E\uDDD1\uD83C[\uDFFB-\uDFFF])))?))?|\uDEF1(?:\uD83C(?:\uDFFB(?:\u200D\uD83E\uDEF2\uD83C[\uDFFC-\uDFFF])?|\uDFFC(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB\uDFFD-\uDFFF])?|\uDFFD(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB\uDFFC\uDFFE\uDFFF])?|\uDFFE(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB-\uDFFD\uDFFF])?|\uDFFF(?:\u200D\uD83E\uDEF2\uD83C[\uDFFB-\uDFFE])?))?)/g;
};
}),
"[project]/node_modules/@react-pdf/image/lib/index.browser.js [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>resolveImage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$png$2d$js$2f$lib$2f$png$2d$js$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/png-js/lib/png-js.browser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jay-peg/src/index.js [app-client] (ecmascript)");
;
;
var global$1 = ("TURBOPACK compile-time truthy", 1) ? /*TURBOPACK member replacement*/ __turbopack_context__.g : "TURBOPACK unreachable";
var lookup = [];
var revLookup = [];
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array;
var inited = false;
function init() {
    inited = true;
    var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    for(var i = 0, len = code.length; i < len; ++i){
        lookup[i] = code[i];
        revLookup[code.charCodeAt(i)] = i;
    }
    revLookup['-'.charCodeAt(0)] = 62;
    revLookup['_'.charCodeAt(0)] = 63;
}
function toByteArray(b64) {
    if (!inited) {
        init();
    }
    var i, j, l, tmp, placeHolders, arr;
    var len = b64.length;
    if (len % 4 > 0) {
        throw new Error('Invalid string. Length must be a multiple of 4');
    }
    // the number of equal signs (place holders)
    // if there are two placeholders, than the two characters before it
    // represent one byte
    // if there is only one, then the three characters before it represent 2 bytes
    // this is just a cheap hack to not do indexOf twice
    placeHolders = b64[len - 2] === '=' ? 2 : b64[len - 1] === '=' ? 1 : 0;
    // base64 is 4/3 + up to two characters of the original data
    arr = new Arr(len * 3 / 4 - placeHolders);
    // if there are placeholders, only get up to the last complete 4 chars
    l = placeHolders > 0 ? len - 4 : len;
    var L = 0;
    for(i = 0, j = 0; i < l; i += 4, j += 3){
        tmp = revLookup[b64.charCodeAt(i)] << 18 | revLookup[b64.charCodeAt(i + 1)] << 12 | revLookup[b64.charCodeAt(i + 2)] << 6 | revLookup[b64.charCodeAt(i + 3)];
        arr[L++] = tmp >> 16 & 0xFF;
        arr[L++] = tmp >> 8 & 0xFF;
        arr[L++] = tmp & 0xFF;
    }
    if (placeHolders === 2) {
        tmp = revLookup[b64.charCodeAt(i)] << 2 | revLookup[b64.charCodeAt(i + 1)] >> 4;
        arr[L++] = tmp & 0xFF;
    } else if (placeHolders === 1) {
        tmp = revLookup[b64.charCodeAt(i)] << 10 | revLookup[b64.charCodeAt(i + 1)] << 4 | revLookup[b64.charCodeAt(i + 2)] >> 2;
        arr[L++] = tmp >> 8 & 0xFF;
        arr[L++] = tmp & 0xFF;
    }
    return arr;
}
function tripletToBase64(num) {
    return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F];
}
function encodeChunk(uint8, start, end) {
    var tmp;
    var output = [];
    for(var i = start; i < end; i += 3){
        tmp = (uint8[i] << 16) + (uint8[i + 1] << 8) + uint8[i + 2];
        output.push(tripletToBase64(tmp));
    }
    return output.join('');
}
function fromByteArray(uint8) {
    if (!inited) {
        init();
    }
    var tmp;
    var len = uint8.length;
    var extraBytes = len % 3; // if we have 1 byte left, pad 2 bytes
    var output = '';
    var parts = [];
    var maxChunkLength = 16383; // must be multiple of 3
    // go through the array every three bytes, we'll deal with trailing stuff later
    for(var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength){
        parts.push(encodeChunk(uint8, i, i + maxChunkLength > len2 ? len2 : i + maxChunkLength));
    }
    // pad the end with zeros, but make sure to not forget the extra bytes
    if (extraBytes === 1) {
        tmp = uint8[len - 1];
        output += lookup[tmp >> 2];
        output += lookup[tmp << 4 & 0x3F];
        output += '==';
    } else if (extraBytes === 2) {
        tmp = (uint8[len - 2] << 8) + uint8[len - 1];
        output += lookup[tmp >> 10];
        output += lookup[tmp >> 4 & 0x3F];
        output += lookup[tmp << 2 & 0x3F];
        output += '=';
    }
    parts.push(output);
    return parts.join('');
}
function read(buffer, offset, isLE, mLen, nBytes) {
    var e, m;
    var eLen = nBytes * 8 - mLen - 1;
    var eMax = (1 << eLen) - 1;
    var eBias = eMax >> 1;
    var nBits = -7;
    var i = isLE ? nBytes - 1 : 0;
    var d = isLE ? -1 : 1;
    var s = buffer[offset + i];
    i += d;
    e = s & (1 << -nBits) - 1;
    s >>= -nBits;
    nBits += eLen;
    for(; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8){}
    m = e & (1 << -nBits) - 1;
    e >>= -nBits;
    nBits += mLen;
    for(; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8){}
    if (e === 0) {
        e = 1 - eBias;
    } else if (e === eMax) {
        return m ? NaN : (s ? -1 : 1) * Infinity;
    } else {
        m = m + Math.pow(2, mLen);
        e = e - eBias;
    }
    return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
}
function write(buffer, value, offset, isLE, mLen, nBytes) {
    var e, m, c;
    var eLen = nBytes * 8 - mLen - 1;
    var eMax = (1 << eLen) - 1;
    var eBias = eMax >> 1;
    var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
    var i = isLE ? 0 : nBytes - 1;
    var d = isLE ? 1 : -1;
    var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
    value = Math.abs(value);
    if (isNaN(value) || value === Infinity) {
        m = isNaN(value) ? 1 : 0;
        e = eMax;
    } else {
        e = Math.floor(Math.log(value) / Math.LN2);
        if (value * (c = Math.pow(2, -e)) < 1) {
            e--;
            c *= 2;
        }
        if (e + eBias >= 1) {
            value += rt / c;
        } else {
            value += rt * Math.pow(2, 1 - eBias);
        }
        if (value * c >= 2) {
            e++;
            c /= 2;
        }
        if (e + eBias >= eMax) {
            m = 0;
            e = eMax;
        } else if (e + eBias >= 1) {
            m = (value * c - 1) * Math.pow(2, mLen);
            e = e + eBias;
        } else {
            m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
            e = 0;
        }
    }
    for(; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8){}
    e = e << mLen | m;
    eLen += mLen;
    for(; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8){}
    buffer[offset + i - d] |= s * 128;
}
var toString = {}.toString;
var isArray = Array.isArray || function(arr) {
    return toString.call(arr) == '[object Array]';
};
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <feross@feross.org> <http://feross.org>
 * @license  MIT
 */ /* eslint-disable no-proto */ var INSPECT_MAX_BYTES = 50;
/**
 * If `Buffer.TYPED_ARRAY_SUPPORT`:
 *   === true    Use Uint8Array implementation (fastest)
 *   === false   Use Object implementation (most compatible, even IE6)
 *
 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
 * Opera 11.6+, iOS 4.2+.
 *
 * Due to various browser bugs, sometimes the Object implementation will be used even
 * when the browser supports typed arrays.
 *
 * Note:
 *
 *   - Firefox 4-29 lacks support for adding new properties to `Uint8Array` instances,
 *     See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438.
 *
 *   - Chrome 9-10 is missing the `TypedArray.prototype.subarray` function.
 *
 *   - IE10 has a broken `TypedArray.prototype.subarray` function which returns arrays of
 *     incorrect length in some situations.

 * We detect these buggy browsers and set `Buffer.TYPED_ARRAY_SUPPORT` to `false` so they
 * get the Object implementation, which is slower but behaves correctly.
 */ Buffer.TYPED_ARRAY_SUPPORT = global$1.TYPED_ARRAY_SUPPORT !== undefined ? global$1.TYPED_ARRAY_SUPPORT : true;
/*
 * Export kMaxLength after typed array support is determined.
 */ kMaxLength();
function kMaxLength() {
    return Buffer.TYPED_ARRAY_SUPPORT ? 0x7fffffff : 0x3fffffff;
}
function createBuffer(that, length) {
    if (kMaxLength() < length) {
        throw new RangeError('Invalid typed array length');
    }
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        // Return an augmented `Uint8Array` instance, for best performance
        that = new Uint8Array(length);
        that.__proto__ = Buffer.prototype;
    } else {
        // Fallback: Return an object instance of the Buffer class
        if (that === null) {
            that = new Buffer(length);
        }
        that.length = length;
    }
    return that;
}
/**
 * The Buffer constructor returns instances of `Uint8Array` that have their
 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
 * returns a single octet.
 *
 * The `Uint8Array` prototype remains unmodified.
 */ function Buffer(arg, encodingOrOffset, length) {
    if (!Buffer.TYPED_ARRAY_SUPPORT && !(this instanceof Buffer)) {
        return new Buffer(arg, encodingOrOffset, length);
    }
    // Common case.
    if (typeof arg === 'number') {
        if (typeof encodingOrOffset === 'string') {
            throw new Error('If encoding is specified then the first argument must be a string');
        }
        return allocUnsafe(this, arg);
    }
    return from(this, arg, encodingOrOffset, length);
}
Buffer.poolSize = 8192; // not used by this implementation
// TODO: Legacy, not needed anymore. Remove in next major version.
Buffer._augment = function(arr) {
    arr.__proto__ = Buffer.prototype;
    return arr;
};
function from(that, value, encodingOrOffset, length) {
    if (typeof value === 'number') {
        throw new TypeError('"value" argument must not be a number');
    }
    if (typeof ArrayBuffer !== 'undefined' && value instanceof ArrayBuffer) {
        return fromArrayBuffer(that, value, encodingOrOffset, length);
    }
    if (typeof value === 'string') {
        return fromString(that, value, encodingOrOffset);
    }
    return fromObject(that, value);
}
/**
 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
 * if value is a number.
 * Buffer.from(str[, encoding])
 * Buffer.from(array)
 * Buffer.from(buffer)
 * Buffer.from(arrayBuffer[, byteOffset[, length]])
 **/ Buffer.from = function(value, encodingOrOffset, length) {
    return from(null, value, encodingOrOffset, length);
};
if (Buffer.TYPED_ARRAY_SUPPORT) {
    Buffer.prototype.__proto__ = Uint8Array.prototype;
    Buffer.__proto__ = Uint8Array;
    if (typeof Symbol !== 'undefined' && Symbol.species && Buffer[Symbol.species] === Buffer) ;
}
function assertSize(size) {
    if (typeof size !== 'number') {
        throw new TypeError('"size" argument must be a number');
    } else if (size < 0) {
        throw new RangeError('"size" argument must not be negative');
    }
}
function alloc(that, size, fill, encoding) {
    assertSize(size);
    if (size <= 0) {
        return createBuffer(that, size);
    }
    if (fill !== undefined) {
        // Only pay attention to encoding if it's a string. This
        // prevents accidentally sending in a number that would
        // be interpretted as a start offset.
        return typeof encoding === 'string' ? createBuffer(that, size).fill(fill, encoding) : createBuffer(that, size).fill(fill);
    }
    return createBuffer(that, size);
}
/**
 * Creates a new filled Buffer instance.
 * alloc(size[, fill[, encoding]])
 **/ Buffer.alloc = function(size, fill, encoding) {
    return alloc(null, size, fill, encoding);
};
function allocUnsafe(that, size) {
    assertSize(size);
    that = createBuffer(that, size < 0 ? 0 : checked(size) | 0);
    if (!Buffer.TYPED_ARRAY_SUPPORT) {
        for(var i = 0; i < size; ++i){
            that[i] = 0;
        }
    }
    return that;
}
/**
 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
 * */ Buffer.allocUnsafe = function(size) {
    return allocUnsafe(null, size);
};
/**
 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
 */ Buffer.allocUnsafeSlow = function(size) {
    return allocUnsafe(null, size);
};
function fromString(that, string, encoding) {
    if (typeof encoding !== 'string' || encoding === '') {
        encoding = 'utf8';
    }
    if (!Buffer.isEncoding(encoding)) {
        throw new TypeError('"encoding" must be a valid string encoding');
    }
    var length = byteLength(string, encoding) | 0;
    that = createBuffer(that, length);
    var actual = that.write(string, encoding);
    if (actual !== length) {
        // Writing a hex string, for example, that contains invalid characters will
        // cause everything after the first invalid character to be ignored. (e.g.
        // 'abxxcd' will be treated as 'ab')
        that = that.slice(0, actual);
    }
    return that;
}
function fromArrayLike(that, array) {
    var length = array.length < 0 ? 0 : checked(array.length) | 0;
    that = createBuffer(that, length);
    for(var i = 0; i < length; i += 1){
        that[i] = array[i] & 255;
    }
    return that;
}
function fromArrayBuffer(that, array, byteOffset, length) {
    array.byteLength; // this throws if `array` is not a valid ArrayBuffer
    if (byteOffset < 0 || array.byteLength < byteOffset) {
        throw new RangeError('\'offset\' is out of bounds');
    }
    if (array.byteLength < byteOffset + (length || 0)) {
        throw new RangeError('\'length\' is out of bounds');
    }
    if (byteOffset === undefined && length === undefined) {
        array = new Uint8Array(array);
    } else if (length === undefined) {
        array = new Uint8Array(array, byteOffset);
    } else {
        array = new Uint8Array(array, byteOffset, length);
    }
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        // Return an augmented `Uint8Array` instance, for best performance
        that = array;
        that.__proto__ = Buffer.prototype;
    } else {
        // Fallback: Return an object instance of the Buffer class
        that = fromArrayLike(that, array);
    }
    return that;
}
function fromObject(that, obj) {
    if (internalIsBuffer(obj)) {
        var len = checked(obj.length) | 0;
        that = createBuffer(that, len);
        if (that.length === 0) {
            return that;
        }
        obj.copy(that, 0, 0, len);
        return that;
    }
    if (obj) {
        if (typeof ArrayBuffer !== 'undefined' && obj.buffer instanceof ArrayBuffer || 'length' in obj) {
            if (typeof obj.length !== 'number' || isnan(obj.length)) {
                return createBuffer(that, 0);
            }
            return fromArrayLike(that, obj);
        }
        if (obj.type === 'Buffer' && isArray(obj.data)) {
            return fromArrayLike(that, obj.data);
        }
    }
    throw new TypeError('First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.');
}
function checked(length) {
    // Note: cannot use `length < kMaxLength()` here because that fails when
    // length is NaN (which is otherwise coerced to zero.)
    if (length >= kMaxLength()) {
        throw new RangeError('Attempt to allocate Buffer larger than maximum ' + 'size: 0x' + kMaxLength().toString(16) + ' bytes');
    }
    return length | 0;
}
Buffer.isBuffer = isBuffer$1;
function internalIsBuffer(b) {
    return !!(b != null && b._isBuffer);
}
Buffer.compare = function compare(a, b) {
    if (!internalIsBuffer(a) || !internalIsBuffer(b)) {
        throw new TypeError('Arguments must be Buffers');
    }
    if (a === b) return 0;
    var x = a.length;
    var y = b.length;
    for(var i = 0, len = Math.min(x, y); i < len; ++i){
        if (a[i] !== b[i]) {
            x = a[i];
            y = b[i];
            break;
        }
    }
    if (x < y) return -1;
    if (y < x) return 1;
    return 0;
};
Buffer.isEncoding = function isEncoding(encoding) {
    switch(String(encoding).toLowerCase()){
        case 'hex':
        case 'utf8':
        case 'utf-8':
        case 'ascii':
        case 'latin1':
        case 'binary':
        case 'base64':
        case 'ucs2':
        case 'ucs-2':
        case 'utf16le':
        case 'utf-16le':
            return true;
        default:
            return false;
    }
};
Buffer.concat = function concat(list, length) {
    if (!isArray(list)) {
        throw new TypeError('"list" argument must be an Array of Buffers');
    }
    if (list.length === 0) {
        return Buffer.alloc(0);
    }
    var i;
    if (length === undefined) {
        length = 0;
        for(i = 0; i < list.length; ++i){
            length += list[i].length;
        }
    }
    var buffer = Buffer.allocUnsafe(length);
    var pos = 0;
    for(i = 0; i < list.length; ++i){
        var buf = list[i];
        if (!internalIsBuffer(buf)) {
            throw new TypeError('"list" argument must be an Array of Buffers');
        }
        buf.copy(buffer, pos);
        pos += buf.length;
    }
    return buffer;
};
function byteLength(string, encoding) {
    if (internalIsBuffer(string)) {
        return string.length;
    }
    if (typeof ArrayBuffer !== 'undefined' && typeof ArrayBuffer.isView === 'function' && (ArrayBuffer.isView(string) || string instanceof ArrayBuffer)) {
        return string.byteLength;
    }
    if (typeof string !== 'string') {
        string = '' + string;
    }
    var len = string.length;
    if (len === 0) return 0;
    // Use a for loop to avoid recursion
    var loweredCase = false;
    for(;;){
        switch(encoding){
            case 'ascii':
            case 'latin1':
            case 'binary':
                return len;
            case 'utf8':
            case 'utf-8':
            case undefined:
                return utf8ToBytes(string).length;
            case 'ucs2':
            case 'ucs-2':
            case 'utf16le':
            case 'utf-16le':
                return len * 2;
            case 'hex':
                return len >>> 1;
            case 'base64':
                return base64ToBytes(string).length;
            default:
                if (loweredCase) return utf8ToBytes(string).length // assume utf8
                ;
                encoding = ('' + encoding).toLowerCase();
                loweredCase = true;
        }
    }
}
Buffer.byteLength = byteLength;
function slowToString(encoding, start, end) {
    var loweredCase = false;
    // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
    // property of a typed array.
    // This behaves neither like String nor Uint8Array in that we set start/end
    // to their upper/lower bounds if the value passed is out of range.
    // undefined is handled specially as per ECMA-262 6th Edition,
    // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
    if (start === undefined || start < 0) {
        start = 0;
    }
    // Return early if start > this.length. Done here to prevent potential uint32
    // coercion fail below.
    if (start > this.length) {
        return '';
    }
    if (end === undefined || end > this.length) {
        end = this.length;
    }
    if (end <= 0) {
        return '';
    }
    // Force coersion to uint32. This will also coerce falsey/NaN values to 0.
    end >>>= 0;
    start >>>= 0;
    if (end <= start) {
        return '';
    }
    if (!encoding) encoding = 'utf8';
    while(true){
        switch(encoding){
            case 'hex':
                return hexSlice(this, start, end);
            case 'utf8':
            case 'utf-8':
                return utf8Slice(this, start, end);
            case 'ascii':
                return asciiSlice(this, start, end);
            case 'latin1':
            case 'binary':
                return latin1Slice(this, start, end);
            case 'base64':
                return base64Slice(this, start, end);
            case 'ucs2':
            case 'ucs-2':
            case 'utf16le':
            case 'utf-16le':
                return utf16leSlice(this, start, end);
            default:
                if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding);
                encoding = (encoding + '').toLowerCase();
                loweredCase = true;
        }
    }
}
// The property is used by `Buffer.isBuffer` and `is-buffer` (in Safari 5-7) to detect
// Buffer instances.
Buffer.prototype._isBuffer = true;
function swap(b, n, m) {
    var i = b[n];
    b[n] = b[m];
    b[m] = i;
}
Buffer.prototype.swap16 = function swap16() {
    var len = this.length;
    if (len % 2 !== 0) {
        throw new RangeError('Buffer size must be a multiple of 16-bits');
    }
    for(var i = 0; i < len; i += 2){
        swap(this, i, i + 1);
    }
    return this;
};
Buffer.prototype.swap32 = function swap32() {
    var len = this.length;
    if (len % 4 !== 0) {
        throw new RangeError('Buffer size must be a multiple of 32-bits');
    }
    for(var i = 0; i < len; i += 4){
        swap(this, i, i + 3);
        swap(this, i + 1, i + 2);
    }
    return this;
};
Buffer.prototype.swap64 = function swap64() {
    var len = this.length;
    if (len % 8 !== 0) {
        throw new RangeError('Buffer size must be a multiple of 64-bits');
    }
    for(var i = 0; i < len; i += 8){
        swap(this, i, i + 7);
        swap(this, i + 1, i + 6);
        swap(this, i + 2, i + 5);
        swap(this, i + 3, i + 4);
    }
    return this;
};
Buffer.prototype.toString = function toString() {
    var length = this.length | 0;
    if (length === 0) return '';
    if (arguments.length === 0) return utf8Slice(this, 0, length);
    return slowToString.apply(this, arguments);
};
Buffer.prototype.equals = function equals(b) {
    if (!internalIsBuffer(b)) throw new TypeError('Argument must be a Buffer');
    if (this === b) return true;
    return Buffer.compare(this, b) === 0;
};
Buffer.prototype.inspect = function inspect() {
    var str = '';
    var max = INSPECT_MAX_BYTES;
    if (this.length > 0) {
        str = this.toString('hex', 0, max).match(/.{2}/g).join(' ');
        if (this.length > max) str += ' ... ';
    }
    return '<Buffer ' + str + '>';
};
Buffer.prototype.compare = function compare(target, start, end, thisStart, thisEnd) {
    if (!internalIsBuffer(target)) {
        throw new TypeError('Argument must be a Buffer');
    }
    if (start === undefined) {
        start = 0;
    }
    if (end === undefined) {
        end = target ? target.length : 0;
    }
    if (thisStart === undefined) {
        thisStart = 0;
    }
    if (thisEnd === undefined) {
        thisEnd = this.length;
    }
    if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
        throw new RangeError('out of range index');
    }
    if (thisStart >= thisEnd && start >= end) {
        return 0;
    }
    if (thisStart >= thisEnd) {
        return -1;
    }
    if (start >= end) {
        return 1;
    }
    start >>>= 0;
    end >>>= 0;
    thisStart >>>= 0;
    thisEnd >>>= 0;
    if (this === target) return 0;
    var x = thisEnd - thisStart;
    var y = end - start;
    var len = Math.min(x, y);
    var thisCopy = this.slice(thisStart, thisEnd);
    var targetCopy = target.slice(start, end);
    for(var i = 0; i < len; ++i){
        if (thisCopy[i] !== targetCopy[i]) {
            x = thisCopy[i];
            y = targetCopy[i];
            break;
        }
    }
    if (x < y) return -1;
    if (y < x) return 1;
    return 0;
};
// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
//
// Arguments:
// - buffer - a Buffer to search
// - val - a string, Buffer, or number
// - byteOffset - an index into `buffer`; will be clamped to an int32
// - encoding - an optional encoding, relevant is val is a string
// - dir - true for indexOf, false for lastIndexOf
function bidirectionalIndexOf(buffer, val, byteOffset, encoding, dir) {
    // Empty buffer means no match
    if (buffer.length === 0) return -1;
    // Normalize byteOffset
    if (typeof byteOffset === 'string') {
        encoding = byteOffset;
        byteOffset = 0;
    } else if (byteOffset > 0x7fffffff) {
        byteOffset = 0x7fffffff;
    } else if (byteOffset < -2147483648) {
        byteOffset = -2147483648;
    }
    byteOffset = +byteOffset; // Coerce to Number.
    if (isNaN(byteOffset)) {
        // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
        byteOffset = dir ? 0 : buffer.length - 1;
    }
    // Normalize byteOffset: negative offsets start from the end of the buffer
    if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
    if (byteOffset >= buffer.length) {
        if (dir) return -1;
        else byteOffset = buffer.length - 1;
    } else if (byteOffset < 0) {
        if (dir) byteOffset = 0;
        else return -1;
    }
    // Normalize val
    if (typeof val === 'string') {
        val = Buffer.from(val, encoding);
    }
    // Finally, search either indexOf (if dir is true) or lastIndexOf
    if (internalIsBuffer(val)) {
        // Special case: looking for empty string/buffer always fails
        if (val.length === 0) {
            return -1;
        }
        return arrayIndexOf(buffer, val, byteOffset, encoding, dir);
    } else if (typeof val === 'number') {
        val = val & 0xFF; // Search for a byte value [0-255]
        if (Buffer.TYPED_ARRAY_SUPPORT && typeof Uint8Array.prototype.indexOf === 'function') {
            if (dir) {
                return Uint8Array.prototype.indexOf.call(buffer, val, byteOffset);
            } else {
                return Uint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset);
            }
        }
        return arrayIndexOf(buffer, [
            val
        ], byteOffset, encoding, dir);
    }
    throw new TypeError('val must be string, number or Buffer');
}
function arrayIndexOf(arr, val, byteOffset, encoding, dir) {
    var indexSize = 1;
    var arrLength = arr.length;
    var valLength = val.length;
    if (encoding !== undefined) {
        encoding = String(encoding).toLowerCase();
        if (encoding === 'ucs2' || encoding === 'ucs-2' || encoding === 'utf16le' || encoding === 'utf-16le') {
            if (arr.length < 2 || val.length < 2) {
                return -1;
            }
            indexSize = 2;
            arrLength /= 2;
            valLength /= 2;
            byteOffset /= 2;
        }
    }
    function read(buf, i) {
        if (indexSize === 1) {
            return buf[i];
        } else {
            return buf.readUInt16BE(i * indexSize);
        }
    }
    var i;
    if (dir) {
        var foundIndex = -1;
        for(i = byteOffset; i < arrLength; i++){
            if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
                if (foundIndex === -1) foundIndex = i;
                if (i - foundIndex + 1 === valLength) return foundIndex * indexSize;
            } else {
                if (foundIndex !== -1) i -= i - foundIndex;
                foundIndex = -1;
            }
        }
    } else {
        if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
        for(i = byteOffset; i >= 0; i--){
            var found = true;
            for(var j = 0; j < valLength; j++){
                if (read(arr, i + j) !== read(val, j)) {
                    found = false;
                    break;
                }
            }
            if (found) return i;
        }
    }
    return -1;
}
Buffer.prototype.includes = function includes(val, byteOffset, encoding) {
    return this.indexOf(val, byteOffset, encoding) !== -1;
};
Buffer.prototype.indexOf = function indexOf(val, byteOffset, encoding) {
    return bidirectionalIndexOf(this, val, byteOffset, encoding, true);
};
Buffer.prototype.lastIndexOf = function lastIndexOf(val, byteOffset, encoding) {
    return bidirectionalIndexOf(this, val, byteOffset, encoding, false);
};
function hexWrite(buf, string, offset, length) {
    offset = Number(offset) || 0;
    var remaining = buf.length - offset;
    if (!length) {
        length = remaining;
    } else {
        length = Number(length);
        if (length > remaining) {
            length = remaining;
        }
    }
    // must be an even number of digits
    var strLen = string.length;
    if (strLen % 2 !== 0) throw new TypeError('Invalid hex string');
    if (length > strLen / 2) {
        length = strLen / 2;
    }
    for(var i = 0; i < length; ++i){
        var parsed = parseInt(string.substr(i * 2, 2), 16);
        if (isNaN(parsed)) return i;
        buf[offset + i] = parsed;
    }
    return i;
}
function utf8Write(buf, string, offset, length) {
    return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length);
}
function asciiWrite(buf, string, offset, length) {
    return blitBuffer(asciiToBytes(string), buf, offset, length);
}
function latin1Write(buf, string, offset, length) {
    return asciiWrite(buf, string, offset, length);
}
function base64Write(buf, string, offset, length) {
    return blitBuffer(base64ToBytes(string), buf, offset, length);
}
function ucs2Write(buf, string, offset, length) {
    return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length);
}
Buffer.prototype.write = function write(string, offset, length, encoding) {
    // Buffer#write(string)
    if (offset === undefined) {
        encoding = 'utf8';
        length = this.length;
        offset = 0;
    // Buffer#write(string, encoding)
    } else if (length === undefined && typeof offset === 'string') {
        encoding = offset;
        length = this.length;
        offset = 0;
    // Buffer#write(string, offset[, length][, encoding])
    } else if (isFinite(offset)) {
        offset = offset | 0;
        if (isFinite(length)) {
            length = length | 0;
            if (encoding === undefined) encoding = 'utf8';
        } else {
            encoding = length;
            length = undefined;
        }
    // legacy write(string, encoding, offset, length) - remove in v0.13
    } else {
        throw new Error('Buffer.write(string, encoding, offset[, length]) is no longer supported');
    }
    var remaining = this.length - offset;
    if (length === undefined || length > remaining) length = remaining;
    if (string.length > 0 && (length < 0 || offset < 0) || offset > this.length) {
        throw new RangeError('Attempt to write outside buffer bounds');
    }
    if (!encoding) encoding = 'utf8';
    var loweredCase = false;
    for(;;){
        switch(encoding){
            case 'hex':
                return hexWrite(this, string, offset, length);
            case 'utf8':
            case 'utf-8':
                return utf8Write(this, string, offset, length);
            case 'ascii':
                return asciiWrite(this, string, offset, length);
            case 'latin1':
            case 'binary':
                return latin1Write(this, string, offset, length);
            case 'base64':
                // Warning: maxLength not taken into account in base64Write
                return base64Write(this, string, offset, length);
            case 'ucs2':
            case 'ucs-2':
            case 'utf16le':
            case 'utf-16le':
                return ucs2Write(this, string, offset, length);
            default:
                if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding);
                encoding = ('' + encoding).toLowerCase();
                loweredCase = true;
        }
    }
};
Buffer.prototype.toJSON = function toJSON() {
    return {
        type: 'Buffer',
        data: Array.prototype.slice.call(this._arr || this, 0)
    };
};
function base64Slice(buf, start, end) {
    if (start === 0 && end === buf.length) {
        return fromByteArray(buf);
    } else {
        return fromByteArray(buf.slice(start, end));
    }
}
function utf8Slice(buf, start, end) {
    end = Math.min(buf.length, end);
    var res = [];
    var i = start;
    while(i < end){
        var firstByte = buf[i];
        var codePoint = null;
        var bytesPerSequence = firstByte > 0xEF ? 4 : firstByte > 0xDF ? 3 : firstByte > 0xBF ? 2 : 1;
        if (i + bytesPerSequence <= end) {
            var secondByte, thirdByte, fourthByte, tempCodePoint;
            switch(bytesPerSequence){
                case 1:
                    if (firstByte < 0x80) {
                        codePoint = firstByte;
                    }
                    break;
                case 2:
                    secondByte = buf[i + 1];
                    if ((secondByte & 0xC0) === 0x80) {
                        tempCodePoint = (firstByte & 0x1F) << 0x6 | secondByte & 0x3F;
                        if (tempCodePoint > 0x7F) {
                            codePoint = tempCodePoint;
                        }
                    }
                    break;
                case 3:
                    secondByte = buf[i + 1];
                    thirdByte = buf[i + 2];
                    if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
                        tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | thirdByte & 0x3F;
                        if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
                            codePoint = tempCodePoint;
                        }
                    }
                    break;
                case 4:
                    secondByte = buf[i + 1];
                    thirdByte = buf[i + 2];
                    fourthByte = buf[i + 3];
                    if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
                        tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | fourthByte & 0x3F;
                        if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
                            codePoint = tempCodePoint;
                        }
                    }
            }
        }
        if (codePoint === null) {
            // we did not generate a valid codePoint so insert a
            // replacement char (U+FFFD) and advance only 1 byte
            codePoint = 0xFFFD;
            bytesPerSequence = 1;
        } else if (codePoint > 0xFFFF) {
            // encode to utf16 (surrogate pair dance)
            codePoint -= 0x10000;
            res.push(codePoint >>> 10 & 0x3FF | 0xD800);
            codePoint = 0xDC00 | codePoint & 0x3FF;
        }
        res.push(codePoint);
        i += bytesPerSequence;
    }
    return decodeCodePointsArray(res);
}
// Based on http://stackoverflow.com/a/22747272/680742, the browser with
// the lowest limit is Chrome, with 0x10000 args.
// We go 1 magnitude less, for safety
var MAX_ARGUMENTS_LENGTH = 0x1000;
function decodeCodePointsArray(codePoints) {
    var len = codePoints.length;
    if (len <= MAX_ARGUMENTS_LENGTH) {
        return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
        ;
    }
    // Decode in chunks to avoid "call stack size exceeded".
    var res = '';
    var i = 0;
    while(i < len){
        res += String.fromCharCode.apply(String, codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH));
    }
    return res;
}
function asciiSlice(buf, start, end) {
    var ret = '';
    end = Math.min(buf.length, end);
    for(var i = start; i < end; ++i){
        ret += String.fromCharCode(buf[i] & 0x7F);
    }
    return ret;
}
function latin1Slice(buf, start, end) {
    var ret = '';
    end = Math.min(buf.length, end);
    for(var i = start; i < end; ++i){
        ret += String.fromCharCode(buf[i]);
    }
    return ret;
}
function hexSlice(buf, start, end) {
    var len = buf.length;
    if (!start || start < 0) start = 0;
    if (!end || end < 0 || end > len) end = len;
    var out = '';
    for(var i = start; i < end; ++i){
        out += toHex(buf[i]);
    }
    return out;
}
function utf16leSlice(buf, start, end) {
    var bytes = buf.slice(start, end);
    var res = '';
    for(var i = 0; i < bytes.length; i += 2){
        res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256);
    }
    return res;
}
Buffer.prototype.slice = function slice(start, end) {
    var len = this.length;
    start = ~~start;
    end = end === undefined ? len : ~~end;
    if (start < 0) {
        start += len;
        if (start < 0) start = 0;
    } else if (start > len) {
        start = len;
    }
    if (end < 0) {
        end += len;
        if (end < 0) end = 0;
    } else if (end > len) {
        end = len;
    }
    if (end < start) end = start;
    var newBuf;
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        newBuf = this.subarray(start, end);
        newBuf.__proto__ = Buffer.prototype;
    } else {
        var sliceLen = end - start;
        newBuf = new Buffer(sliceLen, undefined);
        for(var i = 0; i < sliceLen; ++i){
            newBuf[i] = this[i + start];
        }
    }
    return newBuf;
};
/*
 * Need to make sure that buffer isn't trying to write out of bounds.
 */ function checkOffset(offset, ext, length) {
    if (offset % 1 !== 0 || offset < 0) throw new RangeError('offset is not uint');
    if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length');
}
Buffer.prototype.readUIntLE = function readUIntLE(offset, byteLength, noAssert) {
    offset = offset | 0;
    byteLength = byteLength | 0;
    if (!noAssert) checkOffset(offset, byteLength, this.length);
    var val = this[offset];
    var mul = 1;
    var i = 0;
    while(++i < byteLength && (mul *= 0x100)){
        val += this[offset + i] * mul;
    }
    return val;
};
Buffer.prototype.readUIntBE = function readUIntBE(offset, byteLength, noAssert) {
    offset = offset | 0;
    byteLength = byteLength | 0;
    if (!noAssert) {
        checkOffset(offset, byteLength, this.length);
    }
    var val = this[offset + --byteLength];
    var mul = 1;
    while(byteLength > 0 && (mul *= 0x100)){
        val += this[offset + --byteLength] * mul;
    }
    return val;
};
Buffer.prototype.readUInt8 = function readUInt8(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 1, this.length);
    return this[offset];
};
Buffer.prototype.readUInt16LE = function readUInt16LE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 2, this.length);
    return this[offset] | this[offset + 1] << 8;
};
Buffer.prototype.readUInt16BE = function readUInt16BE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 2, this.length);
    return this[offset] << 8 | this[offset + 1];
};
Buffer.prototype.readUInt32LE = function readUInt32LE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 4, this.length);
    return (this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16) + this[offset + 3] * 0x1000000;
};
Buffer.prototype.readUInt32BE = function readUInt32BE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 4, this.length);
    return this[offset] * 0x1000000 + (this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3]);
};
Buffer.prototype.readIntLE = function readIntLE(offset, byteLength, noAssert) {
    offset = offset | 0;
    byteLength = byteLength | 0;
    if (!noAssert) checkOffset(offset, byteLength, this.length);
    var val = this[offset];
    var mul = 1;
    var i = 0;
    while(++i < byteLength && (mul *= 0x100)){
        val += this[offset + i] * mul;
    }
    mul *= 0x80;
    if (val >= mul) val -= Math.pow(2, 8 * byteLength);
    return val;
};
Buffer.prototype.readIntBE = function readIntBE(offset, byteLength, noAssert) {
    offset = offset | 0;
    byteLength = byteLength | 0;
    if (!noAssert) checkOffset(offset, byteLength, this.length);
    var i = byteLength;
    var mul = 1;
    var val = this[offset + --i];
    while(i > 0 && (mul *= 0x100)){
        val += this[offset + --i] * mul;
    }
    mul *= 0x80;
    if (val >= mul) val -= Math.pow(2, 8 * byteLength);
    return val;
};
Buffer.prototype.readInt8 = function readInt8(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 1, this.length);
    if (!(this[offset] & 0x80)) return this[offset];
    return (0xff - this[offset] + 1) * -1;
};
Buffer.prototype.readInt16LE = function readInt16LE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 2, this.length);
    var val = this[offset] | this[offset + 1] << 8;
    return val & 0x8000 ? val | 0xFFFF0000 : val;
};
Buffer.prototype.readInt16BE = function readInt16BE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 2, this.length);
    var val = this[offset + 1] | this[offset] << 8;
    return val & 0x8000 ? val | 0xFFFF0000 : val;
};
Buffer.prototype.readInt32LE = function readInt32LE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 4, this.length);
    return this[offset] | this[offset + 1] << 8 | this[offset + 2] << 16 | this[offset + 3] << 24;
};
Buffer.prototype.readInt32BE = function readInt32BE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 4, this.length);
    return this[offset] << 24 | this[offset + 1] << 16 | this[offset + 2] << 8 | this[offset + 3];
};
Buffer.prototype.readFloatLE = function readFloatLE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 4, this.length);
    return read(this, offset, true, 23, 4);
};
Buffer.prototype.readFloatBE = function readFloatBE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 4, this.length);
    return read(this, offset, false, 23, 4);
};
Buffer.prototype.readDoubleLE = function readDoubleLE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 8, this.length);
    return read(this, offset, true, 52, 8);
};
Buffer.prototype.readDoubleBE = function readDoubleBE(offset, noAssert) {
    if (!noAssert) checkOffset(offset, 8, this.length);
    return read(this, offset, false, 52, 8);
};
function checkInt(buf, value, offset, ext, max, min) {
    if (!internalIsBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance');
    if (value > max || value < min) throw new RangeError('"value" argument is out of bounds');
    if (offset + ext > buf.length) throw new RangeError('Index out of range');
}
Buffer.prototype.writeUIntLE = function writeUIntLE(value, offset, byteLength, noAssert) {
    value = +value;
    offset = offset | 0;
    byteLength = byteLength | 0;
    if (!noAssert) {
        var maxBytes = Math.pow(2, 8 * byteLength) - 1;
        checkInt(this, value, offset, byteLength, maxBytes, 0);
    }
    var mul = 1;
    var i = 0;
    this[offset] = value & 0xFF;
    while(++i < byteLength && (mul *= 0x100)){
        this[offset + i] = value / mul & 0xFF;
    }
    return offset + byteLength;
};
Buffer.prototype.writeUIntBE = function writeUIntBE(value, offset, byteLength, noAssert) {
    value = +value;
    offset = offset | 0;
    byteLength = byteLength | 0;
    if (!noAssert) {
        var maxBytes = Math.pow(2, 8 * byteLength) - 1;
        checkInt(this, value, offset, byteLength, maxBytes, 0);
    }
    var i = byteLength - 1;
    var mul = 1;
    this[offset + i] = value & 0xFF;
    while(--i >= 0 && (mul *= 0x100)){
        this[offset + i] = value / mul & 0xFF;
    }
    return offset + byteLength;
};
Buffer.prototype.writeUInt8 = function writeUInt8(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0);
    if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value);
    this[offset] = value & 0xff;
    return offset + 1;
};
function objectWriteUInt16(buf, value, offset, littleEndian) {
    if (value < 0) value = 0xffff + value + 1;
    for(var i = 0, j = Math.min(buf.length - offset, 2); i < j; ++i){
        buf[offset + i] = (value & 0xff << 8 * (littleEndian ? i : 1 - i)) >>> (littleEndian ? i : 1 - i) * 8;
    }
}
Buffer.prototype.writeUInt16LE = function writeUInt16LE(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        this[offset] = value & 0xff;
        this[offset + 1] = value >>> 8;
    } else {
        objectWriteUInt16(this, value, offset, true);
    }
    return offset + 2;
};
Buffer.prototype.writeUInt16BE = function writeUInt16BE(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        this[offset] = value >>> 8;
        this[offset + 1] = value & 0xff;
    } else {
        objectWriteUInt16(this, value, offset, false);
    }
    return offset + 2;
};
function objectWriteUInt32(buf, value, offset, littleEndian) {
    if (value < 0) value = 0xffffffff + value + 1;
    for(var i = 0, j = Math.min(buf.length - offset, 4); i < j; ++i){
        buf[offset + i] = value >>> (littleEndian ? i : 3 - i) * 8 & 0xff;
    }
}
Buffer.prototype.writeUInt32LE = function writeUInt32LE(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        this[offset + 3] = value >>> 24;
        this[offset + 2] = value >>> 16;
        this[offset + 1] = value >>> 8;
        this[offset] = value & 0xff;
    } else {
        objectWriteUInt32(this, value, offset, true);
    }
    return offset + 4;
};
Buffer.prototype.writeUInt32BE = function writeUInt32BE(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 0xff;
    } else {
        objectWriteUInt32(this, value, offset, false);
    }
    return offset + 4;
};
Buffer.prototype.writeIntLE = function writeIntLE(value, offset, byteLength, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) {
        var limit = Math.pow(2, 8 * byteLength - 1);
        checkInt(this, value, offset, byteLength, limit - 1, -limit);
    }
    var i = 0;
    var mul = 1;
    var sub = 0;
    this[offset] = value & 0xFF;
    while(++i < byteLength && (mul *= 0x100)){
        if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
            sub = 1;
        }
        this[offset + i] = (value / mul >> 0) - sub & 0xFF;
    }
    return offset + byteLength;
};
Buffer.prototype.writeIntBE = function writeIntBE(value, offset, byteLength, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) {
        var limit = Math.pow(2, 8 * byteLength - 1);
        checkInt(this, value, offset, byteLength, limit - 1, -limit);
    }
    var i = byteLength - 1;
    var mul = 1;
    var sub = 0;
    this[offset + i] = value & 0xFF;
    while(--i >= 0 && (mul *= 0x100)){
        if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
            sub = 1;
        }
        this[offset + i] = (value / mul >> 0) - sub & 0xFF;
    }
    return offset + byteLength;
};
Buffer.prototype.writeInt8 = function writeInt8(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -128);
    if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value);
    if (value < 0) value = 0xff + value + 1;
    this[offset] = value & 0xff;
    return offset + 1;
};
Buffer.prototype.writeInt16LE = function writeInt16LE(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -32768);
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        this[offset] = value & 0xff;
        this[offset + 1] = value >>> 8;
    } else {
        objectWriteUInt16(this, value, offset, true);
    }
    return offset + 2;
};
Buffer.prototype.writeInt16BE = function writeInt16BE(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -32768);
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        this[offset] = value >>> 8;
        this[offset + 1] = value & 0xff;
    } else {
        objectWriteUInt16(this, value, offset, false);
    }
    return offset + 2;
};
Buffer.prototype.writeInt32LE = function writeInt32LE(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -2147483648);
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        this[offset] = value & 0xff;
        this[offset + 1] = value >>> 8;
        this[offset + 2] = value >>> 16;
        this[offset + 3] = value >>> 24;
    } else {
        objectWriteUInt32(this, value, offset, true);
    }
    return offset + 4;
};
Buffer.prototype.writeInt32BE = function writeInt32BE(value, offset, noAssert) {
    value = +value;
    offset = offset | 0;
    if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -2147483648);
    if (value < 0) value = 0xffffffff + value + 1;
    if (Buffer.TYPED_ARRAY_SUPPORT) {
        this[offset] = value >>> 24;
        this[offset + 1] = value >>> 16;
        this[offset + 2] = value >>> 8;
        this[offset + 3] = value & 0xff;
    } else {
        objectWriteUInt32(this, value, offset, false);
    }
    return offset + 4;
};
function checkIEEE754(buf, value, offset, ext, max, min) {
    if (offset + ext > buf.length) throw new RangeError('Index out of range');
    if (offset < 0) throw new RangeError('Index out of range');
}
function writeFloat(buf, value, offset, littleEndian, noAssert) {
    if (!noAssert) {
        checkIEEE754(buf, value, offset, 4);
    }
    write(buf, value, offset, littleEndian, 23, 4);
    return offset + 4;
}
Buffer.prototype.writeFloatLE = function writeFloatLE(value, offset, noAssert) {
    return writeFloat(this, value, offset, true, noAssert);
};
Buffer.prototype.writeFloatBE = function writeFloatBE(value, offset, noAssert) {
    return writeFloat(this, value, offset, false, noAssert);
};
function writeDouble(buf, value, offset, littleEndian, noAssert) {
    if (!noAssert) {
        checkIEEE754(buf, value, offset, 8);
    }
    write(buf, value, offset, littleEndian, 52, 8);
    return offset + 8;
}
Buffer.prototype.writeDoubleLE = function writeDoubleLE(value, offset, noAssert) {
    return writeDouble(this, value, offset, true, noAssert);
};
Buffer.prototype.writeDoubleBE = function writeDoubleBE(value, offset, noAssert) {
    return writeDouble(this, value, offset, false, noAssert);
};
// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
Buffer.prototype.copy = function copy(target, targetStart, start, end) {
    if (!start) start = 0;
    if (!end && end !== 0) end = this.length;
    if (targetStart >= target.length) targetStart = target.length;
    if (!targetStart) targetStart = 0;
    if (end > 0 && end < start) end = start;
    // Copy 0 bytes; we're done
    if (end === start) return 0;
    if (target.length === 0 || this.length === 0) return 0;
    // Fatal error conditions
    if (targetStart < 0) {
        throw new RangeError('targetStart out of bounds');
    }
    if (start < 0 || start >= this.length) throw new RangeError('sourceStart out of bounds');
    if (end < 0) throw new RangeError('sourceEnd out of bounds');
    // Are we oob?
    if (end > this.length) end = this.length;
    if (target.length - targetStart < end - start) {
        end = target.length - targetStart + start;
    }
    var len = end - start;
    var i;
    if (this === target && start < targetStart && targetStart < end) {
        // descending copy from end
        for(i = len - 1; i >= 0; --i){
            target[i + targetStart] = this[i + start];
        }
    } else if (len < 1000 || !Buffer.TYPED_ARRAY_SUPPORT) {
        // ascending copy from start
        for(i = 0; i < len; ++i){
            target[i + targetStart] = this[i + start];
        }
    } else {
        Uint8Array.prototype.set.call(target, this.subarray(start, start + len), targetStart);
    }
    return len;
};
// Usage:
//    buffer.fill(number[, offset[, end]])
//    buffer.fill(buffer[, offset[, end]])
//    buffer.fill(string[, offset[, end]][, encoding])
Buffer.prototype.fill = function fill(val, start, end, encoding) {
    // Handle string cases:
    if (typeof val === 'string') {
        if (typeof start === 'string') {
            encoding = start;
            start = 0;
            end = this.length;
        } else if (typeof end === 'string') {
            encoding = end;
            end = this.length;
        }
        if (val.length === 1) {
            var code = val.charCodeAt(0);
            if (code < 256) {
                val = code;
            }
        }
        if (encoding !== undefined && typeof encoding !== 'string') {
            throw new TypeError('encoding must be a string');
        }
        if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
            throw new TypeError('Unknown encoding: ' + encoding);
        }
    } else if (typeof val === 'number') {
        val = val & 255;
    }
    // Invalid ranges are not set to a default, so can range check early.
    if (start < 0 || this.length < start || this.length < end) {
        throw new RangeError('Out of range index');
    }
    if (end <= start) {
        return this;
    }
    start = start >>> 0;
    end = end === undefined ? this.length : end >>> 0;
    if (!val) val = 0;
    var i;
    if (typeof val === 'number') {
        for(i = start; i < end; ++i){
            this[i] = val;
        }
    } else {
        var bytes = internalIsBuffer(val) ? val : utf8ToBytes(new Buffer(val, encoding).toString());
        var len = bytes.length;
        for(i = 0; i < end - start; ++i){
            this[i + start] = bytes[i % len];
        }
    }
    return this;
};
// HELPER FUNCTIONS
// ================
var INVALID_BASE64_RE = /[^+\/0-9A-Za-z-_]/g;
function base64clean(str) {
    // Node strips out invalid characters like \n and \t from the string, base64-js does not
    str = stringtrim(str).replace(INVALID_BASE64_RE, '');
    // Node converts strings with length < 2 to ''
    if (str.length < 2) return '';
    // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
    while(str.length % 4 !== 0){
        str = str + '=';
    }
    return str;
}
function stringtrim(str) {
    if (str.trim) return str.trim();
    return str.replace(/^\s+|\s+$/g, '');
}
function toHex(n) {
    if (n < 16) return '0' + n.toString(16);
    return n.toString(16);
}
function utf8ToBytes(string, units) {
    units = units || Infinity;
    var codePoint;
    var length = string.length;
    var leadSurrogate = null;
    var bytes = [];
    for(var i = 0; i < length; ++i){
        codePoint = string.charCodeAt(i);
        // is surrogate component
        if (codePoint > 0xD7FF && codePoint < 0xE000) {
            // last char was a lead
            if (!leadSurrogate) {
                // no lead yet
                if (codePoint > 0xDBFF) {
                    // unexpected trail
                    if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
                    continue;
                } else if (i + 1 === length) {
                    // unpaired lead
                    if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
                    continue;
                }
                // valid lead
                leadSurrogate = codePoint;
                continue;
            }
            // 2 leads in a row
            if (codePoint < 0xDC00) {
                if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
                leadSurrogate = codePoint;
                continue;
            }
            // valid surrogate pair
            codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000;
        } else if (leadSurrogate) {
            // valid bmp char, but last char was a lead
            if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
        }
        leadSurrogate = null;
        // encode utf8
        if (codePoint < 0x80) {
            if ((units -= 1) < 0) break;
            bytes.push(codePoint);
        } else if (codePoint < 0x800) {
            if ((units -= 2) < 0) break;
            bytes.push(codePoint >> 0x6 | 0xC0, codePoint & 0x3F | 0x80);
        } else if (codePoint < 0x10000) {
            if ((units -= 3) < 0) break;
            bytes.push(codePoint >> 0xC | 0xE0, codePoint >> 0x6 & 0x3F | 0x80, codePoint & 0x3F | 0x80);
        } else if (codePoint < 0x110000) {
            if ((units -= 4) < 0) break;
            bytes.push(codePoint >> 0x12 | 0xF0, codePoint >> 0xC & 0x3F | 0x80, codePoint >> 0x6 & 0x3F | 0x80, codePoint & 0x3F | 0x80);
        } else {
            throw new Error('Invalid code point');
        }
    }
    return bytes;
}
function asciiToBytes(str) {
    var byteArray = [];
    for(var i = 0; i < str.length; ++i){
        // Node's code seems to be doing this and not & 0x7F..
        byteArray.push(str.charCodeAt(i) & 0xFF);
    }
    return byteArray;
}
function utf16leToBytes(str, units) {
    var c, hi, lo;
    var byteArray = [];
    for(var i = 0; i < str.length; ++i){
        if ((units -= 2) < 0) break;
        c = str.charCodeAt(i);
        hi = c >> 8;
        lo = c % 256;
        byteArray.push(lo);
        byteArray.push(hi);
    }
    return byteArray;
}
function base64ToBytes(str) {
    return toByteArray(base64clean(str));
}
function blitBuffer(src, dst, offset, length) {
    for(var i = 0; i < length; ++i){
        if (i + offset >= dst.length || i >= src.length) break;
        dst[i + offset] = src[i];
    }
    return i;
}
function isnan(val) {
    return val !== val // eslint-disable-line no-self-compare
    ;
}
// the following is from is-buffer, also by Feross Aboukhadijeh and with same lisence
// The _isBuffer check is for Safari 5-7 support, because it's missing
// Object.prototype.constructor. Remove this eventually
function isBuffer$1(obj) {
    return obj != null && (!!obj._isBuffer || isFastBuffer(obj) || isSlowBuffer(obj));
}
function isFastBuffer(obj) {
    return !!obj.constructor && typeof obj.constructor.isBuffer === 'function' && obj.constructor.isBuffer(obj);
}
// For Node v0.10 support. Remove this eventually.
function isSlowBuffer(obj) {
    return typeof obj.readFloatLE === 'function' && typeof obj.slice === 'function' && isFastBuffer(obj.slice(0, 0));
}
class PNG {
    data;
    width;
    height;
    format;
    constructor(data){
        const png = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$png$2d$js$2f$lib$2f$png$2d$js$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"](data);
        this.data = data;
        this.width = png.width;
        this.height = png.height;
        this.format = 'png';
    }
    static isValid(data) {
        try {
            return !!new PNG(data);
        } catch  {
            return false;
        }
    }
}
class JPEG {
    data;
    width;
    height;
    format;
    constructor(data){
        this.data = data;
        this.format = 'jpeg';
        this.width = 0;
        this.height = 0;
        if (data.readUInt16BE(0) !== 0xffd8) {
            throw new Error('SOI not found in JPEG');
        }
        const markers = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jay$2d$peg$2f$src$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].decode(this.data);
        let orientation;
        for(let i = 0; i < markers.length; i += 1){
            const marker = markers[i];
            if (marker.name === 'EXIF' && marker.entries.orientation) {
                orientation = marker.entries.orientation;
            }
            if (marker.name === 'SOF') {
                this.width ||= marker.width;
                this.height ||= marker.height;
            }
        }
        if (orientation > 4) {
            [this.width, this.height] = [
                this.height,
                this.width
            ];
        }
    }
    static isValid(data) {
        return data && Buffer.isBuffer(data) && data.readUInt16BE(0) === 0xffd8;
    }
}
const createCache = ({ limit = 100 } = {})=>{
    let cache = {};
    let keys = [];
    return {
        get: (key)=>key ? cache[key] : null,
        set: (key, value)=>{
            keys.push(key);
            if (keys.length > limit) {
                delete cache[keys.shift()];
            }
            cache[key] = value;
        },
        reset: ()=>{
            cache = {};
            keys = [];
        },
        length: ()=>keys.length
    };
};
const IMAGE_CACHE = createCache({
    limit: 30
});
const isBuffer = Buffer.isBuffer;
const isBlob = (src)=>{
    return typeof Blob !== 'undefined' && src instanceof Blob;
};
const isDataImageSrc = (src)=>{
    return 'data' in src;
};
const isBase64Src = (imageSrc)=>'uri' in imageSrc && /^data:image\/[a-zA-Z]*;base64,[^"]*/g.test(imageSrc.uri);
const fetchRemoteFile = async (src)=>{
    const { method = 'GET', headers, body, credentials } = src;
    const response = await fetch(src.uri, {
        method,
        headers,
        body,
        credentials
    });
    const buffer = await response.arrayBuffer();
    return Buffer.from(buffer);
};
const isValidFormat = (format)=>{
    const lower = format.toLowerCase();
    return lower === 'jpg' || lower === 'jpeg' || lower === 'png';
};
const guessFormat = (buffer)=>{
    let format;
    if (JPEG.isValid(buffer)) {
        format = 'jpg';
    } else if (PNG.isValid(buffer)) {
        format = 'png';
    }
    return format;
};
function getImage(body, format) {
    switch(format.toLowerCase()){
        case 'jpg':
        case 'jpeg':
            return new JPEG(body);
        case 'png':
            return new PNG(body);
        default:
            return null;
    }
}
const resolveBase64Image = async ({ uri })=>{
    const match = /^data:image\/([a-zA-Z]*);base64,([^"]*)/g.exec(uri);
    if (!match) throw new Error(`Invalid base64 image: ${uri}`);
    const format = match[1];
    const data = match[2];
    if (!isValidFormat(format)) throw new Error(`Base64 image invalid format: ${format}`);
    return getImage(Buffer.from(data, 'base64'), format);
};
const resolveImageFromData = async (src)=>{
    if (src.data && src.format) {
        return getImage(src.data, src.format);
    }
    throw new Error(`Invalid data given for local file: ${JSON.stringify(src)}`);
};
const resolveBufferImage = async (buffer)=>{
    const format = guessFormat(buffer);
    if (format) {
        return getImage(buffer, format);
    }
    return null;
};
const resolveBlobImage = async (blob)=>{
    const { type } = blob;
    if (!type || type === 'application/octet-stream') {
        const arrayBuffer = await blob.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        return resolveBufferImage(buffer);
    }
    if (!type.startsWith('image/')) {
        throw new Error(`Invalid blob type: ${type}`);
    }
    const format = type.replace('image/', '');
    if (!isValidFormat(format)) {
        throw new Error(`Invalid blob type: ${type}`);
    }
    const buffer = await blob.arrayBuffer();
    return getImage(Buffer.from(buffer), format);
};
const getImageFormat = (body)=>{
    const isPng = body[0] === 137 && body[1] === 80 && body[2] === 78 && body[3] === 71 && body[4] === 13 && body[5] === 10 && body[6] === 26 && body[7] === 10;
    const isJpg = body[0] === 255 && body[1] === 216 && body[2] === 255;
    let extension = '';
    if (isPng) {
        extension = 'png';
    } else if (isJpg) {
        extension = 'jpg';
    } else {
        throw new Error('Not valid image extension');
    }
    return extension;
};
const resolveImageFromUrl = async (src)=>{
    const data = await fetchRemoteFile(src);
    const format = getImageFormat(data);
    return getImage(data, format);
};
const getCacheKey = (src)=>{
    if (isBlob(src) || isBuffer(src)) return null;
    if (isDataImageSrc(src)) return src.data.toString();
    return src.uri;
};
const resolveImage = (src, { cache = true } = {})=>{
    let image;
    const cacheKey = getCacheKey(src);
    if (isBlob(src)) {
        image = resolveBlobImage(src);
    } else if (isBuffer(src)) {
        image = resolveBufferImage(src);
    } else if (cache && IMAGE_CACHE.get(cacheKey)) {
        return IMAGE_CACHE.get(cacheKey);
    } else if (isBase64Src(src)) {
        image = resolveBase64Image(src);
    } else if (isDataImageSrc(src)) {
        image = resolveImageFromData(src);
    } else {
        image = resolveImageFromUrl(src);
    }
    if (!image) {
        throw new Error('Cannot resolve image');
    }
    if (cache && cacheKey) {
        IMAGE_CACHE.set(cacheKey, image);
    }
    return image;
};
;
}),
"[project]/node_modules/scheduler/cjs/scheduler.development.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
/**
 * @license React
 * scheduler.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ "use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function performWorkUntilDeadline() {
        if (isMessageLoopRunning) {
            var currentTime = exports.unstable_now();
            startTime = currentTime;
            var hasMoreWork = !0;
            try {
                a: {
                    isHostCallbackScheduled = !1;
                    isHostTimeoutScheduled && (isHostTimeoutScheduled = !1, localClearTimeout(taskTimeoutID), taskTimeoutID = -1);
                    isPerformingWork = !0;
                    var previousPriorityLevel = currentPriorityLevel;
                    try {
                        b: {
                            advanceTimers(currentTime);
                            for(currentTask = peek(taskQueue); null !== currentTask && !(currentTask.expirationTime > currentTime && shouldYieldToHost());){
                                var callback = currentTask.callback;
                                if ("function" === typeof callback) {
                                    currentTask.callback = null;
                                    currentPriorityLevel = currentTask.priorityLevel;
                                    var continuationCallback = callback(currentTask.expirationTime <= currentTime);
                                    currentTime = exports.unstable_now();
                                    if ("function" === typeof continuationCallback) {
                                        currentTask.callback = continuationCallback;
                                        advanceTimers(currentTime);
                                        hasMoreWork = !0;
                                        break b;
                                    }
                                    currentTask === peek(taskQueue) && pop(taskQueue);
                                    advanceTimers(currentTime);
                                } else pop(taskQueue);
                                currentTask = peek(taskQueue);
                            }
                            if (null !== currentTask) hasMoreWork = !0;
                            else {
                                var firstTimer = peek(timerQueue);
                                null !== firstTimer && requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
                                hasMoreWork = !1;
                            }
                        }
                        break a;
                    } finally{
                        currentTask = null, currentPriorityLevel = previousPriorityLevel, isPerformingWork = !1;
                    }
                    hasMoreWork = void 0;
                }
            } finally{
                hasMoreWork ? schedulePerformWorkUntilDeadline() : isMessageLoopRunning = !1;
            }
        }
    }
    function push(heap, node) {
        var index = heap.length;
        heap.push(node);
        a: for(; 0 < index;){
            var parentIndex = index - 1 >>> 1, parent = heap[parentIndex];
            if (0 < compare(parent, node)) heap[parentIndex] = node, heap[index] = parent, index = parentIndex;
            else break a;
        }
    }
    function peek(heap) {
        return 0 === heap.length ? null : heap[0];
    }
    function pop(heap) {
        if (0 === heap.length) return null;
        var first = heap[0], last = heap.pop();
        if (last !== first) {
            heap[0] = last;
            a: for(var index = 0, length = heap.length, halfLength = length >>> 1; index < halfLength;){
                var leftIndex = 2 * (index + 1) - 1, left = heap[leftIndex], rightIndex = leftIndex + 1, right = heap[rightIndex];
                if (0 > compare(left, last)) rightIndex < length && 0 > compare(right, left) ? (heap[index] = right, heap[rightIndex] = last, index = rightIndex) : (heap[index] = left, heap[leftIndex] = last, index = leftIndex);
                else if (rightIndex < length && 0 > compare(right, last)) heap[index] = right, heap[rightIndex] = last, index = rightIndex;
                else break a;
            }
        }
        return first;
    }
    function compare(a, b) {
        var diff = a.sortIndex - b.sortIndex;
        return 0 !== diff ? diff : a.id - b.id;
    }
    function advanceTimers(currentTime) {
        for(var timer = peek(timerQueue); null !== timer;){
            if (null === timer.callback) pop(timerQueue);
            else if (timer.startTime <= currentTime) pop(timerQueue), timer.sortIndex = timer.expirationTime, push(taskQueue, timer);
            else break;
            timer = peek(timerQueue);
        }
    }
    function handleTimeout(currentTime) {
        isHostTimeoutScheduled = !1;
        advanceTimers(currentTime);
        if (!isHostCallbackScheduled) if (null !== peek(taskQueue)) isHostCallbackScheduled = !0, requestHostCallback();
        else {
            var firstTimer = peek(timerQueue);
            null !== firstTimer && requestHostTimeout(handleTimeout, firstTimer.startTime - currentTime);
        }
    }
    function shouldYieldToHost() {
        return exports.unstable_now() - startTime < frameInterval ? !1 : !0;
    }
    function requestHostCallback() {
        isMessageLoopRunning || (isMessageLoopRunning = !0, schedulePerformWorkUntilDeadline());
    }
    function requestHostTimeout(callback, ms) {
        taskTimeoutID = localSetTimeout(function() {
            callback(exports.unstable_now());
        }, ms);
    }
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
    exports.unstable_now = void 0;
    if ("object" === typeof performance && "function" === typeof performance.now) {
        var localPerformance = performance;
        exports.unstable_now = function() {
            return localPerformance.now();
        };
    } else {
        var localDate = Date, initialTime = localDate.now();
        exports.unstable_now = function() {
            return localDate.now() - initialTime;
        };
    }
    var taskQueue = [], timerQueue = [], taskIdCounter = 1, currentTask = null, currentPriorityLevel = 3, isPerformingWork = !1, isHostCallbackScheduled = !1, isHostTimeoutScheduled = !1, localSetTimeout = "function" === typeof setTimeout ? setTimeout : null, localClearTimeout = "function" === typeof clearTimeout ? clearTimeout : null, localSetImmediate = "undefined" !== typeof setImmediate ? setImmediate : null, isMessageLoopRunning = !1, taskTimeoutID = -1, frameInterval = 5, startTime = -1;
    if ("function" === typeof localSetImmediate) var schedulePerformWorkUntilDeadline = function() {
        localSetImmediate(performWorkUntilDeadline);
    };
    else if ("undefined" !== typeof MessageChannel) {
        var channel = new MessageChannel(), port = channel.port2;
        channel.port1.onmessage = performWorkUntilDeadline;
        schedulePerformWorkUntilDeadline = function() {
            port.postMessage(null);
        };
    } else schedulePerformWorkUntilDeadline = function() {
        localSetTimeout(performWorkUntilDeadline, 0);
    };
    exports.unstable_IdlePriority = 5;
    exports.unstable_ImmediatePriority = 1;
    exports.unstable_LowPriority = 4;
    exports.unstable_NormalPriority = 3;
    exports.unstable_Profiling = null;
    exports.unstable_UserBlockingPriority = 2;
    exports.unstable_cancelCallback = function(task) {
        task.callback = null;
    };
    exports.unstable_continueExecution = function() {
        isHostCallbackScheduled || isPerformingWork || (isHostCallbackScheduled = !0, requestHostCallback());
    };
    exports.unstable_forceFrameRate = function(fps) {
        0 > fps || 125 < fps ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : frameInterval = 0 < fps ? Math.floor(1e3 / fps) : 5;
    };
    exports.unstable_getCurrentPriorityLevel = function() {
        return currentPriorityLevel;
    };
    exports.unstable_getFirstCallbackNode = function() {
        return peek(taskQueue);
    };
    exports.unstable_next = function(eventHandler) {
        switch(currentPriorityLevel){
            case 1:
            case 2:
            case 3:
                var priorityLevel = 3;
                break;
            default:
                priorityLevel = currentPriorityLevel;
        }
        var previousPriorityLevel = currentPriorityLevel;
        currentPriorityLevel = priorityLevel;
        try {
            return eventHandler();
        } finally{
            currentPriorityLevel = previousPriorityLevel;
        }
    };
    exports.unstable_pauseExecution = function() {};
    exports.unstable_requestPaint = function() {};
    exports.unstable_runWithPriority = function(priorityLevel, eventHandler) {
        switch(priorityLevel){
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                priorityLevel = 3;
        }
        var previousPriorityLevel = currentPriorityLevel;
        currentPriorityLevel = priorityLevel;
        try {
            return eventHandler();
        } finally{
            currentPriorityLevel = previousPriorityLevel;
        }
    };
    exports.unstable_scheduleCallback = function(priorityLevel, callback, options) {
        var currentTime = exports.unstable_now();
        "object" === typeof options && null !== options ? (options = options.delay, options = "number" === typeof options && 0 < options ? currentTime + options : currentTime) : options = currentTime;
        switch(priorityLevel){
            case 1:
                var timeout = -1;
                break;
            case 2:
                timeout = 250;
                break;
            case 5:
                timeout = 1073741823;
                break;
            case 4:
                timeout = 1e4;
                break;
            default:
                timeout = 5e3;
        }
        timeout = options + timeout;
        priorityLevel = {
            id: taskIdCounter++,
            callback: callback,
            priorityLevel: priorityLevel,
            startTime: options,
            expirationTime: timeout,
            sortIndex: -1
        };
        options > currentTime ? (priorityLevel.sortIndex = options, push(timerQueue, priorityLevel), null === peek(taskQueue) && priorityLevel === peek(timerQueue) && (isHostTimeoutScheduled ? (localClearTimeout(taskTimeoutID), taskTimeoutID = -1) : isHostTimeoutScheduled = !0, requestHostTimeout(handleTimeout, options - currentTime))) : (priorityLevel.sortIndex = timeout, push(taskQueue, priorityLevel), isHostCallbackScheduled || isPerformingWork || (isHostCallbackScheduled = !0, requestHostCallback()));
        return priorityLevel;
    };
    exports.unstable_shouldYield = shouldYieldToHost;
    exports.unstable_wrapCallback = function(callback) {
        var parentPriorityLevel = currentPriorityLevel;
        return function() {
            var previousPriorityLevel = currentPriorityLevel;
            currentPriorityLevel = parentPriorityLevel;
            try {
                return callback.apply(this, arguments);
            } finally{
                currentPriorityLevel = previousPriorityLevel;
            }
        };
    };
    "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
}();
}),
"[project]/node_modules/scheduler/index.js [app-client] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
;
else {
    module.exports = __turbopack_context__.r("[project]/node_modules/scheduler/cjs/scheduler.development.js [app-client] (ecmascript)");
}
}),
"[project]/node_modules/@react-pdf/renderer/lib/react-pdf.browser.js [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BlobProvider",
    ()=>BlobProvider,
    "Font",
    ()=>Font,
    "PDFDownloadLink",
    ()=>PDFDownloadLink,
    "PDFViewer",
    ()=>PDFViewer,
    "StyleSheet",
    ()=>StyleSheet,
    "createRenderer",
    ()=>createRenderer,
    "default",
    ()=>index,
    "pdf",
    ()=>pdf,
    "render",
    ()=>render,
    "renderToBuffer",
    ()=>renderToBuffer,
    "renderToFile",
    ()=>renderToFile,
    "renderToStream",
    ()=>renderToStream,
    "renderToString",
    ()=>renderToString,
    "usePDF",
    ()=>usePDF,
    "version",
    ()=>version
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/primitives/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$queue$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/queue/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$font$2f$lib$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/font/lib/index.browser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$render$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/render/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$pdfkit$2f$lib$2f$pdfkit$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/pdfkit/lib/pdfkit.browser.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$layout$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/layout/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/fns/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$reconciler$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@react-pdf/reconciler/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
const omitNils = (object)=>Object.fromEntries(Object.entries(object).filter((_ref)=>{
        let [, value] = _ref;
        return value !== undefined;
    }));
const createInstance = (type, _ref)=>{
    let { style, children, ...props } = _ref;
    return {
        type,
        box: {},
        style: style || {},
        props: props || {},
        children: []
    };
};
const createTextInstance = (text)=>({
        type: 'TEXT_INSTANCE',
        value: text
    });
const appendChild = (parent, child)=>{
    const isParentText = parent.type === 'TEXT' || parent.type === 'LINK' || parent.type === 'TSPAN' || parent.type === 'NOTE';
    const isChildTextInstance = child.type === 'TEXT_INSTANCE';
    const isOrphanTextInstance = isChildTextInstance && !isParentText;
    // Ignore orphan text instances.
    // Caused by cases such as <>{name && <Text>{name}</Text>}</>
    if (isOrphanTextInstance) {
        console.warn(`Invalid '${child.value}' string child outside <Text> component`);
        return;
    }
    parent.children.push(child);
};
const appendChildToContainer = (parentInstance, child)=>{
    if (parentInstance.type === 'ROOT') {
        parentInstance.document = child;
    } else {
        appendChild(parentInstance, child);
    }
};
const insertBefore = (parentInstance, child, beforeChild)=>{
    var _parentInstance$child;
    const index = (_parentInstance$child = parentInstance.children) === null || _parentInstance$child === void 0 ? void 0 : _parentInstance$child.indexOf(beforeChild);
    if (index === undefined) return;
    if (index !== -1 && child) parentInstance.children.splice(index, 0, child);
};
const removeChild = (parentInstance, child)=>{
    var _parentInstance$child2;
    const index = (_parentInstance$child2 = parentInstance.children) === null || _parentInstance$child2 === void 0 ? void 0 : _parentInstance$child2.indexOf(child);
    if (index === undefined) return;
    if (index !== -1) parentInstance.children.splice(index, 1);
};
const removeChildFromContainer = (parentInstance, child)=>{
    var _parentInstance$child3;
    const index = (_parentInstance$child3 = parentInstance.children) === null || _parentInstance$child3 === void 0 ? void 0 : _parentInstance$child3.indexOf(child);
    if (index === undefined) return;
    if (index !== -1) parentInstance.children.splice(index, 1);
};
const commitTextUpdate = (textInstance, oldText, newText)=>{
    textInstance.value = newText;
};
const commitUpdate = (instance, updatePayload, type, oldProps, newProps)=>{
    const { style, ...props } = newProps;
    instance.props = props;
    instance.style = style;
};
const createRenderer = (_ref2)=>{
    let { onChange = ()=>{} } = _ref2;
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$reconciler$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        appendChild,
        appendChildToContainer,
        commitTextUpdate,
        commitUpdate,
        createInstance,
        createTextInstance,
        insertBefore,
        removeChild,
        removeChildFromContainer,
        resetAfterCommit: onChange
    });
};
var version$1 = "4.3.0";
var packageJson = {
    version: version$1
};
const { version } = packageJson;
const fontStore = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$font$2f$lib$2f$index$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]();
// We must keep a single renderer instance, otherwise React will complain
let renderer;
// The pdf instance acts as an event emitter for DOM usage.
// We only want to trigger an update when PDF content changes
const events = {};
const pdf = (initialValue)=>{
    const onChange = ()=>{
        var _events$change;
        const listeners = ((_events$change = events.change) === null || _events$change === void 0 ? void 0 : _events$change.slice()) || [];
        for(let i = 0; i < listeners.length; i += 1)listeners[i]();
    };
    const container = {
        type: 'ROOT',
        document: null
    };
    renderer = renderer || createRenderer({
        onChange
    });
    const mountNode = renderer.createContainer(container);
    const updateContainer = (doc, callback)=>{
        renderer.updateContainer(doc, mountNode, null, callback);
    };
    if (initialValue) updateContainer(initialValue);
    const render = async function(compress) {
        if (compress === void 0) {
            compress = true;
        }
        const props = container.document.props || {};
        const { pdfVersion, language, pageLayout, pageMode, title, author, subject, keyboards, creator = 'react-pdf', producer = 'react-pdf', creationDate = new Date(), modificationDate } = props;
        const ctx = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$pdfkit$2f$lib$2f$pdfkit$2e$browser$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]({
            compress,
            pdfVersion,
            lang: language,
            displayTitle: true,
            autoFirstPage: false,
            info: omitNils({
                Title: title,
                Author: author,
                Subject: subject,
                Keywords: keyboards,
                Creator: creator,
                Producer: producer,
                CreationDate: creationDate,
                ModificationDate: modificationDate
            })
        });
        if (pageLayout) {
            ctx._root.data.PageLayout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["upperFirst"])(pageLayout);
        }
        if (pageMode) {
            ctx._root.data.PageMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$fns$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["upperFirst"])(pageMode);
        }
        const layout = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$layout$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(container.document, fontStore);
        const fileStream = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$render$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(ctx, layout);
        return {
            layout,
            fileStream
        };
    };
    const callOnRender = function(params) {
        if (params === void 0) {
            params = {};
        }
        if (container.document.props.onRender) {
            container.document.props.onRender(params);
        }
    };
    const toBlob = async ()=>{
        const chunks = [];
        const { layout: _INTERNAL__LAYOUT__DATA_, fileStream: instance } = await render();
        return new Promise((resolve, reject)=>{
            instance.on('data', (chunk)=>{
                chunks.push(chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk));
            });
            instance.on('end', ()=>{
                try {
                    const blob = new Blob(chunks, {
                        type: 'application/pdf'
                    });
                    callOnRender({
                        blob,
                        _INTERNAL__LAYOUT__DATA_
                    });
                    resolve(blob);
                } catch (error) {
                    reject(error);
                }
            });
        });
    };
    // TODO: rename this method to `toStream` in next major release, because it return stream not a buffer
    const toBuffer = async ()=>{
        const { layout: _INTERNAL__LAYOUT__DATA_, fileStream } = await render();
        callOnRender({
            _INTERNAL__LAYOUT__DATA_
        });
        return fileStream;
    };
    /*
   * TODO: remove this method in next major release. it is buggy
   * see
   * - https://github.com/diegomura/react-pdf/issues/2112
   * - https://github.com/diegomura/react-pdf/issues/2095
   */ const toString = async ()=>{
        if ("TURBOPACK compile-time truthy", 1) {
            console.warn('`toString` is deprecated and will be removed in next major release');
        }
        let result = '';
        const { fileStream: instance } = await render(false); // For some reason, when rendering to string if compress=true the document is blank
        return new Promise((resolve, reject)=>{
            try {
                instance.on('data', (buffer)=>{
                    result += buffer;
                });
                instance.on('end', ()=>{
                    callOnRender();
                    resolve(result);
                });
            } catch (error) {
                reject(error);
            }
        });
    };
    const on = (event, listener)=>{
        if (!events[event]) events[event] = [];
        events[event].push(listener);
    };
    const removeListener = (event, listener)=>{
        if (!events[event]) return;
        const idx = events[event].indexOf(listener);
        if (idx > -1) events[event].splice(idx, 1);
    };
    return {
        on,
        container,
        toBlob,
        toBuffer,
        toString,
        removeListener,
        updateContainer
    };
};
const Font = fontStore;
const StyleSheet = {
    create: (s)=>s
};
/**
 * PDF hook
 *
 * @param {Object} [options] hook options
 * @returns {[Object, Function]} pdf state and update function
 */ const usePDF = function(_temp) {
    let { document } = _temp === void 0 ? {} : _temp;
    const pdfInstance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        url: null,
        blob: null,
        error: null,
        loading: !!document
    });
    // Setup rendering queue
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePDF.useEffect": ()=>{
            const renderQueue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$queue$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
                autostart: true,
                concurrency: 1
            });
            const queueDocumentRender = {
                "usePDF.useEffect.queueDocumentRender": ()=>{
                    setState({
                        "usePDF.useEffect.queueDocumentRender": (prev)=>({
                                ...prev,
                                loading: true
                            })
                    }["usePDF.useEffect.queueDocumentRender"]);
                    renderQueue.splice(0, renderQueue.length, {
                        "usePDF.useEffect.queueDocumentRender": ()=>state.error ? Promise.resolve() : pdfInstance.current.toBlob()
                    }["usePDF.useEffect.queueDocumentRender"]);
                }
            }["usePDF.useEffect.queueDocumentRender"];
            const onRenderFailed = {
                "usePDF.useEffect.onRenderFailed": (error)=>{
                    console.error(error);
                    setState({
                        "usePDF.useEffect.onRenderFailed": (prev)=>({
                                ...prev,
                                loading: false,
                                error
                            })
                    }["usePDF.useEffect.onRenderFailed"]);
                }
            }["usePDF.useEffect.onRenderFailed"];
            const onRenderSuccessful = {
                "usePDF.useEffect.onRenderSuccessful": (blob)=>{
                    setState({
                        blob,
                        error: null,
                        loading: false,
                        url: URL.createObjectURL(blob)
                    });
                }
            }["usePDF.useEffect.onRenderSuccessful"];
            pdfInstance.current = pdf();
            pdfInstance.current.on('change', queueDocumentRender);
            if (document) {
                pdfInstance.current.updateContainer(document);
            }
            renderQueue.on('error', onRenderFailed);
            renderQueue.on('success', onRenderSuccessful);
            return ({
                "usePDF.useEffect": ()=>{
                    renderQueue.end();
                    pdfInstance.current.removeListener('change', queueDocumentRender);
                }
            })["usePDF.useEffect"];
        }
    }["usePDF.useEffect"], []);
    // Revoke old unused url instances
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "usePDF.useEffect": ()=>{
            return ({
                "usePDF.useEffect": ()=>{
                    if (state.url) {
                        URL.revokeObjectURL(state.url);
                    }
                }
            })["usePDF.useEffect"];
        }
    }["usePDF.useEffect"], [
        state.url
    ]);
    const update = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "usePDF.useCallback[update]": (newDoc)=>{
            pdfInstance.current.updateContainer(newDoc);
        }
    }["usePDF.useCallback[update]"], []);
    return [
        state,
        update
    ];
};
const PDFViewer = (_ref)=>{
    let { title, style, className, children, innerRef, showToolbar = true, ...props } = _ref;
    const [instance, updateInstance] = usePDF();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFViewer.useEffect": ()=>updateInstance(children)
    }["PDFViewer.useEffect"], [
        children
    ]);
    const src = instance.url ? `${instance.url}#toolbar=${showToolbar ? 1 : 0}` : null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("iframe", {
        src: src,
        title: title,
        ref: innerRef,
        style: style,
        className: className,
        ...props
    });
};
const BlobProvider = (_ref)=>{
    let { document: doc, children } = _ref;
    const [instance, updateInstance] = usePDF();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BlobProvider.useEffect": ()=>updateInstance(doc)
    }["BlobProvider.useEffect"], [
        doc
    ]);
    if (!doc) {
        console.warn('You should pass a valid document to BlobProvider');
        return null;
    }
    return children(instance);
};
const PDFDownloadLink = (_ref)=>{
    let { fileName = 'document.pdf', document: doc, children, onClick, href, ...rest } = _ref;
    const [instance, updateInstance] = usePDF();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PDFDownloadLink.useEffect": ()=>updateInstance(doc)
    }["PDFDownloadLink.useEffect"], [
        doc
    ]);
    if (!doc) {
        console.warn('You should pass a valid document to PDFDownloadLink');
        return null;
    }
    const handleDownloadIE = ()=>{
        if (instance && window.navigator.msSaveBlob) {
            // IE
            window.navigator.msSaveBlob(instance.blob, fileName);
        }
    };
    const handleClick = (event)=>{
        handleDownloadIE();
        if (typeof onClick === 'function') onClick(event, instance);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])("a", {
        href: instance.url,
        download: fileName,
        onClick: handleClick,
        ...rest,
        children: typeof children === 'function' ? children(instance) : children
    });
};
const throwEnvironmentError = (name)=>{
    throw new Error(`${name} is a Node specific API. You're either using this method in a browser, or your bundler is not loading react-pdf from the appropriate web build.`);
};
const renderToStream = ()=>{
    throwEnvironmentError('renderToStream');
};
const renderToBuffer = ()=>{
    throwEnvironmentError('renderToBuffer');
};
const renderToString = ()=>{
    throwEnvironmentError('renderToString');
};
const renderToFile = ()=>{
    throwEnvironmentError('renderToFile');
};
const render = ()=>{
    throwEnvironmentError('render');
};
// TODO: remove this default export in next major release because it breaks tree-shacking
var index = {
    pdf,
    usePDF,
    Font,
    version,
    StyleSheet,
    PDFViewer,
    BlobProvider,
    PDFDownloadLink,
    renderToStream,
    renderToString,
    renderToFile,
    render,
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$react$2d$pdf$2f$primitives$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__
};
;
 //# sourceMappingURL=react-pdf.browser.js.map
}),
]);

//# sourceMappingURL=node_modules_72a242f3._.js.map