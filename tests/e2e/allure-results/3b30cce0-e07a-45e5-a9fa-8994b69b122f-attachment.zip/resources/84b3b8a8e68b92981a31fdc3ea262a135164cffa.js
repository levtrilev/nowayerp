(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/lib/common-modal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Modal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function Modal({ children, open }) {
    _s();
    // if (typeof window === 'undefined') {
    //   // This ensures the component does not render on the server
    //   return null;
    // }
    const modalDomElement = document.getElementById("modal");
    const dialog = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [portal, setPortal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])();
    // useEffect(() => {
    //   const modalDomElement = document.getElementById("modal") as Element;
    //     if (modalDomElement) {
    //       setPortal(
    //           createPortal(
    //             <dialog
    //               ref={dialog}
    //               className="w-[400px] mx-auto my-[10rem] p-4 border border-gray-300 rounded-[10px] z-[100]"
    //             >
    //               {children}
    //             </dialog>,
    //             modalDomElement
    //           )
    //         );
    //     }
    // }, [document]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (dialog.current) {
                if (open) {
                    dialog.current.showModal();
                }
                if (!open) {
                    dialog.current.close();
                }
            }
        }
    }["Modal.useEffect"], [
        dialog.current,
        open
    ]);
    const modalElement = document.getElementById("modal");
    if (modalElement) {
        // return portal;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dialog", {
            ref: dialog,
            // onKeyDown={handleCancel ? handleCancel : null}
            className: "w-[400px] mx-auto my-[10rem] p-4 border border-gray-300 rounded-[10px] z-[100]",
            children: children
        }, void 0, false, {
            fileName: "[project]/app/lib/common-modal.tsx",
            lineNumber: 50,
            columnNumber: 7
        }, this), modalDomElement);
    } else {
        return undefined;
    }
}
_s(Modal, "PNs61JjNtUJ7/PYx8bkdIp94qnU=");
_c = Modal;
var _c;
__turbopack_context__.k.register(_c, "Modal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/common-modal.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/lib/common-modal.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=app_lib_common-modal_tsx_45dabcaf._.js.map