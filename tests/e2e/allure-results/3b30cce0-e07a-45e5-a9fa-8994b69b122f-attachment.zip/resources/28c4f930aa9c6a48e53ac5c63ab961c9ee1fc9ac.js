(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_lib_common-modal_tsx_78f6008d._.js",
  "static/chunks/app_6b203c8c._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_d45abfbb._.js",
  "static/chunks/node_modules_brotli_aa4cc70f._.js",
  "static/chunks/node_modules_fontkit_dist_browser-module_mjs_393a1dbe._.js",
  "static/chunks/node_modules_pako_lib_59d1daeb._.js",
  "static/chunks/node_modules_crypto-js_59fbd1d6._.js",
  "static/chunks/node_modules_@react-pdf_png-js_lib_png-js_browser_6e630089.js",
  "static/chunks/node_modules_@react-pdf_pdfkit_lib_pdfkit_browser_bb07d1a8.js",
  "static/chunks/node_modules_yoga-layout_dist_b5bffb70._.js",
  "static/chunks/node_modules_@react-pdf_layout_lib_index_035642ed.js",
  "static/chunks/node_modules_@react-pdf_reconciler_lib_6fedbd67._.js",
  "static/chunks/node_modules_72a242f3._.js"
],
    source: "dynamic"
});
